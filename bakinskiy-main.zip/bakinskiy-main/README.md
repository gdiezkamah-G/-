# Бакинський Бульвар — Мануфактура

Сайт і платформа власного виробництва ресторану (заморожені напівфабрикати для HoReCa).
Правила проєкту: `CLAUDE.md`. Дизайн-джерело правди: `reference/prototype.html`. Специфікація: `docs/`.

MCP-сервер для керування магазином з Claude і ChatGPT: `docs/09-mcp.md`.

Стек: Laravel 13, Blade + чистий CSS з токенів, Livewire (+ Alpine), Filament (адмінка), MySQL, Redis.

## Локальна розробка

PHP і Composer на машині не потрібні, усе працює в Docker.

```sh
cp .env.example .env
docker compose up -d --build                      # app, web (localhost:8080), queue, db, redis
docker compose exec app composer install
docker compose exec app php artisan key:generate
docker compose exec app php artisan migrate --seed
docker compose run --rm node sh -c "npm ci && npm run build"   # або npm run dev
```

- Сайт: <http://localhost:8080>, адмінка: <http://localhost:8080/admin>
- Локальний адмін створюється під час `migrate --seed`, якщо в `.env` задано `ADMIN_EMAIL` і `ADMIN_PASSWORD` (від 12 символів).
- Тести та стиль: `docker compose exec app ./vendor/bin/pest` і `./vendor/bin/pint`.

## Змінні оточення

Повний список з коментарями: `.env.example`. Для production обов'язкові виділені жирним.

| Змінна | Призначення |
|---|---|
| **`APP_KEY`** | Ключ шифрування. Згенерувати: `echo "base64:$(openssl rand -base64 32)"`. Не змінювати після запуску (розлогінить усіх) |
| **`APP_URL`** | Публічний URL зі схемою, без `/` в кінці, напр. `https://bakinskybulvar.com`. Від нього залежать посилання, sitemap, canonical, Open Graph |
| `APP_ENV`, `APP_DEBUG` | У production compose-файл ставить `production` і `false` сам |
| **`DB_PASSWORD`**, **`DB_ROOT_PASSWORD`** | Паролі MySQL (контейнер `db` у `docker-compose.prod.yml`) |
| `DB_DATABASE`, `DB_USERNAME` | За замовчуванням `bakinsky` |
| `DB_HOST`, `REDIS_HOST` | У prod-compose зашито `db` і `redis`. Змінюйте лише якщо база/Redis зовнішні |
| `MAIL_MAILER` | `smtp` у production. Із `log` листи лише пишуться в лог |
| `MAIL_HOST`, `MAIL_PORT`, `MAIL_USERNAME`, `MAIL_PASSWORD`, `MAIL_SCHEME` | SMTP-провайдер. Порт 465 → `MAIL_SCHEME=smtps`, порт 587 → `smtp` |
| `MAIL_FROM_ADDRESS`, `MAIL_FROM_NAME` | Відправник листів |
| `MANAGER_EMAIL` | Куди надсилати нові заявки. Порожньо = поштового сповіщення немає |
| `TELEGRAM_BOT_TOKEN` | Токен бота з @BotFather |
| `TELEGRAM_BOT_USERNAME` | Username бота без `@` (посилання на бота в адмінці, рядки «Telegram» у застосунку) |
| `TELEGRAM_WEBHOOK_SECRET` | Довгий випадковий рядок, який ви вигадуєте самі: Telegram надсилає його із кожним запитом, без нього webhook відповідає 403. Згенерувати: `openssl rand -hex 24` |
| `TRUSTED_PROXIES` | За Traefik/Dokploy залишити `*` |
| `LOG_LEVEL` | `warning` за замовчуванням; логи йдуть у stderr контейнера |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD` | Адмін, який створюється при старті `web` (див. «Адмін-доступ»). Пароль від 12 символів. Якщо не задані, нічого не відбувається |
| `ADMIN_NAME` | Ім'я адміна, необов'язково (за замовчуванням `Admin`) |
| `ADMIN_PASSWORD_RESET` | `true` лише на один деплой, щоб змінити пароль існуючого адміна. Після цього **приберіть змінну** |

## Адмін-доступ

У `/admin` пускає лише користувачів із роллю `admin` або `manager` (поле `users.role`). Без ролі: 403.
Пароля за замовчуванням немає, сидер у production адміна не створює.

**Адмін із змінних оточення.** При кожному старті `web` (після міграцій) виконується `php artisan app:sync-admin`:

- `ADMIN_EMAIL` і `ADMIN_PASSWORD` задані, користувача немає: створюється адмін (`ADMIN_NAME`, інакше `Admin`).
- Користувач уже існує: **нічого не змінюється**, пароль не перезаписується при деплоях.
- Змінні не задані: команда мовчки нічого не робить.
- Пароль коротший за 12 символів або e-mail некоректний: у лог потрапляє зрозуміла помилка (без пароля), адмін не створюється, деплой **не падає**.

**Змінити пароль адміна.** Задайте в Dokploy `ADMIN_PASSWORD=<новий пароль>` і `ADMIN_PASSWORD_RESET=true`, зробіть Deploy, потім **видаліть `ADMIN_PASSWORD_RESET`** (інакше пароль скидатиметься на кожному деплої) і зробіть ще один Deploy. Те саме вручну: `php artisan app:sync-admin --reset-password`.

**Вручну** (додатковий адмін або менеджер):

```sh
php artisan app:create-admin                       # інтерактивно (пароль не потрапляє в історію shell)
php artisan app:create-admin anna@example.com --name="Анна" --role=manager
```

Пароль мінімум 12 символів.

## Production-образ

`Dockerfile` (multi-stage): збірка Vite (node) → `composer install --no-dev` → runtime на `php:8.4-fpm-alpine` з nginx і php-fpm під supervisord в **одному образі**.
Чому так: це один артефакт, один порт (80), без окремого контейнера nginx і спільних томів із кодом. Той самий образ запускається в трьох ролях:

| Сервіс | Команда | Що робить |
|---|---|---|
| `web` | `web` | чекає БД, `migrate --force`, кешує config/route/view/event/filament, стартує nginx + php-fpm |
| `queue` | `queue` | `queue:work` (черга Redis: сповіщення про заявки) |
| `scheduler` | `scheduler` | `schedule:work` (прибирання failed jobs тощо) |

Міграції запускає лише `web` (`RUN_MIGRATIONS=true`). Healthcheck: `GET /up` (200 лише якщо застосунок живий і БД відповідає); у `queue` і `scheduler` перевіряється наявність процесу.
Завантаження: `storage/app` винесено в том `app-storage`, `public/storage` створюється при старті.

## Деплой на Dokploy (Compose)

1. **Домен.** Основний домен: `bakinskybulvar.com`. Створіть A-запис `bakinskybulvar.com` на IP сервера з Dokploy.
2. **Сервіс.** Dokploy → Project → *Create Service* → **Compose**. Provider: GitHub (підключіть GitHub App і виберіть репозиторій), branch `main`, *Compose Type*: Docker Compose, *Compose Path*: `./docker-compose.prod.yml`.
3. **Змінні.** Вкладка *Environment*: вставте мінімум `APP_KEY`, `APP_URL`, `DB_PASSWORD`, `DB_ROOT_PASSWORD`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `MANAGER_EMAIL`, `MAIL_*`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_BOT_USERNAME`, `TELEGRAM_WEBHOOK_SECRET`, за потреби `ADMIN_NAME` (таблиця вище).
4. **Домен у Dokploy.** Вкладка *Domains* → Add: host = `bakinskybulvar.com`, **Service Name = `web`**, **Port = `80`**, HTTPS увімкнути, Certificate = Let's Encrypt. У `APP_URL` вкажіть `https://bakinskybulvar.com`. Піддомен `www` не використовується.
5. **Deploy.** Перша збірка триває кілька хвилин. `web` сам виконає міграції.
6. **Адмін.** Створюється автоматично зі змінних `ADMIN_EMAIL` / `ADMIN_PASSWORD` під час першого деплою (перевірте в логах `web`: `Admin created`). Без цих змінних: вкладка *Terminal* (контейнер `web`), `su-exec www-data php artisan app:create-admin`.
7. **Каталог.** У Terminal контейнера `web`: `su-exec www-data php artisan app:import-products`. Команда з `database/data/products.json` створює 5 категорій і 14 позицій **чернетками** (на сайті їх не видно). У `/admin/products` перегляньте картки, закрийте помітки «Потрібно уточнити» (видаліть підтверджений рядок), заповніть кроки приготування й опублікуйте. Прапорець `--publish` публікує одразу. Команда ідемпотентна: повторний запуск нічого не дублює й не перезаписує поля, змінені в адмінці (лише заповнює порожні); `--overwrite` повертає значення з файлу. Якщо раніше завантажували демо-товари: `su-exec www-data php artisan app:import-products --remove-demo`. Демо-товари створюються лише локальним сідером, у production `db:seed` їх не додає.
8. **Перевірка.** `https://<домен>/up` → 200; головна, каталог, товар; надішліть тестову заявку: вона з'явиться в `/admin/leads`, менеджер отримає лист, а підключені групи Telegram: повідомлення (див. нижче).
9. **Автодеплой.** Вкладка *Deployments* → увімкніть *Auto Deploy* (webhook GitHub) або деплойте вручну кнопкою.
10. **Бекапи.** Дані в томі `dbdata`. Налаштуйте регулярний `mysqldump` (наприклад, Dokploy *Schedules* на `db`) або бекап томів і зберігайте копію поза сервером.

## Telegram: бот і mini app

У `.env` лише три змінні (таблиця вище). Усе інше: отримувачі заявок, тексти бота, меню й команди, прайс, шаблон сповіщення: на сторінці **`/admin/telegram`** (тільки для ролі `admin`).

**Підключення, один раз:**

1. У @BotFather: `/newbot`, збережіть токен і username. Вигадайте `TELEGRAM_WEBHOOK_SECRET`.
2. Додайте три змінні в Dokploy → Deploy. **Воркер черги (`queue`) має працювати**: заявки розсилаються через чергу.
3. Свій Telegram id підкаже @userinfobot. У Terminal контейнера `web`:
   ```sh
   su-exec www-data php artisan app:telegram-add-admin <ваш_telegram_id> --name="Ім'я"
   su-exec www-data php artisan app:telegram-set-webhook
   ```
   Друга команда реєструє webhook (`https://<домен>/telegram/webhook` із секретом), список команд (`/start /catalog /price /samples /manager`) і кнопку меню «Каталог» → `https://<домен>/tg`. Вона потребує `APP_URL` з `https://`. Після зміни назв команд чи кнопки в адмінці натисніть там **«Перевстановити webhook»**.
4. Напишіть боту `/start`: ваш особистий чат стане отримувачем заявок (вимкнути можна в адмінці).
5. **Група менеджерів:** додайте бота в групу й напишіть там `/connect`. Це працює лише від адміна бота (`app:telegram-add-admin` або вкладка «Адміни бота»). Групу видно на вкладці «Отримувачі заявок»: там вмикають/вимикають її, обирають типи заявок (порожньо = усі), кнопка «Надіслати тест».
6. Перевірка: надішліть заявку з сайту. У групі з'явиться повідомлення з кнопками «Взяти в роботу», «Закрити», «Написати клієнту»; натискання змінює статус у `/admin/leads` і оновлює повідомлення.

Прайс для `/price`: або PDF, згенерований з каталогу (потрібен Chromium, він є в образі; перегенерується, коли змінюється каталог), або ваш завантажений PDF (вкладка «Прайс»). Mini app відкривається у боті кнопкою меню та за `https://<домен>/tg`; deep links: `?startapp=catalog`, `product_<slug>`, `order_price`, `order_samples`, `contacts`.

### Адреси в мета-даних

Canonical, Open Graph, `sitemap.xml`, `robots.txt` і JSON-LD завжди формуються з `APP_URL`, незалежно від того, з яким хостом прийшов запит.

### Після виходу в production

- Після першого деплою `robots.txt` відкриває сайт для індексації лише при `APP_ENV=production`; на інших середовищах він закритий.
- Подайте `https://<домен>/sitemap.xml` у Google Search Console.
- Перегляньте розмір `public/assets/og-default.png` (превью для соцмереж): зараз це знімок hero, потім замініть на фірмову картинку 1200×630.
