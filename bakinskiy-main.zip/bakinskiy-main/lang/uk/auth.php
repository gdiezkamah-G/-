<?php

return [
    'failed' => 'Невірний e-mail або пароль.',
    'password' => 'Невірний пароль.',
    'throttle' => 'Забагато спроб входу. Спробуйте за :seconds с.',
];
