#!/bin/sh
# One image, three roles (first argument): web (default) | queue | scheduler | <any command>.
# Every start is idempotent. Only the web container runs the one-time steps (under a database lock); the
# workers wait until web has migrated the database.
set -e
cd /var/www/html

role="${1:-web}"
as_app() { su-exec www-data "$@"; }

# 0. Nothing starts with a broken configuration: a clear list of what is missing, then exit 1.
if ! php artisan app:check-env --quiet-ok --no-interaction; then
    exit 1
fi

# 1. Writable dirs (a mounted volume may arrive owned by root) and the public/storage link.
mkdir -p storage/app/public storage/app/private storage/app/backups storage/framework/cache storage/framework/sessions storage/framework/views storage/logs bootstrap/cache
chown -R www-data:www-data storage bootstrap/cache
[ -L public/storage ] || php artisan storage:link --no-interaction >/dev/null 2>&1 || true

# 2. Wait for the database (DB_WAIT_SECONDS, default 120) and say exactly what is wrong if it never answers.
wait_for_db() {
    limit="${DB_WAIT_SECONDS:-120}"
    waited=0
    while ! as_app php -r '
        try { new PDO(sprintf("mysql:host=%s;port=%s;dbname=%s", getenv("DB_HOST"), getenv("DB_PORT") ?: 3306, getenv("DB_DATABASE")), getenv("DB_USERNAME"), getenv("DB_PASSWORD"), [PDO::ATTR_TIMEOUT => 3]); exit(0); }
        catch (Throwable $e) { file_put_contents("/tmp/dberr", $e->getMessage()); exit(1); }'; do
        waited=$((waited + 2))
        if [ "$waited" -ge "$limit" ]; then
            echo "ERROR: database ${DB_USERNAME}@${DB_HOST}:${DB_PORT:-3306}/${DB_DATABASE} is not reachable after ${limit}s: $(cat /tmp/dberr 2>/dev/null)" >&2
            echo "Check DB_HOST / DB_DATABASE / DB_USERNAME / DB_PASSWORD and that the database service is running." >&2
            exit 1
        fi
        echo "Waiting for the database (${waited}/${limit}s)..."
        sleep 2
    done
    echo "Database is reachable."
}

# Production caches (config, routes, views, events, Filament components and icons).
cache_all() {
    as_app php artisan config:cache --no-interaction
    as_app php artisan route:cache --no-interaction
    as_app php artisan view:cache --no-interaction
    as_app php artisan event:cache --no-interaction
    as_app php artisan filament:optimize --no-interaction || echo "filament:optimize skipped"
}

case "$role" in
    web)
        wait_for_db
        # migrate, admin, catalog (only when empty), Telegram webhook, price list, queue:restart (under a DB lock)
        if [ "${RUN_BOOTSTRAP:-true}" = "true" ]; then
            as_app php artisan app:bootstrap --no-interaction || { echo "ERROR: bootstrap failed, see above." >&2; exit 1; }
        fi
        cache_all
        # a report in the log; it never blocks the start
        as_app php artisan app:doctor --no-fail --no-interaction || true
        exec /usr/bin/supervisord -c /etc/supervisord.conf
        ;;
    queue)
        wait_for_db
        as_app php artisan app:wait-ready --no-interaction || exit 1
        cache_all
        exec su-exec www-data php artisan queue:work --sleep=3 --tries=3 --max-time=3600 --no-interaction
        ;;
    scheduler)
        wait_for_db
        as_app php artisan app:wait-ready --no-interaction || exit 1
        cache_all
        exec su-exec www-data php artisan schedule:work --no-interaction
        ;;
    *)
        exec "$@"
        ;;
esac
