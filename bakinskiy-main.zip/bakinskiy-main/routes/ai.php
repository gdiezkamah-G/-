<?php

use App\Mcp\Servers\BakinskyiServer;
use Laravel\Mcp\Facades\Mcp;

// OAuth 2.1 for Claude / ChatGPT: discovery documents and dynamic client registration (the rest is Passport's /oauth/*)
Mcp::oauthRoutes();

// Staff only: OAuth token (Claude, ChatGPT) or a personal access token (scripts, Claude Code); see App\Http\Middleware\McpAccess
Mcp::web('/mcp', BakinskyiServer::class)->middleware(['auth:sanctum,api', 'mcp.access', 'throttle:mcp']);
