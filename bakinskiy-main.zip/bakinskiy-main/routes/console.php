<?php

use App\Jobs\QueueHeartbeat;
use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

Schedule::command('queue:prune-failed --hours=168')->daily();
Schedule::command('cache:prune-stale-tags')->hourly();

// Liveness signals for app:doctor: the scheduler writes its own, and the queue worker answers a job it dispatches.
Schedule::call(fn () => Cache::put('heartbeat.scheduler', time(), 900))->name('heartbeat-scheduler')->everyMinute();
Schedule::job(new QueueHeartbeat)->name('heartbeat-queue')->everyMinute();

// Nightly database backup (local volume, plus S3 when configured), rotated by BACKUP_KEEP_DAYS.
if (config('bakinsky.backup.enabled')) {
    Schedule::command('app:db-backup')->dailyAt(config('bakinsky.backup.at'))->timezone('Europe/Kyiv')->withoutOverlapping();
}
