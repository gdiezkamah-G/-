<?php

/** @var Nutgram $bot */

use App\Telegram\Handlers\BotRemovedHandler;
use App\Telegram\Handlers\CatalogHandler;
use App\Telegram\Handlers\ChatMigrationHandler;
use App\Telegram\Handlers\ConnectHandler;
use App\Telegram\Handlers\ContactHandler;
use App\Telegram\Handlers\LeadCallbackHandler;
use App\Telegram\Handlers\LeadCommandHandler;
use App\Telegram\Handlers\StartHandler;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Properties\MessageType;

/*
|--------------------------------------------------------------------------
| Bot handlers (loaded by nutgram/laravel). Texts and which commands are on come from the admin settings.
|--------------------------------------------------------------------------
*/

$bot->onCommand('start {param}', StartHandler::class);
$bot->onCommand('start', StartHandler::class);
$bot->onCommand('catalog', CatalogHandler::class);
$bot->onCommand('price', LeadCommandHandler::for('price'));
$bot->onCommand('samples', LeadCommandHandler::for('samples'));
$bot->onCommand('manager', LeadCommandHandler::for('manager'));
$bot->onCommand('connect', ConnectHandler::class);

$bot->onContact(ContactHandler::class);
$bot->onCallbackQueryData('lead:{action}:{id}', LeadCallbackHandler::class);
$bot->onMessageType(MessageType::MIGRATE_TO_CHAT_ID, ChatMigrationHandler::class);
$bot->onMyChatMember(BotRemovedHandler::class);
