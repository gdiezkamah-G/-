<?php

use App\Http\Controllers\PageController;
use App\Http\Controllers\MetaFeedController;
use App\Http\Controllers\SeoController;
use App\Http\Controllers\TelegramWebhookController;
use App\Http\Controllers\TgController;
use Illuminate\Foundation\Http\Middleware\PreventRequestForgery;
use Illuminate\Support\Facades\Route;

Route::get('/', [PageController::class, 'home'])->name('home');
Route::get('/produkciya', [PageController::class, 'catalog'])->name('catalog');
Route::get('/tg', TgController::class)->name('miniapp');
Route::get('/produkciya/{slug}', [PageController::class, 'product'])->name('product');

// Phone-app screens (desktop gets them in phase 1C; until then desktop visitors are sent home).
Route::get('/kontakty', [PageController::class, 'appOnly'])->defaults('screen', 'contacts')->name('contacts');
Route::get('/dlya-horeca', [PageController::class, 'appOnly'])->defaults('screen', 'horeca')->name('horeca');
Route::get('/vyrobnytstvo', [PageController::class, 'appOnly'])->defaults('screen', 'factory')->name('factory');
Route::get('/offline', [PageController::class, 'offline'])->name('offline');
Route::get('/feeds/meta/products.csv', MetaFeedController::class)->name('feeds.meta.products');

// Telegram calls this server-to-server: no CSRF, protected by the webhook secret header.
Route::post('/telegram/webhook', TelegramWebhookController::class)
    ->withoutMiddleware([PreventRequestForgery::class])->name('telegram.webhook');

Route::get('/sitemap.xml', [SeoController::class, 'sitemap'])->name('sitemap');
Route::get('/robots.txt', [SeoController::class, 'robots'])->name('robots');
