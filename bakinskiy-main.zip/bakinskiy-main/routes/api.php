<?php

use App\Http\Controllers\TelegramAuthController;
use Illuminate\Support\Facades\Route;

// /api/v1 (prefix is set in bootstrap/app.php)
Route::post('/telegram/auth', [TelegramAuthController::class, 'auth'])->middleware('throttle:30,1');
Route::get('/telegram/me', [TelegramAuthController::class, 'me'])->middleware(['auth:sanctum', 'abilities:miniapp']);
