<?php

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

/*
|--------------------------------------------------------------------------
| Test Case
|--------------------------------------------------------------------------
|
| The closure you provide to your test functions is always bound to a specific PHPUnit test
| case class. By default, that class is "PHPUnit\Framework\TestCase". Of course, you may
| need to change it using the "pest()" function to bind different classes or traits.
|
*/

pest()->extend(TestCase::class)
    ->use(RefreshDatabase::class)
    ->in('Feature');

/*
|--------------------------------------------------------------------------
| Expectations
|--------------------------------------------------------------------------
|
| When you're writing tests, you often need to check that values meet certain conditions. The
| "expect()" function gives you access to a set of "expectations" methods that you can use
| to assert different things. Of course, you may extend the Expectation API at any time.
|
*/

expect()->extend('toBeOne', function () {
    return $this->toBe(1);
});

/*
|--------------------------------------------------------------------------
| Functions
|--------------------------------------------------------------------------
|
| While Pest is very powerful out-of-the-box, you may have some testing code specific to your
| project that you don't want to repeat in every file. Here you can also expose helpers as
| global functions to help you to reduce the number of lines of code in your test files.
|
*/

function something()
{
    // ..
}

// ---------- Telegram helpers (Nutgram runs as a fake in tests; no network) ----------

use App\Enums\UserRole;
use App\Mcp\Servers\BakinskyiServer;
use App\Models\User;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Properties\UpdateType;
use SergiX44\Nutgram\Testing\FakeNutgram;

function tgBot(): FakeNutgram
{
    return app(Nutgram::class);
}

function tgUser(int $id = 100): array
{
    return ['id' => $id, 'first_name' => 'Іван', 'last_name' => 'Тест', 'username' => 'ivan'.$id, 'is_bot' => false];
}

/** The user writes $text (private chat by default) and the bot replies. */
function tgSay(string $text, int $from = 100, ?array $chat = null, array $extra = []): FakeNutgram
{
    return tgBot()->hearMessage(['text' => $text, 'from' => tgUser($from), 'chat' => $chat ?? ['id' => $from, 'type' => 'private']] + $extra)->reply();
}

/** The user shares a contact through the "Поділитися контактом" button. */
function tgShare(string $phone, int $from = 100): FakeNutgram
{
    return tgBot()->hearMessage([
        'contact' => ['phone_number' => $phone, 'first_name' => 'Іван', 'user_id' => $from],
        'from' => tgUser($from), 'chat' => ['id' => $from, 'type' => 'private'],
    ])->reply();
}

/** A press on an inline button under a message that lives in $chatId. */
function tgPress(string $data, int $chatId, int $from = 200): FakeNutgram
{
    return tgBot()->hearUpdateType(UpdateType::CALLBACK_QUERY, [
        'id' => 'cb1', 'from' => tgUser($from), 'chat_instance' => 'x', 'data' => $data,
        'message' => ['message_id' => 55, 'date' => 1703892479, 'chat' => ['id' => $chatId, 'type' => 'supergroup'], 'from' => tgUser(1)],
    ])->reply();
}

/** Decoded bodies of the Bot API calls made so far (optionally only one method). */
function tgCalls(?string $method = null): array
{
    $out = [];
    foreach (tgBot()->getRequestHistory() as $item) {
        $request = array_values($item)[0];
        $path = ltrim($request->getUri()->getPath(), '/');
        if ($method === null || $path === $method) {
            $data = FakeNutgram::getActualData($request);
            foreach (['reply_markup', 'commands', 'menu_button', 'allowed_updates', 'scope'] as $field) {
                if (isset($data[$field]) && is_string($data[$field])) {
                    $data[$field] = json_decode($data[$field], true) ?? $data[$field];
                }
            }
            $out[] = ['method' => $path] + $data;
        }
    }

    return $out;
}

/** Point the app at an empty throw-away storage dir (backups, PDF) so tests never touch real files. */
function useTempStorage(): string
{
    $dir = sys_get_temp_dir().'/bb-test-'.uniqid();
    foreach (['app/private', 'app/public', 'framework/cache', 'framework/views', 'framework/sessions', 'logs'] as $sub) {
        mkdir("{$dir}/{$sub}", 0775, true);
    }
    app()->useStoragePath($dir);

    return $dir;
}

function tgConfigure(): void
{
    config(['bakinsky.telegram.token' => '123456:TEST-TOKEN', 'nutgram.token' => '123456:TEST-TOKEN', 'bakinsky.telegram.webhook_secret' => 's3cret', 'bakinsky.telegram.bot_username' => 'bakinsky_bot']);
}

/** A complete, valid production environment (as a plain array) for the env/doctor tests. */
function goodEnv(array $over = []): array
{
    return array_merge([
        'APP_ENV' => 'production', 'APP_KEY' => 'base64:'.base64_encode(str_repeat('k', 32)), 'APP_URL' => 'https://bakinskybulvar.com',
        'DB_HOST' => 'db', 'DB_DATABASE' => 'bakinsky', 'DB_USERNAME' => 'u', 'DB_PASSWORD' => 'p',
        'QUEUE_CONNECTION' => 'redis', 'CACHE_STORE' => 'redis', 'SESSION_DRIVER' => 'redis', 'REDIS_HOST' => 'redis',
        'ADMIN_EMAIL' => 'a@b.com', 'ADMIN_PASSWORD' => 'long-enough-password', 'MAIL_MAILER' => 'smtp', 'MAIL_HOST' => 'smtp.example.com',
        'TELEGRAM_BOT_TOKEN' => '1:T', 'TELEGRAM_WEBHOOK_SECRET' => 'secret',
    ], $over);
}

/** A staff user with the given role (admin by default). */
function staff(UserRole $role = UserRole::Admin): User
{
    return User::factory()->role($role)->create();
}

/** The MCP server acting as a user: ->tool(SomeTool::class, [...args]). */
function mcp(?User $user = null)
{
    return BakinskyiServer::actingAs($user ?? staff());
}

/** A JSON-RPC request body for POST /mcp. */
function rpc(string $method = 'tools/list', array $params = []): array
{
    return ['jsonrpc' => '2.0', 'id' => 1, 'method' => $method, 'params' => (object) $params];
}

function toolNames($response): array
{
    return collect($response->json('result.tools'))->pluck('name')->all();
}
