<?php

use Database\Seeders\CatalogSeeder;

beforeEach(fn () => $this->seed(CatalogSeeder::class));

it('uses the seal, not the old monogram, in header and packs', function () {
    $html = $this->get('/')->getContent();

    expect($html)->toContain('src="/assets/logo/seal-gold.svg" alt="" width="54" height="54"')
        ->and($html)->toContain('class="pack__mono" src="/assets/logo/seal-gold.svg"')
        ->and($html)->not->toContain('monogram');
});

it('links favicons and the manifest in the head', function () {
    $this->get('/')->assertSee('rel="icon" href="/assets/logo/favicon.svg"', false)
        ->assertSee('href="/favicon-32.png"', false)
        ->assertSee('rel="apple-touch-icon" href="/apple-touch-icon.png"', false)
        ->assertSee('rel="manifest" href="/manifest.webmanifest"', false);
});

it('ships every brand file the markup points to', function (string $file, array $size) {
    expect(public_path($file))->toBeFile();

    if ($size) {
        expect(array_slice(getimagesize(public_path($file)), 0, 2))->toBe($size);
    }
})->with([
    ['favicon-32.png', [32, 32]],
    ['apple-touch-icon.png', [180, 180]],
    ['icon-192.png', [192, 192]],
    ['icon-512.png', [512, 512]],
    ['assets/og-default.png', [1200, 630]],
    ['assets/logo/seal-gold.svg', []],
    ['assets/logo/lockup-horizontal-gold.svg', []],
    ['favicon.ico', []],
]);

it('has a valid manifest', function () {
    $m = json_decode(file_get_contents(public_path('manifest.webmanifest')), true);

    expect($m['icons'])->not->toBeEmpty()->and($m['theme_color'])->toBe('#0b0906')->and($m['display'])->toBe('standalone')
        ->and($m['start_url'])->toStartWith('/')->and($m['lang'])->toBe('uk');
    foreach ($m['icons'] as $icon) {
        expect(public_path(ltrim($icon['src'], '/')))->toBeFile();
    }
});

it('no longer ships the monogram files', function () {
    expect(public_path('assets/logo/monogram-gold.svg'))->not->toBeFile();
});
