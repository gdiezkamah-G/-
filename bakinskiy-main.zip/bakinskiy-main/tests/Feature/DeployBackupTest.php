<?php

use App\Jobs\SendLeadMessage;
use App\Models\Lead;
use App\Models\Product;
use App\Models\Setting;
use App\Models\TelegramLeadMessage;
use App\Models\TelegramRecipient;
use App\Services\Deploy\BackupManager;
use App\Services\Deploy\DatabaseDumper;
use App\Services\Telegram\LeadNotifier;
use Database\Seeders\CatalogSeeder;
use Illuminate\Support\Facades\DB;

beforeEach(function () {
    $this->dir = useTempStorage();
    $this->seed(CatalogSeeder::class);
});

function dumpFile(): string
{
    $path = storage_path('app/backups/test-'.uniqid().'.sql.gz');
    @mkdir(dirname($path), 0775, true);

    return $path;
}

// ---------- dump and restore ----------

it('restores exactly what was dumped, including quotes, semicolons, newlines, unicode and NULLs', function () {
    $nasty = "Кафе «Схід»; DROP TABLE leads; --\nдругий рядок 'лапки' \"подвійні\" \\ слеш /*#*/ 🍽";
    Lead::create(['company' => $nasty, 'contact_name' => 'Іван', 'phone' => '0501234567', 'comment' => null, 'volume_kg' => 7]);
    $file = dumpFile();

    $rows = app(DatabaseDumper::class)->dump($file);

    DB::table('leads')->delete();
    DB::table('products')->delete();
    expect(Lead::count())->toBe(0)->and(Product::count())->toBe(0)->and($rows)->toBeGreaterThan(10);

    app(DatabaseDumper::class)->restore($file);

    $lead = Lead::sole();
    expect($lead->company)->toBe($nasty)->and($lead->comment)->toBeNull()->and($lead->volume_kg)->toBe(7)
        ->and(Product::count())->toBe(4)->and(Product::where('slug', 'plov')->first()->ingredients[0]['name'])->toBe('Рис');
});

it('writes a gzip file that starts with the dump header', function () {
    $file = dumpFile();
    app(DatabaseDumper::class)->dump($file);

    expect(file_get_contents($file, false, null, 0, 2))->toBe("\x1f\x8b")->and(gzdecode(file_get_contents($file)))->toStartWith('-- bakinsky dump');
});

it('does not dump the throw-away tables (cache, sessions, jobs) but keeps their structure', function () {
    DB::table('jobs')->insert(['queue' => 'default', 'payload' => 'x', 'attempts' => 0, 'available_at' => 1, 'created_at' => 1]);
    $file = dumpFile();
    app(DatabaseDumper::class)->dump($file);
    $sql = gzdecode(file_get_contents($file));

    expect($sql)->toContain('CREATE TABLE "jobs"')->and($sql)->not->toContain('INSERT INTO "jobs"');
});

it('refuses a file that is not one of our dumps', function () {
    $file = dumpFile();
    file_put_contents($file, gzencode('DROP DATABASE bakinsky;'));

    expect(fn () => app(DatabaseDumper::class)->restore($file))->toThrow(RuntimeException::class, 'не дамп');
    expect(Product::count())->toBe(4);
});

// ---------- manager: run, rotate, resolve ----------

it('creates a dated backup file and lists it', function () {
    $r = app(BackupManager::class)->run(14);

    expect($r['file'])->toMatch('/^db-\d{8}-\d{6}\.sql\.gz$/')->and($r['size'])->toBeGreaterThan(500)->and($r['s3'])->toBeFalse()
        ->and(is_file(storage_path('app/backups/'.$r['file'])))->toBeTrue()
        ->and(app(BackupManager::class)->list())->toHaveCount(1);
});

it('rotates backups older than the limit but always keeps the newest', function () {
    $dir = storage_path('app/backups');
    mkdir($dir, 0775, true);
    foreach (['db-20260101-030000.sql.gz' => 30, 'db-20260110-030000.sql.gz' => 20, 'db-20260920-030000.sql.gz' => 3, 'db-20260921-030000.sql.gz' => 2] as $name => $days) {
        file_put_contents("$dir/$name", 'x');
        touch("$dir/$name", now()->subDays($days)->timestamp);
    }

    $removed = app(BackupManager::class)->rotate(14);

    expect($removed)->toBe(2)->and(scandir($dir))->toContain('db-20260920-030000.sql.gz', 'db-20260921-030000.sql.gz')
        ->not->toContain('db-20260101-030000.sql.gz');
});

it('keeps the newest backup even when every file is old', function () {
    $dir = storage_path('app/backups');
    mkdir($dir, 0775, true);
    foreach (['db-20250101-030000.sql.gz', 'db-20250102-030000.sql.gz'] as $name) {
        file_put_contents("$dir/$name", 'x');
        touch("$dir/$name", now()->subDays(400)->timestamp);
    }

    app(BackupManager::class)->rotate(14);

    expect(scandir($dir))->toContain('db-20250102-030000.sql.gz')->not->toContain('db-20250101-030000.sql.gz');
});

it('leaves foreign files in the backups folder alone', function () {
    $dir = storage_path('app/backups');
    mkdir($dir, 0775, true);
    file_put_contents("$dir/notes.txt", 'mine');
    touch("$dir/notes.txt", now()->subDays(100)->timestamp);

    app(BackupManager::class)->rotate(1);

    expect(file_exists("$dir/notes.txt"))->toBeTrue();
});

it('resolves latest, a name on the volume, and a path', function () {
    $m = app(BackupManager::class);
    expect(fn () => $m->resolve('latest'))->toThrow(RuntimeException::class, 'немає жодного');

    $a = $m->run(14)['file'];
    expect($m->resolve('latest'))->toEndWith($a)->and($m->resolve($a))->toEndWith($a)->and($m->resolve(storage_path("app/backups/{$a}")))->toEndWith($a);
    expect(fn () => $m->resolve('nope.sql.gz'))->toThrow(RuntimeException::class, 'не знайдено');
});

it('uses S3 only when fully configured', function () {
    expect(app(BackupManager::class)->s3())->toBeNull();

    config(['bakinsky.backup.s3' => ['bucket' => 'b', 'key' => 'k', 'secret' => 's', 'region' => 'auto', 'endpoint' => 'https://s3.example.com', 'prefix' => 'bb', 'path_style' => true]]);
    expect(app(BackupManager::class)->s3())->not->toBeNull();

    config(['bakinsky.backup.s3.secret' => '']);
    expect(app(BackupManager::class)->s3())->toBeNull();
});

it('says what is missing when restoring from S3 that is not configured', function () {
    expect(fn () => app(BackupManager::class)->resolve('s3'))->toThrow(RuntimeException::class, 'S3 не налаштовано');
});

it('reports the age of the newest backup', function () {
    $m = app(BackupManager::class);
    expect($m->latestAge())->toBeNull();

    $m->run(14);
    expect($m->latestAge())->toBeLessThan(5);
});

// ---------- the commands ----------

it('backs up from the command line and lists the result', function () {
    $this->artisan('app:db-backup')->expectsOutputToContain('Бекап: storage/app/backups/db-')->assertSuccessful();
    $this->artisan('app:db-backup', ['--list' => true])->expectsOutputToContain('db-')->assertSuccessful();
});

it('says so when there are no backups yet', function () {
    $this->artisan('app:db-backup', ['--list' => true])->expectsOutputToContain('Бекапів немає.')->assertSuccessful();
});

it('restores the latest backup from the command line and re-applies migrations', function () {
    app(BackupManager::class)->run(14);
    Product::query()->delete();
    Setting::put('marker', 'after-backup');

    $this->artisan('app:db-restore', ['file' => 'latest', '--force' => true])->expectsOutputToContain('Відновлено')->assertSuccessful();

    expect(Product::count())->toBe(4)->and(Setting::get('marker'))->toBeNull();
});

it('asks before replacing the data and does nothing when declined', function () {
    app(BackupManager::class)->run(14);
    Product::query()->delete();

    $this->artisan('app:db-restore', ['file' => 'latest'])->expectsConfirmation('Продовжити?', 'no')->assertFailed();

    expect(Product::count())->toBe(0);
});

it('fails clearly when the backup to restore does not exist', function () {
    $this->artisan('app:db-restore', ['file' => 'missing.sql.gz', '--force' => true])->expectsOutputToContain('не знайдено')->assertFailed();
});

it('is on the schedule: nightly backup and both heartbeats', function () {
    $this->artisan('schedule:list')->expectsOutputToContain('app:db-backup')->expectsOutputToContain('heartbeat-queue')
        ->expectsOutputToContain('heartbeat-scheduler')->assertSuccessful();
});

it('keeps a retried lead notification from posting twice', function () {
    tgConfigure();
    $lead = Lead::create(['company' => 'К', 'contact_name' => 'І', 'phone' => '0501234567', 'type' => 'order']);
    $r = TelegramRecipient::create(['chat_id' => -1, 'type' => 'group']);
    TelegramLeadMessage::create(['lead_id' => $lead->id, 'chat_id' => -1, 'message_id' => 5]);

    (new SendLeadMessage($lead->id, $r->id))->handle(tgBot(), app(LeadNotifier::class));

    expect(tgCalls('sendMessage'))->toBeEmpty();
});
