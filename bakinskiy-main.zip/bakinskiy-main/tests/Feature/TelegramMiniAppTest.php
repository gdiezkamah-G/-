<?php

use App\Enums\LeadSource;
use App\Enums\LeadType;
use App\Jobs\SendPriceToChat;
use App\Livewire\OrderSheet;
use App\Livewire\TgSheet;
use App\Models\Lead;
use App\Models\Product;
use App\Models\TelegramUser;
use App\Support\TelegramInitData;
use Database\Seeders\CatalogSeeder;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Queue;
use Livewire\Livewire;

const TOKEN = '123456:TEST-TOKEN';

beforeEach(function () {
    tgConfigure();
    $this->seed(CatalogSeeder::class);
});

function initData(array $over = [], ?int $authDate = null, string $token = TOKEN): string
{
    return TelegramInitData::sign(array_merge([
        'auth_date' => (string) ($authDate ?? time()),
        'query_id' => 'AAH',
        'start_param' => 'catalog',
        'user' => json_encode(['id' => 777, 'first_name' => 'Олена', 'last_name' => 'Кравець', 'username' => 'olena', 'language_code' => 'uk'], JSON_UNESCAPED_UNICODE),
    ], $over), $token);
}

// ---------- HMAC validation ----------

it('accepts correctly signed initData', function () {
    $r = TelegramInitData::validate(initData(), TOKEN);

    expect($r['user']['id'])->toBe(777)->and($r['user']['first_name'])->toBe('Олена')->and($r['start_param'])->toBe('catalog');
});

it('rejects forged initData', function (string $case) {
    $valid = initData();
    $data = match ($case) {
        'changed user' => str_replace('777', '888', urldecode($valid)) === urldecode($valid) ? $valid : http_build_query(array_merge(Arr::except(parse_qs($valid), 'user'), ['user' => json_encode(['id' => 888, 'first_name' => 'Підміна'])])),
        'wrong hash' => preg_replace('/hash=[0-9a-f]{6}/', 'hash=000000', $valid),
        'other bot token' => initData(token: '999:OTHER'),
        'no hash' => http_build_query(Arr::except(parse_qs($valid), 'hash')),
        'garbage' => 'not-init-data',
        'empty' => '',
    };

    expect(fn () => TelegramInitData::validate($data, TOKEN))->toThrow(InvalidArgumentException::class);
})->with(['changed user', 'wrong hash', 'other bot token', 'no hash', 'garbage', 'empty']);

it('rejects stale initData (older than 24 hours) and accepts it just inside the window', function () {
    expect(fn () => TelegramInitData::validate(initData(authDate: time() - 86400 - 60), TOKEN))->toThrow(InvalidArgumentException::class, 'expired');
    expect(TelegramInitData::validate(initData(authDate: time() - 86400 + 60), TOKEN)['user']['id'])->toBe(777);
});

it('rejects initData from the future, without auth_date, without a user, or without a configured token', function () {
    expect(fn () => TelegramInitData::validate(initData(authDate: time() + 3600), TOKEN))->toThrow(InvalidArgumentException::class)
        ->and(fn () => TelegramInitData::validate(initData(['auth_date' => '0']), TOKEN))->toThrow(InvalidArgumentException::class)
        ->and(fn () => TelegramInitData::validate(initData(['user' => '{}']), TOKEN))->toThrow(InvalidArgumentException::class)
        ->and(fn () => TelegramInitData::validate(initData(), null))->toThrow(InvalidArgumentException::class, 'token');
});

function parse_qs(string $q): array
{
    parse_str($q, $out);

    return $out;
}

// ---------- sign in + Sanctum ----------

it('signs a Mini App user in and issues a Sanctum token', function () {
    $res = $this->postJson('/api/v1/telegram/auth', ['init_data' => initData()])->assertOk();

    $res->assertJsonPath('user.name', 'Олена Кравець')->assertJsonPath('start_param', 'catalog')->assertJsonStructure(['token']);
    $user = TelegramUser::sole();
    expect($user->telegram_id)->toBe(777)->and($user->username)->toBe('olena')->and($user->tokens)->toHaveCount(1);

    $this->withToken($res->json('token'))->getJson('/api/v1/telegram/me')->assertOk()->assertJsonPath('user.first_name', 'Олена');
});

it('refuses a forged or expired sign-in and creates nothing', function (string $data) {
    $this->postJson('/api/v1/telegram/auth', ['init_data' => $data])->assertUnauthorized();

    expect(TelegramUser::count())->toBe(0);
})->with([
    'wrong signature' => fn () => initData(token: '999:OTHER'),
    'expired' => fn () => initData(authDate: time() - 90000),
]);

it('requires init_data', function () {
    $this->postJson('/api/v1/telegram/auth', [])->assertUnprocessable()->assertJsonValidationErrors('init_data');
});

it('keeps one Mini App token per user and protects /me', function () {
    $first = $this->postJson('/api/v1/telegram/auth', ['init_data' => initData()])->json('token');
    $second = $this->postJson('/api/v1/telegram/auth', ['init_data' => initData()])->json('token');

    expect(TelegramUser::sole()->tokens)->toHaveCount(1);
    $this->getJson('/api/v1/telegram/me')->assertUnauthorized();
    $this->withToken('999|nonsense')->getJson('/api/v1/telegram/me')->assertUnauthorized();
    $this->withToken($second)->getJson('/api/v1/telegram/me')->assertOk();
    expect($first)->not->toBe($second);
});

it('returns the phone once the user has shared it in the bot', function () {
    $token = $this->postJson('/api/v1/telegram/auth', ['init_data' => initData()])->json('token');
    TelegramUser::sole()->update(['phone' => '+380501234567']);

    $this->withToken($token)->getJson('/api/v1/telegram/me')->assertJsonPath('user.phone', '+380501234567');
});

// ---------- the /tg page ----------

it('renders every published product and no unpublished one, on its own layout', function () {
    $draft = Product::query()->first();
    $draft->update(['status' => 'draft']);

    $html = $this->get('/tg')->assertOk()->getContent();

    foreach (Product::published()->get() as $p) {
        expect($html)->toContain('id="p-'.$p->slug.'"');
    }
    expect($html)->not->toContain('id="p-'.$draft->slug.'"')
        ->toContain('telegram-web-app.js')->toContain('data-ui="tg"')->toContain('Запитати про товар')
        ->not->toContain('id="tabbar"')->not->toContain('serviceWorker')->not->toContain('manifest.webmanifest');
});

it('keeps the mobile site free of the Telegram script and /tg out of search engines', function () {
    $this->get('/tg')->assertSee('noindex', false);
    app()->detectEnvironment(fn () => 'production');
    $this->get('/robots.txt')->assertSee('Disallow: /tg', false);
    $this->get('/')->assertDontSee('telegram-web-app.js', false);
});

// ---------- the sheet: every scenario ----------

function sheet(string $mode, ?string $slug = null, ?string $init = ''): mixed
{
    return Livewire::test(TgSheet::class)->call('open', $mode, $slug, $init ?? '');
}

it('creates a manager lead from a verified Telegram user without asking for a phone', function () {
    sheet('manager', null, initData())->set('company', 'Кафе Баку')->set('comment', 'Привіт')->call('submit')->assertSet('step', 'done');

    $lead = Lead::sole();
    expect($lead->type)->toBe(LeadType::Manager)->and($lead->source)->toBe(LeadSource::MiniApp)
        ->and($lead->telegram_user_id)->toBe(TelegramUser::sole()->id)->and($lead->company)->toBe('Кафе Баку');
});

it('creates a sample lead and a product request that carries the product', function () {
    sheet('samples', null, initData())->call('submit');
    expect(Lead::latest('id')->first()->type)->toBe(LeadType::Sample);

    $product = Product::published()->first();
    sheet('request', $product->slug, initData())->set('comment', 'Яка ціна?')->call('submit');
    $lead = Lead::latest('id')->first();
    expect($lead->type)->toBe(LeadType::Request)->and($lead->product_id)->toBe($product->id)->and($lead->source)->toBe(LeadSource::MiniApp);
});

it('falls back to a manager request when the product of a request is not published', function () {
    Product::query()->update(['status' => 'draft']);

    sheet('request', 'no-such-product', initData())->assertSet('mode', 'manager');
});

it('sends the price into the chat when the user shares a number already known', function () {
    Queue::fake();
    $this->postJson('/api/v1/telegram/auth', ['init_data' => initData()]);
    TelegramUser::sole()->update(['phone' => '+380501234567']);

    sheet('price', null, initData())->assertSet('step', 'choose')->call('share')->assertSet('step', 'done');

    $lead = Lead::sole();
    expect($lead->type)->toBe(LeadType::Price)->and($lead->phone)->toBe('+380501234567')->and($lead->source)->toBe(LeadSource::MiniApp);
    Queue::assertPushed(SendPriceToChat::class, fn ($j) => $j->telegramId === 777);
});

it('waits for the contact from the bot, finishes when it arrives, and falls back to manual when refused', function () {
    Queue::fake();
    $c = sheet('price', null, initData())->call('share')->assertSet('step', 'waiting')->assertDispatched('tg-request-contact');

    $c->call('checkPhone')->assertSet('step', 'waiting');
    TelegramUser::sole()->update(['phone' => '+380671112233']);
    $c->call('checkPhone')->assertSet('step', 'done');
    expect(Lead::sole()->phone)->toBe('+380671112233');

    TelegramUser::sole()->update(['phone' => null]);
    sheet('price', null, initData())->call('share')->call('contactResult', false)->assertSet('step', 'form')->assertSet('declined', true);
});

it('asks a manual price request for a phone and does not message a chat without Telegram', function () {
    Queue::fake();
    sheet('price')->assertSet('step', 'form')->call('submit')->assertHasErrors(['phone', 'name']);

    sheet('price')->set('name', 'Іван')->set('phone', '+380501112233')->call('submit')->assertSet('step', 'done');

    $lead = Lead::sole();
    expect($lead->source)->toBe(LeadSource::MiniApp)->and($lead->telegram_user_id)->toBeNull()->and($lead->contact_name)->toBe('Іван');
    Queue::assertNotPushed(SendPriceToChat::class);
});

it('treats forged or expired initData as manual mode without a Telegram user', function (string $data) {
    sheet('samples', null, $data)->set('name', 'Іван')->set('phone', '+380501112233')->call('submit')->assertSet('step', 'done');

    expect(TelegramUser::count())->toBe(0)->and(Lead::sole()->telegram_user_id)->toBeNull();
})->with([
    'forged' => fn () => initData(token: '1:OTHER'),
    'expired' => fn () => initData(authDate: time() - 90000),
]);

it('validates in Ukrainian and ignores a filled honeypot and double submits', function () {
    sheet('manager')->set('phone', 'abc')->set('name', '')->call('submit')
        ->assertHasErrors(['name' => 'required', 'phone' => 'regex'])->assertSee('Вкажіть імʼя.');

    sheet('manager', null, initData())->set('website', 'spam')->call('submit');
    expect(Lead::count())->toBe(0);

    sheet('manager', null, initData())->call('submit')->call('submit');
    expect(Lead::count())->toBe(1);
});

// ---------- startapp / deep links and the bot ----------

it('wires deep links, MainButton and haptics in the page script', function () {
    $js = file_get_contents(resource_path('js/tg.js'));

    expect($js)->toContain('start_param')->toContain('product_')->toContain('disableVerticalSwipes')->toContain('#0E0B08')
        ->and($js)->not->toContain('BackButton');
});

it('sends /start buttons that open the mini app on the right screen', function () {
    tgSay('/start');
    $kb = tgCalls('sendMessage')[0]['reply_markup']['inline_keyboard'];
    expect(json_encode($kb))->toContain('/tg')->toContain('p=price')->toContain('p=samples')->toContain('p=manager');

    tgSay('/start product_lyulya-kebab');
    expect(json_encode(tgCalls('sendMessage')[0]['reply_markup']))->toContain('p=product_lyulya-kebab');
});

it('keeps site requests as source site', function () {
    Livewire::test(OrderSheet::class)->set('company', 'Кафе')->set('contactName', 'Іван')->set('phone', '+380501234567')->call('submit');

    expect(Lead::sole()->source)->toBe(LeadSource::Site);
});
