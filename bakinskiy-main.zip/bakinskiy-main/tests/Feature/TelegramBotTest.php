<?php

use App\Enums\LeadSource;
use App\Enums\LeadStatus;
use App\Enums\LeadType;
use App\Models\Lead;
use App\Models\TelegramAdmin;
use App\Models\TelegramRecipient;
use App\Models\TelegramUser;
use App\Services\Telegram\TelegramSettings;
use Illuminate\Support\Facades\Storage;
use SergiX44\Nutgram\Telegram\Properties\UpdateType;
use Spatie\LaravelPdf\Facades\Pdf;

beforeEach(function () {
    tgConfigure();
    Storage::fake('local');
    // an uploaded price list keeps these tests free of Chromium
    Storage::disk('local')->put('telegram/price.pdf', '%PDF-1.4 test');
    app(TelegramSettings::class)->save('price', ['mode' => 'upload', 'file' => 'telegram/price.pdf']);
});

// ---------- webhook ----------

it('refuses webhook calls without the right secret', function (?string $header) {
    $headers = $header === null ? [] : ['X-Telegram-Bot-Api-Secret-Token' => $header];

    $this->postJson('/telegram/webhook', ['update_id' => 1], $headers)->assertForbidden();
})->with([[null], ['wrong'], ['']]);

it('refuses everything when no secret is configured', function () {
    config(['bakinsky.telegram.webhook_secret' => null]);

    $this->postJson('/telegram/webhook', [], ['X-Telegram-Bot-Api-Secret-Token' => ''])->assertForbidden();
});

it('runs the bot for a call with the right secret', function () {
    tgBot()->hearMessage(['text' => '/start', 'from' => tgUser(), 'chat' => ['id' => 100, 'type' => 'private']]);

    $this->postJson('/telegram/webhook', [], ['X-Telegram-Bot-Api-Secret-Token' => 's3cret'])->assertNoContent();

    expect(tgCalls('sendMessage'))->toHaveCount(1);
});

// ---------- commands ----------

it('greets on /start with the Mini App button and remembers the user', function () {
    tgSay('/start');

    $call = tgCalls('sendMessage')[0];
    expect($call['text'])->toContain('Бакинський Бульвар')
        ->and($call['reply_markup']['inline_keyboard'][0][0]['web_app']['url'])->toEndWith('/tg')
        ->and(TelegramUser::where('telegram_id', 100)->value('first_name'))->toBe('Іван');
});

it('uses the greeting text from the admin settings', function () {
    app(TelegramSettings::class)->save('texts', ['welcome' => 'Привіт із налаштувань']);

    tgSay('/start');

    expect(tgCalls('sendMessage')[0]['text'])->toBe('Привіт із налаштувань');
});

it('turns a deep link into a Mini App button for that screen', function (string $param) {
    tgSay("/start {$param}");

    expect(tgCalls('sendMessage')[0]['reply_markup']['inline_keyboard'][0][0]['web_app']['url'])->toEndWith('/tg?p='.rawurlencode($param));
})->with(['catalog', 'contacts', 'product_dolma-telyatyna']);

it('opens the catalog on /catalog and respects a disabled command', function () {
    tgSay('/catalog');
    expect(tgCalls('sendMessage')[0]['reply_markup']['inline_keyboard'][0][0]['web_app']['url'])->toEndWith('/tg?p=catalog');

    app(TelegramSettings::class)->save('menu', ['commands' => ['catalog' => ['enabled' => false]]]);
    tgSay('/catalog');
    // the fake keeps the calls of the last update only
    expect(tgCalls('sendMessage')[0]['text'])->toBe('Ця функція тимчасово недоступна.');
});

it('does not run lead commands in groups', function () {
    tgSay('/price', 100, ['id' => -500, 'type' => 'group']);

    expect(tgCalls('sendMessage')[0]['text'])->toBe('Напишіть мені в особисті повідомлення, щоб продовжити.')
        ->and(Lead::count())->toBe(0);
});

// ---------- price scenario ----------

it('asks a new user for a contact, then saves a price lead and sends the PDF', function () {
    tgSay('/price');

    $ask = tgCalls('sendMessage')[0];
    expect($ask['reply_markup']['keyboard'][0][0]['request_contact'])->toBeTrue()
        ->and($ask['reply_markup']['keyboard'][1][0]['text'])->toBe('Написати номер вручну');

    tgShare('380501234567');

    $lead = Lead::sole();
    expect($lead->type)->toBe(LeadType::Price)->and($lead->source)->toBe(LeadSource::Bot)->and($lead->status)->toBe(LeadStatus::New)
        ->and($lead->phone)->toBe('+380501234567')->and($lead->contact_name)->toBe('Іван Тест')
        ->and($lead->telegramUser->telegram_id)->toBe(100)->and($lead->company)->toBeNull();

    expect(tgCalls('sendDocument'))->toHaveCount(1)
        ->and(tgCalls('sendDocument')[0]['caption'])->toBe('Прайс-лист «Бакинський Бульвар · Мануфактура»')
        ->and(collect(tgCalls('sendMessage'))->last()['text'])->toContain('Дякуємо');
    expect(TelegramUser::first()->phone)->toBe('+380501234567');
});

it('accepts a number typed by hand and rejects nonsense', function () {
    tgSay('/price');
    tgSay('Написати номер вручну');
    tgSay('привіт');
    expect(collect(tgCalls('sendMessage'))->last()['text'])->toContain('не номер телефону')->and(Lead::count())->toBe(0);

    tgSay('+380 67 111 22 33');

    expect(Lead::sole()->phone)->toBe('+380 67 111 22 33');
});

it('sends the PDF at once to a known user, but still creates a new lead each time', function () {
    TelegramUser::create(['telegram_id' => 100, 'first_name' => 'Іван', 'phone' => '+380501234567', 'company' => 'Кафе «Схід»']);

    foreach ([1, 2] as $i) {
        tgSay('/price');

        expect(Lead::count())->toBe($i)->and(tgCalls('sendDocument'))->toHaveCount(1)
            ->and(collect(tgCalls('sendMessage'))->pluck('text')->join(' '))->not->toContain('Поділіться контактом');
    }

    expect(Lead::first()->company)->toBe('Кафе «Схід»');
});

it('uploads the PDF once and then sends the cached Telegram file_id', function () {
    TelegramUser::create(['telegram_id' => 100, 'first_name' => 'Іван', 'phone' => '+380501234567']);
    $path = Storage::disk('local')->path('telegram/price.pdf');
    app(TelegramSettings::class)->save('price', ['file_id' => 'CACHED-FILE-ID', 'file_hash' => md5_file($path)]);

    tgSay('/price');

    expect(tgCalls('sendDocument')[0]['document'])->toBe('CACHED-FILE-ID');
});

it('forgets the cached file_id when the PDF changes', function () {
    TelegramUser::create(['telegram_id' => 100, 'first_name' => 'Іван', 'phone' => '+380501234567']);
    app(TelegramSettings::class)->save('price', ['file_id' => 'OLD', 'file_hash' => 'not-the-current-hash']);

    tgSay('/price');

    expect(tgCalls('sendDocument')[0]['document'])->not->toBe('OLD');
});

it('still creates the lead and apologises when the price list cannot be built', function () {
    TelegramUser::create(['telegram_id' => 100, 'first_name' => 'Іван', 'phone' => '+380501234567']);
    app(TelegramSettings::class)->save('price', ['mode' => 'upload', 'file' => 'telegram/missing.pdf']);
    // upload mode with a missing file falls back to generation, which cannot run here
    Pdf::fake();
    Storage::disk('local')->delete('telegram/price-list.pdf');

    tgSay('/price');

    expect(Lead::count())->toBe(1);
});

// ---------- samples and manager ----------

it('collects contact and venue for samples', function () {
    tgSay('/samples');
    tgShare('+380501234567');

    expect(collect(tgCalls('sendMessage'))->last()['text'])->toBe('Як називається ваш заклад? (необов’язково)')->and(Lead::count())->toBe(0);

    tgSay('Ресторан «Схід»');

    $lead = Lead::sole();
    expect($lead->type)->toBe(LeadType::Sample)->and($lead->source)->toBe(LeadSource::Bot)->and($lead->company)->toBe('Ресторан «Схід»')
        ->and(tgCalls('sendDocument'))->toBeEmpty()->and(TelegramUser::first()->company)->toBe('Ресторан «Схід»');
});

it('lets the venue question be skipped', function () {
    tgSay('/samples');
    tgShare('+380501234567');
    tgSay('Пропустити');

    expect(Lead::sole()->company)->toBeNull();
});

it('saves a manager request after the contact', function () {
    tgSay('/manager');
    tgShare('+380501234567');

    $lead = Lead::sole();
    expect($lead->type)->toBe(LeadType::Manager)->and($lead->source)->toBe(LeadSource::Bot)->and(tgCalls('sendDocument'))->toBeEmpty();
});

it('works through /start with a lead deep link', function (string $param, LeadType $type) {
    tgSay("/start {$param}");
    tgShare('+380501234567');
    $asksCompany = $type === LeadType::Sample;
    $asksCompany && tgSay('Пропустити');

    expect(Lead::sole()->type)->toBe($type);
})->with([['price', LeadType::Price], ['samples', LeadType::Sample], ['manager', LeadType::Manager]]);

it('remembers a number shared outside a conversation, but only the sender\'s own', function () {
    tgShare('+380501112233');
    expect(TelegramUser::where('telegram_id', 100)->value('phone'))->toBe('+380501112233');

    tgBot()->hearMessage(['contact' => ['phone_number' => '+380999999999', 'first_name' => 'Хтось', 'user_id' => 999], 'from' => tgUser(100), 'chat' => ['id' => 100, 'type' => 'private']])->reply();
    expect(TelegramUser::where('telegram_id', 100)->value('phone'))->toBe('+380501112233');
});

// ---------- /connect and recipients ----------

it('connects a group when the admin writes /connect there', function () {
    TelegramAdmin::create(['telegram_id' => 100, 'name' => 'Власник']);

    tgSay('/connect', 100, ['id' => -1001, 'type' => 'supergroup', 'title' => 'Менеджери']);

    $r = TelegramRecipient::sole();
    expect($r->chat_id)->toBe(-1001)->and($r->title)->toBe('Менеджери')->and($r->type)->toBe('group')->and($r->active)->toBeTrue()->and($r->lead_types)->toBeNull()
        ->and(tgCalls('sendMessage')[0]['text'])->toBe('Групу підключено: сюди надходитимуть нові заявки.');
});

it('refreshes a connected group without switching it back on or touching its filters', function () {
    TelegramAdmin::create(['telegram_id' => 100]);
    TelegramRecipient::create(['chat_id' => -1001, 'title' => 'Стара назва', 'type' => 'group', 'active' => false, 'lead_types' => ['price']]);

    tgSay('/connect', 100, ['id' => -1001, 'type' => 'group', 'title' => 'Нова назва']);

    $r = TelegramRecipient::sole();
    expect($r->title)->toBe('Нова назва')->and($r->active)->toBeFalse()->and($r->lead_types)->toBe(['price']);
});

it('ignores /connect from someone who is not a bot admin', function () {
    tgSay('/connect', 555, ['id' => -1001, 'type' => 'group', 'title' => 'Чужа група']);

    expect(TelegramRecipient::count())->toBe(0)->and(tgCalls('sendMessage')[0]['text'])->toBe('Ця команда доступна лише адміністраторам бота.');
});

it('refuses /connect in a private chat', function () {
    TelegramAdmin::create(['telegram_id' => 100]);

    tgSay('/connect');

    expect(TelegramRecipient::count())->toBe(0)->and(tgCalls('sendMessage')[0]['text'])->toBe('Команда /connect працює лише в групі.');
});

it('makes an admin\'s private chat a recipient on /start, once', function () {
    TelegramAdmin::create(['telegram_id' => 100]);

    tgSay('/start');
    TelegramRecipient::first()->update(['active' => false]);
    tgSay('/start');

    $r = TelegramRecipient::sole();
    expect($r->chat_id)->toBe(100)->and($r->type)->toBe('private')->and($r->active)->toBeFalse();
});

it('follows a group that became a supergroup', function () {
    TelegramRecipient::create(['chat_id' => -111, 'title' => 'Група', 'type' => 'group']);

    tgBot()->hearMessage(['migrate_to_chat_id' => -1009999, 'from' => tgUser(1), 'chat' => ['id' => -111, 'type' => 'group']])->reply();

    expect(TelegramRecipient::sole()->chat_id)->toBe(-1009999);
});

it('switches a recipient off when the bot is removed from the group', function () {
    TelegramRecipient::create(['chat_id' => -111, 'type' => 'group']);

    tgBot()->hearUpdateType(UpdateType::MY_CHAT_MEMBER, [
        'chat' => ['id' => -111, 'type' => 'group'], 'from' => tgUser(1), 'date' => 1703892479,
        'old_chat_member' => ['status' => 'member', 'user' => tgUser(1)],
        'new_chat_member' => ['status' => 'kicked', 'user' => tgUser(1), 'until_date' => 0],
    ])->reply();

    expect(TelegramRecipient::sole()->active)->toBeFalse();
});
