<?php

use App\Enums\ProductStatus;
use App\Mcp\Tools\Catalog\Archive;
use App\Mcp\Tools\Catalog\CatalogAudit;
use App\Mcp\Tools\Catalog\CreateCategory;
use App\Mcp\Tools\Catalog\CreateProduct;
use App\Mcp\Tools\Catalog\GetProduct;
use App\Mcp\Tools\Catalog\ListCategories;
use App\Mcp\Tools\Catalog\ListProducts;
use App\Mcp\Tools\Catalog\ProductRevert;
use App\Mcp\Tools\Catalog\Publish;
use App\Mcp\Tools\Catalog\Reorder;
use App\Mcp\Tools\Catalog\Restore;
use App\Mcp\Tools\Catalog\SetVariants;
use App\Mcp\Tools\Catalog\Unpublish;
use App\Mcp\Tools\Catalog\UpdateCategory;
use App\Mcp\Tools\Catalog\UpdateProduct;
use App\Models\Category;
use App\Models\McpAuditLog;
use App\Models\Product;
use App\Models\ProductRevision;
use Database\Seeders\CatalogSeeder;

beforeEach(fn () => $this->seed(CatalogSeeder::class));

// ---------- reading ----------

it('lists products with filters and pages through them with a cursor', function () {
    $ids = Product::orderBy('id')->pluck('id');
    $first = mcp()->tool(ListProducts::class, ['limit' => 2])->assertOk()->assertSee('"next_cursor":'.$ids[1])->assertDontSee(Product::find($ids[2])->slug);

    mcp()->tool(ListProducts::class, ['limit' => 2, 'cursor' => $ids[1]])->assertSee(Product::find($ids[2])->slug)->assertDontSee(Product::find($ids[0])->slug);
    mcp()->tool(ListProducts::class, ['search' => Product::first()->slug])->assertSee(Product::first()->slug);
    mcp()->tool(ListProducts::class, ['status' => 'bogus'])->assertHasErrors(['статус']);
    mcp()->tool(ListProducts::class, ['category' => 'no-such'])->assertHasErrors(['no-such']);
});

it('shows one product in full and says clearly when it does not exist', function () {
    $p = Product::first();

    mcp()->tool(GetProduct::class, ['product' => $p->slug])->assertSee([$p->name, 'variants', 'storage_temp']);
    mcp()->tool(GetProduct::class, ['product' => (string) $p->id])->assertSee($p->slug);
    mcp()->tool(GetProduct::class, ['product' => 'nope'])->assertHasErrors(['не знайдено']);
});

it('lists categories with counts', function () {
    mcp()->tool(ListCategories::class)->assertSee(['visible_on_site', Category::first()->slug]);
});

// ---------- creating and changing ----------

it('creates a product as a draft and never publishes it', function () {
    $r = mcp()->tool(CreateProduct::class, ['name' => 'Тестовий кебаб', 'category' => Category::first()->slug, 'composition' => 'м’ясо, сіль'])->assertOk();

    $p = Product::where('name', 'Тестовий кебаб')->sole();
    expect($p->status)->toBe(ProductStatus::Draft)->and($p->slug)->not->toBe('')->and($p->composition)->toBe('м’ясо, сіль');
    $r->assertSee('чернетку');
    $this->get('/product/'.$p->slug)->assertNotFound();
});

it('validates new products in Ukrainian and refuses to set the status directly', function () {
    mcp()->tool(CreateProduct::class, ['category' => Category::first()->slug])->assertHasErrors(['назва']);
    mcp()->tool(CreateProduct::class, ['name' => 'X', 'category' => 'nope'])->assertHasErrors(['не знайдено']);
    mcp()->tool(CreateProduct::class, ['name' => 'X', 'category' => Category::first()->slug, 'hue' => 'red'])->assertHasErrors(['hue']);
    mcp()->tool(CreateProduct::class, ['name' => str_repeat('я', 200), 'category' => Category::first()->slug])->assertHasErrors(['160']);
    mcp()->tool(CreateProduct::class, ['name' => 'X', 'category' => Category::first()->slug, 'slug' => Product::first()->slug])->assertHasErrors(['slug']);

    mcp()->tool(CreateProduct::class, ['name' => 'Y', 'category' => Category::first()->slug, 'status' => 'published']);
    expect(Product::where('name', 'Y')->sole()->status)->toBe(ProductStatus::Draft);
});

it('updates only the given fields, keeps the previous version and can revert it', function () {
    $p = Product::first();
    $old = $p->description;

    mcp()->tool(UpdateProduct::class, ['product' => $p->slug, 'description' => 'Новий опис'])->assertSee('revision_id');

    expect($p->fresh()->description)->toBe('Новий опис')->and($p->fresh()->name)->toBe($p->name);
    $rev = ProductRevision::sole();
    expect($rev->snapshot['product']['description'])->toBe($old)->and($rev->audit_id)->not->toBeNull();

    mcp()->tool(ProductRevert::class, ['revision_id' => $rev->id])->assertOk();
    expect($p->fresh()->description)->toBe($old)->and($rev->fresh()->reverted_at)->not->toBeNull();

    mcp()->tool(ProductRevert::class, ['revision_id' => $rev->id])->assertHasErrors(['вже було застосовано']);
    mcp()->tool(ProductRevert::class, ['revision_id' => 99999])->assertHasErrors(['не знайдено']);
});

it('rejects an update with nothing to change and does not allow editing the status through it', function () {
    $p = Product::first();

    mcp()->tool(UpdateProduct::class, ['product' => $p->slug])->assertHasErrors(['жодного поля']);

    $before = $p->status;
    mcp()->tool(UpdateProduct::class, ['product' => $p->slug, 'status' => 'archived', 'subtitle' => 'x']);
    expect($p->fresh()->status)->toBe($before);
});

it('moves a product to another category and keeps slugs unique', function () {
    $p = Product::first();
    $other = Category::where('id', '!=', $p->category_id)->first();

    mcp()->tool(UpdateProduct::class, ['product' => $p->slug, 'category' => $other->slug])->assertOk();
    expect($p->fresh()->category_id)->toBe($other->id);

    mcp()->tool(UpdateProduct::class, ['product' => $p->slug, 'slug' => Product::where('id', '!=', $p->id)->first()->slug])->assertHasErrors(['slug']);
});

it('replaces the variants as a whole, with one default, and a revert brings the old set back', function () {
    $p = Product::first();
    $old = $p->variants()->pluck('size_label')->all();

    mcp()->tool(SetVariants::class, ['product_id' => $p->slug, 'variants' => [
        ['size_label' => '2 кг', 'pack_note' => '20 шт'], ['size_label' => '500 г', 'sort' => 5],
    ]])->assertOk();

    $now = $p->variants()->get();
    expect($now->pluck('size_label')->all())->toBe(['2 кг', '500 г'])->and($now->where('is_default', true))->toHaveCount(1)->and($now->first()->is_default)->toBeTrue();

    mcp()->tool(ProductRevert::class, ['revision_id' => ProductRevision::latest('id')->value('id')])->assertOk();
    expect($p->variants()->pluck('size_label')->all())->toBe($old);
});

it('validates variants: label required, one default, unique sku, at most 20', function () {
    $p = Product::first();

    mcp()->tool(SetVariants::class, ['product_id' => $p->slug, 'variants' => [['pack_note' => 'x']]])->assertHasErrors(['size_label']);
    mcp()->tool(SetVariants::class, ['product_id' => $p->slug, 'variants' => [['size_label' => 'a', 'is_default' => true], ['size_label' => 'b', 'is_default' => true]]])->assertHasErrors(['default']);
    mcp()->tool(SetVariants::class, ['product_id' => $p->slug, 'variants' => [['size_label' => 'a', 'sku' => 'S1'], ['size_label' => 'b', 'sku' => 'S1']]])->assertHasErrors(['sku']);
    mcp()->tool(SetVariants::class, ['product_id' => $p->slug, 'variants' => array_fill(0, 21, ['size_label' => 'a'])])->assertHasErrors(['20']);
});

it('creates and renames categories and reorders items', function () {
    mcp()->tool(CreateCategory::class, ['name' => 'Нова категорія'])->assertSee('Нова категорія');
    $c = Category::where('name', 'Нова категорія')->sole();
    expect($c->slug)->not->toBe('');

    mcp()->tool(CreateCategory::class, ['name' => 'Нова категорія'])->assertHasErrors(['вже є']);
    mcp()->tool(UpdateCategory::class, ['category' => $c->slug, 'name' => 'Ще нова'])->assertOk();
    expect($c->fresh()->name)->toBe('Ще нова');

    $this->get('/catalog')->assertDontSee('Ще нова');

    mcp()->tool(Reorder::class, ['items' => [['type' => 'category', 'id' => $c->id, 'sort' => 0], ['type' => 'product', 'id' => Product::first()->id, 'sort' => 99]]])->assertOk();
    expect($c->fresh()->sort)->toBe(0)->and(Product::first()->sort)->toBe(99);
    mcp()->tool(Reorder::class, ['items' => [['type' => 'category', 'id' => 99999, 'sort' => 1]]])->assertHasErrors(['99999']);
});

// ---------- publishing ----------

it('shows only a preview of a publication without confirm, and publishes with confirm=true', function () {
    $p = Product::first();
    $p->update(['status' => ProductStatus::Draft]);

    mcp()->tool(Publish::class, ['ids' => [$p->slug]])->assertSee(['Буде опубліковано', 'confirm=true']);
    expect($p->fresh()->status)->toBe(ProductStatus::Draft);

    mcp()->tool(Publish::class, ['ids' => [$p->slug], 'confirm' => false])->assertSee('Буде опубліковано');
    expect($p->fresh()->status)->toBe(ProductStatus::Draft);

    mcp()->tool(Publish::class, ['ids' => [$p->slug], 'confirm' => true])->assertSee('Опубліковано: 1');
    expect($p->fresh()->status)->toBe(ProductStatus::Published);
});

it('warns about incomplete products in the publication preview', function () {
    $p = Product::first();
    $p->update(['status' => ProductStatus::Draft, 'composition' => null, 'ingredients' => null, 'needs_confirmation' => ['склад']]);
    $p->variants()->delete();

    mcp()->tool(Publish::class, ['ids' => [$p->slug]])->assertSee(['немає складу', 'немає активного фасування', 'потребує уточнення']);
});

it('unpublishes, archives and restores without deleting anything', function () {
    $p = Product::first();
    $count = Product::count();

    mcp()->tool(Unpublish::class, ['ids' => [$p->slug]])->assertSee('Знято з публікації: 1');
    expect($p->fresh()->status)->toBe(ProductStatus::Draft);

    mcp()->tool(Archive::class, ['ids' => [$p->slug]])->assertOk();
    expect($p->fresh()->status)->toBe(ProductStatus::Archived);
    $this->get('/product/'.$p->slug)->assertNotFound();

    mcp()->tool(Restore::class, ['ids' => [$p->slug]])->assertOk();
    expect($p->fresh()->status)->toBe(ProductStatus::Draft)->and(Product::count())->toBe($count);

    $r = mcp()->tool(Publish::class, ['ids' => [$p->slug, Product::skip(1)->first()->slug], 'confirm' => true]);
    $r->assertSee('Опубліковано: 1');
});

it('skips products in the wrong status and says why', function () {
    $published = Product::published()->first();

    mcp()->tool(Restore::class, ['ids' => [$published->slug]])->assertSee(['пропущено: 1', 'зараз']);
    mcp()->tool(Publish::class, ['ids' => [$published->slug], 'confirm' => true])->assertSee('пропущено: 1');
});

it('refuses more than 20 objects per call and empty lists', function () {
    $ids = range(1, 21);

    mcp()->tool(Publish::class, ['ids' => $ids, 'confirm' => true])->assertHasErrors(['не більше 20']);
    mcp()->tool(Archive::class, ['ids' => $ids])->assertHasErrors(['20']);
    mcp()->tool(Reorder::class, ['items' => array_fill(0, 21, ['type' => 'product', 'id' => 1, 'sort' => 1])])->assertHasErrors(['20']);
    mcp()->tool(Unpublish::class, ['ids' => []])->assertHasErrors();
    expect(Product::where('status', ProductStatus::Archived)->count())->toBe(0);
});

it('has no tool that deletes a product, a category or a lead', function () {
    $files = collect(glob(app_path('Mcp/Tools/*/*.php')))->map(fn ($f) => strtolower(basename($f, '.php')));

    expect($files->filter(fn ($n) => str_contains($n, 'delete') || str_contains($n, 'destroy') || str_contains($n, 'remove')))->toBeEmpty();
});

it('reports what needs attention in the catalog', function () {
    $p = Product::first();
    $p->update(['composition' => null, 'ingredients' => null]);

    mcp()->tool(CatalogAudit::class)->assertSee(['no_composition', $p->slug, 'duplicate_names', 'Фото']);
});

it('writes every call to the audit log with the before and after of a change', function () {
    $user = staff();
    $p = Product::first();

    mcp($user)->tool(ListProducts::class);
    mcp($user)->tool(UpdateProduct::class, ['product' => $p->slug, 'subtitle' => 'Новий підзаголовок']);
    mcp($user)->tool(UpdateProduct::class, ['product' => $p->slug]); // fails

    $logs = McpAuditLog::orderBy('id')->get();
    expect($logs->pluck('tool')->all())->toBe(['catalog_list_products', 'catalog_update_product', 'catalog_update_product'])
        ->and($logs->pluck('result')->all())->toBe(['ok', 'ok', 'error'])
        ->and($logs[0]->writes)->toBeFalse()->and($logs[1]->writes)->toBeTrue()
        ->and($logs[1]->user_id)->toBe($user->id)
        ->and($logs[1]->changes['after']['product']['subtitle'])->toBe('Новий підзаголовок')
        ->and($logs[1]->changes['before']['product']['subtitle'])->toBe($p->subtitle);
});
