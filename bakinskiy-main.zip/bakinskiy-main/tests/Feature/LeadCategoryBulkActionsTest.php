<?php

use App\Enums\LeadStatus;
use App\Enums\UserRole;
use App\Filament\Resources\Categories\Pages\ListCategories;
use App\Filament\Resources\Leads\Pages\ListLeads;
use App\Models\Category;
use App\Models\Lead;
use App\Models\Product;
use App\Models\User;
use Database\Seeders\CatalogSeeder;
use Illuminate\Support\Collection;
use Livewire\Livewire;

beforeEach(function () {
    $this->actingAs($this->manager = User::factory()->role(UserRole::Editor)->create());
});

function makeLeads(int $n = 3): Collection
{
    return collect(range(1, $n))->map(fn ($i) => Lead::create(['company' => "Заклад $i", 'contact_name' => 'Іван', 'phone' => '0501234567']));
}

it('changes the status of selected leads only', function () {
    $leads = makeLeads();

    Livewire::test(ListLeads::class)->callTableBulkAction('status', $leads->take(2), data: ['status' => 'in_progress'])->assertNotified();

    expect(Lead::where('status', LeadStatus::InProgress)->count())->toBe(2)->and($leads->last()->fresh()->status)->toBe(LeadStatus::New);
});

it('rejects an unknown lead status', function () {
    $leads = makeLeads(1);

    Livewire::test(ListLeads::class)->callTableBulkAction('status', $leads, data: ['status' => 'nope'])->assertHasTableBulkActionErrors(['status']);

    expect($leads->first()->fresh()->status)->toBe(LeadStatus::New);
});

it('assigns a manager to selected leads', function () {
    $leads = makeLeads();

    Livewire::test(ListLeads::class)->callTableBulkAction('manager', $leads->take(2), data: ['manager_id' => $this->manager->id]);

    expect(Lead::where('manager_id', $this->manager->id)->count())->toBe(2);
});

it('deletes selected leads in bulk', function () {
    $leads = makeLeads();

    Livewire::test(ListLeads::class)->callTableBulkAction('delete', $leads->take(1));

    expect(Lead::count())->toBe(2);
});

it('deletes empty categories and keeps those that still have products', function () {
    $this->seed(CatalogSeeder::class);
    $empty = Category::create(['name' => 'Порожня', 'slug' => 'porozhnia', 'sort' => 9]);
    $used = Category::where('slug', 'tisto')->first();

    Livewire::test(ListCategories::class)->callTableBulkAction('delete', Category::whereKey([$empty->id, $used->id])->get())->assertNotified();

    expect(Category::where('slug', 'porozhnia')->exists())->toBeFalse()
        ->and(Category::where('slug', 'tisto')->exists())->toBeTrue()
        ->and(Product::where('slug', 'mlynci')->exists())->toBeTrue();
});
