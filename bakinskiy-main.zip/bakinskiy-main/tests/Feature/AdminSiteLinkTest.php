<?php

use App\Enums\UserRole;
use App\Filament\Resources\Products\Pages\EditProduct;
use App\Models\Product;
use App\Models\User;
use Database\Seeders\CatalogSeeder;
use Livewire\Livewire;

beforeEach(function () {
    $this->seed(CatalogSeeder::class);
    $this->actingAs(User::factory()->role(UserRole::Admin)->create());
});

it('links from every admin page to the site in a new tab', function (string $url) {
    $html = $this->get($url)->assertOk()->getContent();

    expect($html)->toContain('Перейти на сайт')->and($html)->toMatch('#href="'.preg_quote(url('/'), '#').'"[^>]*target="_blank"|target="_blank"[^>]*href="'.preg_quote(url('/'), '#').'"#');
})->with(['/admin', '/admin/products', '/admin/leads', '/admin/categories', '/admin/manage-settings']);

it('offers "view on site" for a published product pointing at its page', function () {
    $product = Product::where('slug', 'plov')->first();

    Livewire::test(EditProduct::class, ['record' => 'plov'])
        ->assertActionVisible('view')
        ->assertActionHasUrl('view', route('product', 'plov'));
});

it('hides "view on site" for a draft product', function () {
    Product::where('slug', 'plov')->update(['status' => 'draft']);

    Livewire::test(EditProduct::class, ['record' => 'plov'])->assertActionHidden('view');
});
