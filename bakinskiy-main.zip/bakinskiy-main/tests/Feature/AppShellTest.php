<?php

use App\Models\Product;
use App\Models\Setting;
use App\Support\Plural;
use Database\Seeders\CatalogSeeder;
use Tests\TestCase;

const IPHONE = 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148';
const DESKTOP = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Safari/605.1.15';

beforeEach(fn () => $this->seed(CatalogSeeder::class));

function phone(): TestCase
{
    return test()->withHeader('User-Agent', IPHONE);
}

// ---------- which layout ----------

it('gives phones the app shell and desktops the site', function () {
    phone()->get('/')->assertOk()->assertSee('data-ui="app"', false)->assertSee('class="tabbar', false);
    test()->withHeader('User-Agent', DESKTOP)->get('/')->assertOk()->assertSee('data-ui="full"', false)->assertDontSee('class="tabbar', false);
});

it('lets the ui cookie decide over the User-Agent', function () {
    test()->withHeader('User-Agent', DESKTOP)->withUnencryptedCookie('ui', 'app')->get('/')->assertSee('data-ui="app"', false);
    phone()->withUnencryptedCookie('ui', 'full')->get('/')->assertSee('data-ui="full"', false);
});

it('lets an explicit pin override the cookie', function () {
    phone()->withUnencryptedCookie('ui', 'app')->withUnencryptedCookie('ui_pin', 'full')->get('/')->assertSee('data-ui="full"', false);
    test()->withHeader('User-Agent', DESKTOP)->withUnencryptedCookie('ui', 'full')->withUnencryptedCookie('ui_pin', 'app')->get('/')->assertSee('data-ui="app"', false);
});

it('ignores garbage in the mode cookies', function () {
    phone()->withUnencryptedCookie('ui', 'banana')->get('/')->assertSee('data-ui="app"', false);
});

it('ships the before-first-paint mode script in both layouts', function () {
    foreach ([phone(), test()->withHeader('User-Agent', DESKTOP)] as $client) {
        $client->get('/')->assertSee("rendered = '", false)->assertSee('ui_pin', false)->assertSee("'ui=' + want", false);
    }
});

it('tells caches the page depends on cookie and user agent', function () {
    expect(phone()->get('/')->headers->get('Vary'))->toContain('Cookie')->toContain('User-Agent');
});

it('does not change the desktop layout: no shell assets, same header', function () {
    test()->withHeader('User-Agent', DESKTOP)->get('/produkciya')->assertOk()
        ->assertSee('class="hdr"', false)->assertDontSee('app-shell', false)->assertSee('data-ui-switch="app"', false);
});

// ---------- routes ----------

it('renders every app screen', function (string $url, string $kind) {
    phone()->get($url)->assertOk()->assertSee('data-kind="'.$kind.'"', false)->assertSee('id="sheet-order"', false)
        ->assertSee('id="sheet-more"', false)->assertSee('id="sheet-filter"', false);
})->with([
    ['/', 'home'], ['/produkciya', 'catalog'], ['/produkciya/plov', 'product'],
    ['/kontakty', 'contacts'], ['/dlya-horeca', 'horeca'], ['/vyrobnytstvo', 'factory'],
]);

it('hides the tab bar on detail screens only', function (string $url, bool $hidden) {
    $html = phone()->get($url)->getContent();
    expect(str_contains($html, 'class="tabbar hide"'))->toBe($hidden);
})->with([['/', false], ['/produkciya', false], ['/kontakty', false], ['/produkciya/plov', true], ['/dlya-horeca', true], ['/vyrobnytstvo', true]]);

it('sends desktop visitors of phone-only pages home, and 404s unknown products in the app', function () {
    foreach (['/kontakty', '/dlya-horeca', '/vyrobnytstvo'] as $url) {
        test()->withHeader('User-Agent', DESKTOP)->get($url)->assertRedirect(route('home'));
    }
    phone()->get('/produkciya/nope')->assertNotFound();
});

it('serves an offline page that does not depend on built assets', function () {
    $html = test()->get('/offline')->assertOk()->getContent();

    expect($html)->toContain('Немає з’єднання')->not->toContain('/build/');
});

// ---------- screens ----------

it('lists published products in the app catalog with filter data', function () {
    Product::where('slug', 'mlynci')->update(['status' => 'draft']);
    $html = phone()->get('/produkciya')->assertOk()->getContent();

    expect($html)->toContain('3 позиції')->toContain('data-cat="gryl"')->toContain('data-search="')
        ->not->toContain('Млинці')->toContain('data-c="gryl"')->not->toContain('data-c="tisto"');
});

it('derives the meat base used by the catalog filter', function () {
    $p = new Product(['name' => 'Долма', 'subtitle' => 'з телятиною та бараниною', 'composition' => 'фарш']);
    expect($p->bases)->toBe(['телятина', 'баранина']);

    expect((new Product(['name' => 'Млинець', 'composition' => 'борошно, яйця, молоко']))->bases)->toBe(['без м’яса'])
        ->and((new Product(['name' => 'Плов', 'composition' => 'рис, м’ясо']))->bases)->toBe([])
        ->and((new Product(['name' => 'Курка', 'full_name' => 'м’ясо курки']))->bases)->toBe(['курка']);
});

it('shows the product screen: sizes, price block, accordion, sticky order bar', function () {
    $product = Product::where('slug', 'plov')->first();
    $html = phone()->get('/produkciya/plov')->getContent();

    expect($html)->toContain('data-sz="1 кг" aria-pressed="true"')->toContain('data-sz="3 кг"')
        ->toContain('Ціна — за запитом')->toContain('<summary>Склад')->toContain('<summary>Характеристики')
        ->toContain('<summary>Приготування')->toContain('data-product="'.$product->id.'"')
        ->toContain('class="abar"')->toContain('data-pack-weight');
});

it('shows cooking steps when filled and the placeholder text otherwise', function () {
    phone()->get('/produkciya/plov')->assertSee('Розігрів')->assertDontSee('з’являться найближчим часом');

    Product::where('slug', 'plov')->update(['cooking_steps' => null]);
    phone()->get('/produkciya/plov')->assertSee('Рекомендації з приготування з’являться найближчим часом.');
});

it('handles a product without weight', function () {
    Product::where('slug', 'plov')->first()->variants()->delete();

    phone()->get('/produkciya/plov')->assertOk()->assertSee('Фасування уточнюється.')->assertDontSee('data-sz=', false);
    phone()->get('/produkciya')->assertSee('ФАСУВАННЯ — УТОЧНЮЄТЬСЯ');
});

it('follows the price mode setting on the product screen', function (string $mode, string $text) {
    Setting::put('price_mode', $mode);
    phone()->get('/produkciya/plov')->assertSee($text);
})->with([['ask', 'Ціна — за запитом'], ['from', 'від ХХХ ₴'], ['login', 'Ціни для партнерів']]);

it('keeps the SEO tags on app screens', function () {
    phone()->get('/produkciya/plov')->assertSee('<link rel="canonical"', false)->assertSee('og:title', false)
        ->assertSee('"@type":"Product"', false)->assertSee('name="theme-color" content="#0b0906"', false);
});

it('shows only the contact rows that have data', function () {
    $html = phone()->get('/kontakty')->assertOk()->getContent();
    expect($html)->toContain('Залишити заявку')->not->toContain('Зателефонувати')->not->toContain('mailto:');

    Setting::put('contact_phone', '+380 50 123 45 67');
    Setting::put('contact_email', 'hello@bakinskybulvar.com');
    Setting::put('contact_hours', 'пн–пт, 9:00–18:00');
    config(['bakinsky.telegram.bot_username' => '@bakinsky_bot']);

    phone()->get('/kontakty')->assertSee('href="tel:+380501234567"', false)->assertSee('mailto:hello@bakinskybulvar.com', false)
        ->assertSee('пн–пт, 9:00–18:00')->assertSee('https://t.me/bakinsky_bot', false);
});

it('offers the full-version link and hides Telegram until a bot is configured', function () {
    phone()->get('/')->assertSee('data-ui-switch="full"', false)->assertDontSee('t.me/', false);
});

it('pluralises in Ukrainian', function () {
    $forms = ['позиція', 'позиції', 'позицій'];
    expect([1, 2, 4, 5, 11, 12, 14, 21, 22, 25, 101, 111])->each->toBeInt();
    expect(array_map(fn ($n) => Plural::uk($n, $forms), [1, 2, 4, 5, 11, 12, 14, 21, 22, 25, 101, 111]))
        ->toBe(['позиція', 'позиції', 'позиції', 'позицій', 'позицій', 'позицій', 'позицій', 'позиція', 'позиції', 'позицій', 'позиція', 'позицій']);
});

// ---------- PWA ----------

it('ships a service worker with an offline fallback and a valid manifest', function () {
    $sw = file_get_contents(public_path('sw.js'));

    expect($sw)->toContain("const OFFLINE = '/offline'")->toContain("addEventListener('fetch'")->toContain('/build/')->toContain('admin|livewire');

    $m = json_decode(file_get_contents(public_path('manifest.webmanifest')), true);
    expect($m['name'])->toBe('Бакинський Бульвар')->and($m['theme_color'])->toBe('#0b0906');
    foreach ($m['icons'] as $icon) {
        expect(public_path(ltrim($icon['src'], '/')))->toBeFile();
    }
});

it('links the manifest and registers the worker from the app shell', function () {
    phone()->get('/')->assertSee('rel="manifest" href="/manifest.webmanifest"', false)
        ->assertSee('viewport-fit=cover', false)->assertSee('apple-mobile-web-app-capable', false);
    expect(file_get_contents(resource_path('js/shell/pwa.js')))->toContain("register('/sw.js'");
});
