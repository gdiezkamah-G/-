<?php

use App\Actions\CreateLead;
use App\Enums\LeadSource;
use App\Enums\LeadStatus;
use App\Enums\LeadType;
use App\Jobs\SendLeadMessage;
use App\Jobs\SendLeadNotification;
use App\Models\Lead;
use App\Models\Product;
use App\Models\TelegramLeadMessage;
use App\Models\TelegramRecipient;
use App\Models\TelegramUser;
use App\Services\Telegram\LeadNotifier;
use App\Services\Telegram\TelegramSettings;
use Database\Seeders\CatalogSeeder;
use Illuminate\Support\Facades\Queue;
use SergiX44\Nutgram\Telegram\Exceptions\TelegramException;

beforeEach(function () {
    tgConfigure();
    $this->seed(CatalogSeeder::class);
});

function newLead(LeadType $type = LeadType::Price, array $extra = [], ?TelegramUser $user = null, LeadSource $source = LeadSource::Bot): Lead
{
    return app(CreateLead::class)->handle(array_merge([
        'company' => 'Кафе «Схід»', 'contact_name' => 'Іван Тест', 'phone' => '+380501234567', 'comment' => 'Дзвонити після 12',
    ], $extra), $type, $source, $user);
}

// ---------- who gets a lead ----------

it('sends a new lead to every active recipient whose lead types match', function () {
    $all = TelegramRecipient::create(['chat_id' => -1, 'title' => 'Усі', 'type' => 'group', 'lead_types' => []]);
    $price = TelegramRecipient::create(['chat_id' => -2, 'title' => 'Прайси', 'type' => 'group', 'lead_types' => ['price']]);
    TelegramRecipient::create(['chat_id' => -3, 'title' => 'Замовлення', 'type' => 'group', 'lead_types' => ['order', 'sample']]);
    TelegramRecipient::create(['chat_id' => -4, 'title' => 'Вимкнена', 'type' => 'group', 'active' => false]);
    TelegramRecipient::create(['chat_id' => 7, 'title' => 'Власник', 'type' => 'private', 'lead_types' => null]);

    $lead = newLead(LeadType::Price);

    expect(collect(tgCalls('sendMessage'))->pluck('chat_id')->sort()->values()->all())->toBe([-2, -1, 7])
        ->and(TelegramLeadMessage::where('lead_id', $lead->id)->count())->toBe(3);

    $order = newLead(LeadType::Order);
    expect(TelegramLeadMessage::where('lead_id', $order->id)->pluck('chat_id')->sort()->values()->all())->toBe([-3, -1, 7]);
});

it('treats an empty lead_types list as "every type"', function (?array $types, bool $gets) {
    $r = new TelegramRecipient(['lead_types' => $types]);

    expect($r->wants(LeadType::Manager))->toBe($gets);
})->with([[null, true], [[], true], [['manager'], true], [['price', 'order'], false]]);

it('posts nothing when nobody is connected', function () {
    newLead();

    expect(tgCalls('sendMessage'))->toBeEmpty();
});

// ---------- what the message looks like ----------

it('describes the lead: type, name, phone, venue, comment, product, source, status', function () {
    TelegramRecipient::create(['chat_id' => -1, 'type' => 'group']);
    $product = Product::where('slug', 'plov')->first();

    newLead(LeadType::Order, ['product_id' => $product->id, 'volume_kg' => 50]);

    $text = tgCalls('sendMessage')[0]['text'];
    expect($text)->toContain('<b>Нова заявка: Заявка</b>')->toContain('Ім’я: Іван Тест')->toContain('Телефон: +380501234567')
        ->toContain('Заклад: Кафе «Схід»')->toContain('Коментар: Дзвонити після 12')->toContain('Позиція: Плов по-бакинськи')
        ->toContain('Обсяг: 50 кг')->toContain('Джерело: Бот')->toContain('Статус: Нова');
    expect(tgCalls('sendMessage')[0]['parse_mode'])->toBe('HTML');
});

it('escapes HTML in what the client typed', function () {
    TelegramRecipient::create(['chat_id' => -1, 'type' => 'group']);

    newLead(extra: ['company' => '<b>Хакер</b> & Ко']);

    expect(tgCalls('sendMessage')[0]['text'])->toContain('&lt;b&gt;Хакер&lt;/b&gt; &amp; Ко')->not->toContain('<b>Хакер');
});

it('hides the blocks switched off in the admin', function () {
    TelegramRecipient::create(['chat_id' => -1, 'type' => 'group']);
    app(TelegramSettings::class)->save('notification', ['phone' => false, 'company' => false, 'comment' => false, 'status' => false, 'source' => false, 'name' => false, 'type' => false]);

    newLead();

    $text = tgCalls('sendMessage')[0]['text'];
    expect($text)->toBe('<b>Нова заявка</b>');
});

it('shows the right source for the site and the Mini App', function (LeadSource $source, string $label) {
    TelegramRecipient::create(['chat_id' => -1, 'type' => 'group']);

    newLead(source: $source);

    expect(tgCalls('sendMessage')[0]['text'])->toContain("Джерело: {$label}");
})->with([[LeadSource::Site, 'Сайт'], [LeadSource::MiniApp, 'Mini app'], [LeadSource::Bot, 'Бот']]);

it('puts take / close / write buttons under the message', function () {
    TelegramRecipient::create(['chat_id' => -1, 'type' => 'group']);
    $user = TelegramUser::create(['telegram_id' => 100, 'first_name' => 'Іван', 'username' => 'ivan']);

    $lead = newLead(user: $user);

    $rows = tgCalls('sendMessage')[0]['reply_markup']['inline_keyboard'];
    expect($rows[0][0])->toMatchArray(['text' => 'Взяти в роботу', 'callback_data' => "lead:take:{$lead->id}"])
        ->and($rows[0][1])->toMatchArray(['text' => 'Закрити', 'callback_data' => "lead:close:{$lead->id}"])
        ->and($rows[1][0])->toMatchArray(['text' => 'Написати клієнту', 'url' => 'https://t.me/ivan']);
});

it('links to the client by user id, then by phone', function () {
    TelegramRecipient::create(['chat_id' => -1, 'type' => 'group']);

    newLead(user: TelegramUser::create(['telegram_id' => 100, 'first_name' => 'Без юзернейма']));
    expect(tgCalls('sendMessage')[0]['reply_markup']['inline_keyboard'][1][0]['url'])->toBe('tg://user?id=100');

    newLead(source: LeadSource::Site);
    expect(tgCalls('sendMessage')[1]['reply_markup']['inline_keyboard'][1][0]['url'])->toBe('https://t.me/+380501234567');
});

it('drops the write button when it is switched off', function () {
    TelegramRecipient::create(['chat_id' => -1, 'type' => 'group']);
    app(TelegramSettings::class)->save('notification', ['write_button' => false]);

    newLead();

    expect(tgCalls('sendMessage')[0]['reply_markup']['inline_keyboard'])->toHaveCount(1);
});

// ---------- buttons change the status ----------

function postedLead(array $chats = [-1001]): Lead
{
    foreach ($chats as $i => $chat) {
        TelegramRecipient::create(['chat_id' => $chat, 'type' => 'group', 'title' => "Група $i"]);
    }

    return newLead();
}

it('takes a lead into work and edits every copy of the message', function () {
    $lead = postedLead([-1001, -1002]);

    tgPress("lead:take:{$lead->id}", -1001, from: 200);

    $lead->refresh();
    expect($lead->status)->toBe(LeadStatus::InProgress)->and($lead->handled_by)->toBe('Іван Тест')->and($lead->handled_at)->not->toBeNull();

    $edits = tgCalls('editMessageText');
    expect($edits)->toHaveCount(2)->and(collect($edits)->pluck('chat_id')->map(fn ($c) => (int) $c)->sort()->values()->all())->toBe([-1002, -1001])
        ->and($edits[0]['text'])->toContain('Взяв(ла) в роботу: Іван Тест')->toContain('Статус: В роботі');
    // "take" is gone, "close" stays
    $buttons = collect($edits[0]['reply_markup']['inline_keyboard'][0])->pluck('text')->all();
    expect($buttons)->toBe(['Закрити']);
    expect(tgCalls('answerCallbackQuery')[0]['text'])->toBe('Взято в роботу.');
});

it('closes a lead and removes the action buttons', function () {
    $lead = postedLead();

    tgPress("lead:close:{$lead->id}", -1001);

    expect($lead->fresh()->status)->toBe(LeadStatus::Closed)
        ->and(tgCalls('editMessageText')[0]['text'])->toContain('Закрив(ла): Іван Тест')
        ->and(collect(tgCalls('editMessageText')[0]['reply_markup']['inline_keyboard'])->flatten(1)->pluck('text')->all())->toBe(['Написати клієнту']);
});

it('does not reopen a closed lead or repeat a status', function () {
    $lead = postedLead();
    tgPress("lead:close:{$lead->id}", -1001);

    tgPress("lead:take:{$lead->id}", -1001);
    expect($lead->fresh()->status)->toBe(LeadStatus::Closed)->and(tgCalls('answerCallbackQuery')[0]['text'])->toBe('Уже оброблено.')->and(tgCalls('editMessageText'))->toBeEmpty();
});

it('ignores a button pressed under a message that is not a copy of that lead', function (string $data, int $chat) {
    $lead = postedLead();

    tgPress(str_replace('{id}', (string) $lead->id, $data), $chat);

    expect($lead->fresh()->status)->toBe(LeadStatus::New)->and(tgCalls('answerCallbackQuery')[0]['text'])->toBe('Заявку не знайдено.');
})->with([['lead:take:{id}', -9999], ['lead:take:99999', -1001]]);

it('ignores an unknown button action', function () {
    $lead = postedLead();

    tgPress("lead:delete:{$lead->id}", -1001);

    expect($lead->fresh()->status)->toBe(LeadStatus::New);
});

it('shows the new status in the admin too (same database row)', function () {
    $lead = postedLead();

    tgPress("lead:take:{$lead->id}", -1001);

    expect(Lead::find($lead->id)->status->getLabel())->toBe('В роботі');
});

// ---------- failures must not reach the client ----------

it('queues the notification instead of sending it while the client waits', function () {
    Queue::fake();
    TelegramRecipient::create(['chat_id' => -1, 'type' => 'group']);

    $lead = newLead();

    Queue::assertPushed(SendLeadNotification::class, fn ($job) => $job->lead->is($lead));
    expect($lead->exists)->toBeTrue()->and(tgCalls('sendMessage'))->toBeEmpty();
});

it('fans out one retrying job per recipient', function () {
    TelegramRecipient::create(['chat_id' => -1, 'type' => 'group']);
    TelegramRecipient::create(['chat_id' => -2, 'type' => 'group']);
    $lead = Lead::create(['company' => 'К', 'contact_name' => 'І', 'phone' => '0501234567', 'type' => 'order']);
    Queue::fake();

    (new SendLeadNotification($lead))->handle(app(LeadNotifier::class));

    Queue::assertPushed(SendLeadMessage::class, 2);
    $job = new SendLeadMessage($lead->id, 1);
    expect($job->tries)->toBe(5)->and($job->backoff())->toBe([10, 30, 120, 600]);
});

it('lets the job fail (so the queue retries) when Telegram refuses, without losing the lead', function () {
    $lead = Lead::create(['company' => 'К', 'contact_name' => 'І', 'phone' => '0501234567', 'type' => 'order']);
    $recipient = TelegramRecipient::create(['chat_id' => -1, 'type' => 'group']);
    tgBot()->willReceive([], ok: false);

    expect(fn () => (new SendLeadMessage($lead->id, $recipient->id))->handle(tgBot(), app(LeadNotifier::class)))
        ->toThrow(TelegramException::class);
    expect(Lead::find($lead->id))->not->toBeNull()->and(TelegramLeadMessage::count())->toBe(0);
});

it('does not post to a recipient that was switched off after the job was queued', function () {
    $lead = Lead::create(['company' => 'К', 'contact_name' => 'І', 'phone' => '0501234567', 'type' => 'order']);
    $recipient = TelegramRecipient::create(['chat_id' => -1, 'type' => 'group', 'active' => false]);

    (new SendLeadMessage($lead->id, $recipient->id))->handle(tgBot(), app(LeadNotifier::class));

    expect(tgCalls('sendMessage'))->toBeEmpty();
});

it('skips Telegram entirely when the bot token is not set', function () {
    config(['nutgram.token' => null]);
    TelegramRecipient::create(['chat_id' => -1, 'type' => 'group']);
    $lead = Lead::create(['company' => 'К', 'contact_name' => 'І', 'phone' => '0501234567', 'type' => 'order']);
    Queue::fake();

    (new SendLeadNotification($lead))->handle(app(LeadNotifier::class));

    Queue::assertNotPushed(SendLeadMessage::class);
});
