<?php

use App\Enums\ProductStatus;
use App\Enums\UserRole;
use App\Jobs\WarmPriceList;
use App\Models\Category;
use App\Models\Product;
use App\Models\Setting;
use App\Models\TelegramAdmin;
use App\Models\User;
use App\Services\Telegram\TelegramSettings;
use App\Services\Telegram\WebhookInstaller;
use Database\Seeders\CatalogSeeder;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Queue;

beforeEach(function () {
    config([
        'bakinsky.admin' => ['email' => 'boss@example.test', 'name' => null, 'password' => 'long-enough-password', 'reset_password' => false],
        'bakinsky.catalog_import' => 'draft',
        'bakinsky.telegram.token' => null, 'nutgram.token' => null, 'bakinsky.telegram.webhook_secret' => null, 'bakinsky.telegram.admin_ids' => [],
        'app.url' => 'https://bakinskybulvar.com',
    ]);
});

function tgOn(): void
{
    tgConfigure();
    config(['app.url' => 'https://bakinskybulvar.com']);
}

// ---------- the whole first run ----------

it('sets everything up on an empty database without a manual step', function () {
    tgOn();
    config(['bakinsky.telegram.admin_ids' => ['111', '222'], 'bakinsky.catalog_import' => 'publish']);

    $this->artisan('app:bootstrap')
        ->expectsOutputToContain('[OK] Адмін із ADMIN_*')->expectsOutputToContain('[OK] Адміни Telegram')
        ->expectsOutputToContain('[OK] Каталог')->expectsOutputToContain('[OK] Telegram webhook')->assertSuccessful();

    expect(User::where('email', 'boss@example.test')->sole()->role)->toBe(UserRole::Admin)
        ->and(TelegramAdmin::pluck('telegram_id')->sort()->values()->all())->toBe([111, 222])
        ->and(Product::count())->toBe(14)->and(Category::count())->toBe(5)
        ->and(Product::where('status', ProductStatus::Published)->count())->toBe(14)
        ->and(tgCalls('setWebhook'))->toHaveCount(1)->and(Setting::get('bootstrap_at'))->not->toBeNull();
});

it('is safe to run again and again: nothing is duplicated or overwritten', function () {
    tgOn();
    config(['bakinsky.telegram.admin_ids' => ['111']]);
    $this->artisan('app:bootstrap')->assertSuccessful();

    // edits made in the admin after the first run
    Product::where('slug', 'plov-solodkyi')->update(['name' => 'Мій солодкий плов', 'status' => 'published']);
    User::where('email', 'boss@example.test')->update(['name' => 'Власник']);
    $counts = fn () => [Product::count(), Category::count(), User::count(), TelegramAdmin::count(), DB::table('product_variants')->count()];
    $before = $counts();

    foreach (range(1, 3) as $_) {
        $this->artisan('app:bootstrap')->assertSuccessful();
    }

    expect($counts())->toBe($before)->and(Product::where('slug', 'plov-solodkyi')->first()->name)->toBe('Мій солодкий плов')
        ->and(Product::where('slug', 'plov-solodkyi')->first()->status)->toBe(ProductStatus::Published)
        ->and(User::where('email', 'boss@example.test')->first()->name)->toBe('Власник')
        ->and(Hash::check('long-enough-password', User::where('email', 'boss@example.test')->first()->password))->toBeTrue();
});

// ---------- admin ----------

it('skips the admin without ADMIN_EMAIL / ADMIN_PASSWORD and does not fail on a bad password', function () {
    config(['bakinsky.admin.email' => null]);
    $this->artisan('app:bootstrap')->expectsOutputToContain('[SKIP] Адмін із ADMIN_*')->assertSuccessful();
    expect(User::count())->toBe(0);

    config(['bakinsky.admin' => ['email' => 'a@b.com', 'name' => null, 'password' => 'short', 'reset_password' => false]]);
    $this->artisan('app:bootstrap')->expectsOutputToContain('[WARN] Адмін із ADMIN_*')->assertSuccessful();
    expect(User::count())->toBe(0);
});

// ---------- catalog ----------

it('imports the catalog as drafts by default, publishing only when asked', function (string $mode, int $published) {
    config(['bakinsky.catalog_import' => $mode]);

    $this->artisan('app:bootstrap')->assertSuccessful();

    expect(Product::count())->toBe($mode === 'off' ? 0 : 14)->and(Product::where('status', ProductStatus::Published)->count())->toBe($published);
})->with([['draft', 0], ['publish', 14], ['off', 0]]);

it('never imports into a database that already has products or categories', function (string $existing) {
    $existing === 'product' ? $this->seed(CatalogSeeder::class) : Category::create(['name' => 'Своя', 'slug' => 'svoya', 'sort' => 1]);
    $before = Product::count();

    $this->artisan('app:bootstrap')->expectsOutputToContain('нічого не чіпаю')->assertSuccessful();

    expect(Product::count())->toBe($before)->and(Category::where('slug', 'lyulya-kebab')->exists())->toBeFalse();
})->with(['product', 'category']);

// ---------- Telegram ----------

it('skips Telegram with a clear message when there is no token, secret or https', function (array $config, string $message) {
    config($config);

    $this->artisan('app:bootstrap')->expectsOutputToContain($message)->assertSuccessful();
})->with([
    'no token' => [[], 'TELEGRAM_BOT_TOKEN не задано'],
    'no secret' => [['bakinsky.telegram.token' => '1:T', 'nutgram.token' => '1:T'], 'TELEGRAM_WEBHOOK_SECRET не задано'],
    'no https' => [['bakinsky.telegram.token' => '1:T', 'nutgram.token' => '1:T', 'bakinsky.telegram.webhook_secret' => 's', 'app.url' => 'http://example.com'], 'не https'],
]);

it('sets the webhook once and not again while nothing changed', function () {
    tgOn();

    $this->artisan('app:bootstrap');
    $this->artisan('app:bootstrap')->expectsOutputToContain('Webhook уже встановлено');

    // the fake bot keeps the calls of the whole test
    expect(tgCalls('setWebhook'))->toHaveCount(1)->and(tgCalls('setMyCommands'))->toHaveCount(2)->and(tgCalls('setChatMenuButton'))->toHaveCount(1);
});

it('sets the webhook again when APP_URL, the secret, the token or the menu changes', function (callable $change) {
    tgOn();
    $this->artisan('app:bootstrap');
    expect(tgCalls('setWebhook'))->toHaveCount(1);

    $change();
    $this->artisan('app:bootstrap')->expectsOutputToContain('встановлені');

    expect(tgCalls('setWebhook'))->toHaveCount(2);
})->with([
    'new domain' => [fn () => config(['app.url' => 'https://moved.example'])],
    'new secret' => [fn () => config(['bakinsky.telegram.webhook_secret' => 'another'])],
    'new token' => [fn () => config(['bakinsky.telegram.token' => '999:NEW'])],
    'menu edited' => [fn () => app(TelegramSettings::class)->save('menu', ['button_text' => 'Магазин'])],
]);

it('registers the new domain in the webhook call', function () {
    tgOn();
    config(['app.url' => 'https://moved.example']);

    $this->artisan('app:bootstrap');

    expect(tgCalls('setWebhook')[0]['url'])->toBe('https://moved.example/telegram/webhook')->and(tgCalls('setWebhook')[0]['secret_token'])->toBe('s3cret');
    expect(tgCalls('setChatMenuButton')[0]['menu_button']['web_app']['url'])->toBe('https://moved.example/tg');
});

it('does not fail the start when Telegram refuses, and retries on the next start', function () {
    tgOn();
    tgBot()->willReceive([], ok: false);

    $this->artisan('app:bootstrap')->expectsOutputToContain('[WARN] Telegram webhook')->assertSuccessful();

    expect(Setting::get('tg_webhook_signature'))->toBeNull();
    $this->artisan('app:bootstrap')->expectsOutputToContain('[OK] Telegram webhook')->assertSuccessful();
    expect(Setting::get('tg_webhook_signature'))->not->toBeNull();
});

it('computes a signature that tracks every setting the webhook depends on', function () {
    tgOn();
    $installer = app(WebhookInstaller::class);
    $base = $installer->signature();

    config(['app.url' => 'https://other.example']);
    expect($installer->signature())->not->toBe($base);
    config(['app.url' => 'https://bakinskybulvar.com']);
    expect($installer->signature())->toBe($base);
});

// ---------- price list, queue ----------

it('queues the price list build only when it is needed', function () {
    useTempStorage();
    tgOn();
    Queue::fake();
    config(['bakinsky.catalog_import' => 'publish']);
    $this->artisan('app:bootstrap')->expectsOutputToContain('буде створено у фоні');
    Queue::assertPushed(WarmPriceList::class, 1);

    app(TelegramSettings::class)->save('price', ['mode' => 'upload']);
    $this->artisan('app:bootstrap');
    Queue::assertPushed(WarmPriceList::class, 1);
});

it('asks workers to restart so they pick up the new code', function () {
    Cache::forget('illuminate:queue:restart');

    $this->artisan('app:bootstrap')->expectsOutputToContain('Перезапуск воркера');

    expect(Cache::get('illuminate:queue:restart'))->not->toBeNull();
});

// ---------- workers wait for web ----------

it('lets workers start once the database is migrated', function () {
    $this->artisan('app:wait-ready', ['--timeout' => 1])->expectsOutputToContain('migrations applied')->assertSuccessful();
});

it('keeps workers waiting, then fails clearly, while migrations are pending', function () {
    DB::table('migrations')->where('migration', 'like', '%create_leads%')->delete();

    $this->artisan('app:wait-ready', ['--timeout' => 0])->expectsOutputToContain('Не дочекалися')->assertFailed();
});
