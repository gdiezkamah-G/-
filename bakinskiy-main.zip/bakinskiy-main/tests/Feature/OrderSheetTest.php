<?php

use App\Enums\LeadStatus;
use App\Enums\LeadType;
use App\Enums\UserRole;
use App\Filament\Pages\ManageSettings;
use App\Filament\Resources\Leads\Pages\ListLeads;
use App\Livewire\OrderSheet;
use App\Models\Lead;
use App\Models\Product;
use App\Models\Setting;
use App\Models\User;
use App\Notifications\NewLeadNotification;
use Database\Seeders\CatalogSeeder;
use Illuminate\Support\Facades\Notification;
use Livewire\Livewire;

beforeEach(function () {
    $this->seed(CatalogSeeder::class);
    config(['bakinsky.manager_email' => 'manager@example.test']);
});

function fill($t)
{
    return $t->set('company', 'Кафе «Схід»')->set('contactName', 'Іван')->set('phone', '+380 50 123 45 67');
}

it('validates in Ukrainian and tells the page to show a toast', function () {
    $t = Livewire::test(OrderSheet::class)->call('submit')->assertDispatched('app-toast', message: 'Перевірте виділені поля');

    expect($t->errors()->first('company'))->toBe('Вкажіть назву закладу.')
        ->and($t->errors()->first('contactName'))->toBe('Вкажіть контактну особу.')
        ->and($t->errors()->first('phone'))->toBe('Вкажіть телефон.');
    expect(Lead::count())->toBe(0);
});

it('rejects a malformed phone, volume and unknown product with Ukrainian messages', function () {
    $t = fill(Livewire::test(OrderSheet::class))->set('phone', 'abc')->set('volumeKg', '0')->set('productId', '9999')->call('submit');

    expect($t->errors()->first('phone'))->toContain('Телефон має містити')
        ->and($t->errors()->first('volumeKg'))->toBe('Обсяг має бути не менше 1 кг.')
        ->and($t->errors()->has('productId'))->toBeTrue();

    foreach ($t->errors()->all() as $message) {
        expect($message)->not->toContain('validation.');
    }
});

it('saves a request as a lead with status new and shows the success state', function () {
    Notification::fake();
    $product = Product::where('slug', 'plov')->first();

    fill(Livewire::test(OrderSheet::class)->call('prepare', (string) $product->id, 'order'))
        ->set('volumeKg', '50')->call('submit')->assertHasNoErrors()->assertSet('sent', true)->assertSee('Дякуємо!');

    $lead = Lead::sole();
    expect($lead->type)->toBe(LeadType::Order)->and($lead->status)->toBe(LeadStatus::New)
        ->and($lead->product_id)->toBe($product->id)->and($lead->volume_kg)->toBe(50)->and($lead->company)->toBe('Кафе «Схід»');
    Notification::assertSentOnDemand(NewLeadNotification::class);
});

it('maps the segment to the lead source', function (string $mode, LeadType $expected) {
    fill(Livewire::test(OrderSheet::class)->call('prepare', null, $mode))->call('submit');

    expect(Lead::sole()->type)->toBe($expected);
})->with([['order', LeadType::Order], ['price', LeadType::Price], ['sample', LeadType::Sample]]);

it('switches the segment with setMode and ignores bad values', function () {
    Livewire::test(OrderSheet::class)->call('setMode', 2)->assertSet('mode', 2)->call('setMode', 7)->assertSet('mode', 0);

    fill(Livewire::test(OrderSheet::class))->call('setMode', 1)->call('submit');
    expect(Lead::sole()->type)->toBe(LeadType::Price);
});

it('preselects a published product only', function () {
    $draft = Product::where('slug', 'dolma')->first();
    $draft->update(['status' => 'draft']);
    $live = Product::where('slug', 'plov')->first();

    Livewire::test(OrderSheet::class)->call('prepare', (string) $live->id, 'order')->assertSet('productId', (string) $live->id)
        ->call('prepare', (string) $draft->id, 'order')->assertSet('productId', '');
});

it('starts clean when reopened after a successful request', function () {
    $t = fill(Livewire::test(OrderSheet::class))->call('submit')->assertSet('sent', true);

    $t->call('prepare', null, 'sample')->assertSet('sent', false)->assertSet('company', '')->assertSet('mode', 2);
});

it('drops honeypot submissions silently and rate-limits per IP', function () {
    fill(Livewire::test(OrderSheet::class))->set('website', 'http://spam')->call('submit')->assertSet('sent', true);
    expect(Lead::count())->toBe(0);

    $t = Livewire::test(OrderSheet::class);
    foreach (range(1, 5) as $i) {
        fill($t)->set('company', "Заклад $i")->call('submit')->set('sent', false);
    }
    expect(Lead::count())->toBe(5);

    fill($t)->set('company', 'Шостий')->call('submit')->assertDispatched('app-toast')->assertSet('sent', false);
    expect(Lead::count())->toBe(5);
});

it('renders the sheet markup the page script expects', function () {
    Livewire::test(OrderSheet::class)->assertSee('Заявка')->assertSee('Прайс')->assertSee('Зразки')->assertSee('Назва закладу')
        ->assertSeeHtml('id="sheet-order"')->assertSeeHtml('data-grab');
});

// ---------- admin ----------

it('offers the closed status and the price source in the admin', function () {
    expect(array_map(fn ($s) => $s->getLabel(), LeadStatus::cases()))->toContain('Нова', 'В роботі', 'Закрита')
        ->and(LeadType::Price->getLabel())->toBe('Запит прайсу');

    $this->actingAs(User::factory()->role(UserRole::Manager)->create());
    $leads = collect([1, 2])->map(fn ($i) => Lead::create(['company' => "З$i", 'contact_name' => 'І', 'phone' => '0501234567', 'type' => 'price', 'source' => 'site']));

    Livewire::test(ListLeads::class)->callTableBulkAction('status', $leads, data: ['status' => 'closed']);

    expect(Lead::where('status', LeadStatus::Closed)->count())->toBe(2);
});

it('saves contact details from the admin settings', function () {
    $this->actingAs(User::factory()->role(UserRole::Admin)->create());

    Livewire::test(ManageSettings::class)
        ->fillForm(['price_mode' => 'ask', 'contact_phone' => '+380 50 111 22 33', 'contact_email' => 'a@b.com', 'contact_address' => 'Київ, вул. Тестова 1', 'contact_hours' => 'пн–пт'])
        ->call('save')->assertHasNoFormErrors();

    expect(Setting::get('contact_phone'))->toBe('+380 50 111 22 33')->and(Setting::get('contact_address'))->toBe('Київ, вул. Тестова 1');

    test()->withHeader('User-Agent', 'iPhone Mobile')->get('/kontakty')->assertSee('Київ, вул. Тестова 1');
});
