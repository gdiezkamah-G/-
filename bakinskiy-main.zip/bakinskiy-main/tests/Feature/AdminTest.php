<?php

use App\Enums\UserRole;
use App\Filament\Pages\ManageSettings;
use App\Filament\Resources\Products\Pages\CreateProduct;
use App\Models\Category;
use App\Models\Product;
use App\Models\Setting;
use App\Models\User;
use Database\Seeders\CatalogSeeder;
use Illuminate\Support\Facades\Hash;

beforeEach(function () {
    $this->seed(CatalogSeeder::class);
    $this->actingAs(User::factory()->role(UserRole::Admin)->create());
});

it('opens the admin pages', function (string $url) {
    $this->get($url)->assertOk();
})->with(['/admin', '/admin/categories', '/admin/products', '/admin/leads', '/admin/manage-settings']);

it('opens the product edit form', function () {
    $this->get('/admin/products/'.Product::first()->slug.'/edit')->assertOk()->assertSee('Фасовка');
});

it('requires login for the admin', function () {
    auth()->logout();
    $this->get('/admin/leads')->assertRedirect();
});

it('saves the price display mode', function () {
    Livewire\Livewire::test(ManageSettings::class)
        ->fillForm(['price_mode' => 'from', 'price_from' => 180])
        ->call('save')
        ->assertHasNoFormErrors();

    expect(Setting::get('price_mode'))->toBe('from')
        ->and(Setting::get('price_from'))->toBe('18000');

    $this->get('/produkciya/plov')->assertSee('від 180 ₴ / кг');
});

it('creates a product with variants from the admin form', function () {
    $category = Category::first();

    Livewire\Livewire::test(CreateProduct::class)
        ->fillForm([
            'name' => 'Тест', 'slug' => 'test', 'category_id' => $category->id, 'hue' => '#112233', 'status' => 'published',
            'sort' => 9, 'storage_temp' => '−18 °C',
            'variants' => [['size_label' => '2 кг', 'is_active' => true]],
        ])
        ->call('create')
        ->assertHasNoFormErrors();

    expect(Product::where('slug', 'test')->first()->variants)->toHaveCount(1);
});

it('lets a manager into the admin', function () {
    $this->actingAs(User::factory()->role(UserRole::Manager)->create())->get('/admin/leads')->assertOk();
});

it('keeps users without a role out of the admin', function () {
    $this->actingAs(User::factory()->role(null)->create())->get('/admin/leads')->assertForbidden();
});

it('creates an admin with the artisan command', function () {
    $this->artisan('app:create-admin', ['email' => 'boss@example.test', '--name' => 'Boss', '--password' => 'a-long-password-1'])
        ->assertSuccessful();

    $user = User::where('email', 'boss@example.test')->first();
    expect($user->role)->toBe(UserRole::Admin)
        ->and(Hash::check('a-long-password-1', $user->password))->toBeTrue();
});

it('rejects short passwords and unknown roles in the command', function () {
    $this->artisan('app:create-admin', ['email' => 'a@example.test', '--name' => 'A', '--password' => 'short'])->assertFailed();
    $this->artisan('app:create-admin', ['email' => 'a@example.test', '--role' => 'god'])->assertFailed();
    expect(User::where('email', 'a@example.test')->exists())->toBeFalse();
});
