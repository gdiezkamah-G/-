<?php

use App\Enums\LeadSource;
use App\Enums\LeadType;
use App\Enums\UserRole;
use App\Filament\Pages\ManageTelegram;
use App\Filament\Resources\Leads\Pages\EditLead;
use App\Filament\Resources\Leads\Pages\ListLeads;
use App\Models\Category;
use App\Models\Lead;
use App\Models\Product;
use App\Models\TelegramAdmin;
use App\Models\TelegramRecipient;
use App\Models\User;
use App\Services\Telegram\PriceList;
use App\Services\Telegram\TelegramSettings;
use Database\Seeders\CatalogSeeder;
use Illuminate\Support\Facades\Storage;
use Livewire\Livewire;
use Spatie\LaravelPdf\Facades\Pdf;

beforeEach(function () {
    tgConfigure();
    $this->seed(CatalogSeeder::class);
    Storage::fake('local');
});

function adminUser(UserRole $role = UserRole::Admin): User
{
    return User::factory()->role($role)->create();
}

function telegramPage()
{
    test()->actingAs(adminUser());

    return Livewire::test(ManageTelegram::class);
}

// ---------- access ----------

it('opens the Telegram settings for admins only', function () {
    $this->actingAs(adminUser(UserRole::Admin))->get('/admin/telegram')->assertOk()->assertSee('Налаштування Telegram');
    $this->actingAs(adminUser(UserRole::Manager))->get('/admin/telegram')->assertForbidden();
});

it('shows the bot status: link, token, secret and webhook state', function () {
    telegramPage()->assertSee('@bakinsky_bot')->assertSee('Секрет webhook')->assertSee('http://localhost:8080/tg');
});

it('says so when the secrets are missing', function () {
    config(['bakinsky.telegram.token' => null, 'bakinsky.telegram.webhook_secret' => null, 'bakinsky.telegram.bot_username' => null]);

    telegramPage()->assertSee('TELEGRAM_BOT_TOKEN не задано')->assertSee('TELEGRAM_WEBHOOK_SECRET')->assertSee('TELEGRAM_BOT_USERNAME не задано');
});

// ---------- saving settings ----------

it('saves bot texts, notification blocks and menu entries', function () {
    $t = telegramPage()->fillForm([
        'texts.welcome' => 'Новий привіт', 'texts.thanks' => 'Дякуємо!', 'texts.price_caption' => 'Прайс від нас',
        'notification.phone' => false, 'notification.write_button' => false,
        'menu.button_text' => 'Магазин', 'menu.commands.price.enabled' => false, 'menu.commands.samples.description' => 'Зразки продукції',
    ])->call('save')->assertHasNoFormErrors();

    $s = app(TelegramSettings::class);
    expect($s->text('welcome'))->toBe('Новий привіт')->and($s->text('price_caption'))->toBe('Прайс від нас')
        ->and($s->group('notification')['phone'])->toBeFalse()->and($s->group('notification')['write_button'])->toBeFalse()
        ->and($s->group('notification')['name'])->toBeTrue()
        ->and($s->group('menu')['button_text'])->toBe('Магазин')->and($s->commandEnabled('price'))->toBeFalse()->and($s->commandEnabled('catalog'))->toBeTrue()
        ->and($s->group('menu')['commands']['samples']['description'])->toBe('Зразки продукції');
});

it('requires the bot texts', function () {
    telegramPage()->fillForm(['texts.welcome' => '', 'texts.thanks' => ''])->call('save')->assertHasFormErrors(['texts.welcome' => 'required', 'texts.thanks' => 'required']);
});

it('uses the saved texts in the bot', function () {
    telegramPage()->fillForm(['texts.welcome' => 'Текст з адмінки'])->call('save');

    tgSay('/start');

    expect(tgCalls('sendMessage')[0]['text'])->toBe('Текст з адмінки');
});

it('keeps the defaults for anything never saved', function () {
    expect(app(TelegramSettings::class)->text('thanks'))->toContain('Менеджер зв’яжеться')->and(app(TelegramSettings::class)->commandEnabled('manager'))->toBeTrue();
});

// ---------- recipients and admins ----------

it('lists connected recipients and lets the admin switch them off and pick lead types', function () {
    TelegramRecipient::create(['chat_id' => -1001, 'title' => 'Менеджери', 'type' => 'group', 'active' => true]);

    $t = telegramPage()->assertSee('Менеджери');
    $key = array_key_first($t->get('data.recipients'));

    $t->set("data.recipients.{$key}.active", false)->set("data.recipients.{$key}.lead_types", ['price', 'sample'])->call('save')->assertHasNoFormErrors();

    $r = TelegramRecipient::sole();
    expect($r->active)->toBeFalse()->and($r->lead_types)->toBe(['price', 'sample']);
});

it('adds, updates and removes recipients and admins from the form', function () {
    TelegramRecipient::create(['chat_id' => -1, 'title' => 'Стара', 'type' => 'group']);
    TelegramAdmin::create(['telegram_id' => 1, 'name' => 'Перший']);

    telegramPage()->fillForm([
        'recipients' => [['chat_id' => -2, 'title' => 'Нова група', 'type' => 'group', 'active' => true, 'lead_types' => ['order']]],
        'admins' => [['telegram_id' => 2, 'name' => 'Другий']],
    ])->call('save')->assertHasNoFormErrors();

    expect(TelegramRecipient::pluck('chat_id')->all())->toBe([-2])->and(TelegramRecipient::sole()->lead_types)->toBe(['order'])
        ->and(TelegramAdmin::pluck('telegram_id')->all())->toBe([2]);
});

it('refuses the same chat id twice', function () {
    telegramPage()->fillForm([
        'recipients' => [
            ['chat_id' => -5, 'type' => 'group', 'active' => true],
            ['chat_id' => -5, 'type' => 'group', 'active' => true],
        ],
    ])->call('save');

    expect(TelegramRecipient::count())->toBe(0);
});

it('sends a test message to a recipient', function () {
    TelegramRecipient::create(['chat_id' => -1001, 'title' => 'Менеджери', 'type' => 'group']);

    $t = telegramPage();
    $t->call('sendTest', array_key_first($t->get('data.recipients')))->assertNotified('Тест надіслано');

    expect(tgCalls('sendMessage')[0])->toMatchArray(['chat_id' => -1001]);
    expect(tgCalls('sendMessage')[0]['text'])->toContain('Тестове повідомлення');
});

it('reports a failed test message instead of crashing', function () {
    TelegramRecipient::create(['chat_id' => -1001, 'type' => 'group']);
    $t = telegramPage();
    tgBot()->willReceive([], ok: false);

    $t->call('sendTest', array_key_first($t->get('data.recipients')))->assertNotified('Не вдалося надіслати');
});

it('reinstalls the webhook, commands and menu button from the header button', function () {
    config(['app.url' => 'https://bakinskybulvar.com']);

    telegramPage()->callAction('webhook')->assertNotified('Webhook і меню бота оновлено');

    $hook = tgCalls('setWebhook')[0];
    expect($hook['url'])->toBe('https://bakinskybulvar.com/telegram/webhook')->and($hook['secret_token'])->toBe('s3cret');
    expect(tgCalls('setMyCommands'))->toHaveCount(2)->and(tgCalls('setChatMenuButton'))->toHaveCount(1);
});

// ---------- price list ----------

it('regenerates the price list from the header button', function () {
    $fake = Pdf::fake();

    telegramPage()->callAction('price')->assertNotified('Прайс перегенеровано');

    $fake->assertSaved(fn ($pdf, $path) => str_ends_with($path, 'telegram/price-list.pdf'));
    $fake->assertViewIs('documents.price-list');
});

it('stores an uploaded price list and switches to it', function () {
    Storage::disk('local')->put('telegram/mine.pdf', '%PDF-1.4 mine');
    app(TelegramSettings::class)->save('price', ['file_id' => 'OLD', 'file_hash' => 'x']);

    telegramPage()->fillForm(['price_mode' => 'upload', 'price_file' => ['telegram/mine.pdf']])->call('save')->assertHasNoFormErrors();

    $p = app(TelegramSettings::class)->group('price');
    expect($p['mode'])->toBe('upload')->and($p['file'])->toBe('telegram/mine.pdf')->and($p['file_id'])->toBeNull();
    expect(app(PriceList::class)->path())->toBe(Storage::disk('local')->path('telegram/mine.pdf'));
});

it('builds the price list data from published products grouped by category', function () {
    Product::where('slug', 'mlynci')->update(['status' => 'draft']);

    $data = app(PriceList::class)->data();

    expect(collect($data['groups'])->pluck('name')->all())->toBe(['Гриль', 'Гарячі страви'])
        ->and($data['groups'][1]['rows'][1]['name'])->toBe('Плов по-бакинськи')
        ->and($data['groups'][1]['rows'][1]['pack'])->toBe('1 кг · 3 кг · 5 кг')
        ->and($data['groups'][1]['rows'][1]['storage'])->toBe('−18°C · 6 місяців')
        ->and($data['groups'][1]['rows'][1]['price'])->toBe('—');
});

it('renders the price list document with the handoff design', function () {
    $html = view('documents.price-list', app(PriceList::class)->data())->render();

    expect($html)->toContain('Прайс-лист')->toContain('bb-sheet')->toContain('Люля-кебаб')->toContain('data:font/woff2;base64,')
        ->toContain('data:image/svg+xml;base64,')->not->toContain('TODO')->not->toContain('url(fonts/');
});

it('rebuilds the cached price list only when the catalog changes', function () {
    $fake = Pdf::fake();
    $list = app(PriceList::class);

    $list->path();
    Storage::disk('local')->put(PriceList::AUTO_PATH, '%PDF-1.4 generated');
    $list->path();
    $list->path();
    expect($fake->savedPdfs ?? null)->toBeNull(); // (protected: counted through the hash below)

    $hash = app(TelegramSettings::class)->group('price')['hash'];
    expect($hash)->toBe($list->catalogHash());

    $this->travel(2)->minutes();
    Product::where('slug', 'plov')->first()->touch();
    expect($list->catalogHash())->not->toBe($hash);
});

it('generates a real PDF with Chromium', function () {
    $pdf = app(PriceList::class)->regenerate();

    expect(file_get_contents($pdf, false, null, 0, 5))->toBe('%PDF-')->and(filesize($pdf))->toBeGreaterThan(20000);
})->skip(fn () => ! is_file('/usr/bin/chromium'), 'Chromium is not installed here');

// ---------- artisan commands ----------

it('adds the first Telegram admin from the command line', function () {
    $this->artisan('app:telegram-add-admin', ['telegram_id' => '424242', '--name' => 'Власник'])->expectsOutputToContain('Added')->assertSuccessful();
    $this->artisan('app:telegram-add-admin', ['telegram_id' => '424242', '--name' => 'Власник Ім’я'])->expectsOutputToContain('Updated')->assertSuccessful();

    expect(TelegramAdmin::sole()->telegram_id)->toBe(424242)->and(TelegramAdmin::sole()->name)->toBe('Власник Ім’я');
});

it('rejects a bad Telegram id', function (string $id) {
    $this->artisan('app:telegram-add-admin', ['telegram_id' => $id])->assertFailed();

    expect(TelegramAdmin::count())->toBe(0);
})->with(['abc', '-5', '0', '12.5']);

it('sets the webhook, command list and menu button', function () {
    config(['app.url' => 'https://bakinskybulvar.com']);
    app(TelegramSettings::class)->save('menu', ['button_text' => 'Каталог', 'commands' => ['samples' => ['enabled' => false]]]);

    $this->artisan('app:telegram-set-webhook')->expectsOutputToContain('https://bakinskybulvar.com/telegram/webhook')->assertSuccessful();

    $hook = tgCalls('setWebhook')[0];
    expect($hook['url'])->toBe('https://bakinskybulvar.com/telegram/webhook')->and($hook['secret_token'])->toBe('s3cret')
        ->and($hook['allowed_updates'])->toContain('callback_query');

    $commands = collect(tgCalls('setMyCommands')[0]['commands']);
    expect($commands->pluck('command')->all())->toBe(['start', 'catalog', 'price', 'manager']);
    expect(tgCalls('setMyCommands')[1]['commands'][0]['command'])->toBe('connect');

    $button = tgCalls('setChatMenuButton')[0]['menu_button'];
    expect($button['text'])->toBe('Каталог')->and($button['web_app']['url'])->toBe('https://bakinskybulvar.com/tg');
});

it('can refresh only the commands and the menu', function () {
    config(['app.url' => 'https://bakinskybulvar.com']);

    $this->artisan('app:telegram-set-webhook', ['--menu-only' => true])->assertSuccessful();

    expect(tgCalls('setWebhook'))->toBeEmpty()->and(tgCalls('setMyCommands'))->toHaveCount(2);
});

it('refuses to set the webhook without secrets or without https', function (array $config) {
    config($config);

    $this->artisan('app:telegram-set-webhook')->assertFailed();

    expect(tgCalls('setWebhook'))->toBeEmpty();
})->with([
    'no token' => [['bakinsky.telegram.token' => null]],
    'no secret' => [['bakinsky.telegram.webhook_secret' => null]],
    'plain http' => [['app.url' => 'http://example.test']],
]);

// ---------- leads in the admin ----------

it('filters leads by status, type and source in the admin', function () {
    $this->actingAs(adminUser());
    $mk = fn (array $a) => Lead::create(['company' => 'К', 'contact_name' => 'І', 'phone' => '0501234567'] + $a);
    $a = $mk(['type' => LeadType::Price, 'source' => LeadSource::Bot, 'status' => 'new']);
    $b = $mk(['type' => LeadType::Order, 'source' => LeadSource::Site, 'status' => 'in_progress']);
    $c = $mk(['type' => LeadType::Sample, 'source' => LeadSource::MiniApp, 'status' => 'closed']);

    Livewire::test(ListLeads::class)
        ->filterTable('type', 'price')->assertCanSeeTableRecords([$a])->assertCanNotSeeTableRecords([$b, $c])
        ->resetTableFilters()->filterTable('source', 'miniapp')->assertCanSeeTableRecords([$c])->assertCanNotSeeTableRecords([$a, $b])
        ->resetTableFilters()->filterTable('status', 'in_progress')->assertCanSeeTableRecords([$b])->assertCanNotSeeTableRecords([$a, $c]);
});

it('shows type, source and the client comment on the lead', function () {
    $this->actingAs(adminUser());
    $lead = Lead::create(['company' => null, 'contact_name' => 'Олена', 'phone' => '0501234567', 'type' => LeadType::Manager, 'source' => LeadSource::Bot, 'comment' => 'Передзвоніть']);

    $this->get("/admin/leads/{$lead->id}/edit")->assertOk()->assertSee('Тип')->assertSee('Джерело');
    Livewire::test(EditLead::class, ['record' => $lead->id])
        ->assertFormSet(['type' => LeadType::Manager, 'source' => LeadSource::Bot, 'comment' => 'Передзвоніть']);
});

it('keeps categories and products untouched by the Telegram settings', function () {
    telegramPage()->call('save');

    expect(Category::count())->toBe(3)->and(Product::count())->toBe(4);
});
