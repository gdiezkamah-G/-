<?php

/** Static guards on the deploy files: the properties the deploy relies on must not regress silently. */
function read(string $path): string
{
    return file_get_contents(base_path($path));
}

it('starts every role the same safe way: env check first, then the database', function () {
    $sh = read('docker/prod/entrypoint.sh');

    expect(strpos($sh, 'app:check-env'))->toBeLessThan(strpos($sh, 'wait_for_db()'))
        ->and($sh)->toContain('exit 1')->toContain('DB_WAIT_SECONDS');
});

it('runs the one-time bootstrap only in the web role and makes workers wait for it', function () {
    $sh = read('docker/prod/entrypoint.sh');
    $web = substr($sh, strpos($sh, '    web)'), strpos($sh, '    queue)') - strpos($sh, '    web)'));
    $queue = substr($sh, strpos($sh, '    queue)'), strpos($sh, '    scheduler)') - strpos($sh, '    queue)'));
    $scheduler = substr($sh, strpos($sh, '    scheduler)'), strpos($sh, '    *)') - strpos($sh, '    scheduler)'));

    expect($web)->toContain('app:bootstrap')->toContain('app:doctor')->toContain('cache_all')
        ->and($queue)->not->toContain('app:bootstrap')->toContain('app:wait-ready')->toContain('--max-time=3600')->toContain('--tries=3')
        ->and($scheduler)->not->toContain('app:bootstrap')->toContain('app:wait-ready')->toContain('schedule:work');
});

it('never lets the doctor block the start', function () {
    expect(read('docker/prod/entrypoint.sh'))->toContain('app:doctor --no-fail')->toContain('|| true');
});

it('caches config, routes, views, events and Filament', function () {
    $sh = read('docker/prod/entrypoint.sh');

    foreach (['config:cache', 'route:cache', 'view:cache', 'event:cache', 'filament:optimize'] as $cmd) {
        expect($sh)->toContain($cmd);
    }
});

it('runs three roles on one image with automatic restarts and ordered startup', function () {
    $compose = read('docker-compose.prod.yml');

    expect($compose)->toContain('image: bakinsky-app:latest')
        ->and(substr_count($compose, 'restart: unless-stopped'))->toBeGreaterThanOrEqual(3)
        ->and(substr_count($compose, '<<: *app'))->toBe(3)
        ->and($compose)->toContain('command: ["web"]')->toContain('command: ["queue"]')->toContain('command: ["scheduler"]')
        ->and(substr_count($compose, 'web: { condition: service_healthy }'))->toBe(2)
        ->and($compose)->toContain('/up')->toContain('stop_grace_period');
});

it('keeps all persistent data in named volumes and bootstrap only on web', function () {
    $compose = read('docker-compose.prod.yml');

    expect($compose)->toContain('app-storage:/var/www/html/storage/app')->toContain('dbdata:/var/lib/mysql')->toContain('redisdata:/data')
        ->and($compose)->toMatch('/volumes:\s+dbdata:\s+redisdata:\s+app-storage:/')
        ->and(substr_count($compose, 'RUN_BOOTSTRAP: "true"'))->toBe(1)->and(substr_count($compose, 'RUN_BOOTSTRAP: "false"'))->toBe(2);
});

it('fails the compose file early when a required secret is missing', function () {
    $compose = read('docker-compose.prod.yml');

    foreach (['APP_KEY', 'APP_URL', 'DB_PASSWORD', 'DB_ROOT_PASSWORD'] as $var) {
        expect($compose)->toContain("\${{$var}:?");
    }
});

it('contains no secret values: every credential is a variable reference', function () {
    $compose = read('docker-compose.prod.yml');

    expect($compose)->not->toMatch('/(PASSWORD|SECRET|TOKEN|KEY):\s+[A-Za-z0-9+\/=]{8,}\s*$/m')->and($compose)->not->toMatch('/base64:[A-Za-z0-9+\/=]{20,}/');
    foreach (['Dockerfile', '.env.example'] as $file) {
        expect(read($file))->not->toMatch('/base64:[A-Za-z0-9+\/=]{30,}/');
    }
});

it('keeps runtime data (uploads, backups, price list) out of the image', function () {
    $ignore = read('.dockerignore');

    expect($ignore)->toContain('storage/app/*')->toContain('*.sql.gz')->toContain('.env');
});

it('documents every variable that the config and compose read in .env.example', function () {
    $example = read('.env.example');
    preg_match_all('/^([A-Z][A-Z0-9_]+)=/m', $example, $documented);
    $used = [];
    foreach (['config/bakinsky.php', 'docker-compose.prod.yml', 'config/nutgram.php'] as $file) {
        preg_match_all("/env\('([A-Z0-9_]+)'/", read($file), $a);
        preg_match_all('/\$\{([A-Z][A-Z0-9_]+)[:}?-]/', read($file), $b);
        $used = [...$used, ...$a[1], ...$b[1]];
    }

    expect(array_values(array_diff(array_unique($used), $documented[1])))->toBe([]);
});

it('marks required, recommended and optional variables in .env.example', function () {
    $example = read('.env.example');

    expect($example)->toContain('[REQUIRED]')->toContain('[RECOMMENDED]')->toContain('[OPTIONAL]');
    foreach (['APP_URL', 'APP_KEY', 'DB_PASSWORD', 'ADMIN_EMAIL', 'TELEGRAM_BOT_TOKEN', 'MANAGER_EMAIL', 'BACKUP_S3_BUCKET', 'CATALOG_IMPORT', 'QUEUE_CONNECTION', 'CACHE_STORE', 'SESSION_DRIVER'] as $var) {
        expect($example)->toContain("{$var}=");
    }
});

it('ships the deploy document with the five-item checklist', function () {
    $doc = read('docs/08-deploy-and-migration.md');

    expect($doc)->toContain('Контрольний список після деплою')->toContain('app:db-restore')->toContain('Що зберігати')->toContain('Відкат')->toContain('Логи');
    $list = substr($doc, strpos($doc, 'Контрольний список після деплою'));
    expect(preg_match_all('/^\d\. /m', $list))->toBeLessThanOrEqual(5);
});

it('ships the catalog data the first start imports', function () {
    $data = json_decode(read('database/data/products.json'), true);

    expect($data['products'])->toHaveCount(14)->and($data['categories'])->toHaveCount(5);
});
