<?php

use App\Enums\UserRole;
use App\Filament\Pages\SystemStatus;
use App\Jobs\QueueHeartbeat;
use App\Models\Product;
use App\Models\Setting;
use App\Models\TelegramAdmin;
use App\Models\TelegramRecipient;
use App\Models\User;
use App\Services\Deploy\BackupManager;
use App\Services\Deploy\Check;
use App\Services\Deploy\Doctor;
use App\Services\Telegram\TelegramSettings;
use App\Services\Telegram\WebhookInstaller;
use Database\Seeders\CatalogSeeder;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Livewire\Livewire;

beforeEach(function () {
    useTempStorage();
});

/** @return array<string, Check> */
function diagnose(): array
{
    return collect(app(Doctor::class)->run())->keyBy('name')->all();
}

// ---------- the table ----------

it('reports every area, and OK / WARN / FAIL are the only statuses', function () {
    $names = array_keys(diagnose());

    expect($names)->toContain('Змінні оточення', 'База даних', 'Міграції', 'Storage', 'Кеш / Redis', 'Черга (воркер)', 'Планувальник', 'Невдалі завдання',
        'Адмін сайту', 'Каталог', 'Telegram', 'Отримувачі заявок', 'PDF-прайс', 'Бекапи');
    foreach (diagnose() as $c) {
        expect($c->status)->toBeIn([Check::OK, Check::WARN, Check::FAIL]);
    }
});

it('the database and migrations are OK on a migrated database', function () {
    $d = diagnose();

    expect($d['База даних']->status)->toBe(Check::OK)->and($d['Міграції']->status)->toBe(Check::OK);
});

it('fails on pending migrations and names the fix', function () {
    DB::table('migrations')->where('migration', 'like', '%create_leads%')->delete();

    expect(diagnose()['Міграції']->status)->toBe(Check::FAIL)->and(diagnose()['Міграції']->detail)->toContain('migrate --force');
});

// ---------- admin, catalog ----------

it('fails without an admin and passes with one', function () {
    expect(diagnose()['Адмін сайту']->failed())->toBeTrue()->and(diagnose()['Адмін сайту']->detail)->toContain('ADMIN_EMAIL');

    User::factory()->role(UserRole::Manager)->create();
    expect(diagnose()['Адмін сайту']->failed())->toBeTrue();

    User::factory()->role(UserRole::Admin)->create();
    expect(diagnose()['Адмін сайту']->status)->toBe(Check::OK);
});

it('warns about an empty catalog or one that is only drafts', function () {
    expect(diagnose()['Каталог']->status)->toBe(Check::WARN);

    $this->seed(CatalogSeeder::class);
    Product::query()->update(['status' => 'draft']);
    expect(diagnose()['Каталог']->detail)->toContain('чернетках');

    Product::where('slug', 'plov')->update(['status' => 'published']);
    expect(diagnose()['Каталог']->status)->toBe(Check::OK)->and(diagnose()['Каталог']->detail)->toContain('опубліковано 1');
});

// ---------- worker and scheduler ----------

it('trusts a worker only while its heartbeat is fresh', function (?int $ageSeconds, ?int $bootedSecondsAgo, string $expected) {
    Cache::forget('heartbeat.queue');
    $ageSeconds !== null && Cache::put('heartbeat.queue', time() - $ageSeconds, 900);
    $bootedSecondsAgo !== null && Setting::put('bootstrap_at', (string) (time() - $bootedSecondsAgo));

    expect(diagnose()['Черга (воркер)']->status)->toBe($expected);
})->with([
    'fresh' => [20, 3600, Check::OK],
    'stale after five minutes' => [900, 3600, Check::FAIL],
    'no signal yet, just booted' => [null, 30, Check::WARN],
    'no signal, booted long ago' => [null, 3600, Check::FAIL],
    'no signal, never bootstrapped' => [null, null, Check::FAIL],
]);

it('does the same for the scheduler', function () {
    Cache::put('heartbeat.scheduler', time() - 10, 900);
    expect(diagnose()['Планувальник']->status)->toBe(Check::OK);

    Cache::put('heartbeat.scheduler', time() - 1200, 900);
    expect(diagnose()['Планувальник']->failed())->toBeTrue()->and(diagnose()['Планувальник']->detail)->toContain('scheduler');
});

it('lets the queue heartbeat job stamp the cache', function () {
    Cache::forget('heartbeat.queue');

    (new QueueHeartbeat)->handle();

    expect(time() - Cache::get('heartbeat.queue'))->toBeLessThan(3);
});

it('warns about failed jobs', function () {
    expect(diagnose()['Невдалі завдання']->status)->toBe(Check::OK);

    DB::table('failed_jobs')->insert(['uuid' => 'u1', 'connection' => 'redis', 'queue' => 'default', 'payload' => '{}', 'exception' => 'x', 'failed_at' => now()]);
    expect(diagnose()['Невдалі завдання']->status)->toBe(Check::WARN);
});

// ---------- Telegram ----------

it('says Telegram is off without a token instead of failing', function () {
    config(['bakinsky.telegram.token' => null]);

    expect(diagnose()['Telegram']->status)->toBe(Check::WARN)->and(diagnose()['Отримувачі заявок']->status)->toBe(Check::OK);
});

it('checks the live webhook against APP_URL', function (array $info, string $status) {
    tgConfigure();
    config(['app.url' => 'https://bakinskybulvar.com']);
    tgBot()->willReceive($info + ['has_custom_certificate' => false, 'pending_update_count' => 2]);

    expect(diagnose()['Telegram']->status)->toBe($status);
})->with([
    'no webhook' => [['url' => ''], Check::FAIL],
    'another domain' => [['url' => 'https://old.example/telegram/webhook'], Check::FAIL],
    'telegram reports an error' => [['url' => 'https://bakinskybulvar.com/telegram/webhook', 'last_error_message' => 'Connection timed out', 'last_error_date' => 1700000000], Check::FAIL],
    'settings changed since install' => [['url' => 'https://bakinskybulvar.com/telegram/webhook'], Check::WARN],
]);

it('is OK when the webhook matches and the installed signature is current', function () {
    tgConfigure();
    config(['app.url' => 'https://bakinskybulvar.com']);
    Setting::put('tg_webhook_signature', app(WebhookInstaller::class)->signature());
    tgBot()->willReceive(['url' => 'https://bakinskybulvar.com/telegram/webhook', 'has_custom_certificate' => false, 'pending_update_count' => 0]);

    expect(diagnose()['Telegram']->status)->toBe(Check::OK);
});

it('warns when nobody can receive leads and says how to fix it', function () {
    tgConfigure();
    expect(diagnose()['Отримувачі заявок']->detail)->toContain('TELEGRAM_ADMIN_IDS');

    TelegramAdmin::create(['telegram_id' => 1]);
    expect(diagnose()['Отримувачі заявок']->detail)->toContain('/start');

    TelegramRecipient::create(['chat_id' => -1, 'type' => 'group']);
    expect(diagnose()['Отримувачі заявок']->status)->toBe(Check::OK);
});

// ---------- price list, backups ----------

it('knows whether the price list exists', function () {
    expect(diagnose()['PDF-прайс']->status)->toBe(Check::WARN);

    @mkdir(storage_path('app/private/telegram'), 0775, true);
    file_put_contents(storage_path('app/private/telegram/price-list.pdf'), '%PDF');
    expect(diagnose()['PDF-прайс']->status)->toBe(Check::OK);

    app(TelegramSettings::class)->save('price', ['mode' => 'upload', 'file' => 'telegram/nope.pdf']);
    expect(diagnose()['PDF-прайс']->detail)->toContain('завантажте');
});

it('warns about missing and stale backups, is OK for a fresh one', function () {
    expect(diagnose()['Бекапи']->status)->toBe(Check::WARN);

    $r = app(BackupManager::class)->run(14);
    expect(diagnose()['Бекапи']->status)->toBe(Check::OK);

    touch(storage_path('app/backups/'.$r['file']), time() - 40 * 3600);
    expect(diagnose()['Бекапи']->status)->toBe(Check::WARN)->and(diagnose()['Бекапи']->detail)->toContain('планувальник');

    config(['bakinsky.backup.enabled' => false]);
    expect(diagnose()['Бекапи']->detail)->toContain('вимкнені');
});

// ---------- the command ----------

it('prints a table and exits 1 when something fails, 0 with --no-fail', function () {
    $this->artisan('app:doctor')->expectsOutputToContain('Адмін сайту')->assertFailed();
    $this->artisan('app:doctor', ['--no-fail' => true])->assertSuccessful();
});

it('exits 0 when nothing fails, and prints JSON on request', function () {
    $vars = goodEnv();
    $old = array_map(fn ($k) => getenv($k), array_keys($vars));
    foreach ($vars as $k => $v) {
        putenv("{$k}={$v}");
    }
    $link = public_path('storage');
    $madeLink = ! file_exists($link) && symlink(storage_path('app/public'), $link);
    @mkdir(storage_path('app/public'), 0775, true);

    User::factory()->role(UserRole::Admin)->create();
    Cache::put('heartbeat.queue', time(), 900);
    Cache::put('heartbeat.scheduler', time(), 900);

    try {
        $this->artisan('app:doctor', ['--json' => true])->expectsOutputToContain('"status"')->assertSuccessful();
    } finally {
        $madeLink && @unlink($link);
        foreach (array_keys($vars) as $i => $k) {
            $old[$i] === false ? putenv($k) : putenv("{$k}={$old[$i]}");
        }
    }
});

it('stops after a database failure instead of throwing', function () {
    config(['database.connections.broken' => ['driver' => 'mysql', 'host' => '127.0.0.1', 'port' => 1, 'database' => 'x', 'username' => 'x', 'password' => 'x']]);
    config(['database.default' => 'broken']);
    DB::purge();

    $checks = app(Doctor::class)->run();

    expect($checks[1]->failed())->toBeTrue()->and(count($checks))->toBe(2);
})->skip('breaks the shared in-memory connection used by RefreshDatabase');

// ---------- the admin page ----------

it('shows the same checks in the admin to admins only', function () {
    $this->actingAs(User::factory()->role(UserRole::Admin)->create())->get('/admin/system')->assertOk()->assertSee('Стан системи')->assertSee('Адмін сайту');
    $this->actingAs(User::factory()->role(UserRole::Manager)->create())->get('/admin/system')->assertForbidden();
});

it('refreshes the checks, restarts the worker and creates a backup from the page', function () {
    $this->actingAs(User::factory()->role(UserRole::Admin)->create());
    Cache::forget('illuminate:queue:restart');

    $page = Livewire::test(SystemStatus::class);
    $page->callAction('refresh');
    $page->callAction('worker')->assertNotified('Воркер перезапуститься протягом хвилини');
    expect(Cache::get('illuminate:queue:restart'))->not->toBeNull();

    $page->callAction('backup')->assertNotified('Бекап створено');
    expect(app(BackupManager::class)->list())->toHaveCount(1);
});

it('reinstalls the webhook from the page', function () {
    $this->actingAs(User::factory()->role(UserRole::Admin)->create());
    tgConfigure();
    config(['app.url' => 'https://bakinskybulvar.com']);

    Livewire::test(SystemStatus::class)->callAction('webhook')->assertNotified('Webhook, команди й кнопка меню встановлені: https://bakinskybulvar.com/telegram/webhook');

    expect(tgCalls('setWebhook'))->toHaveCount(1);
});

it('explains why the webhook cannot be installed instead of failing', function () {
    $this->actingAs(User::factory()->role(UserRole::Admin)->create());
    config(['bakinsky.telegram.token' => null]);

    Livewire::test(SystemStatus::class)->callAction('webhook')->assertNotified('TELEGRAM_BOT_TOKEN не задано: бот вимкнений, пропускаю.');
});

// ---------- /up ----------

it('answers /up only when the app and its dependencies work', function () {
    $this->get('/up')->assertOk();
});
