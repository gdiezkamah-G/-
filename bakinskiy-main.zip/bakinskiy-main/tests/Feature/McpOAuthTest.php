<?php

use App\Enums\UserRole;
use App\Filament\Pages\AiConnections;
use App\Models\User;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Laravel\Passport\Passport;
use Livewire\Livewire;

const REDIRECT = 'https://claude.ai/api/mcp/auth_callback';

beforeEach(function () {
    $dir = sys_get_temp_dir().'/bb-oauth-'.uniqid();
    mkdir($dir);
    Passport::loadKeysFrom($dir);
    Artisan::call('passport:keys', ['--force' => true]);
});

function registerClient(string $name = 'Claude'): string
{
    return test()->postJson('/oauth/register', ['client_name' => $name, 'redirect_uris' => [REDIRECT]])->assertCreated()->json('client_id');
}

function pkce(): array
{
    $verifier = bin2hex(random_bytes(32));

    return [$verifier, rtrim(strtr(base64_encode(hash('sha256', $verifier, true)), '+/', '-_'), '=')];
}

function authorizeUrl(string $clientId, string $challenge): string
{
    return '/oauth/authorize?'.http_build_query([
        'client_id' => $clientId, 'redirect_uri' => REDIRECT, 'response_type' => 'code', 'scope' => 'mcp:use',
        'state' => 'st4te', 'code_challenge' => $challenge, 'code_challenge_method' => 'S256',
    ]);
}

/** Runs the whole flow as the given user and returns the access token (or null when consent was not possible). */
function oauthToken(User $user, string $name = 'Claude'): ?string
{
    $id = registerClient($name);
    [$verifier, $challenge] = pkce();

    test()->actingAs($user)->get(authorizeUrl($id, $challenge))->assertOk();

    $approve = test()->actingAs($user)->post('/oauth/authorize', ['state' => 'st4te', 'client_id' => $id, 'auth_token' => session('authToken')]);
    $location = $approve->headers->get('Location');
    parse_str((string) parse_url($location, PHP_URL_QUERY), $query);

    if (empty($query['code'])) {
        return null;
    }

    return test()->postJson('/oauth/token', [
        'grant_type' => 'authorization_code', 'client_id' => $id, 'redirect_uri' => REDIRECT, 'code' => $query['code'], 'code_verifier' => $verifier,
    ])->assertOk()->json('access_token');
}

it('publishes the OAuth discovery documents for the MCP server', function () {
    $this->getJson('/.well-known/oauth-authorization-server')->assertOk()
        ->assertJsonPath('code_challenge_methods_supported', ['S256'])->assertJsonPath('scopes_supported', ['mcp:use'])
        ->assertJsonPath('registration_endpoint', url('/oauth/register'));
    $this->getJson('/.well-known/oauth-protected-resource/mcp')->assertOk()->assertJsonPath('authorization_servers.0', url('/'));
});

it('registers a client dynamically for the allowed redirect domains only', function () {
    registerClient();

    $this->postJson('/oauth/register', ['client_name' => 'Evil', 'redirect_uris' => ['https://evil.example/cb']])->assertStatus(400)->assertJsonPath('error', 'invalid_redirect_uri');
    $this->postJson('/oauth/register', ['client_name' => 'ChatGPT', 'redirect_uris' => ['https://chatgpt.com/connector_platform_oauth_redirect']])->assertCreated();
});

it('sends a guest to the admin login before the consent page', function () {
    [, $challenge] = pkce();

    $this->get(authorizeUrl(registerClient(), $challenge))->assertRedirect(route('filament.admin.auth.login'));
});

it('shows staff the consent page in Ukrainian with exactly their rights', function () {
    [, $challenge] = pkce();
    $id = registerClient('Claude');

    $this->actingAs(staff(UserRole::Manager))->get(authorizeUrl($id, $challenge))->assertOk()
        ->assertSee('Дозволити «Claude» керувати магазином?', false)->assertSee('Заявки: перегляд')
        ->assertDontSee('Каталог: зміни')->assertDontSee('Telegram: тексти');

    $this->actingAs(staff())->get(authorizeUrl($id, $challenge))->assertSee('Каталог: зміни')->assertSee('Дозволити');
});

it('refuses to offer the consent to a user without a role', function () {
    [, $challenge] = pkce();

    $this->actingAs(User::factory()->role(null)->create())->get(authorizeUrl(registerClient(), $challenge))->assertOk()
        ->assertSee('Немає доступу')->assertDontSee('Дозволити');
});

it('runs the whole flow: consent, code, token, MCP call', function () {
    $user = staff();
    $token = oauthToken($user);

    expect($token)->not->toBeNull();

    $names = collect($this->withToken($token)->postJson('/mcp', rpc())->assertOk()->json('result.tools'))->pluck('name');
    expect($names)->toContain('catalog_publish', 'leads_list')->toHaveCount(32);

    $call = $this->withToken($token)->postJson('/mcp', rpc('tools/call', ['name' => 'catalog_list_categories', 'arguments' => (object) []]))->assertOk();
    expect($call->json('result.isError'))->toBeFalse();

    expect(DB::table('mcp_audit_log')->where('tool', 'catalog_list_categories')->value('client'))->toBe('Claude');
});

it('names ChatGPT in the audit log', function () {
    $token = oauthToken(staff(), 'ChatGPT connector');
    $this->withToken($token)->postJson('/mcp', rpc('tools/call', ['name' => 'catalog_list_categories', 'arguments' => (object) []]))->assertOk();

    expect(DB::table('mcp_audit_log')->value('client'))->toBe('ChatGPT');
});

it('gives an OAuth token the rights of the role of its user, no more', function () {
    $token = oauthToken(staff(UserRole::Manager));

    $names = collect($this->withToken($token)->postJson('/mcp', rpc())->assertOk()->json('result.tools'))->pluck('name');
    expect($names)->toContain('leads_list')->not->toContain('catalog_publish', 'telegram_publish_channel_post');
});

it('cuts an OAuth token off when its user loses the role', function () {
    $user = staff();
    $token = oauthToken($user);
    $this->withToken($token)->postJson('/mcp', rpc())->assertOk();

    $user->forceFill(['role' => null])->save();
    $this->app['auth']->forgetGuards();

    $this->withToken($token)->postJson('/mcp', rpc())->assertForbidden();
});

it('stops an OAuth token the moment the connection is revoked in the admin', function () {
    $admin = staff();
    $token = oauthToken($admin);
    $this->withToken($token)->postJson('/mcp', rpc())->assertOk();

    $id = DB::table('oauth_access_tokens')->value('id');
    Livewire::actingAs($admin)->test(AiConnections::class)->assertSee('Claude')->call('revokeConnection', $id);

    $this->app['auth']->forgetGuards();
    $this->withToken($token)->postJson('/mcp', rpc())->assertUnauthorized();
    expect(DB::table('oauth_access_tokens')->where('revoked', true)->count())->toBe(1);
});

it('refuses the token request with a wrong PKCE verifier', function () {
    $id = registerClient();
    [, $challenge] = pkce();
    $user = staff();

    $this->actingAs($user)->get(authorizeUrl($id, $challenge));
    $approve = $this->actingAs($user)->post('/oauth/authorize', ['state' => 'st4te', 'client_id' => $id, 'auth_token' => session('authToken')]);
    parse_str((string) parse_url($approve->headers->get('Location'), PHP_URL_QUERY), $query);

    $this->postJson('/oauth/token', ['grant_type' => 'authorization_code', 'client_id' => $id, 'redirect_uri' => REDIRECT, 'code' => $query['code'], 'code_verifier' => 'wrong-verifier'])
        ->assertStatus(400);
});
