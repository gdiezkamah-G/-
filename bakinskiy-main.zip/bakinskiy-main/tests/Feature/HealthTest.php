<?php

use Illuminate\Support\Facades\DB;

it('answers 200 on /up', function () {
    $this->get('/up')->assertOk();
});

it('fails /up when the database does not respond', function () {
    DB::shouldReceive('select')->once()->with('select 1')->andThrow(new RuntimeException('db down'));

    $this->get('/up')->assertStatus(500);
});

it('schedules housekeeping', function () {
    $this->artisan('schedule:list')->expectsOutputToContain('queue:prune-failed')->assertSuccessful();
});
