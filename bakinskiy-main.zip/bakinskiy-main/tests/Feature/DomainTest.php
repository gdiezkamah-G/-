<?php

use Database\Seeders\CatalogSeeder;
use Illuminate\Support\Facades\URL;

const MAIN = 'https://bakinskybulvar.com';

beforeEach(function () {
    $this->seed(CatalogSeeder::class);
    config(['app.url' => MAIN]);
    URL::forceRootUrl(MAIN);
    URL::forceScheme('https'); // what AppServiceProvider does at boot when APP_URL is https
});

it('serves the main domain and other hosts such as health checks', function () {
    $this->get(MAIN.'/')->assertOk();
    $this->get('http://127.0.0.1/up')->assertOk();
});

it('uses the main domain in canonical, Open Graph, sitemap and robots', function () {
    $this->get(MAIN.'/produkciya/plov')->assertOk()
        ->assertSee('<link rel="canonical" href="'.MAIN.'/produkciya/plov">', false)
        ->assertSee('<meta property="og:url" content="'.MAIN.'/produkciya/plov">', false)
        ->assertSee('<meta property="og:image" content="'.MAIN.'/assets/og-default.png">', false);

    $this->get(MAIN.'/sitemap.xml')->assertSee('<loc>'.MAIN.'</loc>', false)->assertSee(MAIN.'/produkciya/plov', false);
    $this->get(MAIN.'/robots.txt')->assertSee('Sitemap: '.MAIN.'/sitemap.xml');
});

it('uses the main domain in JSON-LD', function () {
    $home = $this->get(MAIN.'/')->getContent();
    $product = $this->get(MAIN.'/produkciya/plov')->getContent();

    expect($home)->toContain('"url":"'.MAIN.'"')->toContain('"logo":"'.MAIN.'/icon-512.png"')
        ->and($product)->toContain('"url":"'.MAIN.'/produkciya/plov"')->toContain('"image":"'.MAIN.'/assets/og-default.png"');
});

it('keeps the main domain in canonical even if the request host differs', function () {
    $this->get('http://staging.example.test/produkciya/plov')
        ->assertSee('<link rel="canonical" href="'.MAIN.'/produkciya/plov">', false);
});
