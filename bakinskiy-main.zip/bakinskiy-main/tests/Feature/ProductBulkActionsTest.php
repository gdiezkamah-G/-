<?php

use App\Enums\ProductStatus;
use App\Enums\UserRole;
use App\Filament\Resources\Products\Pages\ListProducts;
use App\Models\Category;
use App\Models\Product;
use App\Models\User;
use Database\Seeders\CatalogSeeder;
use Livewire\Livewire;

beforeEach(function () {
    $this->seed(CatalogSeeder::class);
    $this->actingAs(User::factory()->role(UserRole::Editor)->create());
});

it('publishes selected products', function () {
    Product::query()->update(['status' => 'draft']);
    $selected = Product::whereIn('slug', ['plov', 'dolma'])->get();

    Livewire::test(ListProducts::class)->callTableBulkAction('publish', $selected)->assertNotified();

    expect(Product::where('status', ProductStatus::Published)->pluck('slug')->sort()->values()->all())->toBe(['dolma', 'plov']);
});

it('moves selected products to drafts and hides them from the site', function () {
    $selected = Product::whereIn('slug', ['plov'])->get();

    Livewire::test(ListProducts::class)->callTableBulkAction('draft', $selected);

    expect(Product::where('slug', 'plov')->first()->status)->toBe(ProductStatus::Draft);
    $this->get('/produkciya/plov')->assertNotFound();
    expect(Product::where('slug', 'dolma')->first()->status)->toBe(ProductStatus::Published);
});

it('changes the category of selected products', function () {
    $target = Category::where('slug', 'tisto')->first();
    $selected = Product::whereIn('slug', ['plov', 'dolma'])->get();

    Livewire::test(ListProducts::class)->callTableBulkAction('category', $selected, data: ['category_id' => $target->id]);

    expect(Product::whereIn('slug', ['plov', 'dolma'])->pluck('category_id')->unique()->all())->toBe([$target->id])
        ->and(Product::where('slug', 'mlynci')->first()->category_id)->toBe($target->id);
});

it('requires a category for the category action', function () {
    $selected = Product::whereIn('slug', ['plov'])->get();
    $before = Product::where('slug', 'plov')->value('category_id');

    Livewire::test(ListProducts::class)->callTableBulkAction('category', $selected, data: [])->assertHasTableBulkActionErrors(['category_id' => 'required']);

    expect(Product::where('slug', 'plov')->value('category_id'))->toBe($before);
});

it('clears "needs confirmation" notes on selected products only', function () {
    Product::query()->update(['needs_confirmation' => ['Уточнити вагу']]);
    $selected = Product::whereIn('slug', ['plov'])->get();

    Livewire::test(ListProducts::class)->callTableBulkAction('confirm', $selected);

    expect(Product::where('slug', 'plov')->first()->needs_confirmation)->toBeNull()
        ->and(Product::where('slug', 'dolma')->first()->needs_confirmation)->toBe(['Уточнити вагу']);
});

it('still deletes in bulk', function () {
    $selected = Product::whereIn('slug', ['plov', 'dolma'])->get();

    Livewire::test(ListProducts::class)->callTableBulkAction('delete', $selected);

    expect(Product::whereIn('slug', ['plov', 'dolma'])->exists())->toBeFalse()->and(Product::count())->toBe(2);
});

it('lists the bulk actions on the page', function () {
    Livewire::test(ListProducts::class)->assertTableBulkActionExists('publish')->assertTableBulkActionExists('draft')
        ->assertTableBulkActionExists('category')->assertTableBulkActionExists('confirm');
});
