<?php

use App\Services\Deploy\Check;
use App\Services\Deploy\EnvCheck;

/** @return array<string, Check> by name */
function envChecks(array $env): array
{
    return collect((new EnvCheck($env))->run())->keyBy('name')->all();
}

it('passes a complete production environment without a single problem', function () {
    $checks = (new EnvCheck(goodEnv()))->run();

    expect(collect($checks)->filter(fn (Check $c) => $c->status !== Check::OK)->all())->toBe([]);
});

it('fails with the variable name when a required one is missing', function (string $var) {
    $env = goodEnv();
    unset($env[$var]);

    $checks = envChecks($env);

    expect($checks[$var]->failed())->toBeTrue()->and($checks[$var]->detail)->not->toBeEmpty();
})->with(['APP_KEY', 'APP_URL', 'DB_HOST', 'DB_DATABASE', 'DB_USERNAME', 'DB_PASSWORD', 'REDIS_HOST']);

it('treats an empty value like a missing one', function () {
    expect(envChecks(goodEnv(['DB_PASSWORD' => '   ']))['DB_PASSWORD']->failed())->toBeTrue();
});

it('rejects a malformed APP_KEY with a hint on how to make one', function (string $key) {
    $c = envChecks(goodEnv(['APP_KEY' => $key]))['APP_KEY'];

    expect($c->failed())->toBeTrue();
})->with(['plain text', 'base64:short', 'base64:!!!notbase64!!!']);

it('explains how to generate a missing APP_KEY', function () {
    $env = goodEnv();
    unset($env['APP_KEY']);

    expect(envChecks($env)['APP_KEY']->detail)->toContain('openssl rand -base64 32');
});

it('checks APP_URL: invalid fails, http and a trailing slash only warn', function () {
    expect(envChecks(goodEnv(['APP_URL' => 'not a url']))['APP_URL']->failed())->toBeTrue()
        ->and(envChecks(goodEnv(['APP_URL' => 'http://example.com']))['APP_URL']->status)->toBe(Check::WARN)
        ->and(envChecks(goodEnv(['APP_URL' => 'https://example.com/']))['APP_URL']->status)->toBe(Check::WARN);
});

it('requires REDIS_HOST only when something uses Redis', function () {
    $env = goodEnv(['QUEUE_CONNECTION' => 'database', 'CACHE_STORE' => 'database', 'SESSION_DRIVER' => 'database']);
    unset($env['REDIS_HOST']);

    expect(envChecks($env))->not->toHaveKey('REDIS_HOST');
});

it('only warns about optional things: no admin, short password, half a Telegram setup, placeholder mail host, no token', function () {
    $noAdmin = goodEnv();
    unset($noAdmin['ADMIN_EMAIL'], $noAdmin['ADMIN_PASSWORD']);
    expect(envChecks($noAdmin)['ADMIN_*']->status)->toBe(Check::WARN)
        ->and(envChecks(goodEnv(['ADMIN_PASSWORD' => 'short']))['ADMIN_PASSWORD']->status)->toBe(Check::WARN)
        ->and(envChecks(goodEnv(['ADMIN_PASSWORD' => null]))['ADMIN_*']->status)->toBe(Check::WARN)
        ->and(envChecks(goodEnv(['TELEGRAM_WEBHOOK_SECRET' => null]))['TELEGRAM_WEBHOOK_SECRET']->status)->toBe(Check::WARN)
        ->and(envChecks(goodEnv(['TELEGRAM_BOT_TOKEN' => null, 'TELEGRAM_WEBHOOK_SECRET' => null]))['TELEGRAM_BOT_TOKEN']->status)->toBe(Check::WARN)
        ->and(envChecks(goodEnv(['MAIL_HOST' => 'smtp.вашого-провайдера.com']))['MAIL_HOST']->status)->toBe(Check::WARN)
        ->and(envChecks(goodEnv(['MAIL_MAILER' => 'log']))['MAIL_MAILER']->status)->toBe(Check::WARN)
        ->and(envChecks(goodEnv(['BACKUP_S3_BUCKET' => 'b']))['BACKUP_S3_*']->status)->toBe(Check::WARN);

    foreach ([$noAdmin, goodEnv(['TELEGRAM_BOT_TOKEN' => null])] as $env) {
        expect(collect((new EnvCheck($env))->run())->filter->failed()->all())->toBe([]);
    }
});

it('the command exits 1 with a plain list when something required is missing, 0 otherwise', function () {
    $vars = goodEnv();
    $old = array_map(fn ($k) => getenv($k), array_keys($vars));
    foreach ($vars as $k => $v) {
        putenv("{$k}={$v}");
    }

    $this->artisan('app:check-env')->assertSuccessful();

    putenv('DB_PASSWORD=');
    putenv('APP_KEY=');
    $this->artisan('app:check-env')->expectsOutputToContain('[FAIL] APP_KEY')->expectsOutputToContain('[FAIL] DB_PASSWORD')
        ->expectsOutputToContain('Деплой зупинено')->assertFailed();

    foreach (array_keys($vars) as $i => $k) {
        $old[$i] === false ? putenv($k) : putenv("{$k}={$old[$i]}");
    }
});
