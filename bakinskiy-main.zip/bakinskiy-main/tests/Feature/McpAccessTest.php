<?php

use App\Enums\Ability;
use App\Enums\LeadType;
use App\Enums\UserRole;
use App\Mcp\Prompts\CatalogCleanup;
use App\Mcp\Prompts\FollowupLeads;
use App\Mcp\Prompts\WeeklyLeadsReport;
use App\Mcp\Resources\BrandGuide;
use App\Mcp\Servers\BakinskyiServer;
use App\Mcp\Support\McpAccess;
use App\Mcp\Tools\Catalog\ListProducts;
use App\Mcp\Tools\Catalog\Publish;
use App\Mcp\Tools\Leads\ListLeads;
use App\Mcp\Tools\Site\SystemStatus;
use App\Mcp\Tools\Telegram\PublishChannelPost;
use App\Models\Lead;
use App\Models\McpAuditLog;
use App\Models\TelegramUser;
use App\Models\User;
use Database\Seeders\CatalogSeeder;
use Illuminate\Support\Facades\Auth;
use Laravel\Mcp\Request;

beforeEach(fn () => $this->seed(CatalogSeeder::class));

/** Every tool class of the server, grouped by the folder it lives in. */
function toolClasses(string $group): array
{
    return collect(glob(app_path("Mcp/Tools/{$group}/*.php")))
        ->map(fn ($f) => "App\\Mcp\\Tools\\{$group}\\".basename($f, '.php'))
        ->reject(fn ($c) => str_ends_with($c, 'StatusTool'))->values()->all();
}

// ---------- who sees which tools ----------

it('shows every tool to an admin', function () {
    $all = [...toolClasses('Catalog'), ...toolClasses('Leads'), ...toolClasses('Telegram'), ...toolClasses('Site')];

    expect($all)->toHaveCount(32);
    BakinskyiServer::actingAs(staff())->tools()->assertRegistered($all);
});

it('gives an editor the catalog and the leads, but not Telegram, site or system', function () {
    $editor = staff(UserRole::Editor);

    BakinskyiServer::actingAs($editor)->tools()
        ->assertRegistered([...toolClasses('Catalog'), ...toolClasses('Leads')])
        ->assertNotRegistered([...toolClasses('Telegram'), ...toolClasses('Site')]);
});

it('gives a manager only the leads', function () {
    BakinskyiServer::actingAs(staff(UserRole::Manager))->tools()
        ->assertRegistered(toolClasses('Leads'))
        ->assertNotRegistered([...toolClasses('Catalog'), ...toolClasses('Telegram'), ...toolClasses('Site')]);
});

it('shows nothing to someone without a role', function () {
    BakinskyiServer::actingAs(User::factory()->role(null)->create())->tools()
        ->assertNotRegistered([ListProducts::class, ListLeads::class, SystemStatus::class]);
});

it('treats a tool the role lacks as not found', function () {
    $manager = staff(UserRole::Manager);

    BakinskyiServer::actingAs($manager)->tool(Publish::class, ['ids' => [1], 'confirm' => true])->assertNotRegistered();
    BakinskyiServer::actingAs($manager)->tool(PublishChannelPost::class, ['kind' => 'catalog_pinned', 'confirm' => true])->assertNotRegistered();
});

it('refuses and logs a call that gets past the tool list without the right', function () {
    $manager = staff(UserRole::Manager);
    Auth::login($manager);

    $response = app(ListProducts::class)->handle(new Request([]));

    expect($response->isError())->toBeTrue()->and((string) $response->content())->toContain('Недостатньо прав');
    expect(McpAuditLog::sole())->result->toBe('denied')->tool->toBe('catalog_list_products')->user_id->toBe($manager->id);
});

it('shows prompts only for the tools the user has', function () {
    BakinskyiServer::actingAs(staff(UserRole::Manager))->prompts()->assertRegistered([FollowupLeads::class, WeeklyLeadsReport::class])->assertNotRegistered([CatalogCleanup::class]);
    BakinskyiServer::actingAs(staff())->prompts()->assertRegistered([FollowupLeads::class, WeeklyLeadsReport::class, CatalogCleanup::class]);
});

it('offers the brand guide, schema, statuses and post templates to everyone with a role', function () {
    BakinskyiServer::actingAs(staff(UserRole::Manager))->resource(BrandGuide::class)->assertSee(['Люля-кебаб', 'за запитом']);
    BakinskyiServer::actingAs(staff())->resources()->assertRegistered(BrandGuide::class);
});

it('has a role for every ability and managers cannot reach catalog or site abilities', function () {
    expect(UserRole::Admin->abilities())->toBe(Ability::all())
        ->and(UserRole::Manager->can(Ability::CatalogWrite))->toBeFalse()
        ->and(UserRole::Manager->can(Ability::LeadsWrite))->toBeTrue()
        ->and(UserRole::Editor->can(Ability::SiteWrite))->toBeFalse()
        ->and(UserRole::Editor->can(Ability::CatalogWrite))->toBeTrue();
});

// ---------- tokens over HTTP ----------

it('answers 401 with the OAuth discovery hint when there is no token', function () {
    $this->postJson('/mcp', rpc())->assertUnauthorized()->assertHeader('WWW-Authenticate');
    $this->withToken('bogus')->postJson('/mcp', rpc())->assertUnauthorized();
});

it('accepts a personal token and lists the tools of its owner', function () {
    $token = staff()->createToken('script', ['*'])->plainTextToken;

    $names = toolNames($this->withToken($token)->postJson('/mcp', rpc())->assertOk());

    expect($names)->toContain('catalog_publish', 'leads_list', 'system_status')->toHaveCount(32);
});

it('narrows the tools to the abilities of the personal token', function () {
    $token = staff()->createToken('reader', [Ability::LeadsRead])->plainTextToken;

    $names = toolNames($this->withToken($token)->postJson('/mcp', rpc())->assertOk());

    expect($names)->toContain('leads_list', 'leads_get', 'leads_summary')->not->toContain('leads_update_status', 'catalog_list_products', 'catalog_publish');
});

it('cannot widen a role through the token abilities', function () {
    $token = staff(UserRole::Manager)->createToken('greedy', ['*', Ability::CatalogWrite, Ability::SiteWrite])->plainTextToken;

    $names = toolNames($this->withToken($token)->postJson('/mcp', rpc())->assertOk());

    expect($names)->toContain('leads_list')->not->toContain('catalog_publish', 'site_update_contacts');
});

it('rejects a token of a user who has no role in the admin', function () {
    $token = User::factory()->role(null)->create()->createToken('x', ['*'])->plainTextToken;

    $this->withToken($token)->postJson('/mcp', rpc())->assertForbidden();
});

it('checks the role on every call: a demoted user is cut off at once with the same token', function () {
    $user = staff();
    $token = $user->createToken('script', ['*'])->plainTextToken;

    $this->withToken($token)->postJson('/mcp', rpc())->assertOk();

    $user->forceFill(['role' => null])->save();
    $this->app['auth']->forgetGuards();

    $this->withToken($token)->postJson('/mcp', rpc())->assertForbidden();
});

it('applies a role change to the very next call', function () {
    $user = staff();
    $token = $user->createToken('script', ['*'])->plainTextToken;
    expect(toolNames($this->withToken($token)->postJson('/mcp', rpc())))->toContain('catalog_publish');

    $user->forceFill(['role' => UserRole::Manager])->save();
    $this->app['auth']->forgetGuards();

    expect(toolNames($this->withToken($token)->postJson('/mcp', rpc())))->not->toContain('catalog_publish')->toContain('leads_list');
});

it('stops accepting a revoked token', function () {
    $user = staff();
    $token = $user->createToken('script', ['*'])->plainTextToken;
    $this->withToken($token)->postJson('/mcp', rpc())->assertOk();

    $user->tokens()->delete();
    $this->app['auth']->forgetGuards();

    $this->withToken($token)->postJson('/mcp', rpc())->assertUnauthorized();
});

it('does not accept a Mini App token of a Telegram user', function () {
    $tg = TelegramUser::create(['telegram_id' => 5, 'first_name' => 'Клієнт']);
    $token = $tg->createToken('miniapp', ['miniapp'])->plainTextToken;

    expect($this->withToken($token)->postJson('/mcp', rpc())->status())->toBeIn([401, 403]);
});

it('calls a tool over HTTP and writes the audit log with the token as the client', function () {
    $user = staff();
    $token = $user->createToken('Claude Code', ['*'])->plainTextToken;
    Lead::create(['company' => 'Кафе', 'contact_name' => 'Іван', 'phone' => '+380501234567', 'type' => LeadType::Price]);

    $r = $this->withToken($token)->postJson('/mcp', rpc('tools/call', ['name' => 'leads_list', 'arguments' => (object) []]))->assertOk();

    expect($r->json('result.content.0.text'))->toContain('Кафе');
    expect(McpAuditLog::sole())->client->toBe('токен: Claude Code')->tool->toBe('leads_list')->user_id->toBe($user->id);
});

it('limits the request rate of the MCP endpoint', function () {
    $token = staff()->createToken('script', ['*'])->plainTextToken;

    foreach (range(1, 90) as $i) {
        $this->withToken($token)->postJson('/mcp', rpc())->assertOk();
    }

    $this->withToken($token)->postJson('/mcp', rpc())->assertStatus(429);
});

it('checks the staff rule in McpAccess for abilities and clients', function () {
    $admin = staff();
    $token = $admin->createToken('s', [Ability::LeadsRead]);
    $admin->withAccessToken($token->accessToken);

    expect(McpAccess::allows($admin, Ability::LeadsRead))->toBeTrue()
        ->and(McpAccess::allows($admin, Ability::LeadsWrite))->toBeFalse()
        ->and(McpAccess::allows(null, Ability::LeadsRead))->toBeFalse()
        ->and(McpAccess::client($admin))->toBe('токен: s');
});

it('marks read-only tools as read-only and only the public-site changes as destructive', function () {
    $token = staff()->createToken('script', ['*'])->plainTextToken;
    $tools = collect($this->withToken($token)->postJson('/mcp', rpc())->assertOk()->json('result.tools'))->keyBy('name');

    $destructive = $tools->filter(fn ($t) => ($t['annotations']['destructiveHint'] ?? null) === true)->keys()->sort()->values()->all();
    expect($destructive)->toBe(['catalog_archive', 'catalog_publish', 'catalog_unpublish', 'telegram_publish_channel_post']);

    foreach (['catalog_list_products', 'catalog_get_product', 'catalog_audit', 'leads_list', 'leads_get', 'leads_summary', 'telegram_get_settings', 'system_status', 'price_pdf_info'] as $name) {
        expect($tools[$name]['annotations']['readOnlyHint'])->toBeTrue($name);
    }
    foreach (['catalog_create_product', 'leads_update_status', 'site_update_contacts'] as $name) {
        expect($tools[$name]['annotations']['readOnlyHint'] ?? false)->toBeFalse($name)->and($tools[$name]['annotations']['destructiveHint'] ?? true)->toBeFalse($name);
    }
    expect($tools->pluck('title')->filter(fn ($t) => preg_match('/^[A-Za-z ]+$/', $t)))->toBeEmpty();
});
