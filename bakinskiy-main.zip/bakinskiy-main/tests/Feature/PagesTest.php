<?php

use App\Models\Setting;
use Database\Seeders\CatalogSeeder;

beforeEach(fn () => $this->seed(CatalogSeeder::class));

it('renders the public pages', function (string $url) {
    $this->get($url)->assertOk()->assertSee('Бакинський Бульвар');
})->with(['/', '/produkciya', '/produkciya/lyulya-kebab', '/produkciya/dolma', '/produkciya/plov', '/produkciya/mlynci']);

it('returns 404 for an unknown product', function () {
    $this->get('/produkciya/nope')->assertNotFound();
});

it('shows catalog categories and products from the database', function () {
    $this->get('/produkciya')->assertSee('Гарячі страви')->assertSee('Люля-кебаб')->assertSee('Млинці');
});

it('shows pack sizes as variants on the product page', function () {
    $this->get('/produkciya/plov')->assertSee('3 кг')->assertSee('Пароконвектомат, 15 хв');
});

it('switches the price block by setting', function (string $mode, string $text) {
    Setting::put('price_mode', $mode);
    $this->get('/produkciya/plov')->assertSee($text);
})->with([['ask', 'Ціна — за запитом'], ['from', 'від ХХХ ₴'], ['login', 'Ціни для партнерів']]);

it('shows the default variant weight on packs and preselects its chip', function () {
    $html = $this->get('/produkciya/lyulya-kebab')->getContent();

    expect($html)->toMatch('/data-pack-weight\s*>1 кг<\/span>/')
        ->and($html)->toMatch('/data-sz="1 кг" aria-pressed="true"/')
        ->and($html)->toMatch('/data-sz="500 г" aria-pressed="false"/');
    $this->get('/produkciya')->assertSee('Гриль · 1 кг');
});
