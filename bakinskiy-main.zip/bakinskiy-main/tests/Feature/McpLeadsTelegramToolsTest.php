<?php

use App\Enums\LeadSource;
use App\Enums\LeadStatus;
use App\Enums\LeadType;
use App\Enums\ProductStatus;
use App\Enums\UserRole;
use App\Mcp\Tools\Leads\AddLeadNote;
use App\Mcp\Tools\Leads\AssignLead;
use App\Mcp\Tools\Leads\GetLead;
use App\Mcp\Tools\Leads\LeadsSummary;
use App\Mcp\Tools\Leads\ListLeads;
use App\Mcp\Tools\Leads\UpdateLeadStatus;
use App\Mcp\Tools\Site\GetSettings as SiteGetSettings;
use App\Mcp\Tools\Site\SystemStatus;
use App\Mcp\Tools\Site\UpdateContacts;
use App\Mcp\Tools\Telegram\GetSettings;
use App\Mcp\Tools\Telegram\PreviewChannelPost;
use App\Mcp\Tools\Telegram\PricePdfInfo;
use App\Mcp\Tools\Telegram\PricePdfRegenerate;
use App\Mcp\Tools\Telegram\PublishChannelPost;
use App\Mcp\Tools\Telegram\RecipientsList;
use App\Mcp\Tools\Telegram\RecipientToggle;
use App\Mcp\Tools\Telegram\UpdateTexts;
use App\Models\Lead;
use App\Models\Product;
use App\Models\Setting;
use App\Models\TelegramRecipient;
use App\Models\User;
use App\Services\Telegram\TelegramSettings;
use Database\Seeders\CatalogSeeder;
use Illuminate\Support\Facades\Storage;
use Spatie\LaravelPdf\Facades\Pdf;

beforeEach(function () {
    tgConfigure();
    $this->seed(CatalogSeeder::class);
});

function lead(array $over = []): Lead
{
    return Lead::create($over + ['company' => 'Кафе Схід', 'contact_name' => 'Іван', 'phone' => '+380501234567', 'type' => LeadType::Price, 'source' => LeadSource::Site]);
}

// ---------- leads ----------

it('lists and filters leads and pages them with a cursor', function () {
    $a = lead();
    $b = lead(['company' => 'Ресторан Море', 'type' => LeadType::Sample, 'source' => LeadSource::MiniApp, 'status' => LeadStatus::InProgress]);
    $c = lead(['company' => 'Готель', 'status' => LeadStatus::Won]);

    mcp()->tool(ListLeads::class)->assertSee(['Кафе Схід', 'Ресторан Море', 'Готель']);
    mcp()->tool(ListLeads::class, ['status' => 'in_progress'])->assertSee('Ресторан Море')->assertDontSee('Кафе Схід');
    mcp()->tool(ListLeads::class, ['type' => 'sample', 'source' => 'miniapp'])->assertSee('Ресторан Море')->assertDontSee('Готель');
    mcp()->tool(ListLeads::class, ['search' => 'Море'])->assertSee('Ресторан Море')->assertDontSee('Готель');
    mcp()->tool(ListLeads::class, ['limit' => 1])->assertSee('"next_cursor":'.$c->id)->assertSee('Готель')->assertDontSee('Ресторан Море');
    mcp()->tool(ListLeads::class, ['limit' => 1, 'cursor' => $c->id])->assertSee('Ресторан Море');
});

it('filters leads by date and rejects bad input in Ukrainian', function () {
    $old = lead(['company' => 'Давня']);
    $old->forceFill(['created_at' => now()->subDays(10)])->save();
    lead(['company' => 'Свіжа']);

    mcp()->tool(ListLeads::class, ['date_from' => now()->subDays(2)->format('Y-m-d')])->assertSee('Свіжа')->assertDontSee('Давня');
    mcp()->tool(ListLeads::class, ['date_from' => '13.01.2026'])->assertHasErrors(['YYYY-MM-DD']);
    mcp()->tool(ListLeads::class, ['status' => 'zzz'])->assertHasErrors();
    mcp()->tool(ListLeads::class, ['limit' => 500])->assertHasErrors();
});

it('shows a lead in full and reports a missing one', function () {
    $l = lead(['comment' => 'Потрібно 50 кг', 'volume_kg' => 50]);

    mcp()->tool(GetLead::class, ['id' => $l->id])->assertSee(['Потрібно 50 кг', '"volume_kg":50', '+380501234567']);
    mcp()->tool(GetLead::class, ['id' => 999])->assertHasErrors(['не знайдено']);
});

it('changes the status, records who took the lead first, and never deletes', function () {
    $user = staff(UserRole::Manager);
    $l = lead();

    mcp($user)->tool(UpdateLeadStatus::class, ['id' => $l->id, 'status' => 'in_progress'])->assertSee('В роботі');
    $l->refresh();
    expect($l->status)->toBe(LeadStatus::InProgress)->and($l->handled_by)->toBe($user->name)->and($l->handled_at)->not->toBeNull();

    $at = $l->handled_at;
    mcp($user)->tool(UpdateLeadStatus::class, ['id' => $l->id, 'status' => 'won']);
    expect($l->fresh()->status)->toBe(LeadStatus::Won)->and($l->fresh()->handled_at->equalTo($at))->toBeTrue()->and(Lead::count())->toBe(1);

    mcp($user)->tool(UpdateLeadStatus::class, ['id' => $l->id, 'status' => 'deleted'])->assertHasErrors();
});

it('appends notes without losing the old ones', function () {
    $user = staff();
    $l = lead(['notes' => 'Старе']);

    mcp($user)->tool(AddLeadNote::class, ['id' => $l->id, 'text' => 'Передзвонити завтра']);
    expect($l->fresh()->notes)->toStartWith('Старе')->toContain('Передзвонити завтра')->toContain($user->name);

    mcp($user)->tool(AddLeadNote::class, ['id' => $l->id, 'text' => ''])->assertHasErrors();
    mcp($user)->tool(AddLeadNote::class, ['id' => $l->id, 'text' => str_repeat('я', 1001)])->assertHasErrors(['1000']);
});

it('assigns a lead to a staff member only and lists staff when the id is wrong', function () {
    $l = lead();
    $m = staff(UserRole::Manager);
    $outsider = User::factory()->role(null)->create();

    mcp()->tool(AssignLead::class, ['id' => $l->id, 'user_id' => $m->id])->assertSee($m->name);
    expect($l->fresh()->manager_id)->toBe($m->id);

    mcp()->tool(AssignLead::class, ['id' => $l->id, 'user_id' => $outsider->id])->assertHasErrors(['Доступні']);
    mcp()->tool(AssignLead::class, ['id' => $l->id, 'user_id' => 0])->assertOk();
    expect($l->fresh()->manager_id)->toBeNull();
});

it('summarises leads by type, source and product, and counts the stale new ones', function () {
    $p = Product::first();
    lead(['product_id' => $p->id, 'type' => LeadType::Request, 'source' => LeadSource::MiniApp]);
    lead();
    $stale = lead(['company' => 'Стара']);
    $stale->forceFill(['created_at' => now()->subDays(2)])->save();

    $r = mcp()->tool(LeadsSummary::class, ['period' => 'week'])->assertSee(['"total":3', '"new_older_than_24h":1', $p->name, '"miniapp":1']);
    mcp()->tool(LeadsSummary::class, ['period' => 'today'])->assertSee('"total":2');
    mcp()->tool(LeadsSummary::class, ['period' => 'year'])->assertHasErrors();
});

// ---------- telegram ----------

it('shows the Telegram settings without any secret', function () {
    config(['bakinsky.telegram.webhook_secret' => 'TOP-SECRET-VALUE']);

    $r = mcp()->tool(GetSettings::class)->assertSee(['welcome', 'bot_username', 'bakinsky_bot'])->assertDontSee(['123456:TEST-TOKEN', 'TOP-SECRET-VALUE', 's3cret']);
});

it('updates only the given bot texts', function () {
    $s = app(TelegramSettings::class);
    $thanks = $s->text('thanks');

    mcp()->tool(UpdateTexts::class, ['welcome' => 'Вітаємо в Мануфактурі!'])->assertOk();
    expect($s->text('welcome'))->toBe('Вітаємо в Мануфактурі!')->and($s->text('thanks'))->toBe($thanks);

    mcp()->tool(UpdateTexts::class, [])->assertHasErrors(['жодного']);
    mcp()->tool(UpdateTexts::class, ['welcome' => str_repeat('я', 1501)])->assertHasErrors(['1500']);
});

it('lists recipients and toggles one', function () {
    $r = TelegramRecipient::create(['chat_id' => -100123, 'title' => 'Менеджери', 'type' => 'group', 'active' => true]);

    mcp()->tool(RecipientsList::class)->assertSee(['Менеджери', '"active":true']);
    mcp()->tool(RecipientToggle::class, ['id' => $r->id, 'active' => false])->assertSee('більше не отримує');
    expect($r->fresh()->active)->toBeFalse();
    mcp()->tool(RecipientToggle::class, ['id' => 999, 'active' => true])->assertHasErrors(['не знайдено']);
});

it('previews a channel post without sending anything', function () {
    $p = Product::published()->first();

    mcp()->tool(PreviewChannelPost::class, ['kind' => 'product', 'product' => $p->slug])
        ->assertSee([$p->name, 'start=product_'.$p->slug, 'лише перегляд']);
    mcp()->tool(PreviewChannelPost::class, ['kind' => 'catalog_pinned'])->assertSee(['start=catalog', 'start=price']);
    mcp()->tool(PreviewChannelPost::class, ['kind' => 'product'])->assertHasErrors(['вкажіть товар']);
    mcp()->tool(PreviewChannelPost::class, ['kind' => 'story'])->assertHasErrors();

    expect(tgCalls('sendMessage'))->toBeEmpty();
});

it('publishes to the channel only with confirm=true, then edits the same post instead of duplicating it', function () {
    config(['bakinsky.telegram.channel_id' => '@bb_channel']);
    $p = Product::published()->first();

    mcp()->tool(PublishChannelPost::class, ['kind' => 'product', 'product' => $p->slug])->assertSee(['confirm=true', 'Буде опубліковано']);
    expect(tgCalls('sendMessage'))->toBeEmpty();

    tgBot()->willReceive(['message_id' => 501, 'date' => time(), 'chat' => ['id' => -1001, 'type' => 'channel']]);
    mcp()->tool(PublishChannelPost::class, ['kind' => 'product', 'product' => $p->slug, 'confirm' => true])->assertSee('Пост опубліковано');
    $sent = tgCalls('sendMessage');
    expect($sent)->toHaveCount(1)->and($sent[0]['chat_id'])->toBe('@bb_channel')->and($sent[0]['text'])->toContain($p->name)
        ->and(json_encode($sent[0]['reply_markup']))->toContain('start=product_'.$p->slug);
    expect(app(TelegramSettings::class)->group('channel')['messages']['product:'.$p->slug])->toBe(501);

    tgBot()->willReceive(['message_id' => 501, 'date' => time(), 'chat' => ['id' => -1001, 'type' => 'channel']]);
    mcp()->tool(PublishChannelPost::class, ['kind' => 'product', 'product' => $p->slug, 'confirm' => true])->assertSee('оновлено');
    expect(tgCalls('editMessageText'))->toHaveCount(1)->and((int) tgCalls('editMessageText')[0]['message_id'])->toBe(501);
});

it('pins the catalog post the first time', function () {
    config(['bakinsky.telegram.channel_id' => '-1001']);

    tgBot()->willReceive(['message_id' => 7, 'date' => time(), 'chat' => ['id' => -1001, 'type' => 'channel']])->willReceive(true);
    mcp()->tool(PublishChannelPost::class, ['kind' => 'catalog_pinned', 'confirm' => true])->assertOk();

    expect(tgCalls('pinChatMessage'))->toHaveCount(1)->and((int) tgCalls('pinChatMessage')[0]['message_id'])->toBe(7);
});

it('does not post an unpublished product or without a channel', function () {
    $p = Product::first();
    $p->update(['status' => ProductStatus::Draft]);
    config(['bakinsky.telegram.channel_id' => '@bb']);

    mcp()->tool(PublishChannelPost::class, ['kind' => 'product', 'product' => $p->slug, 'confirm' => true])->assertHasErrors(['не опублікований']);

    config(['bakinsky.telegram.channel_id' => null]);
    mcp()->tool(PublishChannelPost::class, ['kind' => 'catalog_pinned', 'confirm' => true])->assertHasErrors(['Канал не задано']);
    expect(tgCalls('sendMessage'))->toBeEmpty();
});

it('tells the model when Telegram refuses the post', function () {
    config(['bakinsky.telegram.channel_id' => '@bb']);
    tgBot()->willReceive([], ok: false);

    mcp()->tool(PublishChannelPost::class, ['kind' => 'catalog_pinned', 'confirm' => true])->assertHasErrors(['Telegram не прийняв пост']);
});

it('regenerates the price PDF and reports on it', function () {
    Storage::fake('local');
    Pdf::fake();

    mcp()->tool(PricePdfInfo::class)->assertSee(['"exists":false', 'published_products']);
    mcp()->tool(PricePdfRegenerate::class)->assertOk();
    Pdf::assertSaved(fn () => true);
});

// ---------- site and system ----------

it('reads and updates the site contacts', function () {
    Setting::put('contact_phone', '+380500000000');

    mcp()->tool(SiteGetSettings::class)->assertSee('+380500000000');
    mcp()->tool(UpdateContacts::class, ['phone' => '+380 50 123 45 67', 'city' => 'Київ'])->assertOk();
    expect(Setting::get('contact_phone'))->toBe('+380 50 123 45 67')->and(Setting::get('contact_city'))->toBe('Київ');

    mcp()->tool(UpdateContacts::class, ['phone' => 'abc'])->assertHasErrors(['Телефон']);
    mcp()->tool(UpdateContacts::class, ['email' => 'not-an-email'])->assertHasErrors(['e-mail']);
    mcp()->tool(UpdateContacts::class, [])->assertHasErrors(['жодного']);

    mcp()->tool(UpdateContacts::class, ['city' => ''])->assertOk();
    expect(Setting::get('contact_city'))->toBeNull();
});

it('reports the system status like the doctor does', function () {
    mcp()->tool(SystemStatus::class)->assertSee(['checks', 'MCP (підключення ШІ)']);
});
