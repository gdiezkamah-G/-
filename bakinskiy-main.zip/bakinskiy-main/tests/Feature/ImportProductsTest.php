<?php

use App\Enums\ProductStatus;
use App\Enums\UserRole;
use App\Filament\Resources\Products\Pages\EditProduct;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\User;
use Database\Seeders\CatalogSeeder;
use Database\Seeders\DatabaseSeeder;

const REAL_FILE = 'database/data/products.json';

function importFile(array $data): string
{
    $path = tempnam(sys_get_temp_dir(), 'imp').'.json';
    file_put_contents($path, json_encode($data, JSON_UNESCAPED_UNICODE));

    return $path;
}

function sample(array $over = []): array
{
    return [
        'categories' => [['slug' => 'plov', 'name' => 'Плов', 'sort' => 4]],
        'products' => [array_merge([
            'slug' => 'plov-test', 'category' => 'plov', 'name' => 'Плов', 'subtitle' => "по-східному, з м'ясом",
            'full_name' => 'Плов по-східному заморожений', 'composition' => "рис, м'ясо, сіль.",
            'highlights' => ['Рис', "М'ясо", 'Сіль', 'Зелень'],
            'variants' => [['size_label' => '300 г', 'weight_g' => 300, 'units' => null, 'pack_note' => null, 'is_default' => true]],
            'storage_temp' => '-18 °C', 'shelf_life_months' => 6, 'cooking_steps' => null, 'needs_confirmation' => ['Уточнити вагу'], 'sort' => 1,
        ], $over)],
    ];
}

it('imports the real file: 5 categories, 14 drafts, 13 variants', function () {
    $this->artisan('app:import-products')->assertSuccessful();

    expect(Category::count())->toBe(5)->and(Product::count())->toBe(14)->and(ProductVariant::count())->toBe(13)
        ->and(Product::where('status', ProductStatus::Published)->count())->toBe(0);
});

it('keeps imported drafts off the site', function () {
    $this->artisan('app:import-products')->assertSuccessful();

    $this->get('/produkciya/plov-po-skhidnomu')->assertNotFound();
    $this->get('/produkciya')->assertOk()->assertDontSee('Плов');
});

it('publishes with --publish and the site shows 5 category chips', function () {
    $this->artisan('app:import-products', ['--publish' => true])->assertSuccessful();

    $html = $this->get('/produkciya')->assertOk()->getContent();
    foreach (['Люля-кебаб', 'Долма', 'Плов', 'Млинці', 'М’ясо для шаурми'] as $name) {
        expect($html)->toContain('>'.$name.'</button>');
    }
    expect(substr_count($html, 'class="chip"'))->toBe(6); // "Усі" + 5 categories
    $this->get('/produkciya/plov-po-skhidnomu')->assertOk();
});

it('is idempotent: a second run duplicates nothing and reports skipped', function () {
    $this->artisan('app:import-products')->assertSuccessful();
    $this->artisan('app:import-products')->expectsOutputToContain('skipped')->assertSuccessful();

    expect(Category::count())->toBe(5)->and(Product::count())->toBe(14)->and(ProductVariant::count())->toBe(13);
});

it('does not overwrite fields edited in the admin', function () {
    $this->artisan('app:import-products')->assertSuccessful();
    $p = Product::where('slug', 'plov-po-skhidnomu')->first();
    $p->update(['name' => 'Мій плов', 'composition' => 'мій склад', 'sort' => 99, 'storage_temp' => '−20 °C', 'needs_confirmation' => []]);
    $p->variants()->first()->update(['weight_g' => 350]);

    $this->artisan('app:import-products')->assertSuccessful();

    $p->refresh();
    expect($p->name)->toBe('Мій плов')->and($p->composition)->toBe('мій склад')->and($p->sort)->toBe(99)
        ->and($p->storage_temp)->toBe('−20 °C')->and($p->needs_confirmation)->toBe([])
        ->and($p->variants()->first()->weight_g)->toBe(350);
});

it('fills fields that were emptied, but never un-confirms resolved notes', function () {
    $this->artisan('app:import-products')->assertSuccessful();
    $p = Product::where('slug', 'm-yaso-dlya-shaurmy-telyatyna')->first();
    $p->update(['composition' => null, 'needs_confirmation' => []]);

    $this->artisan('app:import-products')->assertSuccessful();

    expect($p->fresh()->composition)->not->toBeEmpty()->and($p->fresh()->needs_confirmation)->toBe([]);
});

it('--overwrite restores values from the file', function () {
    $this->artisan('app:import-products')->assertSuccessful();
    $p = Product::where('slug', 'plov-po-skhidnomu')->first();
    $p->update(['name' => 'Мій плов', 'sort' => 99]);

    $this->artisan('app:import-products', ['--overwrite' => true])->assertSuccessful();

    expect($p->fresh()->name)->toBe('Плов')->and($p->fresh()->sort)->not->toBe(99);
});

it('creates no variant for a position without a weight and still renders its page', function () {
    $this->artisan('app:import-products', ['--publish' => true])->assertSuccessful();
    $p = Product::where('slug', 'm-yaso-dlya-shaurmy-telyatyna')->first();

    expect($p->variants)->toHaveCount(0);
    $this->get('/produkciya/m-yaso-dlya-shaurmy-telyatyna')->assertOk()
        ->assertDontSee('data-sz=', false)->assertDontSee('data-pack-weight', false)
        ->assertSee('М’ясо для шаурми')->assertSee('Повна назва');
    $this->get('/produkciya')->assertOk();
    $this->get('/')->assertOk();
});

it('hides the cooking block while steps are empty and shows it once filled', function () {
    $this->artisan('app:import-products', ['--publish' => true])->assertSuccessful();
    $p = Product::where('slug', 'plov-po-skhidnomu')->first();

    expect($p->cooking_steps)->toBeNull();
    $this->get('/produkciya/plov-po-skhidnomu')->assertOk()->assertDontSee('Приготувати просто');

    $p->update(['cooking_steps' => [['title' => 'Розігрів', 'text' => 'Пароконвектомат', 'minutes' => 15]]]);
    $this->get('/produkciya/plov-po-skhidnomu')->assertSee('Приготувати просто');
});

it('maps highlights to 4-6 coloured ingredients', function () {
    $this->artisan('app:import-products')->assertSuccessful();

    Product::all()->each(function (Product $p) {
        expect(count($p->ingredients))->toBeBetween(4, 6);
        foreach ($p->ingredients as $i) {
            expect($i['color'])->toMatch('/^#[0-9a-f]{6}$/i')->and($i['name'])->not->toBeEmpty();
        }
    });
    expect(Product::where('slug', 'plov-solodkyi')->first()->ingredients[0]['name'])->not->toBeEmpty();
});

it('normalises apostrophes, minus and shelf life', function () {
    $this->artisan('app:import-products', ['--file' => importFile(sample())])->assertSuccessful();
    $p = Product::where('slug', 'plov-test')->first();

    expect($p->subtitle)->toBe('по-східному, з м’ясом')->and($p->storage_temp)->toBe('−18 °C')
        ->and($p->shelf_life)->toBe('6 місяців')->and($p->hue)->toBe('#8a6420')->and($p->full_name)->toBe('Плов по-східному заморожений');

    $this->artisan('app:import-products', ['--file' => importFile(sample(['slug' => 'млинець-3', 'shelf_life_months' => 3]))])->assertSuccessful();
    expect(Product::where('slug', 'млинець-3')->first()->shelf_life)->toBe('3 місяці');
});

it('stores needs_confirmation and lists it in the report', function () {
    $this->artisan('app:import-products')
        ->expectsOutputToContain('Потрібно уточнити (4)')
        ->expectsOutputToContain('Вага в оригіналі написана як')
        ->assertSuccessful();

    expect(Product::where('slug', 'm-yaso-dlya-shaurmy-telyatyna')->first()->needs_confirmation)->toHaveCount(3);
});

it('fails clearly on a missing file, bad JSON and an unknown category', function () {
    $this->artisan('app:import-products', ['--file' => '/no/such/file.json'])->expectsOutputToContain('File not found')->assertFailed();

    $bad = tempnam(sys_get_temp_dir(), 'bad').'.json';
    file_put_contents($bad, '{oops');
    $this->artisan('app:import-products', ['--file' => $bad])->expectsOutputToContain('Invalid JSON')->assertFailed();

    $this->artisan('app:import-products', ['--file' => importFile(sample(['category' => 'nope']))])
        ->expectsOutputToContain('unknown category')->assertFailed();
});

it('removes demo data only with --remove-demo', function () {
    $this->seed(CatalogSeeder::class);
    $this->artisan('app:import-products')->assertSuccessful();
    expect(Product::where('slug', 'dolma')->exists())->toBeTrue();

    $this->artisan('app:import-products', ['--remove-demo' => true])->expectsOutputToContain('Demo data removed: 4 products, 3 categories')->assertSuccessful();

    expect(Product::where('slug', 'dolma')->exists())->toBeFalse()->and(Category::where('slug', 'gryl')->exists())->toBeFalse()
        ->and(Product::count())->toBe(14);
});

it('never seeds demo products in production', function () {
    app()->detectEnvironment(fn () => 'production');

    $this->artisan('db:seed', ['--class' => DatabaseSeeder::class, '--force' => true])->assertSuccessful();

    expect(Product::count())->toBe(0);
});

it('shows the "needs confirmation" notes in the admin card until they are removed', function () {
    $this->artisan('app:import-products')->assertSuccessful();
    $this->actingAs(User::factory()->role(UserRole::Editor)->create());

    $edit = fn () => Livewire\Livewire::test(EditProduct::class, ['record' => 'm-yaso-dlya-shaurmy-telyatyna']);

    $notes = array_values($edit()->assertSee('Потрібно уточнити')->get('data.needs_confirmation'));
    expect($notes)->toHaveCount(3)->and(json_encode($notes, JSON_UNESCAPED_UNICODE))->toContain('Склад містить алергени');

    Product::where('slug', 'm-yaso-dlya-shaurmy-telyatyna')->update(['needs_confirmation' => []]);
    $edit()->assertDontSee('Потрібно уточнити');

    $this->get('/admin/products')->assertOk()->assertSee('Потрібно уточнити');
});
