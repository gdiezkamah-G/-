<?php

use App\Enums\UserRole;
use App\Models\User;
use Database\Seeders\DatabaseSeeder;
use Illuminate\Support\Facades\Hash;

function adminConfig(array $over = []): void
{
    config(['bakinsky.admin' => array_merge([
        'email' => 'boss@example.test', 'name' => null, 'password' => 'first-password-123', 'reset_password' => false,
    ], $over)]);
}

it('creates the admin once with the default name', function () {
    adminConfig();

    $this->artisan('app:sync-admin')->expectsOutputToContain('Admin created')->assertSuccessful();

    $user = User::where('email', 'boss@example.test')->sole();
    expect($user->role)->toBe(UserRole::Admin)->and($user->name)->toBe('Admin')
        ->and(Hash::check('first-password-123', $user->password))->toBeTrue()
        ->and($user->password)->not->toBe('first-password-123');
});

it('uses ADMIN_NAME when given', function () {
    adminConfig(['name' => 'Анна']);
    $this->artisan('app:sync-admin')->assertSuccessful();

    expect(User::first()->name)->toBe('Анна');
});

it('does nothing on a repeated run, even with a different password or name', function () {
    adminConfig();
    $this->artisan('app:sync-admin');
    $hash = User::first()->password;

    adminConfig(['password' => 'another-password-456', 'name' => 'Other']);
    $this->artisan('app:sync-admin')->expectsOutputToContain('already exists')->assertSuccessful();

    $user = User::sole();
    expect($user->password)->toBe($hash)->and($user->name)->toBe('Admin');
});

it('resets the password with --reset-password', function () {
    adminConfig();
    $this->artisan('app:sync-admin');

    adminConfig(['password' => 'another-password-456']);
    $this->artisan('app:sync-admin', ['--reset-password' => true])->assertSuccessful();

    expect(Hash::check('another-password-456', User::sole()->password))->toBeTrue();
});

it('resets the password with ADMIN_PASSWORD_RESET=true', function () {
    adminConfig();
    $this->artisan('app:sync-admin');

    adminConfig(['password' => 'another-password-456', 'reset_password' => 'true']);
    $this->artisan('app:sync-admin')->assertSuccessful();

    expect(Hash::check('another-password-456', User::sole()->password))->toBeTrue();
});

it('stays silent and harmless without variables', function (array $over) {
    adminConfig($over);

    $this->artisan('app:sync-admin')->doesntExpectOutput()->assertSuccessful();
    expect(User::count())->toBe(0);
})->with([[['email' => null, 'password' => null]], [['email' => 'a@example.test', 'password' => '']], [['email' => '', 'password' => 'long-enough-password']]]);

it('rejects a short password without leaking it', function () {
    adminConfig(['password' => 'short-pw-1']);

    $this->artisan('app:sync-admin')
        ->expectsOutputToContain('at least 12 characters')
        ->doesntExpectOutputToContain('short-pw-1')
        ->assertFailed();

    expect(User::count())->toBe(0);
});

it('rejects an invalid e-mail', function () {
    adminConfig(['email' => 'not-an-email']);

    $this->artisan('app:sync-admin')->expectsOutputToContain('ADMIN_EMAIL')->assertFailed();
    expect(User::count())->toBe(0);
});

it('never lets a short reset password through', function () {
    adminConfig();
    $this->artisan('app:sync-admin');
    $hash = User::first()->password;

    adminConfig(['password' => 'tiny', 'reset_password' => true]);
    $this->artisan('app:sync-admin')->assertFailed();

    expect(User::first()->password)->toBe($hash);
});

it('does not seed an admin in production', function () {
    adminConfig();
    app()->detectEnvironment(fn () => 'production');

    $this->artisan('db:seed', ['--class' => DatabaseSeeder::class, '--force' => true])->assertSuccessful();

    expect(User::count())->toBe(0);
});

it('still creates the local admin from the seeder outside production', function () {
    adminConfig();

    $this->seed(DatabaseSeeder::class);

    expect(User::where('email', 'boss@example.test')->exists())->toBeTrue();
});
