<?php

use App\Enums\Ability;
use App\Enums\UserRole;
use App\Filament\Pages\AiConnections;
use App\Filament\Pages\ManageTelegram;
use App\Filament\Resources\AuditLogs\Pages\ListAuditLogs;
use App\Mcp\Tools\Catalog\ListCategories;
use App\Mcp\Tools\Catalog\UpdateProduct;
use App\Mcp\Tools\Leads\ListLeads;
use App\Models\McpAuditLog;
use App\Models\Product;
use App\Models\ProductRevision;
use App\Services\Deploy\Check;
use App\Services\Deploy\Doctor;
use App\Services\Telegram\TelegramSettings;
use Database\Seeders\CatalogSeeder;
use Illuminate\Support\Facades\Storage;
use Laravel\Sanctum\PersonalAccessToken;
use Livewire\Livewire;

beforeEach(function () {
    tgConfigure();
    $this->seed(CatalogSeeder::class);
});

// ---------- access to the admin sections by role ----------

it('keeps products, categories and leads apart by role', function () {
    $manager = staff(UserRole::Manager);
    $editor = staff(UserRole::Editor);
    $admin = staff();

    $this->actingAs($manager)->get('/admin/leads')->assertOk();
    $this->actingAs($manager)->get('/admin/products')->assertForbidden();
    $this->actingAs($manager)->get('/admin/categories')->assertForbidden();
    $this->actingAs($manager)->get('/admin/manage-settings')->assertForbidden();

    $this->actingAs($editor)->get('/admin/products')->assertOk();
    $this->actingAs($editor)->get('/admin/leads')->assertOk();
    $this->actingAs($editor)->get('/admin/telegram')->assertForbidden();
    $this->actingAs($editor)->get('/admin/system')->assertForbidden();

    $this->actingAs($admin)->get('/admin/products')->assertOk();
    $this->actingAs($admin)->get('/admin/manage-settings')->assertOk();
});

it('lets every role with access open the AI pages, and nobody without a role', function () {
    foreach ([UserRole::Admin, UserRole::Editor, UserRole::Manager] as $role) {
        $this->actingAs(staff($role))->get('/admin/ai-connections')->assertOk()->assertSee('Підключення ШІ');
        $this->actingAs(staff($role))->get('/admin/ai-log')->assertOk();
    }
});

it('does not let a browser session alone authenticate the MCP endpoint', function () {
    $this->actingAs(staff())->postJson('/mcp', rpc())->assertUnauthorized();
});

// ---------- the connection page ----------

it('shows the server address and how to connect Claude and ChatGPT', function () {
    Livewire::actingAs(staff())->test(AiConnections::class)
        ->assertSee(url('/mcp'))->assertSee('Add custom connector')->assertSee('Developer mode')->assertSee('Дозволити');
});

it('creates a personal token that works, is shown once and is limited to what the role allows', function () {
    $editor = staff(UserRole::Editor);

    // an ability beyond the role is not even an option
    Livewire::actingAs($editor)->test(AiConnections::class)
        ->callAction('createToken', ['name' => 'Greedy', 'abilities' => [Ability::CatalogRead, Ability::SiteWrite]])->assertNotSet('newToken', 'x');
    expect(PersonalAccessToken::count())->toBe(0);

    $page = Livewire::actingAs($editor)->test(AiConnections::class)
        ->callAction('createToken', ['name' => 'Claude Code', 'abilities' => [Ability::CatalogRead, Ability::LeadsRead]])
        ->assertSee('Новий токен');

    $plain = $page->get('newToken');
    expect($plain)->not->toBeEmpty();

    $stored = PersonalAccessToken::sole();
    expect($stored->abilities)->toBe([Ability::CatalogRead, Ability::LeadsRead])->and($stored->token)->not->toBe($plain);

    $names = toolNames($this->withToken($plain)->postJson('/mcp', rpc())->assertOk());
    expect($names)->toContain('catalog_list_products', 'leads_list')->not->toContain('catalog_publish', 'site_update_contacts');

    $page->call('dismissToken')->assertSet('newToken', null)->assertDontSee($plain);
});

it('revokes a personal token and the next call fails', function () {
    $admin = staff();
    $plain = $admin->createToken('script', ['*'])->plainTextToken;
    $id = PersonalAccessToken::sole()->id;

    Livewire::actingAs($admin)->test(AiConnections::class)->assertSee('script')->call('revokeToken', $id)->assertDontSee('script');

    $this->app['auth']->forgetGuards();
    $this->withToken($plain)->postJson('/mcp', rpc())->assertUnauthorized();
});

it('shows staff only their own tokens, but lets an admin see and revoke all', function () {
    $manager = staff(UserRole::Manager);
    $other = staff(UserRole::Editor);
    $other->createToken('Чужий токен', ['*']);
    $manager->createToken('Мій токен', ['*']);
    $otherId = PersonalAccessToken::where('name', 'Чужий токен')->value('id');

    Livewire::actingAs($manager)->test(AiConnections::class)->assertSee('Мій токен')->assertDontSee('Чужий токен')->call('revokeToken', $otherId);
    expect(PersonalAccessToken::where('name', 'Чужий токен')->exists())->toBeTrue();

    Livewire::actingAs(staff())->test(AiConnections::class)->assertSee('Мій токен')->assertSee('Чужий токен')->call('revokeToken', $otherId);
    expect(PersonalAccessToken::where('name', 'Чужий токен')->exists())->toBeFalse();
});

// ---------- the AI log ----------

it('shows the AI log with the calls, and lets staff see only their own', function () {
    $admin = staff();
    $manager = staff(UserRole::Manager);
    mcp($admin)->tool(UpdateProduct::class, ['product' => Product::first()->slug, 'subtitle' => 'Новий']);
    mcp($manager)->tool(ListLeads::class);

    Livewire::actingAs($admin)->test(ListAuditLogs::class)->assertCanSeeTableRecords(McpAuditLog::all())
        ->filterTable('tool', 'leads_list')->assertCanSeeTableRecords(McpAuditLog::where('tool', 'leads_list')->get())->assertCanNotSeeTableRecords(McpAuditLog::where('tool', 'catalog_update_product')->get());

    Livewire::actingAs($manager)->test(ListAuditLogs::class)->assertCanSeeTableRecords(McpAuditLog::where('user_id', $manager->id)->get())
        ->assertCanNotSeeTableRecords(McpAuditLog::where('user_id', $admin->id)->get());
});

it('rolls a product edit back from the AI log, once', function () {
    $admin = staff();
    $p = Product::first();
    $old = $p->subtitle;
    mcp($admin)->tool(UpdateProduct::class, ['product' => $p->slug, 'subtitle' => 'Змінений ШІ']);
    $log = McpAuditLog::where('tool', 'catalog_update_product')->sole();

    $page = Livewire::actingAs($admin)->test(ListAuditLogs::class)->assertTableActionVisible('revert', $log)->callTableAction('revert', $log);
    expect($p->fresh()->subtitle)->toBe($old)->and(ProductRevision::first()->reverted_at)->not->toBeNull();

    $page->assertTableActionHidden('revert', $log);
    expect(McpAuditLog::where('tool', 'product_revert')->exists())->toBeTrue();
});

it('hides the rollback from users who cannot edit the catalog and for read-only calls', function () {
    $admin = staff();
    $manager = staff(UserRole::Manager);
    mcp($admin)->tool(UpdateProduct::class, ['product' => Product::first()->slug, 'subtitle' => 'X']);
    $log = McpAuditLog::sole();

    Livewire::actingAs($admin)->test(ListAuditLogs::class)->assertTableActionVisible('details', $log);
    mcp($admin)->tool(ListCategories::class);
    $read = McpAuditLog::where('tool', 'catalog_list_categories')->sole();
    Livewire::actingAs($admin)->test(ListAuditLogs::class)->assertTableActionHidden('revert', $read);
});

// ---------- Telegram channel setting ----------

it('saves the channel on the Telegram page and forgets the remembered posts when it changes', function () {
    $s = app(TelegramSettings::class);
    $s->replace('channel', ['chat_id' => '@old', 'messages' => ['catalog_pinned' => 5]]);

    $page = Livewire::actingAs(staff())->test(ManageTelegram::class);
    $page->fillForm(['channel_id' => '@old'])->call('save');
    expect($s->group('channel'))->toBe(['chat_id' => '@old', 'messages' => ['catalog_pinned' => 5]]);

    $page->fillForm(['channel_id' => '@new_channel'])->call('save');
    expect($s->group('channel'))->toBe(['chat_id' => '@new_channel', 'messages' => []]);
});

// ---------- diagnostics ----------

it('reports MCP in the doctor: keys, route, connections', function () {
    $dir = useTempStorage();
    $find = fn () => collect(app(Doctor::class)->run())->firstWhere('name', 'MCP (підключення ШІ)');

    expect($find()->status)->toBe(Check::WARN)->and($find()->detail)->toContain('ключів');

    mkdir("{$dir}/app/oauth", 0775, true);
    file_put_contents("{$dir}/app/oauth/oauth-private.key", 'x');
    file_put_contents("{$dir}/app/oauth/oauth-public.key", 'y');

    expect($find()->status)->toBe(Check::OK)->and($find()->detail)->toContain('активних підключень: 0');
});

it('creates the OAuth keys at bootstrap once and never overwrites them', function () {
    $dir = useTempStorage();
    Storage::fake('local');
    config(['bakinsky.admin' => ['email' => null, 'name' => null, 'password' => null, 'reset_password' => false], 'bakinsky.catalog_import' => 'off', 'bakinsky.telegram.token' => null, 'nutgram.token' => null, 'passport.private_key' => null, 'passport.public_key' => null]);

    $this->artisan('app:bootstrap')->expectsOutputToContain('[OK] Ключі OAuth')->assertSuccessful();
    $key = file_get_contents("{$dir}/app/oauth/oauth-private.key");
    expect($key)->toContain('PRIVATE KEY')->and(substr(sprintf('%o', fileperms("{$dir}/app/oauth/oauth-private.key")), -3))->toBe('600');

    $this->artisan('app:bootstrap')->expectsOutputToContain('[SKIP] Ключі OAuth')->assertSuccessful();
    expect(file_get_contents("{$dir}/app/oauth/oauth-private.key"))->toBe($key);
});
