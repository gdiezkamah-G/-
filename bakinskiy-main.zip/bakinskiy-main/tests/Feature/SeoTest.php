<?php

use App\Models\Product;
use App\Models\Setting;
use Database\Seeders\CatalogSeeder;

beforeEach(fn () => $this->seed(CatalogSeeder::class));

function jsonLd(string $html): string
{
    preg_match('#<script type="application/ld\+json">(.*?)</script>#s', $html, $m);

    return $m[1] ?? '';
}

it('serves a sitemap with every published page', function () {
    $res = $this->get('/sitemap.xml')->assertOk();

    expect($res->headers->get('Content-Type'))->toContain('application/xml');
    $res->assertSee(route('home'), false)->assertSee(route('catalog'), false)
        ->assertSee(route('product', 'plov'), false)->assertSee(route('product', 'mlynci'), false);
});

it('hides drafts from the sitemap', function () {
    Product::where('slug', 'plov')->update(['status' => 'draft']);

    $this->get('/sitemap.xml')->assertDontSee('/produkciya/plov', false);
});

it('blocks indexing outside production and points to the sitemap', function () {
    $this->get('/robots.txt')->assertOk()->assertSee('Disallow: /')->assertSee('Sitemap: '.route('sitemap'));
});

it('allows indexing in production but keeps the admin out', function () {
    app()->detectEnvironment(fn () => 'production');

    $this->get('/robots.txt')->assertSee('Disallow: /admin')->assertSee('Allow: /')->assertDontSee("Disallow: /\n");
});

it('has meta and open graph tags on every page', function (string $url) {
    $this->get($url)->assertOk()
        ->assertSee('<meta name="description"', false)
        ->assertSee('<link rel="canonical" href="'.url($url).'">', false)
        ->assertSee('<meta property="og:title"', false)
        ->assertSee('<meta property="og:image" content="'.url('/assets/og-default.png').'">', false);
})->with(['/', '/produkciya', '/produkciya/dolma']);

it('uses the product description from the database in meta', function () {
    $this->get('/produkciya/dolma')->assertSee('Класична долма', false);
});

it('emits Product JSON-LD without a price in ask mode', function () {
    $ld = jsonLd($this->get('/produkciya/dolma')->getContent());

    expect($ld)->toContain('"@type":"Product"')->toContain('"name":"Долма у виноградному листі"')
        ->not->toContain('offers')->not->toContain('price');
});

it('adds an offer only in from mode with a price', function () {
    Setting::put('price_mode', 'from');
    expect(jsonLd($this->get('/produkciya/dolma')->getContent()))->not->toContain('"offers"');

    Setting::put('price_from', '18000');
    expect(jsonLd($this->get('/produkciya/dolma')->getContent()))->toContain('"price":"180.00"')->toContain('"priceCurrency":"UAH"');
});
