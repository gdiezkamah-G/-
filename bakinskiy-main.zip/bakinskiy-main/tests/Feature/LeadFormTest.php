<?php

use App\Enums\LeadStatus;
use App\Enums\LeadType;
use App\Livewire\LeadForm;
use App\Models\Lead;
use App\Models\Product;
use App\Notifications\NewLeadNotification;
use Database\Seeders\CatalogSeeder;
use Illuminate\Support\Facades\Notification;
use Livewire\Livewire;

beforeEach(function () {
    $this->seed(CatalogSeeder::class);
    config(['bakinsky.manager_email' => 'manager@example.test']);
});

it('validates required fields', function () {
    Livewire::test(LeadForm::class)
        ->call('submit')
        ->assertHasErrors(['company', 'contactName', 'phone']);

    expect(Lead::count())->toBe(0);
});

it('rejects a malformed phone', function () {
    Livewire::test(LeadForm::class)
        ->set('company', 'Кафе')->set('contactName', 'Іван')->set('phone', 'abc')
        ->call('submit')->assertHasErrors(['phone']);
});

it('stores a lead and notifies the manager', function () {
    Notification::fake();
    $product = Product::where('slug', 'plov')->first();

    Livewire::test(LeadForm::class)
        ->call('prepare', (string) $product->id, false)
        ->set('company', 'Ресторан Тест')->set('contactName', 'Іван')->set('phone', '+380501234567')->set('volumeKg', '50')
        ->call('submit')
        ->assertHasNoErrors()
        ->assertSet('sent', true);

    $lead = Lead::first();
    expect($lead->product_id)->toBe($product->id)
        ->and($lead->volume_kg)->toBe(50)
        ->and($lead->status)->toBe(LeadStatus::New)
        ->and($lead->type)->toBe(LeadType::Order);

    Notification::assertSentOnDemand(NewLeadNotification::class);
});

it('marks sample requests', function () {
    Livewire::test(LeadForm::class)
        ->call('prepare', null, true)
        ->set('company', 'Готель')->set('contactName', 'Анна')->set('phone', '0501234567')
        ->call('submit');

    expect(Lead::first()->type)->toBe(LeadType::Sample);
});

it('drops honeypot submissions silently', function () {
    Livewire::test(LeadForm::class)
        ->set('company', 'Бот')->set('contactName', 'Бот')->set('phone', '0501234567')->set('website', 'http://spam')
        ->call('submit');

    expect(Lead::count())->toBe(0);
});

it('rate limits the form per IP', function () {
    $t = Livewire::test(LeadForm::class);
    foreach (range(1, 6) as $i) {
        $t->set('company', "Заклад $i")->set('contactName', 'Іван')->set('phone', '0501234567')->call('submit')->set('sent', false);
    }

    expect(Lead::count())->toBe(5);
});

it('shows validation errors in Ukrainian, never as raw translation keys', function () {
    $t = Livewire::test(LeadForm::class)->call('submit');

    expect($t->errors()->first('company'))->toBe('Поле «назва закладу» обов’язкове.')
        ->and($t->errors()->first('contactName'))->toBe('Поле «контактна особа» обов’язкове.')
        ->and($t->errors()->first('phone'))->toBe('Поле «телефон» обов’язкове.');

    foreach ($t->errors()->all() as $message) {
        expect($message)->not->toContain('validation.');
    }
});
