# Доменна модель (стартова, уточнюємо по ходу)

Закладаємо одразу, наповнюємо по фазах. У фазі 1 потрібні тільки Category, Product, ProductVariant, Lead.

- **Category**: name, slug, sort.
- **Product**: name, subtitle, slug, category_id, short_tagline, description, ingredients (json), cooking_steps (json: title, text, minutes), shelf_life, storage_temp, status.
- **ProductVariant** (фасовка): product_id, sku, size_label («500 г», «1 кг»), weight_g, pack_type, is_active, sort.
- **MediaAsset**: поліморфний (product/variant), role (pack, dish, macro, frozen, cooked, cross-section), path, alt.
- **Lead**: company, contact_name, phone, product_id?, volume_kg?, source, status, manager_id?, notes.
- **Customer** (компанія): name, type (restaurant, hotel, catering, retail), tax_id, group_id, address, status. **Contact**: customer_id, name, phone, email, role.
- **CustomerGroup** і **PriceList / Price**: variant_id, group_id, price, currency, valid_from/to.
- **Order / OrderItem**: customer_id, status, delivery_at, address, totals; item: variant_id, qty, price.
- **Warehouse, Batch, StockMovement**: партія (variant_id, produced_at, expires_at, qty), рух (in, out, reserve, writeoff), облік FEFO.
- **Document**: тип (КП, прайс, накладна), customer_id, номер, pdf_path, дані snapshot.
- **User/Role**: admin, manager, warehouse.
- **ActivityLog** і **AgentDraft** (для майбутнього MCP-агента).
- **Setting**: ключ-значення (режим показу цін, контакти, тощо).

Ціни в БД зберігаються цілими в мінімальних одиницях. Усі статуси як enum.
