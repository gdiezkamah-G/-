# 09. MCP: керування магазином з Claude і ChatGPT

Один віддалений MCP-сервер усередині Laravel (пакет `laravel/mcp`). Адреса: `APP_URL/mcp`. Користуються лише співробітники адмінки: адміністратори, редактори, менеджери (кожен у межах своєї ролі).

## Архітектура

| Частина | Де |
|---|---|
| Маршрут і сервер | `routes/ai.php` (`Mcp::web('/mcp', BakinskyiServer::class)`), `app/Mcp/Servers/BakinskyiServer.php` |
| Інструменти (32) | `app/Mcp/Tools/{Catalog,Leads,Telegram,Site}`, базовий клас `BaseTool` |
| Ресурси (4), підказки (6) | `app/Mcp/Resources`, `app/Mcp/Prompts` |
| Права | `app/Enums/Ability.php` + `UserRole::abilities()` |
| Перевірка доступу | `app/Http/Middleware/McpAccess.php`, `app/Mcp/Support/McpAccess.php` |
| Журнал і версії | таблиці `mcp_audit_log`, `product_revisions`; `app/Mcp/Support/Audit.php`, `CatalogService` |
| Адмінка | «Підключення ШІ» (`AiConnections`), «Журнал ШІ» (`AuditLogResource`) |
| OAuth | Laravel Passport, сторінка згоди `resources/views/mcp/authorize.blade.php` |

Ланцюг запиту до `/mcp`: токен (`auth:sanctum,api`) → `mcp.access` (є роль?) → `throttle:mcp` (90 запитів/хв на користувача) → інструмент → ще раз перевірка права → журнал.

## Ролі й права

| Роль | Права |
|---|---|
| `admin` | усе |
| `editor` | каталог + заявки |
| `manager` | лише заявки |

Роль береться з бази **на кожен виклик**: понизили або прибрали користувача, і його токени (OAuth чи персональні) перестають працювати одразу. Інструмент, на який немає права, не зʼявляється у списку й не виконується. Персональний токен може лише звузити права ролі, не розширити.

Права: `catalog:read`, `catalog:write`, `leads:read`, `leads:write`, `telegram:read`, `telegram:write`, `site:read`, `site:write`, `system:read`.

## Інструменти

| Інструмент | Право | Що робить |
|---|---|---|
| `catalog_list_products`, `catalog_get_product`, `catalog_list_categories` | catalog:read | перегляд (курсорна пагінація) |
| `catalog_audit` | catalog:read | що потребує уваги: без складу, опису, фасування, «потребує уточнення», дублікати |
| `catalog_create_product` | catalog:write | новий товар **чернеткою** |
| `catalog_update_product` | catalog:write | зміна полів (статус не змінює); зберігає версію |
| `catalog_set_variants` | catalog:write | повний набір фасувань; зберігає версію |
| `catalog_create_category`, `catalog_update_category`, `catalog_reorder` | catalog:write | категорії й порядок |
| `catalog_publish` ⚠ | catalog:write | публікація; без `confirm=true` лише перегляд із попередженнями |
| `catalog_unpublish` ⚠, `catalog_archive` ⚠, `catalog_restore` | catalog:write | зняти, архівувати, відновити (як чернетку) |
| `product_revert` | catalog:write | повернути версію товару (статус не чіпає) |
| `leads_list`, `leads_get`, `leads_summary` | leads:read | заявки, підсумки |
| `leads_update_status`, `leads_add_note`, `leads_assign` | leads:write | робота із заявкою |
| `telegram_get_settings`, `telegram_recipients_list`, `telegram_preview_channel_post`, `price_pdf_info` | telegram:read | перегляд (без секретів) |
| `telegram_update_texts`, `telegram_recipient_toggle`, `price_pdf_regenerate` | telegram:write | налаштування бота й прайс |
| `telegram_publish_channel_post` ⚠ | telegram:write | пост у каналі; без `confirm=true` лише перегляд |
| `site_get_settings` / `site_update_contacts` | site:read / site:write | контакти |
| `system_status` | system:read | те саме, що `app:doctor` |

⚠ = позначено `destructiveHint`: змінює публічний сайт чи канал.

Ресурси: `bakinskyi://brand-guide`, `catalog-schema`, `lead-statuses`, `channel-post-templates`. Підказки: `add_product_from_notes`, `write_product_description`, `prepare_channel_post`, `weekly_leads_report`, `catalog_cleanup`, `followup_leads`.

## Запобіжники

- Видалення товарів, категорій і заявок через MCP **немає**: лише зняти, архівувати, відновити.
- Нове створюється чернеткою. Категорія без опублікованих товарів на сайті не видна.
- Публікація (сайт, канал) потребує явного `confirm=true`; без нього повертається «Буде опубліковано: …».
- Не більше 20 обʼєктів за виклик, інакше зрозуміла помилка.
- Увесь ввід валідується; помилки повертаються українською.
- Секрети (токен бота, паролі, `.env`) не віддаються. Персональні дані клієнтів лише в заявках і лише з `leads:read`.
- Кожен виклик пишеться в `mcp_audit_log` (користувач, клієнт, інструмент, параметри без секретів, результат, «було/стало»).
- Редагування товару зберігає попередню версію: `product_revert(revision_id)` або кнопка «Відкотити» в «Журналі ШІ». Повернення теж можна скасувати.
- `config/sanctum.php`: `guard => []`, тобто сесія адмінки сама ніколи не автентифікує `/mcp` чи API.

## OAuth (Claude, ChatGPT)

Стандарт MCP: OAuth 2.1, PKCE (S256), динамічна реєстрація клієнтів.

1. Клієнт читає `/.well-known/oauth-protected-resource/mcp` і `/.well-known/oauth-authorization-server`.
2. Реєструється: `POST /oauth/register` (дозволені redirect-домени в `config/mcp.php`: claude.ai/com, chatgpt.com, openai, localhost, схеми claude/cursor/vscode).
3. Відкриває `/oauth/authorize`: якщо співробітник не увійшов, його ведуть на логін адмінки (той самий акаунт), потім показується сторінка згоди «Дозволити <клієнт> керувати магазином?» з переліком його прав. Акаунту без ролі показується «Немає доступу».
4. Код → `POST /oauth/token` (PKCE) → access token (7 днів) + refresh (60 днів).
5. Далі `Authorization: Bearer …` на `/mcp`.

Ключі Passport створюються при старті (`app:bootstrap`) у `storage/app/oauth` (том, що переживає редеплой). Альтернатива: змінні `PASSPORT_PRIVATE_KEY` / `PASSPORT_PUBLIC_KEY`.

## Як підключити

**Claude.ai / ChatGPT:** додайте сервер через MCP/Connectors з URL `https://<домен>/mcp` і пройдіть OAuth. E-mail акаунта Claude/ChatGPT не має збігатися з e-mail користувача сайту: права визначаються користувачем адмінки, який проходить OAuth.

**ChatGPT:** Settings → **Apps & Connectors** → Advanced → **Developer mode**; потім **Create**: назва, URL `https://<домен>/mcp`, автентифікація OAuth; підтвердіть на сторінці згоди. У чаті оберіть застосунок (режим розробника).

**Найпростіше для Claude Code / скриптів:** «Підключення ШІ» → «Створити токен для Claude / скрипта» (оберіть права), потім  
`claude mcp add --transport http bakinsky https://<домен>/mcp --header "Authorization: Bearer <токен>"`

Перевірка локально: `php artisan mcp:inspector /mcp` (потрібен Node; у полі Authorization вставте токен).

## Як відкликати доступ

Адмінка → «Підключення ШІ»: «Відкликати» біля підключення або токена (дія миттєва). Повністю закрити людину: змінити або прибрати її роль. Усі дії видно в «Журналі ШІ».

## Як додати інструмент

1. Клас у `app/Mcp/Tools/<Група>/`, що розширює `BaseTool`: `ability()`, `run(Request, User): array|Response`, за потреби `schema()` і `$writes = true`.
2. Атрибути: `#[Name('snake_case')]`, `#[Title('Українська назва')]`, `#[Description('…')]`, `#[IsReadOnly]` для читання; `#[IsDestructive]` лише якщо змінює публічний сайт, інакше `#[IsDestructive(false)]`.
3. Помилки для моделі: `throw new ToolError('…українською…')`; ввід перевіряйте через `$this->validated()`.
4. Для змін товару: `$before = $this->remember($product, $user)` перед змінами та `$this->changed($before, $after)` після.
5. Додайте клас у `BakinskyiServer::$tools` і тест (`mcp($user)->tool(Class::class, [...])`).

## Діагностика

- «Стан системи» / `app:doctor`: рядок «MCP (підключення ШІ)»: маршрут, ключі OAuth, таблиці, кількість підключень і токенів.
- 401 на `/mcp`: немає або прострочений токен; 403: у користувача немає ролі чи токен не має жодного права.
- Клієнт «не бачить» інструмент: у ролі немає потрібного права.
- Канал Telegram: «Налаштування Telegram» → «Канал» (або `TELEGRAM_CHANNEL_ID`); бот має бути адміном каналу.
