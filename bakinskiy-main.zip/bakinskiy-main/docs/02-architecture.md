# Архітектура

- **Моноліт Laravel.** Публічний сайт (Blade + Livewire), адмінка (Filament), API (`/api/v1`, Sanctum).
- **Структура:** `app/Models`, `app/Filament`, `app/Livewire`, `app/Services` (бізнес-логіка), `app/Actions` (одна дія = один клас), `resources/views/components` (Blade-компоненти), `resources/css`, `resources/js`.
- **CSS:** `tokens.css` (змінні) → `base.css` → `components/*.css` (по файлу на компонент) → `pages/*.css`. Без Tailwind у публічній частині. Сборка Vite.
- **JS:** невеликі модулі без бібліотек: `tilt.js`, `sparks.js` (canvas), `reveal.js` (IntersectionObserver), `scroll-progress.js`, `compare.js`, `count.js`, `timer.js`, `view-transitions.js`. Alpine для модалки, фільтрів, перемикачів.
- **Контент у БД**, а не в коді: товари, фасовка, склад, режими приготування, категорії.
- **Заглушки фото** це Blade-компонент `<x-media.placeholder>` з тим самим API, що й майбутній `<x-media.image>`.
- **Черги:** Redis, сповіщення про заявки через чергу.
- **Деплой:** Docker образ, Dokploy, `.env` через панель, healthcheck, міграції при релізі.
- **Безпека:** CSRF, rate limit на форму заявки, honeypot, валідація, логування.
- **Тести:** Pest (feature) + Playwright (візуальна перевірка).
