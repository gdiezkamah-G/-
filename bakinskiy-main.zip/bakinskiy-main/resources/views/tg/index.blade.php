<x-layouts.tg>
<div class="top"><img src="/assets/logo/seal-gold.svg" alt="" width="46" height="46"><div><b>Бакинський Бульвар</b><small>МАНУФАКТУРА</small></div></div>
<p class="lead">Власне виробництво ресторану. Заморожені напівфабрикати для кафе, готелів і кейтерингу.</p>

<div class="qa">
  <button type="button" data-act="price"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 13l-7 7-9-9V4h7z"/><circle cx="8" cy="8" r="1.4"/></svg>Прайс</button>
  <button type="button" data-act="samples"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 3h6M10 3v6l-5 9a2 2 0 002 3h10a2 2 0 002-3l-5-9V3"/></svg>Зразки</button>
  <button type="button" data-act="manager"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z"/></svg>Менеджер</button>
</div>

<div class="chips" id="chips" role="group" aria-label="Категорії">
  <button class="chip" type="button" aria-pressed="true" data-c="">Усі</button>
  @foreach($categories as $c)<button class="chip" type="button" aria-pressed="false" data-c="{{ $c->slug }}">{{ $c->name }}</button>@endforeach
</div>

<div id="list">
@foreach($categories as $c)
  <div class="cat" id="c-{{ $c->slug }}"><h2>{{ $c->name }}</h2><span>{{ $c->products->count() }} поз.</span></div>
  @foreach($c->products as $p)
    @php
        $sizes = $p->activeVariants->map(fn ($v) => $v->size_label.($v->pack_note ? ' · '.$v->pack_note : ''))->implode(', ');
        $shelf = $p->shelf_life ? preg_replace('/^(\d+)\s*місяц\S*$/u', '$1 міс.', $p->shelf_life) : null;
    @endphp
    <div class="row" id="p-{{ $p->slug }}" data-s="{{ $p->slug }}" data-n="{{ $p->name }}">
      <button type="button" aria-expanded="false" aria-controls="m-{{ $p->slug }}">
        <div class="th"><x-app.pack :product="$p" fallback="" /></div>
        <div class="tx"><b>{{ $p->name }}</b><small>{{ $p->subtitle }}</small></div>
        <span class="sz">{{ $p->pack_label }}</span>
        <svg class="chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>
      </button>
      <div class="more" id="m-{{ $p->slug }}"><div><div class="in">
        @if($p->composition_text)<p><b>Склад.</b> {{ $p->composition_text }}</p>@endif
        <dl>
          <dt>Фасування</dt><dd>{{ $sizes ?: '—' }}</dd>
          <dt>Зберігання</dt><dd>{{ $p->storage_temp ?: '−18 °C' }}</dd>
          @if($shelf)<dt>Термін</dt><dd>{{ $shelf }}</dd>@endif
          <dt>Ціна</dt><dd>{{ $price }}</dd>
        </dl>
        <div class="ask"><button type="button" class="btn btn--p" data-ask="{{ $p->slug }}">Запитати про товар</button></div>
      </div></div></div>
    </div>
  @endforeach
@endforeach
</div>

<div class="foot" id="contacts">
  <h3>Контакти</h3>
  <p>{{ $contacts['city'] ?: 'Київ' }} · HoReCa, оптові поставки</p>
  @if($contacts['phone'])<p><a href="{{ $contacts['phone_href'] }}">{{ $contacts['phone'] }}</a></p>@endif
  <p><a href="{{ $contacts['site'] }}" data-site>{{ $contacts['site_label'] }}</a></p>
  <button type="button" class="btn" id="site" data-url="{{ $contacts['site'] }}">Відкрити повний сайт</button>
</div>

{{-- drawn by us only when the page is opened outside Telegram; inside, the native MainButton is used --}}
<div class="main" id="main"><button type="button" id="mb"><span id="mbt">Отримати прайс</span></button></div>

<livewire:tg-sheet />
</x-layouts.tg>
