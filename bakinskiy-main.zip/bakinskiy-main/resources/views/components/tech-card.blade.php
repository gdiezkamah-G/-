@props(['product'])
<section style="border-top:1px solid var(--line)"><div class="wrap tcard"><div class="shead rv"><span class="eyebrow">Технічна картка</span><h2 class="gold-text">Характеристики</h2></div>
 <table class="spec" aria-label="Характеристики"><tbody>
  @if($product->full_name)<tr><th scope="row">Повна назва</th><td>{{ $product->full_name }}</td></tr>@endif
  @if($product->activeVariants->isNotEmpty())<tr><th scope="row">Фасування</th><td>{{ $product->activeVariants->map(fn ($v) => $v->size_label.($v->pack_note ? ' ('.$v->pack_note.')' : ''))->implode(' · ') }}</td></tr>@endif
  @foreach(['Зберігання' => $product->storage_temp, 'Термін придатності' => $product->shelf_life, 'Приготування' => $product->cooking_summary, 'Паковання' => $product->packaging] as $k => $v)
    @if($v)<tr><th scope="row">{{ $k }}</th><td>{{ $v }}</td></tr>@endif
  @endforeach
  @if($product->composition_text)<tr><th scope="row">Склад</th><td>{{ $product->composition_text }}</td></tr>@endif
 </tbody></table>
 <x-price-block /></div></section>
