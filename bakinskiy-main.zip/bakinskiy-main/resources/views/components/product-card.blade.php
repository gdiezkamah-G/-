@props(['product'])
<a class="card" :class="{ fade: fading, out: !shown('{{ $product->category->slug }}') }" href="{{ route('product', $product->slug) }}" data-src>
  <div class="card__m"><x-pack :product="$product" tilt /><x-media.placeholder :hue="$product->hue" /></div>
  <h3>{{ $product->name }} <span style="font:italic 500 .7em var(--serif);color:var(--gold)">{{ $product->subtitle }}</span></h3>
  <div class="card__r"><span>{{ collect([$product->category->name, $product->pack_label])->filter()->implode(' · ') }}</span><span class="go">Детальніше <x-arrow /></span></div>
</a>
