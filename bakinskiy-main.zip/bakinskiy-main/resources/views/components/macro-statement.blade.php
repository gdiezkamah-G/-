@props(['product'])
@php($wd = fn (string $t) => collect(explode(' ', $t))->map(fn ($w, $i) => '<span style="--i:'.$i.'">'.e($w).'</span>')->implode(' '))
<section class="macro" style="--hue:{{ $product->hue }};padding:0"><div class="macro__bg"></div><div class="wrap"><h2 class="gold-text wd">{!! $wd('Нічого зайвого.') !!}</h2><p class="wd">{!! $wd('Продукт. Рецептура. Смак.') !!}</p></div><div class="ph">Макро-фото · приклад</div></section>
