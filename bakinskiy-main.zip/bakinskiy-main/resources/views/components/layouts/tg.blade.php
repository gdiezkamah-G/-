@props(['title' => 'Бакинський Бульвар', 'description' => 'Власне виробництво ресторану. Заморожені напівфабрикати для кафе, готелів і кейтерингу.'])
<!doctype html>
<html lang="uk" data-ui="tg">
<head>
<meta charset="utf-8">
{{-- Telegram Mini App: its own light page. No tab bar, no screen stack, no service worker. --}}
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, user-scalable=no">
<title>{{ $title }}</title>
<meta name="description" content="{{ $description }}">
<meta name="robots" content="noindex">
<meta name="theme-color" content="#0E0B08">
<meta name="color-scheme" content="dark">
<link rel="icon" href="/assets/logo/favicon.svg" type="image/svg+xml">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Onest:wght@400;500;600&family=Playfair+Display:ital,wght@0,500;0,600;0,700;1,500;1,600&display=swap&subset=cyrillic">
<script src="https://telegram.org/js/telegram-web-app.js"></script>
@vite(['resources/css/tg.css', 'resources/js/tg.js'])
@livewireStyles
</head>
<body>
{{ $slot }}
@livewireScripts
</body>
</html>
