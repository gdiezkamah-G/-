@props(['title' => 'Бакинський Бульвар — Мануфактура', 'description' => null, 'image' => null, 'kind' => 'home', 'notab' => false, 'categories' => null])
@php($image ??= url('/assets/og-default.png'))
@php($description = \Illuminate\Support\Str::limit(strip_tags(filled($description) ? $description : 'Заморожені напівфабрикати за рецептами ресторану «Бакинський Бульвар». Для кафе, готелів і кейтерингу.'), 200))
@php($categories ??= \App\Models\Category::whereHas('products', fn ($q) => $q->published())->orderBy('sort')->get())
<!doctype html>
<html lang="uk" data-ui="app">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<x-head-meta :title="$title" :description="$description" :image="$image" />
<meta name="theme-color" content="#0b0906">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Бакинський Бульвар">
<x-ui-mode-script mode="app" />
@vite(['resources/css/app-shell.css', 'resources/js/app-shell.js'])
@livewireStyles
@stack('head')
<x-site-seo />
</head>
<body class="app-shell">
<div class="app" id="app">
  <div class="screens" id="screens">
    <div class="screen {{ $notab ? 'nt' : '' }}" data-kind="{{ $kind }}" data-url="{{ '/'.ltrim(request()->path(), '/') }}" data-title="{{ $title }}" @if($notab) data-notab @endif>{{ $slot }}</div>
  </div>
  <x-app.tabbar :kind="$kind" :hidden="$notab" />
  <div class="edge" id="edge" hidden aria-hidden="true"></div>
  <div class="scrim" id="scrim"></div>
  <livewire:order-sheet />
  <x-app.sheet-filter :categories="$categories" />
  <x-app.sheet-more />
  <div class="toast" id="toast" role="status"></div>
</div>
@livewireScripts
</body>
</html>
