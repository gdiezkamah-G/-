@props(['title' => 'Бакинський Бульвар — Мануфактура', 'description' => null, 'image' => null])
@php($image ??= url('/assets/og-default.png'))
@php($description = \Illuminate\Support\Str::limit(strip_tags(filled($description) ? $description : 'Заморожені напівфабрикати за рецептами ресторану «Бакинський Бульвар». Для кафе, готелів і кейтерингу.'), 200))
<!doctype html>
<html lang="uk" data-ui="full">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<x-head-meta :title="$title" :description="$description" :image="$image" />
<meta name="theme-color" content="#0E0B08">
<x-ui-mode-script mode="full" />
<script>if (matchMedia('(prefers-reduced-motion: reduce)').matches) document.documentElement.dataset.fx = 'off';</script>
@vite(['resources/css/app.css', 'resources/js/app.js'])
@livewireStyles
@stack('head')
<x-site-seo />
</head>
<body>
<x-header />
<main id="app">{{ $slot }}</main>
<x-footer />
<livewire:lead-form />
<div class="toast" id="toast" role="status"></div>
@livewireScripts
</body>
</html>
