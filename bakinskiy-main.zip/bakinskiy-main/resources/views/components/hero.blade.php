@props(['products'])
<section class="hero" style="padding:0">
 <div class="hero__bg"></div><div class="hero__light"></div><div class="hero__plate"></div><div class="hero__ring"></div><canvas id="sparks" aria-hidden="true"></canvas>
 <div class="wrap">
  <div>
   <span class="eyebrow">Власне виробництво ресторану</span>
   <h1 class="gold-text shim">Смак східного столу<em>у вашій кухні</em></h1>
   <p class="lead">Заморожені напівфабрикати за рецептами ресторану «Бакинський Бульвар». Для кафе, готелів і кейтерингу.</p>
   <div class="hero__cta"><button class="btn btn--p" type="button" data-order>Замовити <x-arrow /></button><a class="btn" href="{{ route('catalog') }}">Каталог продукції</a></div>
  </div>
  <div class="hero__stack" aria-hidden="true">@foreach($products as $p)<x-pack :product="$p" tilt />@endforeach</div>
 </div>
</section>
