@php
    $mode = \App\Enums\PriceMode::tryFrom(\App\Models\Setting::get('price_mode', 'ask')) ?? \App\Enums\PriceMode::Ask;
    $from = \App\Models\Setting::get('price_from');
@endphp
<div class="price" id="price" style="margin-top:22px">
@if($mode === \App\Enums\PriceMode::From)
  <div><b>від {{ $from !== null && $from !== '' ? number_format((int) $from / 100, 0, ',', ' ') : 'ХХХ' }} ₴ / кг</b><span>Остаточна ціна залежить від обсягу</span></div><button class="btn btn--s" type="button" data-order>Розрахувати</button>
@elseif($mode === \App\Enums\PriceMode::Login)
  <div><b>Ціни для партнерів</b><span>Показуються після входу в кабінет</span></div><button class="btn btn--s" type="button" disabled>Увійти</button>
@else
  <div><b>Ціна — за запитом</b><span>Надішлемо прайс і умови протягом робочого дня</span></div><button class="btn btn--s" type="button" data-order>Отримати прайс</button>
@endif
</div>
