@props(['name'])
@php
    // Inline the line icon so its strokes can be drawn (pathLength=1) and inherit currentColor.
    $svg = file_get_contents(public_path("assets/icons/icon-{$name}-gold.svg"));
    $svg = preg_replace('/ role="img" aria-label="[^"]*"/', ' aria-hidden="true"', $svg);
    $svg = str_replace('stroke="#C9A25A"', 'stroke="currentColor"', $svg);
    $svg = preg_replace('/<(path|circle) /', '<$1 pathLength="1" ', $svg);
@endphp
{!! $svg !!}
