@props(['product'])
@php($sizes = $product->activeVariants->pluck('size_label'))
@php($default = $product->pack_label)
<div class="wrap"><nav class="crumbs" aria-label="Навігація"><a href="{{ route('home') }}">Головна</a><span>/</span><a href="{{ route('catalog') }}">Продукція</a><span>/</span><span aria-current="page">{{ $product->name }}</span></nav></div>
<section class="ph1" style="--hue:{{ $product->hue }};padding:0" id="ph1"><div class="wrap">
 <div><span class="eyebrow">{{ $product->category->name }}</span><h1 class="gold-text">{{ $product->name }}</h1>@if($product->short_tagline ?: $product->subtitle)<p class="tag">{{ $product->short_tagline ?: $product->subtitle }}</p>@endif
  @if($sizes->isNotEmpty())<div class="sizes" role="group" aria-label="Фасування">@foreach($sizes as $i => $z)<button type="button" data-sz="{{ $z }}" aria-pressed="{{ $z === $default ? 'true' : 'false' }}">{{ $z }}</button>@endforeach</div>@endif
  <p class="sz-line" @if($sizes->isEmpty()) style="margin-top:26px" @endif>@if($default)<span id="szl">{{ $default }}</span> · @endif заморожена · {{ $product->storage_temp }}</p>
  <div class="ph1__cta" id="ctaRow"><button class="btn btn--p" type="button" data-order="{{ $product->id }}">Замовити <x-arrow /></button><a class="lnk" href="#b2b" data-scroll="b2b">Для HoReCa <x-arrow /></a></div></div>
 <div class="plate" style="--hue:{{ $product->hue }}"><x-media.placeholder :hue="$product->hue" /><div class="steam" aria-hidden="true"><i></i><i></i><i></i></div>
  <x-pack :product="$product" id="front" /></div>
</div></section>
