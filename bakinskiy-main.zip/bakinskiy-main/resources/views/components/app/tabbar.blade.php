@props(['kind', 'hidden' => false])
@php($tab = ['home' => 'home', 'catalog' => 'catalog', 'product' => 'catalog', 'contacts' => 'contacts'][$kind] ?? null)
<nav class="tabbar {{ $hidden ? 'hide' : '' }}" id="tabbar" aria-label="Головна навігація">
  <a class="tb" href="{{ route('home') }}" data-nav data-tab="home" @if($tab === 'home') aria-current="true" @endif><x-app.icon name="house" />Головна</a>
  <a class="tb" href="{{ route('catalog') }}" data-nav data-tab="catalog" @if($tab === 'catalog') aria-current="true" @endif><x-app.icon name="catalog" />Каталог</a>
  <button class="tb tb--c" type="button" data-order aria-label="Замовити"><i><x-app.icon name="send" w="1.8" /></i><span>Замовити</span></button>
  <a class="tb" href="{{ route('contacts') }}" data-nav data-tab="contacts" @if($tab === 'contacts') aria-current="true" @endif><x-app.icon name="phone" />Контакти</a>
  <button class="tb" type="button" data-more><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="19" cy="12" r="1.8"/></svg>Ще</button>
</nav>
