@php
    $mode = \App\Enums\PriceMode::tryFrom(\App\Models\Setting::get('price_mode', 'ask')) ?? \App\Enums\PriceMode::Ask;
    $from = \App\Models\Setting::get('price_from');
@endphp
<div class="price">
@if($mode === \App\Enums\PriceMode::From)
  <div><b>від {{ filled($from) ? number_format((int) $from / 100, 0, ',', ' ') : 'ХХХ' }} ₴ / кг</b><span>Остаточна ціна залежить від обсягу</span></div>
@elseif($mode === \App\Enums\PriceMode::Login)
  <div><b>Ціни для партнерів</b><span>Показуються після входу в кабінет</span></div>
@else
  <div><b>Ціна — за запитом</b><span>Надішлемо прайс протягом робочого дня</span></div>
@endif
</div>
