@props(['categories'])
<div class="sheet" id="sheet-filter" role="dialog" aria-modal="true" aria-label="Фільтри"><div class="grab" data-grab></div><div class="sheet__b">
  <h2 class="gold-text">Фільтри</h2>
  <p class="eyebrow" style="margin-bottom:10px">Категорія</p>
  <div class="chips" style="padding:0 0 14px;flex-wrap:wrap" data-fgroup="cat">
    <button class="chip" type="button" data-fc="all" aria-pressed="true">Усі</button>
    @foreach($categories as $c)<button class="chip" type="button" data-fc="{{ $c->slug }}" aria-pressed="false">{{ $c->name }}</button>@endforeach
  </div>
  <p class="eyebrow" style="margin-bottom:10px">Основа</p>
  <div class="chips" style="padding:0 0 18px;flex-wrap:wrap" data-fgroup="base">
    @foreach(['all' => 'Усі', 'курка' => 'Курка', 'телятина' => 'Телятина', 'баранина' => 'Баранина', 'індичка' => 'Індичка', 'без м’яса' => 'Без м’яса'] as $key => $label)
      <button class="chip" type="button" data-fb="{{ $key }}" aria-pressed="{{ $key === 'all' ? 'true' : 'false' }}">{{ $label }}</button>
    @endforeach
  </div>
  <div class="f2"><button class="btn" type="button" data-freset>Скинути</button><button class="btn btn--p" type="button" data-fapply>Показати (<span data-fcount>0</span>)</button></div>
</div></div>
