@php($bot = config('bakinsky.telegram.bot_username'))
<div class="sheet" id="sheet-more" role="dialog" aria-modal="true" aria-label="Ще"><div class="grab" data-grab></div><div class="sheet__b">
  <h2 class="gold-text">Ще</h2>
  <div class="list" style="margin:0">
    <a class="row" href="{{ route('horeca') }}" data-nav data-close-sheet><i><x-app.icon name="fact" /></i><span><b>Для HoReCa</b><small>Переваги та умови співпраці</small></span><x-app.icon name="chev" /></a>
    <a class="row" href="{{ route('factory') }}" data-nav data-close-sheet><i><x-line-icon name="gear" /></i><span><b>Виробництво</b><small>Як ми готуємо</small></span><x-app.icon name="chev" /></a>
    @if($bot)
      <a class="row" href="https://t.me/{{ ltrim($bot, '@') }}" target="_blank" rel="noopener"><i><x-app.icon name="tg" /></i><span><b>Відкрити в Telegram</b><small>Бот і каталог у месенджері</small></span><x-app.icon name="chev" /></a>
    @endif
    <button class="row install" type="button" data-install hidden><i><x-app.icon name="home" /></i><span><b>Встановити на екран «Додому»</b><small>Працює як застосунок</small></span><x-app.icon name="chev" /></button>
    <button class="row" type="button" data-toast="Політика конфіденційності з’явиться тут"><i><x-app.icon name="lock" /></i><span><b>Політика конфіденційності</b></span><x-app.icon name="chev" /></button>
    <button class="row" type="button" data-toast="Умови використання з’являться тут"><i><x-app.icon name="doc" /></i><span><b>Умови використання</b></span><x-app.icon name="chev" /></button>
    <a class="row" href="{{ route('home') }}" data-ui-switch="full"><i><x-app.icon name="desktop" /></i><span><b>Повна версія сайту</b><small>Відкрити звичайний вигляд</small></span><x-app.icon name="chev" /></a>
    <div class="row"><i><x-app.icon name="gl" /></i><span><b>Мова</b><small>Українська</small></span></div>
  </div>
</div></div>
