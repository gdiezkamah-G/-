<header class="hdr"><div class="wrap">
  <a class="brand" href="{{ route('home') }}" aria-label="Бакинський Бульвар, на головну"><img src="/assets/logo/seal-gold.svg" alt="" width="54" height="54"><span><b>Бакинський Бульвар</b><small>МАНУФАКТУРА</small></span></a>
  <nav class="nav" aria-label="Головне меню">
    <a href="{{ route('home') }}" @if(request()->routeIs('home')) aria-current="page" @endif>Головна</a>
    <a href="{{ route('catalog') }}" @if(request()->routeIs('catalog', 'product')) aria-current="page" @endif>Продукція</a>
    <a href="{{ route('home') }}#process">Виробництво</a>
  </nav>
  <button class="btn btn--p btn--s" type="button" data-order>Замовити</button>
</div></header>
