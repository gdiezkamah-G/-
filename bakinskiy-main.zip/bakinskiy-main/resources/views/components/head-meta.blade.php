@props(['title', 'description', 'image'])
@php($setting = app('App\\Models\\Setting'))
@php($title = $title ?: $setting::get('seo_default_title', 'Бакинський Бульвар — Мануфактура'))
@php($description = $description ?: $setting::get('seo_default_description', 'Заморожені напівфабрикати за рецептами ресторану «Бакинський Бульвар».'))
@php($image = $setting::get('seo_og_image_url', $image))
<title>{{ $title }}</title>
<meta name="description" content="{{ $description }}">
<link rel="canonical" href="{{ url(request()->path()) }}">
<meta property="og:site_name" content="Бакинський Бульвар — Мануфактура">
<meta property="og:locale" content="uk_UA">
<meta property="og:type" content="website">
<meta property="og:title" content="{{ $title }}">
<meta property="og:description" content="{{ $description }}">
<meta property="og:url" content="{{ url(request()->path()) }}">
<meta property="og:image" content="{{ $image }}">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{{ $title }}">
<meta name="twitter:description" content="{{ $description }}">
<meta name="twitter:image" content="{{ $image }}">
<link rel="icon" href="/assets/logo/favicon.svg" type="image/svg+xml">
<link rel="icon" href="/favicon-32.png" type="image/png" sizes="32x32">
<link rel="icon" href="/favicon.ico" sizes="32x32">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="manifest" href="/manifest.webmanifest">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Onest:wght@400;500;600&family=Playfair+Display:ital,wght@0,500;0,600;0,700;1,500;1,600&display=swap&subset=cyrillic">
