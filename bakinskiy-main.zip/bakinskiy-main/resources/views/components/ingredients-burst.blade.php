@props(['product'])
@php
    $slots = [[14, 14], [86, 14], [8, 50], [92, 50], [14, 86], [86, 86]];
    $pick = [4 => [0, 1, 4, 5], 5 => [0, 1, 2, 3, 5], 6 => [0, 1, 2, 3, 4, 5]];
    $items = collect($product->ingredients ?? []);
    $idx = $pick[min(6, max(4, $items->count()))];
    $items = $items->take(count($idx))->values();
@endphp
@if($items->isNotEmpty())
<section><div class="wrap"><div class="shead rv"><span class="eyebrow">Склад</span><h2 class="gold-text">З чого народжується смак</h2></div>
 <div class="ing" id="ing"><svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">@foreach($items as $i => $it)<line x1="50" y1="50" x2="{{ $slots[$idx[$i]][0] }}" y2="{{ $slots[$idx[$i]][1] }}" pathLength="1"/>@endforeach</svg><div class="ing__c">{{ $product->name }}</div>@foreach($items as $i => $it)<div class="ing__i" style="--x:{{ $slots[$idx[$i]][0] }};--y:{{ $slots[$idx[$i]][1] }};--c:{{ $it['color'] ?? '#d9d3c0' }}"><i></i>{{ $it['name'] }}</div>@endforeach</div></div></section>
@endif
