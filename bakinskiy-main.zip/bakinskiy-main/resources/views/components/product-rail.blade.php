@props(['products'])
<div class="rail" tabindex="0" aria-label="Продукція">@foreach($products as $p)<a href="{{ route('product', $p->slug) }}" data-src><x-pack :product="$p" tilt /><div class="rail__cap"><b>{{ $p->name }}</b><span>{{ $p->pack_label }}</span></div></a>@endforeach</div>
