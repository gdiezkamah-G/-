@props(['categories'])
<div class="chips" role="group" aria-label="Категорії">
  <button class="chip" type="button" @click="pick('all')" :aria-pressed="f === 'all'" aria-pressed="true">Усі</button>
  @foreach($categories as $c)
    <button class="chip" type="button" @click="pick('{{ $c->slug }}')" :aria-pressed="f === '{{ $c->slug }}'" aria-pressed="false">{{ $c->name }}</button>
  @endforeach
</div>
