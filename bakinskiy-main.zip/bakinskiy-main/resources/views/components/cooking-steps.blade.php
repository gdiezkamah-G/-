@props(['product'])
@php($minutes = $product->cook_minutes)
@if($product->has_steps)
<section style="border-top:1px solid var(--line)"><div class="wrap"><div class="shead rv"><span class="eyebrow">Приготування</span><h2 class="gold-text">Приготувати просто</h2></div>
 <div class="cooks">@foreach($product->cooking_steps ?? [] as $i => $s)<div class="step cook rv" data-m="{{ $s['minutes'] ?? 0 }}"><span class="n">0{{ $i + 1 }}</span><h4>{{ $s['title'] }}</h4><p>{{ $s['text'] }}</p>@if(! empty($s['minutes']))<button class="btn btn--s" type="button" data-timer>Таймер {{ $s['minutes'] }} хв</button><div class="timer"><i></i></div>@endif</div>@endforeach</div>
 <div class="stats rv"><div><b id="stW">{{ $product->pack_label ?: '—' }}</b><span>упаковка</span></div><div><b><span data-count="{{ $minutes }}" style="font:inherit;letter-spacing:0;text-transform:none;color:inherit">{{ $minutes }}</span> хв</b><span>приготування</span></div><div><b><span data-count="-18" style="font:inherit;letter-spacing:0;text-transform:none;color:inherit">−18</span>°C</b><span>зберігання</span></div></div></div></section>
@endif
