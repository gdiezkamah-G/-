<section class="cta" id="cta"><div class="wrap">
 <span class="eyebrow">Співпраця</span><h2 class="gold-text">Готові спробувати на своїй кухні?</h2>
 <p class="lead" style="margin-inline:auto">Залиште заявку, і ми надішлемо зразки та прайс.</p>
 <button class="btn btn--p" type="button" data-order>Замовити <x-arrow /></button>
</div></section>
