@props(['mode'])
{{-- Runs before the first paint. Decides app/full from the real viewport, remembers it in the `ui` cookie
     and reloads once when the server rendered the other layout. `ui_pin` (set by the "Повна версія" /
     "Відкрити як застосунок" links) overrides the width check. --}}
<script>
(function () {
    var d = document.documentElement, rendered = '{{ $mode }}';
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) d.dataset.fx = 'off';
    var pin = (document.cookie.match(/(?:^|; )ui_pin=(app|full)/) || [])[1];
    var want = pin || (matchMedia('(max-width:768px)').matches ? 'app' : 'full');
    document.cookie = 'ui=' + want + '; path=/; max-age=31536000; samesite=lax';
    if (want !== rendered) {
        try {
            var last = +sessionStorage.getItem('ui_reload') || 0;
            if (Date.now() - last < 10000) return; // never loop
            sessionStorage.setItem('ui_reload', Date.now());
        } catch (e) {}
        d.style.visibility = 'hidden';
        location.reload();
    }
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) d.dataset.fx = 'off';
})();
</script>
