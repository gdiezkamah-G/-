<div class="feat"><div class="wrap"><ul class="draw">
 <li><span class="ico"><x-line-icon name="chef-hat" /></span>Рецепти ресторану</li>
 <li><span class="ico"><x-line-icon name="leaf" /></span>Натуральні інгредієнти</li>
 <li><span class="ico"><x-line-icon name="snowflake" /></span>Заморожено −18 °C</li>
 <li><span class="ico"><x-line-icon name="truck" /></span>Доставка</li>
 <li><span class="ico"><x-line-icon name="shield-check" /></span>Контроль якості</li>
</ul></div></div>
