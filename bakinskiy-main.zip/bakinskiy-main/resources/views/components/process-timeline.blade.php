<section class="process" id="process" style="border-top:1px solid var(--line)"><div class="wrap">
 <div class="rv"><span class="eyebrow">Виробництво</span><h2 class="gold-text" style="margin-top:12px;font-size:clamp(30px,4.2vw,52px)">Від рецепта до вашої морозильної камери</h2><p class="lead">П’ять кроків, на кожному з яких ми відповідаємо за якість.</p></div>
 <div class="tl" id="tl"><div class="tl__fill"></div>
  <div class="st"><h3>Рецепт ресторану</h3><p>Беремо страву, перевірену залом. Рецептура не змінюється при масштабуванні.</p></div>
  <div class="st"><h3>Відбір сировини</h3><p>Працюємо з постійними постачальниками й перевіряємо кожну партію.</p></div>
  <div class="st"><h3>Виробництво</h3><p>Ручне формування та контроль ваги кожної порції.</p></div>
  <div class="st"><h3>Заморожування</h3><p>Швидке охолодження до −18 °C і вакуумне паковання.</p></div>
  <div class="st"><h3>Доставка</h3><p>Привозимо за графіком у холодовому ланцюгу.</p></div>
 </div></div></section>
