{{-- Photo stub. Same props as the future <x-media.image>, so it can be swapped without touching callers. --}}
@props(['hue', 'label' => 'Фото страви · приклад'])
<div class="dish" style="--hue:{{ $hue }}"><div class="dish__plate"></div><small>{{ $label }}</small></div>
