@php
    $setting = fn (string $key, ?string $default = null) => \App\Models\Setting::get($key, $default);
    $sameAs = collect([$setting('seo_instagram_url'), $setting('seo_facebook_url')])->filter()->values()->all();
    $organization = array_filter([
        '@type' => 'Organization',
        'name' => $setting('seo_default_title', 'Бакинський Бульвар — Мануфактура'),
        'url' => url('/'),
        'logo' => $setting('seo_og_image_url', url('/icon-512.png')),
        'telephone' => $setting('seo_org_phone'),
        'email' => $setting('seo_org_email'),
        'sameAs' => $sameAs ?: null,
    ]);
    if ($setting('seo_org_address') || $setting('seo_org_city')) {
        $organization['address'] = array_filter(['@type' => 'PostalAddress', 'streetAddress' => $setting('seo_org_address'), 'addressLocality' => $setting('seo_org_city')]);
    }
    if ($setting('seo_org_hours')) {
        $organization['openingHours'] = $setting('seo_org_hours');
    }
@endphp
<x-json-ld :data="['@context' => 'https://schema.org', '@graph' => [$organization, ['@type' => 'WebSite', 'name' => $organization['name'], 'url' => url('/')]]]" />
@if($setting('seo_google_analytics_id'))
<script async src="https://www.googletagmanager.com/gtag/js?id={{ urlencode($setting('seo_google_analytics_id')) }}"></script>
<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag('js',new Date);gtag('config','{{ $setting('seo_google_analytics_id') }}');</script>
@endif
@if($setting('seo_gtm_id'))
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f)})(window,document,'script','dataLayer','{{ $setting('seo_gtm_id') }}');</script>
@endif
@if($setting('seo_meta_pixel_id'))
<script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','{{ $setting('seo_meta_pixel_id') }}');fbq('track','PageView');</script>
@endif
