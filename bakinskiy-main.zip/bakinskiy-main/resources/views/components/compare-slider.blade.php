@props(['product'])
<section><div class="wrap"><div class="shead rv"><span class="eyebrow">Результат</span><h2 class="gold-text">Від морозилки до столу</h2></div>
 <div class="cmp" id="cmp" style="--hue:{{ $product->hue }}"><x-media.placeholder :hue="$product->hue" label="Фото · готова страва, приклад" />
  <div class="cmp__f"><x-media.placeholder :hue="$product->hue" label="Фото · заморожена, приклад" /></div>
  <span class="cmp__l a">Заморожена</span><span class="cmp__l b">Готова</span>
  <input type="range" min="2" max="98" value="50" aria-label="Порівняння: заморожена та готова страва" id="cmpr"><div class="cmp__h"></div></div></div></section>
