@props(['eyebrow', 'title'])
<div class="page-h"><div class="wrap"><span class="eyebrow">{{ $eyebrow }}</span><h1 class="gold-text">{{ $title }}</h1>{{ $slot }}</div></div>
