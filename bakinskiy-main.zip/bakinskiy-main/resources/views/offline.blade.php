<!doctype html>
<html lang="uk" data-ui="app">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Немає з’єднання — Бакинський Бульвар</title>
<meta name="theme-color" content="#0b0906">
<meta name="robots" content="noindex">
<style>
{{-- Self-contained: this page is served from the service worker cache, hashed CSS files may not be there. --}}
:root{--bg:#0E0B08;--gold:#C9A25A;--gold-hi:#F2DFA8;--text:#F3EAD7;--muted:#B9AC92;--ink:#1A1208;color-scheme:dark}
*{box-sizing:border-box}
html,body{height:100%;margin:0}
body{background:var(--bg);color:var(--text);font:400 15px/1.5 'Onest',system-ui,-apple-system,'Segoe UI',Roboto,sans-serif;display:grid;place-items:center;padding:24px;text-align:center}
main{display:grid;justify-items:center;gap:14px;max-width:340px}
img{width:96px;height:96px}
h1{margin:0;font:600 28px/1.1 'Playfair Display',Georgia,serif;color:var(--gold-hi)}
p{margin:0;color:var(--muted)}
button{margin-top:6px;height:48px;padding:0 24px;border-radius:12px;border:1px solid #E3C27B;background:linear-gradient(180deg,#E9CD86,var(--gold) 55%,#A9803B);color:var(--ink);font:600 13px/1 inherit;letter-spacing:.07em;text-transform:uppercase;cursor:pointer}
</style>
</head>
<body>
<main>
  <img src="/assets/logo/seal-gold.svg" alt="">
  <h1>Немає з’єднання</h1>
  <p>Перевірте інтернет і спробуйте ще раз. Раніше відкриті сторінки можуть бути доступні без мережі.</p>
  <button type="button" onclick="location.reload()">Оновити</button>
</main>
</body>
</html>
