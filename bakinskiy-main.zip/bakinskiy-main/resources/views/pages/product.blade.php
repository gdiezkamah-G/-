<x-layouts.app :title="trim($product->name.' '.$product->subtitle).' — Бакинський Бульвар'" :description="$product->description ?: $product->short_tagline ?: $product->full_name">
@push('head')<x-json-ld :data="$jsonLd" />@endpush
<x-product-hero :product="$product" />
<x-ingredients-burst :product="$product" />
<x-macro-statement :product="$product" />
<x-compare-slider :product="$product" />
<x-cooking-steps :product="$product" />
<x-tech-card :product="$product" />
<x-b2b-panel :product="$product" />
<section style="border-top:1px solid var(--line);padding-bottom:90px"><div class="wrap"><div class="shead rv"><span class="eyebrow">Також у каталозі</span><h2 class="gold-text">Спробуйте ще</h2></div><x-product-rail :products="$related" /></div></section>
<div class="sticky" id="sticky"><b>{{ $product->name }}</b><button class="btn btn--p btn--s" type="button" data-order="{{ $product->id }}">Замовити</button></div>
</x-layouts.app>
