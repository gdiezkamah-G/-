<x-layouts.app title="Продукція — Бакинський Бульвар" description="Люля-кебаб, долма, плов, млинці: заморожені напівфабрикати для кафе, ресторанів, готелів і кейтерингу. Різна фасовка під ваш обсяг.">
@push('head')<x-json-ld :data="['@context' => 'https://schema.org', '@type' => 'ItemList', 'name' => 'Продукція Бакинського Бульвару', 'itemListElement' => $products->values()->map(fn ($p, $i) => ['@type' => 'ListItem', 'position' => $i + 1, 'name' => trim($p->name.' '.$p->subtitle), 'url' => route('product', $p->slug)])->all()]" />@endpush
<div x-data="{ f: 'all', fading: false,
  shown(c) { return this.f === 'all' || this.f === c },
  pick(v) { if (v === this.f) return; this.fading = true; setTimeout(() => { this.f = v; this.$nextTick(() => requestAnimationFrame(() => this.fading = false)) }, document.documentElement.dataset.fx === 'off' ? 0 : 260) } }">
  <x-page-header eyebrow="Каталог" title="Продукція"><x-filter-chips :categories="$categories" /></x-page-header>
  <div class="wrap"><div class="grid" id="grid">@foreach($products as $p)<x-product-card :product="$p" />@endforeach</div></div>
</div>
</x-layouts.app>
