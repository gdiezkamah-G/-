<x-layouts.app>
@push('head')<x-json-ld :data="['@context' => 'https://schema.org', '@graph' => [['@type' => 'Organization', 'name' => 'Бакинський Бульвар — Мануфактура', 'url' => url('/'), 'logo' => url('/icon-512.png'), 'description' => 'Власне виробництво ресторану: заморожені напівфабрикати для HoReCa.'], ['@type' => 'WebSite', 'name' => 'Бакинський Бульвар — Мануфактура', 'url' => url('/')]]]" />@endpush
@php($top = $products->take(3))
{{-- Hero stack: the first product stands in the middle, the next two on the sides. --}}
<x-hero :products="collect([$top[1] ?? null, $top[0] ?? null, $top[2] ?? null])->filter()" />
<x-ornament-band />
<x-feature-strip />
<section><div class="wrap">
 <div class="sec-h rv"><div><span class="eyebrow">Продукція</span><h2 class="gold-text">Страви, які вже люблять гості</h2></div><div class="arrows"><button type="button" aria-label="Назад" data-rail="-1">←</button><button type="button" aria-label="Далі" data-rail="1">→</button></div></div>
 <x-product-rail :products="$products" />
 <p class="rv" style="margin-top:6px"><a class="btn" href="{{ route('catalog') }}">Весь каталог <x-arrow /></a></p>
</div></section>
<x-process-timeline />
<x-cta-band />
</x-layouts.app>
