@php $json = fn ($v) => json_encode($v, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); @endphp
<div class="space-y-4 text-sm">
    <div><b>{{ $log->tool }}</b> · {{ $log->created_at?->timezone('Europe/Kyiv')->format('d.m.Y H:i:s') }} · {{ $log->user?->name ?? '—' }} · {{ $log->client ?? '—' }}</div>
    @if($log->message)<div>{{ $log->message }}</div>@endif
    <div>
        <div class="font-medium mb-1">Параметри</div>
        <pre style="white-space:pre-wrap;word-break:break-word;font-size:12px;background:rgba(128,128,128,.12);padding:10px;border-radius:8px">{{ $json($log->input ?? []) }}</pre>
    </div>
    @if($log->changes)
        <div>
            <div class="font-medium mb-1">Було</div>
            <pre style="white-space:pre-wrap;word-break:break-word;font-size:12px;background:rgba(128,128,128,.12);padding:10px;border-radius:8px">{{ $json($log->changes['before'] ?? null) }}</pre>
        </div>
        <div>
            <div class="font-medium mb-1">Стало</div>
            <pre style="white-space:pre-wrap;word-break:break-word;font-size:12px;background:rgba(128,128,128,.12);padding:10px;border-radius:8px">{{ $json($log->changes['after'] ?? null) }}</pre>
        </div>
    @endif
</div>
