<x-filament-panels::page>
    @php
        $colors = ['OK' => 'success', 'WARN' => 'warning', 'FAIL' => 'danger'];
        $bad = collect($checks)->where('status', 'FAIL')->count();
        $warn = collect($checks)->where('status', 'WARN')->count();
    @endphp

    <x-filament::section>
        <div class="text-sm">
            @if ($bad)
                <b>Є проблеми: {{ $bad }}.</b> Виправте червоні рядки.
            @elseif ($warn)
                Усе працює, зауважень: {{ $warn }}.
            @else
                Усе гаразд.
            @endif
        </div>
    </x-filament::section>

    <x-filament::section>
        <table class="w-full text-sm" style="border-collapse:collapse">
            <tbody>
                @foreach ($checks as $c)
                    <tr style="border-bottom:1px solid rgba(128,128,128,.2)">
                        <td style="padding:10px 12px 10px 0;width:80px;white-space:nowrap">
                            <x-filament::badge :color="$colors[$c['status']] ?? 'gray'">{{ $c['status'] }}</x-filament::badge>
                        </td>
                        <td style="padding:10px 16px 10px 0;white-space:nowrap;font-weight:500">{{ $c['name'] }}</td>
                        <td style="padding:10px 0">{{ $c['detail'] }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </x-filament::section>
</x-filament-panels::page>
