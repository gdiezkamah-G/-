<x-filament-panels::page>
    @php $url = $this->serverUrl(); @endphp

    @if ($newToken)
        <x-filament::section icon="heroicon-o-key" icon-color="warning" heading="Новий токен: скопіюйте зараз">
            <p class="text-sm" style="margin-bottom:8px">Повторно його показати неможливо. Якщо загубите, відкличте й створіть новий.</p>
            <code style="display:block;word-break:break-all;padding:10px;border-radius:8px;background:rgba(128,128,128,.14);font-size:13px" x-data x-on:click="navigator.clipboard.writeText($el.innerText)">{{ $newToken }}</code>
            <div style="margin-top:10px"><x-filament::button size="sm" color="gray" wire:click="dismissToken">Я скопіював(ла)</x-filament::button></div>
        </x-filament::section>
    @endif

    <x-filament::section heading="Адреса MCP-сервера">
        <code style="display:block;padding:10px;border-radius:8px;background:rgba(128,128,128,.14);font-size:14px;word-break:break-all">{{ $url }}</code>
        <p class="text-sm" style="margin-top:10px;opacity:.8">Ваші права: {{ implode(' · ', $this->myAbilities()) ?: 'немає' }}.</p>
    </x-filament::section>

    <x-filament::section heading="Як підключити">
        <div class="text-sm" style="display:grid;gap:18px">
            <div>
                <b>Claude.ai / ChatGPT</b> — OAuth-підключення
                <ol style="margin:6px 0 0 18px;list-style:decimal">
                    <li>Відкрийте налаштування MCP/Connectors і додайте сервер.</li>
                    <li>Назва: «Бакинський Бульвар». URL: <code>{{ $url }}</code>. Натисніть <b>Add</b>.</li>
                    <li>Відкриється наша сторінка згоди: увійдіть під своїм акаунтом адмінки й натисніть <b>«Дозволити»</b>.</li>
                    <li>Після OAuth-підтвердження увімкніть конектор у чаті.</li>
                </ol>
            </div>
            <div>
                <b>ChatGPT</b> (потрібен план з режимом розробника)
                <ol style="margin:6px 0 0 18px;list-style:decimal">
                    <li>Settings → <b>Apps &amp; Connectors</b> → Advanced → увімкніть <b>Developer mode</b>.</li>
                    <li>Там же натисніть <b>Create</b> (додати MCP-сервер): назва «Бакинський Бульвар», URL <code>{{ $url }}</code>, автентифікація <b>OAuth</b>.</li>
                    <li>Підтвердіть доступ на нашій сторінці згоди (<b>«Дозволити»</b>).</li>
                    <li>У новому чаті оберіть цей застосунок у режимі розробника (кнопка «+» → Developer mode) і користуйтеся.</li>
                </ol>
            </div>
            <div>
                <b>Найпростіше: Claude Code / скрипти</b><br>
                Створіть токен кнопкою «Створити токен для Claude / скрипта». E-mail Claude не має збігатися з e-mail користувача сайту.<br>
                <code style="word-break:break-all">claude mcp add --transport http bakinsky {{ $url }} --header "Authorization: Bearer &lt;токен&gt;"</code>
            </div>
            <p style="opacity:.8">Нове створюється чернетками, публікація лише з підтвердженням, видалення недоступне, усі дії в «Журналі ШІ».</p>
        </div>
    </x-filament::section>

    <x-filament::section heading="Активні підключення (Claude, ChatGPT)">
        @php $connections = $this->connections(); @endphp
        @if (! $connections)
            <p class="text-sm" style="opacity:.7">Поки що ніхто не підключений.</p>
        @else
            <table class="w-full text-sm" style="border-collapse:collapse">
                <thead><tr style="text-align:left;border-bottom:1px solid rgba(128,128,128,.3)"><th style="padding:6px 8px 6px 0">Клієнт</th><th>Користувач</th><th>Підключено</th><th>Остання активність</th><th></th></tr></thead>
                <tbody>
                @foreach ($connections as $c)
                    <tr style="border-bottom:1px solid rgba(128,128,128,.2)">
                        <td style="padding:10px 8px 10px 0;font-weight:500">{{ $c['client'] }}</td>
                        <td>{{ $c['user'] }}</td>
                        <td>{{ $c['since'] }}</td>
                        <td>{{ $c['last'] ?? '—' }}</td>
                        <td style="text-align:right"><x-filament::button size="xs" color="danger" wire:click="revokeConnection('{{ $c['id'] }}')" wire:confirm="Відкликати доступ? Клієнту доведеться підключитися знову.">Відкликати</x-filament::button></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        @endif
    </x-filament::section>

    <x-filament::section heading="Персональні токени">
        @php $tokens = $this->tokens(); @endphp
        @if (! $tokens)
            <p class="text-sm" style="opacity:.7">Токенів немає. Створіть кнопкою «Створити токен» угорі сторінки.</p>
        @else
            <table class="w-full text-sm" style="border-collapse:collapse">
                <thead><tr style="text-align:left;border-bottom:1px solid rgba(128,128,128,.3)"><th style="padding:6px 8px 6px 0">Назва</th><th>Користувач</th><th>Права</th><th>Остання активність</th><th></th></tr></thead>
                <tbody>
                @foreach ($tokens as $t)
                    <tr style="border-bottom:1px solid rgba(128,128,128,.2)">
                        <td style="padding:10px 8px 10px 0;font-weight:500">{{ $t['name'] }}</td>
                        <td>{{ $t['user'] }}</td>
                        <td style="max-width:320px">{{ $t['abilities'] }}</td>
                        <td>{{ $t['last'] ?? 'не використовувався' }}</td>
                        <td style="text-align:right"><x-filament::button size="xs" color="danger" wire:click="revokeToken({{ $t['id'] }})" wire:confirm="Відкликати токен?">Відкликати</x-filament::button></td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        @endif
    </x-filament::section>
</x-filament-panels::page>
