<div x-data="{ async show(e) {
        const d = e.detail || {};
        const open = () => window.AppSheets.open(document.getElementById('sheet-order'));
        if ($wire.sent) { await $wire.prepare(d.product || null, d.mode || 'order'); open(); return; }
        open();
        $wire.prepare(d.product || null, d.mode || 'order');
    } }" @open-order.window="show($event)">
<div class="sheet" id="sheet-order" role="dialog" aria-modal="true" aria-label="Замовити" wire:ignore.self>
 <div class="grab" data-grab></div>
 <div class="sheet__b">
 @if($sent)
  <div class="ok"><svg viewBox="0 0 72 72" fill="none" stroke="#C9A25A" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="36" cy="36" r="30" pathLength="1"/><path d="M22 37l10 10 18-20" pathLength="1"/></svg><h2 class="gold-text" style="margin:0">Дякуємо!</h2><p class="note" style="font-size:14px">Менеджер зв’яжеться з вами протягом робочого дня.</p><button class="btn btn--b" type="button" data-close-sheet>Готово</button></div>
 @else
  <h2 class="gold-text">Замовити</h2>
  @if($product)<div class="mini"><x-app.pack :product="$product" /><div><b>{{ $product->name }}</b><div class="note">{{ $product->subtitle }}</div></div></div>@endif
  <div class="seg" role="group" aria-label="Тип запиту">
    @foreach(['Заявка', 'Прайс', 'Зразки'] as $i => $label)<button type="button" wire:click="setMode({{ $i }})" aria-pressed="{{ $mode === $i ? 'true' : 'false' }}">{{ $label }}</button>@endforeach
  </div>
  <form wire:submit="submit" novalidate>
   <label class="f">Назва закладу<input wire:model="company" autocomplete="organization" placeholder="Ресторан, готель, кейтеринг" @error('company') aria-invalid="true" @enderror>@error('company')<span class="err">{{ $message }}</span>@enderror</label>
   <div class="f2">
    <label class="f">Контактна особа<input wire:model="contactName" autocomplete="name" @error('contactName') aria-invalid="true" @enderror>@error('contactName')<span class="err">{{ $message }}</span>@enderror</label>
    <label class="f">Телефон<input wire:model="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="+380" @error('phone') aria-invalid="true" @enderror>@error('phone')<span class="err">{{ $message }}</span>@enderror</label>
   </div>
   <div class="f2">
    <label class="f">Позиція<select wire:model="productId"><option value="">Кілька позицій</option>@foreach($products as $p)<option value="{{ $p->id }}">{{ $p->name }}, {{ $p->subtitle }}</option>@endforeach</select></label>
    <label class="f">Обсяг, кг<input wire:model="volumeKg" type="number" min="1" inputmode="numeric" placeholder="50" @error('volumeKg') aria-invalid="true" @enderror>@error('volumeKg')<span class="err">{{ $message }}</span>@enderror</label>
   </div>
   <input class="hp" type="text" wire:model="website" tabindex="-1" autocomplete="off" aria-hidden="true">
   <button class="btn btn--p btn--b" type="submit" wire:loading.attr="disabled">Надіслати</button>
  </form>
 @endif
 </div>
</div>
</div>
