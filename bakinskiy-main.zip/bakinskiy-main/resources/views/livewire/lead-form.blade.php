<div x-data="{ show(e) {
        const d = e.detail || {};
        const open = () => $refs.dlg.showModal();
        if ($wire.sent) { $wire.prepare(d.product || null, !!d.sample).then(open); return; }
        open();
        $wire.prepare(d.product || null, !!d.sample);
    } }" @open-order.window="show($event)">
<dialog x-ref="dlg" wire:ignore.self aria-labelledby="dlgT" @click="if ($event.target === $el) $el.close()">
 <button class="x" type="button" aria-label="Закрити" @click="$refs.dlg.close()">×</button>
 <div class="dlg">
 @if($sent)
  <div class="ok"><img src="/assets/logo/seal-gold.svg" width="64" height="64" alt=""><h2 id="dlgT" class="gold-text">Дякуємо!</h2><p class="lead">Менеджер зв’яжеться з вами протягом робочого дня.</p><button class="btn" type="button" @click="$refs.dlg.close()">Закрити</button></div>
 @else
  <h2 id="dlgT" class="gold-text">{{ $sample ? 'Запросити зразки' : 'Замовити' }}</h2>
  <form wire:submit="submit" style="display:grid;gap:14px" novalidate>
   <label for="f1">Назва закладу<input id="f1" wire:model="company" required autocomplete="organization" placeholder="Ресторан, готель, кейтеринг">@error('company')<span class="err">{{ $message }}</span>@enderror</label>
   <div class="row2"><label for="f2">Контактна особа<input id="f2" wire:model="contactName" required autocomplete="name">@error('contactName')<span class="err">{{ $message }}</span>@enderror</label><label for="f3">Телефон<input id="f3" wire:model="phone" type="tel" required autocomplete="tel" placeholder="+380">@error('phone')<span class="err">{{ $message }}</span>@enderror</label></div>
   <div class="row2"><label for="f4">Позиція<select id="f4" wire:model="productId"><option value="">Кілька позицій</option>@foreach($products as $p)<option value="{{ $p->id }}">{{ $p->name }} ({{ $p->subtitle }})</option>@endforeach</select></label><label for="f5">Орієнтовний обсяг, кг<input id="f5" wire:model="volumeKg" type="number" min="1" placeholder="50">@error('volumeKg')<span class="err">{{ $message }}</span>@enderror</label></div>
   <input type="text" wire:model="website" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-9999px">
   <button class="btn btn--p" type="submit" wire:loading.attr="disabled">{{ $sample ? 'Надіслати запит' : 'Надіслати заявку' }}</button>
  </form>
 @endif
 </div>
</dialog>
</div>
