@php
    $texts = [
        'price' => ['Отримати прайс', $user ? 'Надішліть контакт — і PDF-прайс прийде в цей чат.' : 'Залиште номер — менеджер надішле прайс.', $user ? 'Надіслати' : 'Надіслати'],
        'samples' => ['Зразки', 'Оберіть що хочете спробувати — домовимось про доставку.', 'Замовити зразки'],
        'manager' => ['Зв’язатися з менеджером', $user ? 'Напишіть питання — відповімо в Telegram.' : 'Напишіть питання — зв’яжемось з вами.', 'Надіслати'],
        'request' => ['Запитати про товар', 'Уточнимо ціну, фасування та умови доставки.', 'Надіслати запит'],
    ][$mode] ?? ['', '', 'Надіслати'];
    $priceManual = $mode === 'price' && $step === 'form';
@endphp
<div x-data="{ on: false, dy: 0, y0: null,
        state(o) { window.dispatchEvent(new CustomEvent('tg-sheet-state', { detail: { open: o } })) },
        show(d) { this.on = true; this.state(true); $wire.open(d.mode, d.slug || null, window.TgApp.initData) },
        hide() { if (!this.on) return; this.on = false; this.dy = 0; this.state(false); setTimeout(() => !this.on && $wire.close(), 420) } }"
     @tg-open.window="show($event.detail)"
     @keydown.escape.window="hide()"
     @tg-request-contact.window="window.TgApp.requestContact(ok => $wire.contactResult(ok))">
  <div class="scrim" :class="{ on }" wire:ignore.self @click="hide()"></div>
  <div class="sheet" :class="{ on, drag: y0 !== null }" :style="dy ? `transform:translateY(${dy}px)` : ''" wire:ignore.self
       role="dialog" aria-modal="true" aria-label="{{ $texts[0] ?: 'Заявка' }}" :aria-hidden="!on" :inert="!on">
    <div class="g" wire:ignore.self
         @pointerdown="y0 = $event.clientY; $el.setPointerCapture($event.pointerId)"
         @pointermove="y0 !== null && (dy = Math.max(0, $event.clientY - y0))"
         @pointerup="if (y0 !== null) { dy > 110 ? hide() : (dy = 0); y0 = null }"
         @pointercancel="dy = 0; y0 = null"></div>
    <div class="b">
    @if($step === 'done')
      <div class="ok">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M7.5 12.5l3 3 6-6.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
        <h2>{{ $resultTitle }}</h2>
        <p class="s">{{ $resultText }}</p>
        <button type="button" class="btn btn--p" style="width:100%" @click="hide()">Готово</button>
      </div>
    @elseif($mode !== '')
      <h2>{{ $texts[0] }}</h2>
      <p class="s">{{ $priceManual && $user ? 'Залиште номер — надішлемо прайс у чат.' : $texts[1] }}</p>

      @if($user)
        <div class="who"><i>{{ mb_strtoupper(mb_substr($user->first_name ?: $user->full_name, 0, 1)) }}</i><div>{{ $user->full_name }}<small>{{ $user->username ? '@'.$user->username.' · ' : '' }}дані підставлено з Telegram</small></div></div>
      @endif

      @if($step === 'choose')
        <button type="button" class="btn btn--p" style="width:100%;height:50px;margin-bottom:10px" wire:click="share" wire:loading.attr="disabled">Поділитися номером</button>
        <button type="button" class="btn" style="width:100%;height:46px" wire:click="manual">Ввести вручну</button>
      @elseif($step === 'waiting')
        <div wire:poll.1s="checkPhone" class="s" style="color:var(--muted);text-align:center;padding:10px 0 4px">Чекаємо підтвердження від Telegram…</div>
        <button type="button" class="btn" style="width:100%;height:46px;margin-top:10px" wire:click="manual">Ввести вручну</button>
      @else
        @if($declined)<p class="s" style="color:var(--gold-hi)">Не вдалося отримати номер від Telegram. Введіть його вручну.</p>@endif
        <form wire:submit="submit" novalidate>
          @if($productLine)
            <label class="f"><span>Товар</span><input readonly value="{{ $productLine }}"></label>
          @endif
          @if(! $user)
            <label class="f"><span>Імʼя</span><input wire:model="name" autocomplete="name" placeholder="Як до вас звертатись" @error('name') aria-invalid="true" @enderror>@error('name')<span class="err">{{ $message }}</span>@enderror</label>
          @endif
          @if(! $user || ($mode === 'price' && ! $user->phone))
            <label class="f"><span>Телефон</span><input wire:model="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="+380" @error('phone') aria-invalid="true" @enderror>@error('phone')<span class="err">{{ $message }}</span>@enderror</label>
          @endif
          <label class="f"><span>Заклад (необов'язково)</span><input wire:model="company" placeholder="Назва закладу" @error('company') aria-invalid="true" @enderror>@error('company')<span class="err">{{ $message }}</span>@enderror</label>
          <label class="f"><span>Коментар</span><textarea wire:model="comment" placeholder="Обсяги, адреса доставки…" @error('comment') aria-invalid="true" @enderror></textarea>@error('comment')<span class="err">{{ $message }}</span>@enderror</label>
          <input class="hp" type="text" wire:model="website" tabindex="-1" autocomplete="off" aria-hidden="true">
          <button type="submit" class="btn btn--p" style="width:100%;height:50px" wire:loading.attr="disabled" wire:target="submit">{{ $texts[2] }}</button>
        </form>
      @endif
    @endif
    </div>
  </div>
</div>
