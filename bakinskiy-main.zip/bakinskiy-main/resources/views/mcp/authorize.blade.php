@php
    use App\Enums\Ability;
    use App\Mcp\Support\McpAccess;

    $isStaff = $user->role !== null;
    $name = trim((string) $client->name) ?: 'Невідомий застосунок';
    $abilities = $isStaff ? array_values(array_filter(Ability::all(), fn ($a) => McpAccess::allows($user, $a))) : [];
    $labels = Ability::labels();
@endphp
<!doctype html>
<html lang="uk">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<meta name="color-scheme" content="dark">
<title>Підключення ШІ</title>
<link rel="icon" href="/assets/logo/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Onest:wght@400;500;600&family=Playfair+Display:ital,wght@0,600;1,600&display=swap&subset=cyrillic">
@vite('resources/css/mcp.css')
</head>
<body>
<main class="card">
  <div class="brand"><img src="/assets/logo/favicon.svg" alt=""><div><b>Бакинський Бульвар</b><small>Мануфактура</small></div></div>

  @if($isStaff)
    <h1>Дозволити «{{ $name }}» керувати магазином?</h1>
    <p class="who">Ви увійшли як <b>{{ $user->name }}</b> ({{ $user->role->getLabel() }}). Застосунок діятиме від вашого імені й лише в межах ваших прав:</p>
    <ul class="can">
      @foreach($abilities as $a)<li>{{ $labels[$a] }}</li>@endforeach
    </ul>
    <p class="note">Нові товари й пости створюються чернетками. Публікація на сайті й у каналі — лише з вашого підтвердження. Видалення через ШІ недоступне, усі дії пишуться в журнал. Доступ можна відкликати в адмінці: «Підключення ШІ».</p>
    <div class="row">
      <form method="post" action="{{ route('passport.authorizations.deny') }}">
        @csrf @method('DELETE')
        <input type="hidden" name="state" value="{{ $request->state }}">
        <input type="hidden" name="client_id" value="{{ $client->getKey() }}">
        <input type="hidden" name="auth_token" value="{{ $authToken }}">
        <button type="submit">Скасувати</button>
      </form>
      <form method="post" action="{{ route('passport.authorizations.approve') }}">
        @csrf
        <input type="hidden" name="state" value="{{ $request->state }}">
        <input type="hidden" name="client_id" value="{{ $client->getKey() }}">
        <input type="hidden" name="auth_token" value="{{ $authToken }}">
        <button type="submit" class="p">Дозволити</button>
      </form>
    </div>
  @else
    <h1>Немає доступу</h1>
    <p class="lead">Акаунт {{ $user->email }} не має ролі в адмінці, тому підключати ШІ до магазину від його імені не можна. Увійдіть під акаунтом співробітника.</p>
    <form method="post" action="{{ route('passport.authorizations.deny') }}">
      @csrf @method('DELETE')
      <input type="hidden" name="state" value="{{ $request->state }}">
      <input type="hidden" name="client_id" value="{{ $client->getKey() }}">
      <input type="hidden" name="auth_token" value="{{ $authToken }}">
      <button type="submit" class="p">Повернутися</button>
    </form>
  @endif
</main>
</body>
</html>
