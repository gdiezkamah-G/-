@php
    $variants = $product->activeVariants;
    $default = $product->pack_label;
    $steps = collect($product->cooking_steps ?? []);
@endphp
<x-layouts.app-shell kind="product" :notab="true" :title="trim($product->name.' '.$product->subtitle).' — Бакинський Бульвар'" :description="$product->description ?: $product->short_tagline ?: $product->full_name">
@push('head')<x-json-ld :data="$jsonLd" />@endpush
  <div class="sh" data-sh style="position:sticky"><a class="ib" href="{{ route('catalog') }}" data-back aria-label="Назад"><x-app.icon name="back" /></a><span class="t">{{ $product->name }}</span><button class="ib" type="button" data-share data-title="{{ trim($product->name.' '.$product->subtitle) }}" aria-label="Поділитися"><x-app.icon name="share" /></button></div>
  <div class="gal"><div class="gal__s" id="gs"><div><x-app.pack :product="$product" :weight="true" /></div><div><x-media.placeholder :hue="$product->hue" label="Фото страви · приклад" /></div><div><div class="sect" style="--hue:{{ $product->hue }}"><i></i></div></div></div><div class="dots" id="dots"><i class="on"></i><i></i><i></i></div></div>
  <div class="pb"><span class="eyebrow">{{ $product->category->name }}</span><h1 class="gold-text">{{ $product->name }}</h1><div class="sub">{{ $product->subtitle }}</div>
    @if($variants->isNotEmpty())
      <div class="sizes" role="group" aria-label="Фасування">@foreach($variants as $v)<button class="chip" type="button" data-sz="{{ $v->size_label }}" aria-pressed="{{ $v->size_label === $default ? 'true' : 'false' }}">{{ $v->size_label }}{{ $v->pack_note ? ' · '.$v->pack_note : '' }}</button>@endforeach</div>
    @else
      <p class="note" style="margin-top:14px">Фасування уточнюється.</p>
    @endif
    <x-app.price />
    <div class="acc">
      @if($product->composition_text)<details open><summary>Склад <x-app.icon name="chev" /></summary><div class="b">{{ $product->composition_text }}</div></details>@endif
      <details><summary>Характеристики <x-app.icon name="chev" /></summary><div class="b"><dl class="kv" style="margin:0">
        @if($product->full_name)<dt>Повна назва</dt><dd>{{ $product->full_name }}</dd>@endif
        <dt>Фасування</dt><dd>{{ $variants->isEmpty() ? '—' : $variants->map(fn ($v) => $v->size_label.($v->pack_note ? ' ('.$v->pack_note.')' : ''))->implode(', ') }}</dd>
        @if($product->storage_temp)<dt>Зберігання</dt><dd>{{ $product->storage_temp }}</dd>@endif
        @if($product->shelf_life)<dt>Термін придатності</dt><dd>{{ $product->shelf_life }}</dd>@endif
        @if($product->cooking_summary)<dt>Приготування</dt><dd>{{ $product->cooking_summary }}</dd>@endif
        @if($product->packaging)<dt>Паковання</dt><dd>{{ $product->packaging }}</dd>@endif
      </dl></div></details>
      <details><summary>Приготування <x-app.icon name="chev" /></summary><div class="b">
        @if($steps->isNotEmpty())
          <ol style="margin:0;padding-left:20px">@foreach($steps as $s)<li style="margin-bottom:6px"><b style="color:var(--text);font-weight:500">{{ $s['title'] }}.</b> {{ $s['text'] }}{{ ! empty($s['minutes']) ? ' ('.$s['minutes'].' хв)' : '' }}</li>@endforeach</ol>
        @else
          Рекомендації з приготування з’являться найближчим часом.
        @endif
      </div></details>
    </div>
  </div>
  <div class="abar"><button class="btn btn--p" type="button" data-order data-product="{{ $product->id }}">Замовити</button><button class="ib" type="button" data-order data-product="{{ $product->id }}" data-mode="sample" aria-label="Запросити зразки"><x-app.icon name="sample" /></button></div>
</x-layouts.app-shell>
