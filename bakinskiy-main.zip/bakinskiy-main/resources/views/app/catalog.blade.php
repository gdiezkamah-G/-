<x-layouts.app-shell kind="catalog" title="Продукція — Бакинський Бульвар" description="Люля-кебаб, долма, плов, млинці: заморожені напівфабрикати для кафе, ресторанів, готелів і кейтерингу." :categories="$categories">
  <div class="sh" data-sh><span class="sp"></span><span class="t">Продукція</span><button class="ib" type="button" data-filter aria-label="Фільтри"><x-app.icon name="filter" /></button></div>
  <div class="lt"><h1 class="gold-text">Продукція</h1><p data-count>{{ $products->count() }} {{ \App\Support\Plural::uk($products->count(), ['позиція', 'позиції', 'позицій']) }}</p></div>
  <label class="srch"><x-app.icon name="search" /><input id="q" type="search" placeholder="Пошук: долма, плов…" aria-label="Пошук" autocomplete="off"></label>
  <div class="chips" id="chips">
    <button class="chip" type="button" data-c="all" aria-pressed="true">Усі</button>
    @foreach($categories as $c)<button class="chip" type="button" data-c="{{ $c->slug }}" aria-pressed="false">{{ $c->name }}</button>@endforeach
  </div>
  <div id="gridw">
    <div class="grid">@foreach($products as $i => $p)<a class="pc" href="{{ route('product', $p->slug) }}" data-nav style="animation-delay:{{ $i * 40 }}ms" data-cat="{{ $p->category->slug }}" data-bases="{{ implode('|', $p->bases) }}" data-search="{{ $p->search_text }}"><x-app.pack :product="$p" /><b>{{ $p->name }}</b><span>{{ $p->subtitle }}</span><em>{{ $p->pack_label ?: 'ФАСУВАННЯ — УТОЧНЮЄТЬСЯ' }}</em></a>@endforeach</div>
    <div class="empty" hidden>Нічого не знайдено.<br>Змініть запит або фільтри.</div>
  </div>
</x-layouts.app-shell>
