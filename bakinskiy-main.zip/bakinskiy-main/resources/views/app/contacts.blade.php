<x-layouts.app-shell kind="contacts" title="Контакти — Бакинський Бульвар" description="Залиште заявку, і ми запропонуємо позиції, фасовку та умови для вашого закладу.">
  <div class="sh" data-sh><span class="sp"></span><span class="t">Контакти</span><span class="sp"></span></div>
  <div class="lt"><h1 class="gold-text">Контакти</h1><p>Розкажіть про ваш заклад, ми запропонуємо позиції та умови.</p></div>
  <div class="list">
    @if($contacts['phone'])<a class="row" href="{{ $contacts['phone_href'] }}"><i><x-app.icon name="phone" /></i><span><b>Зателефонувати</b><small>{{ $contacts['phone'] }}</small></span><x-app.icon name="chev" /></a>@endif
    @if($contacts['telegram'])<a class="row" href="{{ $contacts['telegram'] }}" target="_blank" rel="noopener"><i><x-app.icon name="tg" /></i><span><b>Написати в Telegram</b><small>Відповідаємо протягом дня</small></span><x-app.icon name="chev" /></a>@endif
    @if($contacts['email'])<a class="row" href="mailto:{{ $contacts['email'] }}"><i><x-app.icon name="mail" /></i><span><b>Написати на пошту</b><small>{{ $contacts['email'] }}</small></span><x-app.icon name="chev" /></a>@endif
    <button class="row" type="button" data-order><i><x-app.icon name="send" /></i><span><b>Залишити заявку</b><small>Зв’яжемось, надішлемо прайс і зразки</small></span><x-app.icon name="chev" /></button>
  </div>
  @if($contacts['address'])<div class="map"><i></i><small>{{ $contacts['address'] }}</small></div>@endif
  @if($contacts['address'] || $contacts['hours'])
    <div class="list" @if(! $contacts['address']) style="margin-top:16px" @endif>
      @if($contacts['address'])<div class="row"><i><x-app.icon name="fact" /></i><span><b>Виробництво</b><small>{{ $contacts['address'] }}</small></span></div>@endif
      @if($contacts['hours'])<div class="row"><i><x-app.icon name="list" /></i><span><b>Графік роботи</b><small>{{ $contacts['hours'] }}</small></span></div>@endif
    </div>
  @endif
</x-layouts.app-shell>
