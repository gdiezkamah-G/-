@php
    // "Популярне": the first product of every category, so the row shows variety
    $popular = $products->groupBy('category_id')->map->first()->take(5)->values();
    // Hero stack: the first product in the middle, two more from other categories on the sides
    $pool = $popular->count() >= 3 ? $popular : $products->take(3);
    $stack = collect([$pool[1] ?? null, $pool[0] ?? null, $pool[3] ?? $pool[2] ?? null])->filter();
@endphp
<x-layouts.app-shell kind="home">
  <div class="sh sh--home" data-sh><div class="brand"><img src="/assets/logo/seal-gold.svg" alt="" width="40" height="40"><span><b>Бакинський Бульвар</b><small>МАНУФАКТУРА</small></span></div><button class="ib" type="button" data-more aria-label="Меню"><x-app.icon name="list" /></button></div>
  <section class="hero"><canvas id="sp" aria-hidden="true"></canvas><span class="eyebrow">Власне виробництво ресторану</span><h2 class="gold-text">Смак східного столу</h2><p>Заморожені напівфабрикати для кафе, готелів і кейтерингу.</p>
    <div class="stack" aria-hidden="true">@foreach($stack as $p)<x-app.pack :product="$p" />@endforeach</div>
    <div class="cta2"><button class="btn btn--p" type="button" data-order>Замовити</button><a class="btn" href="{{ route('catalog') }}" data-nav>Каталог</a></div></section>
  <div class="quick"><a class="qa" href="{{ route('catalog') }}" data-nav><i><x-app.icon name="list" /></i>Каталог</a><button class="qa" type="button" data-order data-mode="price"><i><x-app.icon name="price" /></i>Прайс</button><button class="qa" type="button" data-order data-mode="sample"><i><x-app.icon name="sample" /></i>Зразки</button><a class="qa" href="{{ route('contacts') }}" data-nav><i><x-app.icon name="phone" /></i>Менеджер</a></div>
  <div class="sec"><h3 class="gold-text">Категорії</h3><a href="{{ route('catalog') }}" data-nav>Усі</a></div>
  <div class="hs">@foreach($categories as $c)<a class="cat" style="--hue:{{ $c->hue }}" href="{{ route('catalog', ['c' => $c->slug]) }}" data-nav data-cat="{{ $c->slug }}"><b>{{ $c->name }}</b><span>{{ $c->products_count }} {{ \App\Support\Plural::uk($c->products_count, ['поз.', 'поз.', 'поз.']) }}</span></a>@endforeach</div>
  <div class="sec"><h3 class="gold-text">Популярне</h3><a href="{{ route('catalog') }}" data-nav>Усі</a></div>
  <div class="hs">@foreach($popular as $p)<a class="rl" href="{{ route('product', $p->slug) }}" data-nav><x-app.pack :product="$p" /><b>{{ $p->name }}</b><span>{{ $p->subtitle }}</span></a>@endforeach</div>
  <div class="marq" aria-hidden="true"><i></i></div>
  <div class="sec"><h3 class="gold-text">Чому ми</h3></div>
  <div class="feat"><div><x-line-icon name="chef-hat" />Рецепти ресторану</div><div><x-line-icon name="leaf" />Натуральний склад</div><div><x-line-icon name="snowflake" />Заморожено −18 °C</div><div><x-line-icon name="truck" />Доставка</div><div><x-line-icon name="shield-check" />Контроль якості</div></div>
  <a class="banner" href="{{ route('horeca') }}" data-nav><span class="eyebrow">Для бізнесу</span><h3 class="gold-text">Для HoReCa</h3><p>Різна фасовка, зразки для дегустації та персональний прайс.</p><span class="btn btn--s" style="height:40px;padding:0 16px">Дізнатись більше</span></a>
</x-layouts.app-shell>
