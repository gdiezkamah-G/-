@php
    $benefits = [
        ['chef-hat', 'Стабільна якість порцій', 'Одна рецептура і вага на кожну зміну.'],
        ['box', 'Різна фасовка', 'Під ваш обсяг і формат кухні.'],
        ['gear', 'Швидке приготування', 'Від морозилки до подачі за лічені хвилини.'],
        ['thermometer', 'Холодовий ланцюг', 'Зберігання −18 °C, доставка в охолодженому транспорті.'],
        ['shield-check', 'Контроль якості', 'Перевірка кожної партії.'],
    ];
@endphp
<x-layouts.app-shell kind="horeca" :notab="true" title="Для HoReCa — Бакинський Бульвар" description="Рецептури ресторану для вашої кухні: стабільний смак, зрозуміла логістика, швидкий старт.">
  <div class="sh" data-sh><a class="ib" href="{{ route('home') }}" data-back aria-label="Назад"><x-app.icon name="back" /></a><span class="t">Для HoReCa</span><span class="sp"></span></div>
  <div class="lt"><span class="eyebrow">Для бізнесу</span><h1 class="gold-text" style="margin-top:10px">Для HoReCa</h1><p>Рецептури ресторану для вашої кухні: стабільний смак, зрозуміла логістика, швидкий старт.</p></div>
  <div class="list">@foreach($benefits as [$icon, $title, $text])<div class="row"><i><x-line-icon :name="$icon" /></i><span><b>{{ $title }}</b><small>{{ $text }}</small></span></div>@endforeach</div>
  <div class="sec"><h3 class="gold-text">Як ми працюємо</h3></div>
  <div class="tl"><div><h4>Заявка</h4><p>Залишаєте контакти й орієнтовний обсяг.</p></div><div><h4>Зразки</h4><p>Привозимо на дегустацію.</p></div><div><h4>Прайс і умови</h4><p>Узгоджуємо фасовку та графік поставок.</p></div><div><h4>Поставка</h4><p>Регулярні доставки в холодовому ланцюгу.</p></div></div>
  <div class="abar"><button class="btn btn--p" type="button" data-order data-mode="sample">Запросити зразки</button></div>
</x-layouts.app-shell>
