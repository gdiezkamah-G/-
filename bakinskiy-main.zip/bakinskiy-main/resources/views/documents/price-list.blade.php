<!doctype html>
<html lang="uk" data-theme="paper">
<head>
<meta charset="utf-8">
<title>Прайс-лист</title>
<style>{!! \App\Support\DocumentCss::inlined() !!}</style>
<style>
@page{size:A4;margin:0}
html,body{margin:0;background:#fff}
.bb-table tr{break-inside:avoid}
.bb-sheet__h{break-after:avoid}
.bb-sheet{box-shadow:none}
</style>
</head>
<body class="bb-stage bb-stage--flush">
<article class="bb-sheet" data-theme="paper" aria-label="Прайс-лист">
  <div class="bb-sheet__top">
    <img class="bb-sheet__logo" src="{{ \App\Support\DocumentCss::image('lockup-horizontal-gold.svg') }}" alt="Бакинський Бульвар — Мануфактура">
    <div class="bb-sheet__meta">Діє з: {{ $date }}</div>
  </div>
  <p class="bb-sheet__eyebrow" style="margin-top:32px">Для закладів і магазинів</p>
  <h1 class="bb-sheet__title" style="margin-top:8px">Прайс-лист</h1>
  <p class="bb-sheet__intro">Заморожені напівфабрикати власного виробництва за рецептами ресторану. Зберігання продукції — при −18°C.</p>
  @foreach($groups as $i => $group)
    <div class="bb-sheet__h"><span>{{ str_pad($i + 1, 2, '0', STR_PAD_LEFT) }}</span><h2>{{ $group['name'] }}</h2></div>
    <table class="bb-table">
      <thead><tr><th>Позиція</th><th>Фасування</th><th>Зберігання</th><th class="is-num">Ціна, грн</th></tr></thead>
      <tbody>
        @foreach($group['rows'] as $row)
          <tr><td class="is-name">{{ $row['name'] }}</td><td>{{ $row['pack'] }}</td><td style="white-space:nowrap">{{ $row['storage'] }}</td><td class="is-num">{{ $row['price'] }}</td></tr>
        @endforeach
      </tbody>
    </table>
  @endforeach
  <footer class="bb-sheet__foot">
    <div class="bb-sheet__band" aria-hidden="true"></div>
    <div class="bb-sheet__contacts"><span>Бакинський Бульвар · Мануфактура</span><span>{{ $contacts }}</span></div>
  </footer>
</article>
</body>
</html>
