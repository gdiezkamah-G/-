import { fxOn } from './fx.js';

document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-rail]');
    if (!b) return;
    const rail = b.closest('section').querySelector('.rail');
    rail.scrollBy({ left: b.dataset.rail * rail.clientWidth * 0.7, behavior: fxOn() ? 'smooth' : 'auto' });
});

document.addEventListener('click', (e) => {
    const a = e.target.closest('[data-scroll]');
    if (!a) return;
    e.preventDefault();
    document.getElementById(a.dataset.scroll)?.scrollIntoView({ behavior: fxOn() ? 'smooth' : 'auto' });
});
