import { fxOn } from './fx.js';

const run = (el) => {
    const to = +el.dataset.count;
    const t0 = performance.now();
    const f = (t) => {
        const k = Math.min(1, (t - t0) / 1200);
        el.textContent = String(Math.round(to * (1 - Math.pow(1 - k, 3)))).replace('-', '−');
        if (k < 1) requestAnimationFrame(f);
    };
    requestAnimationFrame(f);
};

if (fxOn()) {
    document.querySelectorAll('[data-count]').forEach((el) => {
        if (el.getBoundingClientRect().top > innerHeight * 0.92) {
            el.textContent = '0';
            const o = new IntersectionObserver(
                (e) => {
                    if (e[0].isIntersecting) {
                        run(el);
                        o.disconnect();
                    }
                },
                { threshold: 0.6 },
            );
            o.observe(el);
        }
    });
}
