// "Відкрити як застосунок" (desktop footer on phones) and "Повна версія" (app menu).
document.addEventListener('click', (e) => {
    const a = e.target.closest('[data-ui-switch]');
    if (!a) return;
    e.preventDefault();
    const year = 'path=/; max-age=31536000; samesite=lax';
    if (a.dataset.uiSwitch === 'full') {
        document.cookie = `ui_pin=full; ${year}`;
        document.cookie = `ui=full; ${year}`;
    } else {
        document.cookie = 'ui_pin=; path=/; max-age=0'; // back to automatic (by width)
        document.cookie = `ui=app; ${year}`;
    }
    location.href = a.getAttribute('href') || '/';
});
