// Telegram Mini App page (/tg): chips, one-open accordion, MainButton, deep links. No framework: the lead sheet is
// a Livewire component (resources/views/livewire/tg-sheet.blade.php) that this file only talks to through events.

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const tg = window.Telegram?.WebApp;
const inTelegram = !!(tg && tg.initData);
const BG = '#0E0B08';
const PRICE = 'Отримати прайс';

const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const behavior = () => (reduced.matches ? 'auto' : 'smooth');

// ---------- Telegram chrome ----------
if (inTelegram) {
    document.documentElement.classList.add('in-tg');
    tg.ready();
    tg.expand?.();
    tg.disableVerticalSwipes?.();
    // always our noir theme, whatever theme the user's Telegram has
    tg.setHeaderColor?.(BG);
    tg.setBackgroundColor?.(BG);
    tg.setBottomBarColor?.(BG);
    tg.MainButton.setParams?.({ color: '#C9A25A', text_color: '#1A1208' });

    // sign the user in (the server verifies the signature, upserts the user, issues a Sanctum token); the forms
    // re-verify initData themselves, so this call is a convenience, never a requirement
    fetch('/api/v1/telegram/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ init_data: tg.initData }),
    })
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => d && (window.__tgToken = d.token))
        .catch(() => {});
}

// ---------- helpers other scripts and the sheet use ----------
const haptic = {
    impact: (style = 'light') => inTelegram && tg.HapticFeedback?.impactOccurred?.(style),
    notify: (type) => inTelegram && tg.HapticFeedback?.notificationOccurred?.(type),
};

window.TgApp = {
    inTelegram,
    initData: inTelegram ? tg.initData : '',
    haptic,
    openLink: (url) => (inTelegram && tg.openLink ? tg.openLink(url) : window.open(url, '_blank', 'noopener')),
    /** Ask Telegram to send the user's phone to the bot. cb(true) once it was shared, cb(false) if refused or unsupported. */
    requestContact(cb) {
        if (!inTelegram || !tg.requestContact) return cb(false);
        let done = false;
        const finish = (ok) => {
            if (done) return;
            done = true;
            tg.offEvent?.('contactRequested', onEvent);
            cb(ok);
        };
        const onEvent = (e) => finish((e?.status || e) === 'sent');
        tg.onEvent?.('contactRequested', onEvent);
        tg.requestContact((allowed) => allowed === false && finish(false));
        setTimeout(() => finish(false), 60000);
    },
};

// ---------- MainButton: native inside Telegram, our own bar outside ----------
const fallbackBar = $('#main');
const fallbackText = $('#mbt');
let main = { text: PRICE, act: 'price', slug: null };
let sheetOpen = false;

function renderMain() {
    if (inTelegram) {
        tg.MainButton.setText(main.text);
        sheetOpen ? tg.MainButton.hide() : tg.MainButton.show();
    } else if (fallbackBar) {
        fallbackBar.hidden = sheetOpen;
    }
}

function setMain(text, act, slug = null) {
    if (main.text === text) return;
    main = { text, act, slug };
    if (inTelegram) return renderMain();
    // short fade, like the prototype
    fallbackText.style.opacity = 0;
    setTimeout(() => {
        fallbackText.textContent = text;
        fallbackText.style.opacity = 1;
    }, 120);
}

const openSheet = (mode, slug = null) => window.dispatchEvent(new CustomEvent('tg-open', { detail: { mode, slug } }));
const onMain = () => (main.act === 'ask' ? openSheet('request', main.slug) : openSheet('price'));

if (inTelegram) tg.MainButton.onClick(onMain);
$('#mb')?.addEventListener('click', onMain);
renderMain();

// the sheet tells us when it opens/closes: the MainButton gives way to it
window.addEventListener('tg-sheet-state', (e) => {
    sheetOpen = !!e.detail?.open;
    renderMain();
});
window.addEventListener('tg-result', (e) => haptic.notify(e.detail?.ok ? 'success' : 'error'));

// ---------- quick actions and "ask about a product" ----------
document.addEventListener('click', (e) => {
    const act = e.target.closest('[data-act]');
    if (act) {
        haptic.impact();
        return openSheet(act.dataset.act);
    }
    const ask = e.target.closest('[data-ask]');
    if (ask) {
        haptic.impact();
        return openSheet('request', ask.dataset.ask);
    }
    if (e.target.closest('#site')) window.TgApp.openLink($('#site').dataset.url);
});

// ---------- accordion: one open at a time, the row scrolls to the top of the visible area ----------
const chips = $('#chips');
const stickyHeight = () => (chips ? chips.offsetHeight : 0);

function scrollToEl(el, extra = 12) {
    window.scrollTo({ top: el.getBoundingClientRect().top + scrollY - stickyHeight() - extra, behavior: behavior() });
}

function toggleRow(row, open) {
    $$('.row.open').forEach((x) => {
        if (x === row && open) return;
        x.classList.remove('open');
        $('button', x).setAttribute('aria-expanded', 'false');
    });
    row.classList.toggle('open', open);
    $('button', row).setAttribute('aria-expanded', String(open));

    if (open) {
        setMain(`Запитати: ${row.dataset.n}`, 'ask', row.dataset.s);
        // wait one frame so the collapsing row above has started moving, then aim at the final position
        setTimeout(() => scrollToEl(row), 60);
    } else if (!$('.row.open')) {
        setMain(PRICE, 'price');
    }
}

$$('.row > button').forEach((b) =>
    b.addEventListener('click', () => {
        haptic.impact();
        const row = b.parentElement;
        toggleRow(row, !row.classList.contains('open'));
    }),
);

// ---------- chips: tap scrolls to the section; the active chip follows the scroll ----------
function activate(slug) {
    $$('.chip', chips).forEach((c) => {
        const on = c.dataset.c === slug;
        c.setAttribute('aria-pressed', String(on));
        on && c.scrollIntoView?.({ inline: 'center', block: 'nearest', behavior: behavior() });
    });
}

chips?.addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    haptic.impact();
    activate(chip.dataset.c);
    lock = Date.now();
    const target = chip.dataset.c ? document.getElementById(`c-${chip.dataset.c}`) : null;
    target ? scrollToEl(target, 4) : window.scrollTo({ top: Math.max(0, chips.offsetTop - 4), behavior: behavior() });
});

let lock = 0;
let ticking = false;
const sections = $$('.cat');
addEventListener(
    'scroll',
    () => {
        if (ticking || Date.now() - lock < 900 || !chips) return;
        ticking = true;
        requestAnimationFrame(() => {
            ticking = false;
            if (scrollY < chips.offsetTop - 8) return activate('');
            const line = stickyHeight() + 24;
            const current = [...sections].reverse().find((s) => s.getBoundingClientRect().top <= line);
            activate(current ? current.id.slice(2) : '');
        });
    },
    { passive: true },
);

// ---------- deep links: ?p= (bot buttons) or start_param (t.me/bot/app?startapp=) ----------
function deepLink() {
    const param = (inTelegram && tg.initDataUnsafe?.start_param) || new URLSearchParams(location.search).get('p') || '';

    if (['price', 'samples', 'manager'].includes(param)) {
        const fire = () => openSheet(param);
        document.addEventListener('livewire:initialized', () => setTimeout(fire, 100), { once: true });
        setTimeout(() => !sheetOpen && fire(), 1200); // safety net if the event was missed
    } else if (param.startsWith('product_')) {
        const row = document.getElementById(`p-${param.slice(8)}`);
        row && setTimeout(() => toggleRow(row, true), 250);
    } else if (param === 'contacts') {
        setTimeout(() => $('#contacts')?.scrollIntoView({ behavior: behavior() }), 250);
    }
}
deepLink();
