import { toast } from './toast.js';

// Real-time timer on the cooking step (the prototype ran it at demo speed).
const timers = new WeakMap();

document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-timer]');
    if (!btn) return;
    const step = btn.closest('.step');
    const bar = step.querySelector('.timer i');
    const total = +step.dataset.m * 60;
    clearInterval(timers.get(step));

    if (step.classList.contains('run') && btn.dataset.on) {
        step.classList.remove('run');
        btn.dataset.on = '';
        btn.textContent = 'Таймер ' + step.dataset.m + ' хв';
        return;
    }

    const end = Date.now() + total * 1000;
    step.classList.add('run');
    btn.dataset.on = '1';
    const draw = () => {
        const left = Math.max(0, Math.round((end - Date.now()) / 1000));
        btn.innerHTML = `<span class="t">${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}</span> стоп`;
        bar.style.transform = `scaleX(${1 - left / total})`;
        return left;
    };
    draw();
    const id = setInterval(() => {
        if (draw() <= 0) {
            clearInterval(id);
            step.classList.remove('run');
            btn.dataset.on = '';
            btn.textContent = 'Готово ✓';
            toast('Таймер завершено');
        }
    }, 250);
    timers.set(step, id);
});
