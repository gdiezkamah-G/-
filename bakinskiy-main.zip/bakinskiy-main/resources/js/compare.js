const input = document.getElementById('cmpr');
const box = document.getElementById('cmp');
input?.addEventListener('input', () => box.style.setProperty('--pos', input.value));
