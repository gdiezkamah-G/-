import { fxOn } from './fx.js';

// Timeline fill, ingredient burst (--k), CTA lattice parallax, sticky order bar.
const tl = document.getElementById('tl');
const ing = document.getElementById('ing');
const cta = document.getElementById('cta');
const sticky = document.getElementById('sticky');
const ctaRow = document.getElementById('ctaRow');
let ticking = false;

function update() {
    ticking = false;
    const vh = innerHeight;
    if (tl) {
        const r = tl.getBoundingClientRect();
        const p = Math.min(1, Math.max(0, (vh * 0.65 - r.top) / r.height));
        tl.style.setProperty('--p', p.toFixed(3));
        tl.querySelectorAll('.st').forEach((s) => s.classList.toggle('on', s.getBoundingClientRect().top < vh * 0.65));
    }
    if (ing && fxOn()) {
        const r = ing.getBoundingClientRect();
        ing.style.setProperty('--k', Math.min(1, Math.max(0, (vh * 0.9 - r.top) / (vh * 0.55))).toFixed(3));
    }
    if (cta && fxOn()) {
        const r = cta.getBoundingClientRect();
        cta.style.setProperty('--py', ((r.top - vh / 2) * 0.18).toFixed(1) + 'px');
    }
    if (sticky && ctaRow) sticky.classList.toggle('show', ctaRow.getBoundingClientRect().bottom < 0);
}

const schedule = () => {
    if (!ticking) {
        ticking = true;
        requestAnimationFrame(update);
    }
};
addEventListener('scroll', schedule, { passive: true });
addEventListener('resize', schedule);
update();
