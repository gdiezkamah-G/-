import { $, vibrate } from './util.js';

// Bottom sheets: Замовити (Livewire), Фільтри, Ще. One scrim, drag-down to close, Escape closes.
const scrim = $('#scrim');
let current = null;
let opener = null;

const setInert = (on) => ['#screens', '#tabbar'].forEach((s) => ($(s) && ($(s).inert = on)));

export const AppSheets = {
    get current() {
        return current;
    },
    open(el) {
        if (!el) return;
        if (current && current !== el) AppSheets.close(true);
        opener = document.activeElement;
        el.style.transform = '';
        scrim.classList.add('on');
        requestAnimationFrame(() => el.classList.add('on'));
        current = el;
        setInert(true);
        vibrate();
        el.setAttribute('tabindex', '-1');
        setTimeout(() => el.focus({ preventScroll: true }), 50);
    },
    close(keepScrim = false) {
        if (!current) return;
        current.classList.remove('on');
        current.style.transform = '';
        if (!keepScrim) scrim.classList.remove('on');
        current = null;
        setInert(false);
        opener?.focus?.({ preventScroll: true });
    },
};
window.AppSheets = AppSheets;

scrim.addEventListener('click', () => AppSheets.close());
document.addEventListener('click', (e) => {
    if (e.target.closest('[data-close-sheet]')) AppSheets.close();
});

// drag the grab handle down to dismiss
let sheet = null;
let y0 = null;
let dy = 0;

document.addEventListener('pointerdown', (e) => {
    const grab = e.target.closest('[data-grab]');
    if (!grab) return;
    sheet = grab.closest('.sheet');
    y0 = e.clientY;
    dy = 0;
    sheet.classList.add('drag');
    grab.setPointerCapture(e.pointerId);
});
document.addEventListener('pointermove', (e) => {
    if (y0 == null) return;
    dy = Math.max(0, e.clientY - y0);
    sheet.style.transform = `translateY(${dy}px)`;
});
const endDrag = () => {
    if (y0 == null) return;
    y0 = null;
    sheet.classList.remove('drag');
    if (dy > 110) AppSheets.close();
    else sheet.style.transform = '';
};
document.addEventListener('pointerup', endDrag);
document.addEventListener('pointercancel', endDrag);

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && current) {
        e.stopPropagation();
        AppSheets.close();
    }
});
