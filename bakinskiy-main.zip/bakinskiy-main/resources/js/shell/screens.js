import { $, $$ } from './util.js';
import { initCatalog } from './catalog.js';
import { startSparks } from './sparks.js';

/** Per-screen behaviour: collapsing header, catalog filters, gallery dots, hero sparks. */
export function initScreen(el) {
    if (el._ready) return;
    el._ready = true;

    const kind = el.dataset.kind;
    const header = $('[data-sh]', el);

    el.addEventListener(
        'scroll',
        () => header?.classList.toggle('on', el.scrollTop > (kind === 'product' ? 260 : 36)),
        { passive: true },
    );

    if (kind === 'catalog') initCatalog(el);

    if (kind === 'product') {
        const gs = $('#gs', el);
        const dots = $$('#dots i', el);
        gs?.addEventListener(
            'scroll',
            () => {
                const i = Math.round(gs.scrollLeft / gs.clientWidth);
                dots.forEach((d, k) => d.classList.toggle('on', k === i));
            },
            { passive: true },
        );
    }

    if (kind === 'home') setTimeout(() => startSparks(el), 80);
}
