import { $, $$, EASE, dur, vibrate, toast, fxOn } from './util.js';
import { AppSheets } from './sheets.js';
import { CF } from './catalog.js';
import { initScreen } from './screens.js';

// Screen stack: tabs replace the stack (fade), detail screens are pushed (slide), edge swipe / back pops.
// Every screen is a real server-rendered URL; JS only fetches it and animates it in. Without JS the links just work.

const screens = $('#screens');
const tabbar = $('#tabbar');
const edge = $('#edge');

const TABS = ['/', '/produkciya', '/kontakty'];
const KNOWN = [/^\/$/, /^\/produkciya$/, /^\/produkciya\/[^/]+$/, /^\/kontakty$/, /^\/dlya-horeca$/, /^\/vyrobnytstvo$/];
const NOTAB = new Set(['product', 'horeca', 'factory']);
const TAB_OF = { home: 'home', catalog: 'catalog', contacts: 'contacts' };
const BACK_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 5l-7 7 7 7"/></svg>';

const norm = (p) => (p.length > 1 ? p.replace(/\/+$/, '') : p);
const isTab = (p) => TABS.includes(norm(p));
const isKnown = (p) => KNOWN.some((r) => r.test(norm(p)));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function kindOf(path) {
    path = norm(path);
    if (path === '/') return 'home';
    if (path === '/produkciya') return 'catalog';
    if (path === '/kontakty') return 'contacts';
    if (path === '/dlya-horeca') return 'horeca';
    if (path === '/vyrobnytstvo') return 'factory';
    return 'product';
}

let stack = []; // [{ path, el }]
let expectPop = false; // we triggered history.back() ourselves
let token = 0;

// ---------- fetching screens ----------
const cache = new Map(); // path -> { promise, value, at }

function getScreen(path) {
    const hit = cache.get(path);
    if (hit && Date.now() - hit.at < 60000) return hit;

    const entry = { value: null, at: Date.now() };
    entry.promise = fetch(path, { credentials: 'same-origin', headers: { Accept: 'text/html', 'X-Shell-Nav': '1' } })
        .then(async (r) => {
            if (!r.ok) throw new Error('status');
            const doc = new DOMParser().parseFromString(await r.text(), 'text/html');
            const el = doc.querySelector('.screen');
            // The server answered with the desktop layout (the visitor switched mode): do a real navigation.
            if (doc.documentElement.dataset.ui !== 'app' || !el) throw new Error('mode');
            entry.value = { el: document.importNode(el, true), title: doc.title };
            return entry.value;
        })
        .catch((err) => {
            cache.delete(path);
            throw err;
        });
    cache.set(path, entry);

    return entry;
}

// ---------- skeletons ----------
function skeleton(kind) {
    const el = document.createElement('div');
    el.className = 'screen screen--skel' + (NOTAB.has(kind) ? ' nt' : '');
    el.dataset.kind = kind;
    const head = NOTAB.has(kind)
        ? `<div class="sh"><button class="ib" type="button" data-back aria-label="Назад">${BACK_ICON}</button></div>`
        : '<div class="sh"><span class="sp"></span></div>';
    const line = (w, h = 14, mt = 12) => `<div class="sk" style="height:${h}px;width:${w};margin-top:${mt}px"></div>`;
    let body;
    if (kind === 'product') {
        body = `<div class="sk" style="height:min(430px,56vh);margin-top:calc(-1*(var(--sat) + 58px));border-radius:0"></div><div class="pb">${line('30%', 10)}${line('70%', 34, 14)}${line('45%', 18)}${line('100%', 56, 22)}</div>`;
    } else if (kind === 'catalog') {
        const card = '<div><div class="sk" style="aspect-ratio:3/4"></div><div class="sk" style="height:14px;margin-top:12px;width:70%"></div><div class="sk" style="height:10px;margin-top:8px;width:45%"></div></div>';
        body = `<div class="lt">${line('60%', 34, 0)}${line('35%', 12, 10)}</div><div class="grid">${card.repeat(6)}</div>`;
    } else {
        body = `<div class="lt">${line('55%', 34, 0)}${line('80%', 12, 10)}</div><div style="padding:0 16px">${line('100%', 64, 14).repeat(4)}</div>`;
    }
    el.innerHTML = head + body;

    return el;
}

function swap(skel, loaded) {
    [...skel.attributes].forEach((a) => skel.removeAttribute(a.name));
    [...loaded.el.attributes].forEach((a) => skel.setAttribute(a.name, a.value));
    skel.innerHTML = loaded.el.innerHTML;
    skel._ready = false;
    initScreen(skel);
    document.title = loaded.title;
    showTabbar(!NOTAB.has(skel.dataset.kind));
    setTab(skel.dataset.kind);
}

// ---------- chrome ----------
function showTabbar(visible) {
    tabbar.classList.toggle('hide', !visible);
}
function setTab(kind) {
    const tab = TAB_OF[kind];
    $$('.tb[data-tab]').forEach((b) => (tab ? b.setAttribute('aria-current', b.dataset.tab === tab) : b.removeAttribute('aria-current')));
}
function syncChrome() {
    const top = stack.at(-1).el;
    const kind = top.dataset.kind;
    showTabbar(!NOTAB.has(kind));
    setTab(kind);
    edge.hidden = stack.length < 2;
    if (top.dataset.title) document.title = top.dataset.title;
    // the Telegram bridge (MainButton / BackButton) listens to this
    document.dispatchEvent(new CustomEvent('shell:screen', { detail: { kind, depth: stack.length, el: top } }));
}

function failed(path, err) {
    if (err?.message === 'mode') {
        location.href = path;

        return;
    }
    toast('Немає з’єднання. Спробуйте ще раз');
}

// ---------- navigation ----------
async function go(path, { push = true } = {}) {
    const mine = ++token;
    const top = stack.at(-1);

    if (stack.length === 1 && top.path === path) {
        top.el.scrollTo({ top: 0, behavior: fxOn() ? 'smooth' : 'auto' });

        return;
    }

    vibrate();
    const entry = getScreen(path);
    let skel = null;

    if (!entry.value) {
        const first = await Promise.race([entry.promise.then(() => 'ok', () => 'err'), sleep(110).then(() => 'slow')]);
        if (mine !== token) return;
        if (first === 'err') return entry.promise.catch((e) => failed(path, e));
        if (!entry.value) skel = skeleton(kindOf(path));
    }

    const el = skel || entry.value.el;
    const old = stack.map((s) => s.el);

    screens.appendChild(el);
    el.animate([{ opacity: 0, transform: 'translateY(10px)' }, { opacity: 1, transform: 'none' }], { duration: dur(260), easing: EASE });
    stack = [{ path, el }];
    old.forEach((o) => o.remove());
    if (push) history.pushState({ shell: 1 }, '', path);

    if (skel) {
        syncChrome();
        try {
            await entry.promise;
            if (mine === token) swap(skel, entry.value);
        } catch (e) {
            failed(path, e);
        }
    } else {
        initScreen(el);
        syncChrome();
    }
}

async function pushScreen(path, { push = true } = {}) {
    const mine = ++token;
    vibrate();
    const entry = getScreen(path);
    const skel = entry.value ? null : skeleton(kindOf(path));
    const el = skel || entry.value.el;
    const top = stack.at(-1).el;

    el.style.zIndex = stack.length + 2;
    screens.appendChild(el);
    el.animate([{ transform: 'translateX(100%)' }, { transform: 'none' }], { duration: dur(340), easing: EASE });
    top.animate([{ transform: 'none', filter: 'brightness(1)' }, { transform: 'translateX(-26%)', filter: 'brightness(.6)' }], { duration: dur(340), easing: EASE, fill: 'forwards' });
    stack.push({ path, el });
    if (push) history.pushState({ shell: 1 }, '', path);

    if (skel) {
        syncChrome();
        try {
            await entry.promise;
            if (mine === token || stack.some((s) => s.el === skel)) swap(skel, entry.value);
        } catch (e) {
            popAnimated();
            failed(path, e);
        }
    } else {
        initScreen(el);
        syncChrome();
    }
}

function popAnimated(dx = 0) {
    if (stack.length < 2) return;
    vibrate();
    const gone = stack.pop();
    const prev = stack.at(-1).el;

    prev.getAnimations().forEach((a) => a.cancel());
    prev.animate([{ transform: 'translateX(-26%)', filter: 'brightness(.6)' }, { transform: 'none', filter: 'none' }], { duration: dur(320), easing: EASE });
    gone.el.animate([{ transform: `translateX(${dx}px)` }, { transform: 'translateX(100%)' }], { duration: dur(320), easing: EASE, fill: 'forwards' }).onfinish = () => gone.el.remove();
    syncChrome();
}

/** UI "back": pop with history.back() when there is something to pop, otherwise open the logical parent. */
function back(fallback) {
    if (stack.length > 1) {
        expectPop = true;
        history.back();
        popAnimated();

        return;
    }
    route(fallback || '/produkciya');
}

function route(path, opts) {
    return isTab(path) ? go(norm(path), opts) : pushScreen(norm(path), opts);
}

// ---------- events ----------
document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href]');
    if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;

    if (a.hasAttribute('data-back')) {
        e.preventDefault();
        back(a.getAttribute('href'));

        return;
    }
    if (!a.hasAttribute('data-nav') || (a.target && a.target !== '_self')) return;

    const url = new URL(a.href, location.href);
    if (url.origin !== location.origin || !isKnown(url.pathname)) return;

    e.preventDefault();
    if (a.dataset.cat) {
        CF.cat = a.dataset.cat;
        CF.q = '';
        CF.base = 'all';
    }
    const path = norm(url.pathname);

    if (a.hasAttribute('data-close-sheet') || AppSheets.current) {
        AppSheets.close();
        setTimeout(() => route(path), 180);

        return;
    }
    route(path);
});

// the skeleton's back button has no href
document.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-back]');
    if (b) back('/produkciya');
});

// start loading on touch, before the click lands
const prefetch = (e) => {
    const a = e.target.closest?.('a[data-nav]');
    if (!a) return;
    const url = new URL(a.href, location.href);
    if (url.origin === location.origin && isKnown(url.pathname)) getScreen(norm(url.pathname)).promise.catch(() => {});
};
document.addEventListener('pointerdown', prefetch, { passive: true });

addEventListener('popstate', () => {
    if (expectPop) {
        expectPop = false;

        return;
    }
    const path = norm(location.pathname);
    AppSheets.close();
    if (stack.length > 1 && stack.at(-2).path === path) {
        popAnimated();

        return;
    }
    if (stack.at(-1).path !== path) route(path, { push: false });
});

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !AppSheets.current && stack.length > 1) back();
});

// swipe from the left edge = back
let drag = null;
edge.addEventListener('pointerdown', (e) => {
    if (stack.length < 2) return;
    drag = { x: e.clientX };
    edge.setPointerCapture(e.pointerId);
});
edge.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const top = stack.at(-1).el;
    top.style.transition = 'none';
    top.style.transform = `translateX(${Math.max(0, e.clientX - drag.x)}px)`;
});
const endSwipe = (e) => {
    if (!drag) return;
    const dx = Math.max(0, e.clientX - drag.x);
    const top = stack.at(-1).el;
    drag = null;
    top.style.transform = '';
    if (dx > 110) {
        expectPop = true;
        history.back();
        popAnimated(dx);
    } else {
        top.animate([{ transform: `translateX(${dx}px)` }, { transform: 'none' }], { duration: dur(200) });
    }
};
edge.addEventListener('pointerup', endSwipe);
edge.addEventListener('pointercancel', endSwipe);

window.AppNav = { route, back: () => back(), depth: () => stack.length };

// ---------- boot ----------
(() => {
    const first = $('.screen', screens);
    const path = norm(location.pathname);
    stack = [{ path, el: first }];
    history.replaceState({ shell: 1 }, '', location.pathname + location.search);
    initScreen(first);
    syncChrome();
})();
