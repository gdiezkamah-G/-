import { $, $$, fxOn, plural } from './util.js';
import { AppSheets } from './sheets.js';

// Catalog filter state lives for the whole session (like the prototype's CF).
export const CF = { q: '', cat: 'all', base: 'all' };

const visibleCount = (cards, f) => cards.filter((c) => matches(c, f)).length;

function matches(card, f) {
    const bases = (card.dataset.bases || '').split('|');
    return (
        (f.cat === 'all' || card.dataset.cat === f.cat) &&
        (f.base === 'all' || bases.includes(f.base)) &&
        (!f.q || card.dataset.search.includes(f.q.toLowerCase()))
    );
}

/** Show/hide the server-rendered cards according to CF; restart the fade-in like the prototype's re-render. */
export function applyCatalog(root) {
    const grid = $('#gridw', root);
    if (!grid) return;
    const cards = $$('.pc', grid);
    let i = 0;

    cards.forEach((card) => {
        const show = matches(card, CF);
        card.hidden = !show;
        if (show) {
            card.style.animation = 'none';
            void card.offsetHeight;
            card.style.animation = '';
            card.style.animationDelay = fxOn() ? `${i++ * 40}ms` : '0ms';
        }
    });

    const n = visibleCount(cards, CF);
    $$('#chips .chip', root).forEach((c) => c.setAttribute('aria-pressed', c.dataset.c === CF.cat));
    const count = $('[data-count]', root);
    if (count) count.textContent = `${n} ${plural(n, ['позиція', 'позиції', 'позицій'])}`;
    $('.empty', grid).hidden = n > 0;
}

export function initCatalog(root) {
    const params = new URLSearchParams(location.search);
    if (params.has('c') && root.dataset.url === location.pathname) CF.cat = params.get('c');

    const q = $('#q', root);
    q.value = CF.q;
    q.addEventListener('input', () => {
        CF.q = q.value.trim();
        applyCatalog(root);
    });
    $('#chips', root).addEventListener('click', (e) => {
        const chip = e.target.closest('[data-c]');
        if (!chip) return;
        CF.cat = chip.dataset.c;
        applyCatalog(root);
    });
    applyCatalog(root);
}

// ---- filter sheet ----
const sheet = () => $('#sheet-filter');
let draft = { cat: 'all', base: 'all' };

function drawFilter() {
    const s = sheet();
    $$('[data-fc]', s).forEach((b) => b.setAttribute('aria-pressed', b.dataset.fc === draft.cat));
    $$('[data-fb]', s).forEach((b) => b.setAttribute('aria-pressed', b.dataset.fb === draft.base));
    const cards = $$('.screen[data-kind=catalog] .pc');
    $('[data-fcount]', s).textContent = visibleCount(cards, { q: CF.q, ...draft });
}

export function openFilter() {
    draft = { cat: CF.cat, base: CF.base };
    drawFilter();
    AppSheets.open(sheet());
}

sheet()?.addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.dataset.fc) draft.cat = b.dataset.fc;
    else if (b.dataset.fb) draft.base = b.dataset.fb;
    else if (b.hasAttribute('data-freset')) draft = { cat: 'all', base: 'all' };
    else if (b.hasAttribute('data-fapply')) {
        CF.cat = draft.cat;
        CF.base = draft.base;
        AppSheets.close();
        const screen = $('.screen[data-kind=catalog]');
        if (screen) applyCatalog(screen);
        return;
    } else return;
    drawFilter();
});
