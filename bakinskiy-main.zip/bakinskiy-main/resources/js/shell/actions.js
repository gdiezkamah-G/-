import { $, $$, toast } from './util.js';
import { AppSheets } from './sheets.js';
import { applyCatalog, openFilter } from './catalog.js';

// Delegated buttons that work on any screen.
document.addEventListener('click', (e) => {
    let a;

    if ((a = e.target.closest('[data-order]'))) {
        window.dispatchEvent(new CustomEvent('open-order', { detail: { product: a.dataset.product || null, mode: a.dataset.mode || 'order' } }));
        return;
    }
    if (e.target.closest('[data-more]')) {
        AppSheets.open($('#sheet-more'));
        return;
    }
    if (e.target.closest('[data-filter]')) {
        openFilter();
        return;
    }
    if ((a = e.target.closest('[data-toast]'))) {
        toast(a.dataset.toast);
        return;
    }
    if ((a = e.target.closest('[data-share]'))) {
        share(a.dataset.title);
        return;
    }
    if ((a = e.target.closest('[data-sz]'))) {
        $$('[data-sz]', a.parentElement).forEach((b) => b.setAttribute('aria-pressed', b === a));
        const screen = a.closest('.screen');
        $$('[data-pack-weight]', screen).forEach((el) => (el.textContent = a.dataset.sz));
        return;
    }
    if ((a = e.target.closest('[data-install]'))) {
        install();
    }
});

async function share(title) {
    const url = location.href;
    try {
        if (navigator.share) {
            await navigator.share({ title, url });
            return;
        }
        await navigator.clipboard.writeText(url);
        toast('Посилання скопійовано');
    } catch (err) {
        if (err?.name !== 'AbortError') toast('Не вдалося поділитися');
    }
}

// "Встановити на екран"
let deferred = null;
const standalone = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
const ios = /iphone|ipad|ipod/i.test(navigator.userAgent);

const showInstall = () => $$('[data-install]').forEach((el) => (el.hidden = standalone()));

window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferred = e;
    showInstall();
});
window.addEventListener('appinstalled', () => {
    deferred = null;
    $$('[data-install]').forEach((el) => (el.hidden = true));
    toast('Застосунок додано на екран');
});
if (ios) showInstall(); // iOS has no prompt API: we show the hint instead

async function install() {
    if (deferred) {
        deferred.prompt();
        await deferred.userChoice;
        deferred = null;
        AppSheets.close();
        return;
    }
    toast('Поділитися → «На початковий екран»');
}

export { applyCatalog };
