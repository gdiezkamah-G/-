export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];

export const EASE = 'cubic-bezier(.22,.8,.2,1)';

const reduced = matchMedia('(prefers-reduced-motion: reduce)');
export const fxOn = () => !reduced.matches && document.documentElement.dataset.fx !== 'off';
/** Animation duration: zero when effects are off (reduced motion), so nothing moves. */
export const dur = (ms) => (fxOn() ? ms : 0);

export const vibrate = () => {
    try {
        navigator.vibrate && navigator.vibrate(8);
    } catch (e) {}
};

let toastTimer;
export function toast(message) {
    const el = $('#toast');
    if (!el) return;
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 2200);
}
document.addEventListener('app-toast', (e) => toast(e.detail?.message || ''));

/** Ukrainian plural: [1 позиція, 2 позиції, 5 позицій] */
export function plural(n, forms) {
    const m100 = n % 100;
    const m10 = n % 10;
    if (m100 >= 11 && m100 <= 14) return forms[2];
    if (m10 === 1) return forms[0];
    if (m10 >= 2 && m10 <= 4) return forms[1];
    return forms[2];
}
