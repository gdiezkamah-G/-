import { fxOn } from './util.js';

// Hero sparks (canvas), a lighter version of the site's: 22 particles.
let raf = 0;

export function startSparks(screen) {
    const cv = screen.querySelector('#sp');
    if (!cv || !fxOn()) return;
    cancelAnimationFrame(raf);

    const host = cv.parentElement;
    const c = cv.getContext('2d');
    const dpr = Math.min(2, devicePixelRatio || 1);
    const W = host.clientWidth;
    const H = host.clientHeight;
    cv.width = W * dpr;
    cv.height = H * dpr;
    c.setTransform(dpr, 0, 0, dpr, 0, 0);

    const mk = (init) => ({
        x: Math.random() * W,
        y: init ? Math.random() * H : H + 8,
        r: Math.random() * 1.4 + 0.4,
        v: Math.random() * 0.4 + 0.2,
        d: (Math.random() - 0.5) * 0.3,
        a: Math.random() * 0.6 + 0.25,
        ph: Math.random() * 6.3,
    });
    const ps = Array.from({ length: 22 }, () => mk(true));

    const tick = (t) => {
        if (!cv.isConnected || !fxOn()) {
            raf = 0;
            return;
        }
        c.clearRect(0, 0, W, H);
        for (const p of ps) {
            p.y -= p.v;
            p.x += p.d + Math.sin(t / 900 + p.ph) * 0.2;
            if (p.y < -8) Object.assign(p, mk(false));
            const g = c.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 5);
            g.addColorStop(0, `rgba(255,226,150,${p.a})`);
            g.addColorStop(1, 'rgba(201,162,90,0)');
            c.fillStyle = g;
            c.beginPath();
            c.arc(p.x, p.y, p.r * 5, 0, 6.283);
            c.fill();
        }
        raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
}
