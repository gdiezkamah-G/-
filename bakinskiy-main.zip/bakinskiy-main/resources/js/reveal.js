import { fxOn } from './fx.js';

// Only elements below the first screen get .pre, so the page is complete at rest and without JS.
if (fxOn()) {
    const io = new IntersectionObserver(
        (es) =>
            es.forEach((e) => {
                if (e.isIntersecting) {
                    e.target.classList.remove('pre');
                    io.unobserve(e.target);
                }
            }),
        { threshold: 0.15 },
    );
    document.querySelectorAll('.rv,.draw,.wd').forEach((el) => {
        if (el.getBoundingClientRect().top > innerHeight * 0.92) {
            el.classList.add('pre');
            io.observe(el);
        }
    });
}
