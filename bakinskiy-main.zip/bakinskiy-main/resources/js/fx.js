// Single switch for all effects: prefers-reduced-motion turns them off (also set early in <head>).
export const reduced = matchMedia('(prefers-reduced-motion: reduce)');
export const fxOn = () => !reduced.matches;
if (reduced.matches) document.documentElement.dataset.fx = 'off';
reduced.addEventListener?.('change', () => {
    document.documentElement.dataset.fx = reduced.matches ? 'off' : '';
});
