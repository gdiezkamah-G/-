// Any [data-order] button opens the lead form; its value is the product id, [data-sample] switches to a sample request.
document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-order]');
    if (!b) return;
    window.dispatchEvent(new CustomEvent('open-order', { detail: { product: b.dataset.order || null, sample: b.hasAttribute('data-sample') } }));
});
