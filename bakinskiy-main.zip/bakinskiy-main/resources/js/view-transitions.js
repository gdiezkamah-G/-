// Catalog card pack -> product pack. Cross-document view transitions (Chrome 126+); other browsers just navigate.
let clickedPack = null;

document.addEventListener('click', (e) => {
    const a = e.target.closest('a[data-src]');
    clickedPack = a ? a.querySelector('.pack') : null;
});

addEventListener('pageswap', (e) => {
    if (!e.viewTransition || !clickedPack) return;
    clickedPack.style.viewTransitionName = 'pack';
    e.viewTransition.finished.finally(() => (clickedPack.style.viewTransitionName = ''));
});

addEventListener('pagereveal', (e) => {
    const target = document.getElementById('front');
    if (!e.viewTransition || !target) return;
    target.style.viewTransitionName = 'pack';
    e.viewTransition.finished.finally(() => (target.style.viewTransitionName = ''));
});
