// Pack size chips on the product page: update the line under them, the stats row and the weight on the pack.
document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-sz]');
    if (!b) return;
    document.querySelectorAll('[data-sz]').forEach((x) => x.setAttribute('aria-pressed', x === b));
    const line = document.getElementById('szl');
    const stat = document.getElementById('stW');
    const pack = document.querySelector('[data-pack-weight]');
    if (line) line.textContent = b.dataset.sz;
    if (stat) stat.textContent = b.dataset.sz;
    if (pack) pack.textContent = b.dataset.sz;
});
