import { fxOn } from './fx.js';

// Hero: light follows the cursor, canvas sparks rise (paused when off-screen).
const hs = document.querySelector('.hero');
const cv = document.getElementById('sparks');

if (hs && cv) {
    hs.addEventListener('pointermove', (e) => {
        if (!fxOn()) return;
        const r = hs.getBoundingClientRect();
        hs.style.setProperty('--mx', e.clientX - r.left + 'px');
        hs.style.setProperty('--my', e.clientY - r.top + 'px');
    });

    if (fxOn()) {
        const c = cv.getContext('2d');
        const dpr = Math.min(2, devicePixelRatio || 1);
        let W, H, raf = 0, visible = true;
        const size = () => {
            W = hs.clientWidth;
            H = hs.clientHeight;
            cv.width = W * dpr;
            cv.height = H * dpr;
            c.setTransform(dpr, 0, 0, dpr, 0, 0);
        };
        size();
        addEventListener('resize', size);

        const mk = (init) => ({
            x: Math.random() * W,
            y: init ? Math.random() * H : H + 10,
            r: Math.random() * 1.7 + 0.4,
            v: Math.random() * 0.5 + 0.25,
            d: (Math.random() - 0.5) * 0.35,
            a: Math.random() * 0.6 + 0.25,
            ph: Math.random() * 6.28,
        });
        const ps = Array.from({ length: W < 600 ? 22 : 42 }, () => mk(true));

        const tick = (t) => {
            if (!fxOn() || !visible) {
                raf = 0;
                return;
            }
            c.clearRect(0, 0, W, H);
            for (const p of ps) {
                p.y -= p.v;
                p.x += p.d + Math.sin(t / 900 + p.ph) * 0.25;
                if (p.y < -10) Object.assign(p, mk(false));
                const f = Math.min(1, (H - p.y) / 90, p.y / 120 + 0.3);
                const g = c.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 5);
                g.addColorStop(0, `rgba(255,226,150,${p.a * f})`);
                g.addColorStop(1, 'rgba(201,162,90,0)');
                c.fillStyle = g;
                c.beginPath();
                c.arc(p.x, p.y, p.r * 5, 0, 6.283);
                c.fill();
            }
            raf = requestAnimationFrame(tick);
        };

        // start after the first screen has painted so sparks never delay LCP
        const start = () => {
            new IntersectionObserver((e) => {
                visible = e[0].isIntersecting;
                if (visible && !raf) raf = requestAnimationFrame(tick);
            }).observe(hs);
        };
        'requestIdleCallback' in window ? requestIdleCallback(start, { timeout: 1500 }) : setTimeout(start, 300);
    }
}
