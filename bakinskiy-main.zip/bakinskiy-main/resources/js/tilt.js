import { fxOn } from './fx.js';

// Pack tilt toward the cursor, foil shine follows it. Product hero plate gets a small parallax.
document.querySelectorAll('.tilt').forEach((el) => {
    el.addEventListener('pointermove', (e) => {
        if (!fxOn()) return;
        const r = el.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width;
        const y = (e.clientY - r.top) / r.height;
        el.style.setProperty('--ry', ((x - 0.5) * 16).toFixed(1) + 'deg');
        el.style.setProperty('--rx', ((0.5 - y) * 16).toFixed(1) + 'deg');
        el.style.setProperty('--sx', x * 100 + '%');
        el.style.setProperty('--sy', y * 100 + '%');
        el.style.setProperty('--so', '.8');
    });
    el.addEventListener('pointerleave', () => {
        ['--ry', '--rx', '--so'].forEach((k) => el.style.removeProperty(k));
    });
});

const hero = document.getElementById('ph1');
const plate = hero?.querySelector('.plate');
hero?.addEventListener('pointermove', (e) => {
    if (!fxOn()) return;
    const r = hero.getBoundingClientRect();
    plate.style.setProperty('--px', ((e.clientX - r.left) / r.width - 0.5).toFixed(2));
    plate.style.setProperty('--py', ((e.clientY - r.top) / r.height - 0.5).toFixed(2));
});
