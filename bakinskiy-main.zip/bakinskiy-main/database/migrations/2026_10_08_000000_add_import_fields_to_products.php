<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->string('full_name')->nullable()->after('subtitle');
            $table->text('composition')->nullable()->after('description');
            $table->json('needs_confirmation')->nullable();
        });

        Schema::table('product_variants', function (Blueprint $table) {
            $table->unsignedSmallInteger('units')->nullable()->after('weight_g');
            $table->string('pack_note')->nullable()->after('units');
        });
    }

    public function down(): void
    {
        Schema::table('products', fn (Blueprint $t) => $t->dropColumn(['full_name', 'composition', 'needs_confirmation']));
        Schema::table('product_variants', fn (Blueprint $t) => $t->dropColumn(['units', 'pack_note']));
    }
};
