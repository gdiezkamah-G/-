<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->foreignId('category_id')->constrained()->restrictOnDelete();
            $table->string('name');
            $table->string('subtitle')->nullable();
            $table->string('slug')->unique();
            $table->string('short_tagline')->nullable();
            $table->text('description')->nullable();
            $table->string('hue', 9)->default('#5a2a1c');
            $table->json('ingredients')->nullable();
            $table->json('cooking_steps')->nullable();
            $table->string('cooking_summary')->nullable();
            $table->string('packaging')->nullable();
            $table->string('shelf_life')->nullable();
            $table->string('storage_temp')->default('−18 °C');
            $table->string('status')->default('draft')->index();
            $table->unsignedSmallInteger('sort')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
