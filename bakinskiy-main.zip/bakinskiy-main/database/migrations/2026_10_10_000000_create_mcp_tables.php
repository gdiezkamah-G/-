<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('mcp_audit_log', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->string('client', 120)->nullable();
            $table->string('tool', 80)->index();
            $table->boolean('writes')->default(false);
            $table->json('input')->nullable();
            $table->string('result', 10)->index(); // ok | error | denied
            $table->text('message')->nullable();
            $table->json('changes')->nullable(); // {before, after} for writes
            $table->timestamp('created_at')->nullable()->index();
        });

        Schema::create('product_revisions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('audit_id')->nullable()->constrained('mcp_audit_log')->nullOnDelete();
            $table->string('tool', 80)->nullable();
            $table->json('snapshot'); // the product and its variants BEFORE the change
            $table->timestamp('reverted_at')->nullable();
            $table->timestamp('created_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('product_revisions');
        Schema::dropIfExists('mcp_audit_log');
    }
};
