<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('telegram_users', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('telegram_id')->unique();
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('username')->nullable();
            $table->string('language_code', 12)->nullable();
            $table->string('phone', 32)->nullable();
            $table->string('company')->nullable();
            $table->timestamp('last_seen_at')->nullable();
            $table->timestamps();
        });

        Schema::create('telegram_recipients', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('chat_id')->unique();
            $table->string('title')->nullable();
            $table->string('type', 10)->default('group');
            $table->boolean('active')->default(true);
            $table->json('lead_types')->nullable(); // empty = every type
            $table->timestamps();
        });

        Schema::create('telegram_admins', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('telegram_id')->unique();
            $table->string('name')->nullable();
            $table->timestamps();
        });

        Schema::table('leads', function (Blueprint $table) {
            $table->string('type', 20)->default('order')->after('phone')->index();
            $table->text('comment')->nullable()->after('volume_kg');
            $table->foreignId('telegram_user_id')->nullable()->after('manager_id')->constrained()->nullOnDelete();
            $table->string('handled_by')->nullable();
            $table->timestamp('handled_at')->nullable();
            $table->string('company')->nullable()->change();
        });

        // `source` used to hold what the client asked for; that is now `type`, and `source` is the channel.
        DB::table('leads')->update(['type' => DB::raw('source')]);
        DB::table('leads')->update(['source' => 'site']);

        Schema::create('telegram_lead_messages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('lead_id')->constrained()->cascadeOnDelete();
            $table->bigInteger('chat_id');
            $table->unsignedBigInteger('message_id');
            $table->timestamps();
            $table->unique(['lead_id', 'chat_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('telegram_lead_messages');
        DB::table('leads')->update(['source' => DB::raw('type')]);
        Schema::table('leads', function (Blueprint $table) {
            $table->dropConstrainedForeignId('telegram_user_id');
            $table->dropColumn(['type', 'comment', 'handled_by', 'handled_at']);
        });
        Schema::dropIfExists('telegram_admins');
        Schema::dropIfExists('telegram_recipients');
        Schema::dropIfExists('telegram_users');
    }
};
