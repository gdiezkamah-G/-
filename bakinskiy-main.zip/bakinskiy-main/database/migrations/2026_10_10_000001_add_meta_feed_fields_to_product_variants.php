<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('product_variants', function (Blueprint $table) {
            $table->unsignedInteger('price')->nullable()->after('sku');
            $table->string('currency', 3)->default('UAH')->after('price');
            $table->string('availability', 32)->nullable()->default('in stock')->after('currency');
        });
    }

    public function down(): void
    {
        Schema::table('product_variants', function (Blueprint $table) {
            $table->dropColumn(['price', 'currency', 'availability']);
        });
    }
};
