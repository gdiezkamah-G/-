<?php

namespace Database\Seeders;

use App\Enums\PriceMode;
use App\Models\Setting;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Demo products are for local development only; production gets the real catalog via app:import-products.
        if (! app()->environment('production')) {
            $this->call(CatalogSeeder::class);
        }

        if (Setting::find('price_mode') === null) {
            Setting::put('price_mode', PriceMode::Ask->value);
        }

        // Local dev only. In production the admin comes from the web container start (app:sync-admin)
        // or from `php artisan app:create-admin`; the seeder never creates one.
        if (! app()->environment('production')) {
            $this->command->call('app:sync-admin');
        }
    }
}
