<?php

namespace Database\Seeders;

use App\Enums\ProductStatus;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Seeder;

/** Conditional products from the prototype; real items replace them via the admin panel. */
class CatalogSeeder extends Seeder
{
    public const DEMO_PRODUCTS = ['lyulya-kebab', 'dolma', 'plov', 'mlynci'];

    public const DEMO_CATEGORIES = ['gryl', 'garyachi-stravy', 'tisto'];

    public function run(): void
    {
        $cats = collect([
            ['name' => 'Гриль', 'slug' => 'gryl'],
            ['name' => 'Гарячі страви', 'slug' => 'garyachi-stravy'],
            ['name' => 'Тісто', 'slug' => 'tisto'],
        ])->mapWithKeys(fn ($c, $i) => [
            $c['slug'] => Category::updateOrCreate(['slug' => $c['slug']], ['name' => $c['name'], 'sort' => $i]),
        ]);

        $packaging = 'Вакуумний пакет, короб за домовленістю';

        $items = [
            [
                'cat' => 'gryl', 'slug' => 'lyulya-kebab', 'name' => 'Люля-кебаб', 'subtitle' => 'курячий', 'hue' => '#7a3320',
                'tagline' => 'Рецептура ресторану. Ручне формування.',
                'description' => 'Соковитий кебаб із курячого фаршу зі спеціями за рецептом ресторану. Формується на шпажці, готується на грилі, у печі або на сковороді.',
                'summary' => 'Гриль або піч, 12–15 хв',
                'sizes' => [['500 г', 500], ['1 кг', 1000], ['5 кг', 5000]],
                'ingredients' => [['М’ясо курки', '#d9d3c0'], ['Цибуля', '#c98a4b'], ['Спеції за рецептом', '#8a9a4a'], ['Сіль', '#a63d2a']],
                'steps' => [['Підготовка', 'Не розморожуйте, витягніть з упаковки.', 0], ['Приготування', 'Гриль або піч при 220 °C.', 14], ['Подача', 'Із лавашем, цибулею та соусом.', 0]],
            ],
            [
                'cat' => 'garyachi-stravy', 'slug' => 'dolma', 'name' => 'Долма', 'subtitle' => 'у виноградному листі', 'hue' => '#4f6234',
                'tagline' => 'Традиційна рецептура. Ручна робота.',
                'description' => 'Класична долма: ніжний фарш із рисом і зеленню, загорнутий у виноградний лист. Тушкується в бульйоні або готується на парі.',
                'summary' => 'Пара або плита, 25 хв',
                'sizes' => [['500 г', 500], ['1 кг', 1000], ['5 кг', 5000]],
                'ingredients' => [['Фарш', '#6b8a3a'], ['Рис', '#e6dfc8'], ['Виноградний лист', '#b0562f'], ['Зелень', '#a63d2a'], ['Спеції', '#d9c46a']],
                'steps' => [['Підготовка', 'Викладіть у гастроємність, залийте бульйоном.', 0], ['Тушкування', 'Під кришкою на слабкому вогні.', 25], ['Подача', 'З мацоні та свіжою зеленню.', 0]],
            ],
            [
                'cat' => 'garyachi-stravy', 'slug' => 'plov', 'name' => 'Плов', 'subtitle' => 'по-бакинськи', 'hue' => '#8a6420',
                'tagline' => 'Розсипчастий, ароматний, стабільний на роздачі.',
                'description' => 'Розсипчастий плов зі шафрановим рисом і тушкованим м’ясом. Розігрівається в пароконвектоматі та тримає форму на роздачі.',
                'summary' => 'Пароконвектомат, 15 хв',
                'sizes' => [['1 кг', 1000], ['3 кг', 3000], ['5 кг', 5000]],
                'ingredients' => [['Рис', '#e6dfc8'], ['М’ясо', '#a63d2a'], ['Шафран', '#e0a21a'], ['Сухофрукти', '#7a3a4a'], ['Спеції', '#b0562f']],
                'steps' => [['Підготовка', 'Розкладіть у гастроємність шаром до 5 см.', 0], ['Розігрів', 'Пароконвектомат, 110 °C з парою.', 15], ['Подача', 'Посипте зеленню та сумахом.', 0]],
            ],
            [
                'cat' => 'tisto', 'slug' => 'mlynci', 'name' => 'Млинці', 'subtitle' => 'з м’ясом', 'hue' => '#8a7448',
                'tagline' => 'Тонке тісто. Щедра начинка.',
                'description' => 'Тонкі млинці з м’ясною начинкою. Підсмажуються за кілька хвилин, зручні для сніданкового меню та банкетів.',
                'summary' => 'Сковорода або фритюр, 6 хв',
                'sizes' => [['500 г', 500], ['1 кг', 1000], ['3 кг', 3000]],
                'ingredients' => [['Борошно', '#e6dfc8'], ['Яйце', '#e0c86a'], ['Молоко', '#d9d3c0'], ['М’ясна начинка', '#a63d2a']],
                'steps' => [['Підготовка', 'Не розморожуйте.', 0], ['Смаження', 'Сковорода з олією, середній вогонь.', 6], ['Подача', 'Зі сметаною або соусом.', 0]],
            ],
        ];

        foreach ($items as $i => $it) {
            $product = Product::updateOrCreate(['slug' => $it['slug']], [
                'category_id' => $cats[$it['cat']]->id,
                'name' => $it['name'],
                'subtitle' => $it['subtitle'],
                'short_tagline' => $it['tagline'],
                'description' => $it['description'],
                'hue' => $it['hue'],
                'ingredients' => array_map(fn ($g) => ['name' => $g[0], 'color' => $g[1]], $it['ingredients']),
                'cooking_steps' => array_map(fn ($s) => ['title' => $s[0], 'text' => $s[1], 'minutes' => $s[2]], $it['steps']),
                'cooking_summary' => $it['summary'],
                'packaging' => $packaging,
                'shelf_life' => '6 місяців',
                'storage_temp' => '−18 °C',
                'status' => ProductStatus::Published,
                'sort' => $i,
            ]);

            $product->variants()->delete();
            foreach ($it['sizes'] as $n => [$label, $grams]) {
                $product->variants()->create([
                    'sku' => strtoupper($it['slug']).'-'.$grams,
                    'size_label' => $label,
                    'weight_g' => $grams,
                    'pack_type' => 'Вакуумний пакет',
                    'is_default' => $label === '1 кг' || ($n === 0 && ! in_array('1 кг', array_column($it['sizes'], 0))),
                    'sort' => $n,
                ]);
            }
        }
    }
}
