<?php

use App\Http\Middleware\McpAccess;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Laravel\Sanctum\Http\Middleware\CheckAbilities;
use Laravel\Sanctum\Http\Middleware\CheckForAnyAbility;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        apiPrefix: 'api/v1',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // Traefik (Dokploy) terminates TLS in front of the container.
        // ui / ui_pin are written by plain JS (see ui-mode-script), so Laravel must not try to decrypt them
        $middleware->alias(['abilities' => CheckAbilities::class, 'ability' => CheckForAnyAbility::class, 'mcp.access' => McpAccess::class]);
        $middleware->encryptCookies(except: ['ui', 'ui_pin']);
        // OAuth consent: not signed in -> the admin login (the same account as the panel), then back to the consent page
        $middleware->redirectGuestsTo(fn (Request $request) => $request->expectsJson() || $request->is('mcp') ? null : route('filament.admin.auth.login'));
        $middleware->trustProxies(at: env('TRUSTED_PROXIES', '*'));
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*', 'mcp', 'oauth/token*', 'oauth/register') || $request->expectsJson(),
        );
    })->create();
