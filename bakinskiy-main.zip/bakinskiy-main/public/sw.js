/* Бакинський Бульвар service worker: static files + offline page.
   Pages are network-first (they differ per layout and change with the catalog); only a copy is kept for offline use. */
const VERSION = 'v1';
const STATIC = `bb-static-${VERSION}`;
const PAGES = `bb-pages-${VERSION}`;
const OFFLINE = '/offline';

const PRECACHE = [
    OFFLINE,
    '/manifest.webmanifest',
    '/assets/logo/seal-gold.svg',
    '/assets/logo/favicon.svg',
    '/assets/ornament/ornament-band-gold.svg',
    '/assets/ornament/ornament-ring-gold.svg',
    '/assets/ornament/pattern-lattice-gold.svg',
    '/icon-192.png',
    '/icon-512.png',
];

self.addEventListener('install', (event) => {
    event.waitUntil(caches.open(STATIC).then((c) => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches
            .keys()
            .then((keys) => Promise.all(keys.filter((k) => ![STATIC, PAGES].includes(k)).map((k) => caches.delete(k))))
            .then(() => self.clients.claim()),
    );
});

const isStatic = (url) =>
    url.origin === location.origin
        ? url.pathname.startsWith('/build/') || url.pathname.startsWith('/assets/') || /\.(?:png|svg|ico|webp|woff2?)$/.test(url.pathname)
        : ['fonts.googleapis.com', 'fonts.gstatic.com'].includes(url.hostname);

// never touch the admin, Livewire, health checks or anything that is not a GET
const skip = (url) => url.origin === location.origin && /^\/(admin|livewire|up|filament|storage)\b/.test(url.pathname);

self.addEventListener('fetch', (event) => {
    const req = event.request;
    const url = new URL(req.url);

    if (req.method !== 'GET' || skip(url)) return;

    if (req.mode === 'navigate' || req.headers.get('X-Shell-Nav')) {
        event.respondWith(page(req));

        return;
    }

    if (isStatic(url)) event.respondWith(staticFirst(req));
});

async function page(req) {
    try {
        const res = await fetch(req);
        if (res.ok && res.type === 'basic') {
            const copy = res.clone();
            caches.open(PAGES).then((c) => c.put(req, copy));
        }

        return res;
    } catch (err) {
        const cached = await caches.match(req, { cacheName: PAGES });
        if (cached) return cached;
        if (req.mode === 'navigate') return (await caches.match(OFFLINE)) || Response.error();

        throw err;
    }
}

async function staticFirst(req) {
    const cache = await caches.open(STATIC);
    const hit = await cache.match(req);
    const fresh = fetch(req)
        .then((res) => {
            if (res.ok || res.type === 'opaque') cache.put(req, res.clone());

            return res;
        })
        .catch(() => hit);

    return hit || fresh;
}
