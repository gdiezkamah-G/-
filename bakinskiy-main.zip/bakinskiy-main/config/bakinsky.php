<?php

return [
    // Read by `php artisan app:sync-admin` (config, not env(), so it also works with a cached config).
    'admin' => [
        'email' => env('ADMIN_EMAIL'),
        'name' => env('ADMIN_NAME'),
        'password' => env('ADMIN_PASSWORD'),
        'reset_password' => env('ADMIN_PASSWORD_RESET', false),
    ],
    'manager_email' => env('MANAGER_EMAIL'),
    'telegram' => [
        'token' => env('TELEGRAM_BOT_TOKEN'),
        'bot_username' => env('TELEGRAM_BOT_USERNAME'),
        'webhook_secret' => env('TELEGRAM_WEBHOOK_SECRET'),
        // optional: the channel the catalog and product posts go to (@name or -100…); can also be set in the admin
        'channel_id' => env('TELEGRAM_CHANNEL_ID'),
        // optional: Telegram user ids (comma separated) made bot admins at start, so no terminal command is needed
        'admin_ids' => array_filter(array_map('trim', explode(',', (string) env('TELEGRAM_ADMIN_IDS', '')))),
    ],

    // First deploy only: what to do with the catalog from database/data/products.json when the tables are empty.
    // draft = import as drafts (safe: nothing unconfirmed goes public), publish = import and publish, off = skip.
    'catalog_import' => env('CATALOG_IMPORT', 'draft'),

    'backup' => [
        'at' => env('BACKUP_AT', '03:15'),
        'keep_days' => (int) env('BACKUP_KEEP_DAYS', 14),
        'enabled' => filter_var(env('BACKUP_ENABLED', true), FILTER_VALIDATE_BOOLEAN),
        // optional off-site copy (any S3-compatible storage). Empty bucket = local volume only.
        's3' => [
            'bucket' => env('BACKUP_S3_BUCKET'),
            'key' => env('BACKUP_S3_KEY'),
            'secret' => env('BACKUP_S3_SECRET'),
            'region' => env('BACKUP_S3_REGION', 'auto'),
            'endpoint' => env('BACKUP_S3_ENDPOINT'),
            'prefix' => trim((string) env('BACKUP_S3_PREFIX', 'bakinskybulvar'), '/'),
            'path_style' => filter_var(env('BACKUP_S3_PATH_STYLE', true), FILTER_VALIDATE_BOOLEAN),
        ],
    ],
];
