import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    plugins: [
        laravel({
            input: ['resources/css/app.css', 'resources/js/app.js', 'resources/css/app-shell.css', 'resources/js/app-shell.js', 'resources/css/tg.css', 'resources/js/tg.js', 'resources/css/mcp.css'],
            refresh: true,
        }),
    ],
    server: {
        host: true,
        watch: { ignored: ['**/storage/framework/views/**'] },
    },
});
