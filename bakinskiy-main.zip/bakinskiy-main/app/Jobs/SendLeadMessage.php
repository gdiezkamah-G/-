<?php

namespace App\Jobs;

use App\Models\Lead;
use App\Models\TelegramLeadMessage;
use App\Models\TelegramRecipient;
use App\Services\Telegram\LeadNotifier;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Log;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Exceptions\TelegramException;
use SergiX44\Nutgram\Telegram\Properties\ParseMode;

/** Posts one lead to one recipient. Retries with growing delays; a failure never touches the client's request. */
class SendLeadMessage implements ShouldQueue
{
    use Queueable;

    public int $tries = 5;

    public function __construct(public int $leadId, public int $recipientId) {}

    /** @return list<int> */
    public function backoff(): array
    {
        return [10, 30, 120, 600];
    }

    public function handle(Nutgram $bot, LeadNotifier $notifier): void
    {
        $lead = Lead::find($this->leadId);
        $recipient = TelegramRecipient::find($this->recipientId);

        if (! $lead || ! $recipient || ! $recipient->active) {
            return;
        }

        // a retry after a send that already succeeded must not post the lead twice
        if (TelegramLeadMessage::where('lead_id', $lead->id)->where('chat_id', $recipient->chat_id)->exists()) {
            return;
        }

        try {
            $message = $bot->sendMessage(
                text: $notifier->text($lead),
                chat_id: $recipient->chat_id,
                parse_mode: ParseMode::HTML,
                reply_markup: $notifier->keyboard($lead),
                disable_web_page_preview: true,
            );
        } catch (TelegramException $e) {
            // A group that became a supergroup gets a new chat id: follow it and try again right away.
            if ($newId = $e->getParameter('migrate_to_chat_id')) {
                $recipient->update(['chat_id' => $newId]);
                $this->release(1);

                return;
            }

            throw $e;
        }

        if ($message) {
            TelegramLeadMessage::updateOrCreate(
                ['lead_id' => $lead->id, 'chat_id' => $recipient->chat_id],
                ['message_id' => $message->message_id],
            );
        }
    }

    public function failed(\Throwable $e): void
    {
        Log::warning('Telegram lead notification failed', ['lead' => $this->leadId, 'recipient' => $this->recipientId, 'error' => $e->getMessage()]);
    }
}
