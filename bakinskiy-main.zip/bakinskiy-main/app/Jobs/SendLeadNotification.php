<?php

namespace App\Jobs;

use App\Models\Lead;
use App\Services\Telegram\LeadNotifier;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;

/** Fans a new lead out to every active recipient that wants its type (one job per recipient). */
class SendLeadNotification implements ShouldQueue
{
    use Queueable;

    public function __construct(public Lead $lead) {}

    public function handle(LeadNotifier $notifier): void
    {
        if (! config('nutgram.token')) {
            return;
        }

        foreach ($notifier->recipientsFor($this->lead) as $recipient) {
            SendLeadMessage::dispatch($this->lead->id, $recipient->id);
        }
    }
}
