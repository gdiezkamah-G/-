<?php

namespace App\Jobs;

use App\Services\Telegram\PriceList;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Log;
use SergiX44\Nutgram\Nutgram;
use Throwable;

/** After a price request from the Mini App the bot sends the PDF into the user's chat (queued, with retries). */
class SendPriceToChat implements ShouldQueue
{
    use Queueable;

    public int $tries = 3;

    public function __construct(public int $telegramId) {}

    /** @return list<int> */
    public function backoff(): array
    {
        return [10, 60];
    }

    public function handle(Nutgram $bot, PriceList $price): void
    {
        $price->sendTo($bot, $this->telegramId);
    }

    public function failed(Throwable $e): void
    {
        Log::warning('Price list could not be sent to the chat', ['telegram_id' => $this->telegramId, 'error' => $e->getMessage()]);
    }
}
