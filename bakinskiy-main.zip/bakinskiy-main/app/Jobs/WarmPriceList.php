<?php

namespace App\Jobs;

use App\Services\Telegram\PriceList;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Log;
use Throwable;

/** Builds the auto price list right after a deploy, so the first client in the bot does not wait for Chromium. */
class WarmPriceList implements ShouldQueue
{
    use Queueable;

    public int $tries = 2;

    public int $timeout = 120;

    public function handle(PriceList $price): void
    {
        try {
            $price->path();
        } catch (Throwable $e) {
            Log::warning('Price list warm-up failed', ['error' => $e->getMessage()]);
        }
    }
}
