<?php

namespace App\Jobs;

use App\Models\Lead;
use App\Services\Telegram\LeadNotifier;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Log;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Exceptions\TelegramException;
use SergiX44\Nutgram\Telegram\Properties\ParseMode;

/** Re-renders every posted copy of a lead after its status changed (who took it, when). */
class RefreshLeadMessages implements ShouldQueue
{
    use Queueable;

    public int $tries = 3;

    public function __construct(public int $leadId) {}

    public function handle(Nutgram $bot, LeadNotifier $notifier): void
    {
        $lead = Lead::with('telegramMessages')->find($this->leadId);

        foreach ($lead?->telegramMessages ?? [] as $copy) {
            try {
                $bot->editMessageText(
                    text: $notifier->text($lead),
                    chat_id: $copy->chat_id,
                    message_id: $copy->message_id,
                    parse_mode: ParseMode::HTML,
                    reply_markup: $notifier->keyboard($lead),
                    disable_web_page_preview: true,
                );
            } catch (TelegramException $e) {
                // "message is not modified" is fine; a deleted message or a kicked bot is not worth retrying.
                Log::info('Could not refresh lead message', ['lead' => $lead->id, 'chat' => $copy->chat_id, 'error' => $e->getMessage()]);
            }
        }
    }
}
