<?php

namespace App\Mcp\Resources;

use Laravel\Mcp\Request;
use Laravel\Mcp\Response;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\MimeType;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Uri;
use Laravel\Mcp\Server\Resource;

#[Name('channel-post-templates')]
#[Uri('bakinskyi://channel-post-templates')]
#[Description('Шаблони постів для Telegram-каналу: каталог і товар.')]
#[MimeType('text/markdown')]
class ChannelPostTemplates extends Resource
{
    public function handle(Request $request): Response
    {
        return Response::text(<<<'MD'
# Шаблони постів для каналу

Пост генерує сам інструмент (telegram_preview_channel_post), текст нижче показує структуру й тон.

**Закріплений пост з каталогом (`catalog_pinned`):**
```
Бакинський Бульвар · Мануфактура
Заморожені напівфабрикати за рецептами ресторану для кафе, готелів і кейтерингу.

Люля-кебаб
• Люля-кебаб — з м’яса курки, кулінарний
...
Ціни — за запитом. Прайс-лист і зразки: кнопки нижче.
[Відкрити каталог] [Отримати прайс]
```

**Пост про товар (`product`):** назва й підзаголовок, одне речення, склад, фасування, зберігання, «Ціна — за запитом». Кнопки: [Запитати про товар] [Відкрити каталог].

**Принципи:** один пост на товар (повторна публікація оновлює його); без вигуків, без обіцянок щодо цін; опубліковані можна лише товари зі статусом «опубліковано». Кнопки ведуть у бота, а він відкриває mini app на потрібному екрані.
MD);
    }
}
