<?php

namespace App\Mcp\Resources;

use Laravel\Mcp\Request;
use Laravel\Mcp\Response;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\MimeType;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Uri;
use Laravel\Mcp\Server\Resource;

#[Name('catalog-schema')]
#[Uri('bakinskyi://catalog-schema')]
#[Description('Поля товару, фасування й статуси каталогу.')]
#[MimeType('text/markdown')]
class CatalogSchema extends Resource
{
    public function handle(Request $request): Response
    {
        return Response::text(<<<'MD'
# Схема каталогу

**Категорія:** id, slug, name, sort. Не має статусу: на сайті видно лише категорії, де є опубліковані товари.

**Товар (product):** id, slug (унікальний, латиниця), name, subtitle, full_name, short_tagline, description (до 4000), composition (до 2000, рядок), ingredients (список), cooking_steps (список), cooking_summary, packaging, shelf_life, storage_temp, hue (#rrggbb, колір пака), needs_confirmation (список полів, які ще треба уточнити), sort, category.

**Статуси товару:**
- `draft` — чернетка, не видно на сайті. Усе нове створюється таким.
- `published` — опубліковано, видно клієнтам, потрапляє в прайс і каталог бота.
- `archived` — в архіві: не видно, не в прайсі. Повертається через catalog_restore як чернетка.
Статус змінюють лише catalog_publish / unpublish / archive / restore, не catalog_update_product.

**Фасування (variant):** id, size_label («1 кг»), pack_note («10 шт»), weight_g, units, sku, pack_type, is_default (одне на товар), is_active, sort. Задається повним набором через catalog_set_variants.

**Версії:** кожна зміна товару або фасувань зберігає попередню версію (revision_id); product_revert повертає її, але ніколи не змінює статус.
MD);
    }
}
