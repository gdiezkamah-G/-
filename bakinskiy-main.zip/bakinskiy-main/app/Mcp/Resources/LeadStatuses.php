<?php

namespace App\Mcp\Resources;

use Laravel\Mcp\Request;
use Laravel\Mcp\Response;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\MimeType;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Uri;
use Laravel\Mcp\Server\Resource;

#[Name('lead-statuses')]
#[Uri('bakinskyi://lead-statuses')]
#[Description('Статуси, типи й джерела заявок і що вони означають.')]
#[MimeType('text/markdown')]
class LeadStatuses extends Resource
{
    public function handle(Request $request): Response
    {
        return Response::text(<<<'MD'
# Заявки

**Статуси:**
- `new` — нова, ніхто ще не взяв у роботу.
- `in_progress` — в роботі: менеджер уже зв’язався або веде розмову.
- `won` — виграна: домовились, є замовлення.
- `lost` — втрачена: клієнт відмовився або не відповів.
- `closed` — закрита без результату (дубль, помилка, не по темі).
Перший перехід з `new` запам’ятовує, хто й коли взяв заявку.

**Типи:** `order` — заявка з форми, `price` — запит прайсу, `sample` — запит зразків, `manager` — звʼязок з менеджером, `request` — запит про конкретний товар.

**Джерела:** `site` — сайт, `miniapp` — Telegram mini app, `bot` — чат з ботом.

**Правило:** «нова» заявка старше 24 годин — привід нагадати менеджеру.
MD);
    }
}
