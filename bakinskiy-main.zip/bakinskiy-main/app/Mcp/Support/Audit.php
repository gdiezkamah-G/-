<?php

namespace App\Mcp\Support;

use App\Models\McpAuditLog;
use App\Models\User;

class Audit
{
    private const SECRET = '/token|secret|password|key|authorization/i';

    /**
     * @param  array<string, mixed>  $input
     * @param  array{before?: mixed, after?: mixed}|null  $changes
     */
    public static function write(?User $user, string $tool, bool $writes, array $input, string $result, ?string $message = null, ?array $changes = null): McpAuditLog
    {
        return McpAuditLog::create([
            'user_id' => $user?->id,
            'client' => $user ? McpAccess::client($user) : null,
            'tool' => $tool,
            'writes' => $writes,
            'input' => self::scrub($input),
            'result' => $result,
            'message' => $message ? mb_substr($message, 0, 1000) : null,
            'changes' => $changes,
        ]);
    }

    /** @param  array<mixed>  $data */
    public static function scrub(array $data): array
    {
        $out = [];

        foreach ($data as $k => $v) {
            $out[$k] = is_string($k) && preg_match(self::SECRET, $k) ? '***' : (is_array($v) ? self::scrub($v) : (is_string($v) ? mb_substr($v, 0, 2000) : $v));
        }

        return $out;
    }
}
