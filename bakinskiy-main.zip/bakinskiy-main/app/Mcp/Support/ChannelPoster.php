<?php

namespace App\Mcp\Support;

use App\Enums\ProductStatus;
use App\Models\Category;
use App\Models\Product;
use App\Services\Telegram\TelegramSettings;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Properties\ParseMode;
use SergiX44\Nutgram\Telegram\Types\Keyboard\InlineKeyboardButton;
use SergiX44\Nutgram\Telegram\Types\Keyboard\InlineKeyboardMarkup;
use Throwable;

/**
 * Posts into the Telegram channel: one pinned catalog post and one post per product. A post is remembered by its
 * message id and edited on the next publish, never duplicated. Buttons are plain links (a channel cannot open a Mini App
 * directly): they lead to the bot, whose /start deep links open the Mini App on the right screen.
 */
class ChannelPoster
{
    public const KINDS = ['catalog_pinned', 'product'];

    public function __construct(private TelegramSettings $settings) {}

    public function channelId(): ?string
    {
        $id = $this->settings->group('channel')['chat_id'] ?? null;

        return filled($id) ? (string) $id : (filled(config('bakinsky.telegram.channel_id')) ? (string) config('bakinsky.telegram.channel_id') : null);
    }

    /** @return array{text: string, buttons: list<array{label: string, url: string}>, key: string} */
    public function render(string $kind, ?Product $product): array
    {
        return match ($kind) {
            'catalog_pinned' => $this->catalog(),
            'product' => $product ? $this->product($product) : throw new ToolError('Для поста «product» вкажіть товар (id або slug).'),
            default => throw new ToolError('Невідомий тип поста «'.$kind.'». Доступні: '.implode(', ', self::KINDS).'.'),
        };
    }

    public function publish(string $kind, ?Product $product): string
    {
        $post = $this->render($kind, $product);
        $chat = $this->channelId() ?? throw new ToolError('Канал не задано. Вкажіть його в адмінці (Налаштування Telegram → Канал) або в TELEGRAM_CHANNEL_ID.');

        if (blank(config('bakinsky.telegram.token'))) {
            throw new ToolError('TELEGRAM_BOT_TOKEN не задано: бот не може писати в канал.');
        }

        $bot = app(Nutgram::class);
        $markup = InlineKeyboardMarkup::make();
        foreach ($post['buttons'] as $b) {
            $markup->addRow(InlineKeyboardButton::make($b['label'], url: $b['url']));
        }

        $channel = $this->settings->group('channel');
        $existing = $channel['messages'][$post['key']] ?? null;

        try {
            if ($existing) {
                try {
                    $bot->editMessageText(text: $post['text'], chat_id: $chat, message_id: (int) $existing, parse_mode: ParseMode::HTML, reply_markup: $markup, link_preview_options: null);

                    return 'updated';
                } catch (Throwable $e) {
                    // "message is not modified" is fine; a deleted post is posted again below
                    if (str_contains($e->getMessage(), 'not modified')) {
                        return 'unchanged';
                    }
                }
            }

            $message = $bot->sendMessage(text: $post['text'], chat_id: $chat, parse_mode: ParseMode::HTML, reply_markup: $markup);

            if ($kind === 'catalog_pinned') {
                $bot->pinChatMessage(chat_id: $chat, message_id: $message->message_id, disable_notification: true);
            }
        } catch (ToolError $e) {
            throw $e;
        } catch (Throwable $e) {
            throw new ToolError('Telegram не прийняв пост: '.$e->getMessage().'. Перевірте, що бот доданий адміністратором у канал.');
        }

        $this->settings->replace('channel', ['chat_id' => $channel['chat_id'], 'messages' => [$post['key'] => $message->message_id] + $channel['messages']]);

        return $existing ? 'reposted' : 'created';
    }

    /** @return array{text: string, buttons: list<array{label: string, url: string}>, key: string} */
    private function catalog(): array
    {
        $lines = ['<b>Бакинський Бульвар · Мануфактура</b>', 'Заморожені напівфабрикати за рецептами ресторану для кафе, готелів і кейтерингу.', ''];

        foreach (Category::orderBy('sort')->with(['products' => fn ($q) => $q->published()])->get() as $category) {
            if ($category->products->isEmpty()) {
                continue;
            }
            $lines[] = '<b>'.e($category->name).'</b>';
            foreach ($category->products as $p) {
                $lines[] = '• '.e(trim($p->name.' '.($p->subtitle ? '— '.$p->subtitle : '')));
            }
            $lines[] = '';
        }

        $lines[] = 'Ціни — за запитом. Прайс-лист і зразки: кнопки нижче.';

        return [
            'text' => implode("\n", $lines),
            'buttons' => [['label' => 'Відкрити каталог', 'url' => $this->link('catalog')], ['label' => 'Отримати прайс', 'url' => $this->link('price')]],
            'key' => 'catalog_pinned',
        ];
    }

    /** @return array{text: string, buttons: list<array{label: string, url: string}>, key: string} */
    private function product(Product $p): array
    {
        if ($p->status !== ProductStatus::Published) {
            throw new ToolError("Товар «{$p->name}» не опублікований: у канал можна постити лише опубліковані товари.");
        }

        $p->loadMissing('activeVariants');
        $lines = ['<b>'.e($p->name).'</b>'.($p->subtitle ? "\n".e($p->subtitle) : '')];

        if ($p->short_tagline) {
            $lines[] = '';
            $lines[] = e($p->short_tagline);
        }
        if ($p->composition) {
            $lines[] = '';
            $lines[] = '<b>Склад:</b> '.e($p->composition);
        }

        $lines[] = '';
        $sizes = $p->activeVariants->pluck('size_label')->filter()->implode(' · ');
        $lines[] = ($sizes ? 'Фасування: '.e($sizes).'. ' : '').'Зберігання: '.e((string) $p->storage_temp).($p->shelf_life ? '. Термін: '.e($p->shelf_life) : '').'.';
        $lines[] = 'Ціна — за запитом.';

        return [
            'text' => implode("\n", $lines),
            'buttons' => [['label' => 'Запитати про товар', 'url' => $this->link('product_'.$p->slug)], ['label' => 'Відкрити каталог', 'url' => $this->link('catalog')]],
            'key' => 'product:'.$p->slug,
        ];
    }

    private function link(string $param): string
    {
        $bot = config('bakinsky.telegram.bot_username');

        if (blank($bot)) {
            throw new ToolError('TELEGRAM_BOT_USERNAME не задано: нема на що вести кнопки поста.');
        }

        return 'https://t.me/'.ltrim((string) $bot, '@').'?start='.rawurlencode($param);
    }
}
