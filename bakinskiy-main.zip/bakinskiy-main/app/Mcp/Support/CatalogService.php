<?php

namespace App\Mcp\Support;

use App\Enums\ProductStatus;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductRevision;
use App\Models\ProductVariant;
use App\Models\User;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class CatalogService
{
    public const MAX_BATCH = 20;

    /** Fields of a product the model may write (status is changed only by the publish / unpublish / archive / restore tools). */
    public const FIELDS = [
        'name', 'subtitle', 'full_name', 'short_tagline', 'description', 'composition', 'ingredients', 'cooking_steps',
        'cooking_summary', 'packaging', 'shelf_life', 'storage_temp', 'hue', 'needs_confirmation', 'sort',
    ];

    /** @return array<string, mixed> */
    public static function productRules(bool $creating): array
    {
        $req = $creating ? 'required' : 'sometimes';

        return [
            'name' => [$req, 'string', 'max:160'],
            'subtitle' => 'sometimes|nullable|string|max:200',
            'full_name' => 'sometimes|nullable|string|max:255',
            'short_tagline' => 'sometimes|nullable|string|max:200',
            'description' => 'sometimes|nullable|string|max:4000',
            'composition' => 'sometimes|nullable|string|max:2000',
            'ingredients' => 'sometimes|nullable|array|max:40',
            'ingredients.*' => 'string|max:120',
            'cooking_steps' => 'sometimes|nullable|array|max:20',
            'cooking_steps.*' => 'string|max:400',
            'cooking_summary' => 'sometimes|nullable|string|max:255',
            'packaging' => 'sometimes|nullable|string|max:255',
            'shelf_life' => 'sometimes|nullable|string|max:120',
            'storage_temp' => 'sometimes|nullable|string|max:120',
            'hue' => ['sometimes', 'string', 'regex:/^#[0-9a-fA-F]{6}$/'],
            'needs_confirmation' => 'sometimes|nullable|array|max:20',
            'needs_confirmation.*' => 'string|max:120',
            'sort' => 'sometimes|integer|min:0|max:65535',
        ];
    }

    /** @return array<string, string> */
    public static function attributes(): array
    {
        return [
            'name' => 'назва', 'subtitle' => 'підзаголовок', 'full_name' => 'повна назва', 'short_tagline' => 'короткий опис',
            'description' => 'опис', 'composition' => 'склад', 'ingredients' => 'інгредієнти', 'cooking_steps' => 'кроки приготування',
            'cooking_summary' => 'приготування', 'packaging' => 'пакування', 'shelf_life' => 'термін придатності',
            'storage_temp' => 'зберігання', 'hue' => 'колір (hue)', 'needs_confirmation' => 'потребує уточнення', 'sort' => 'порядок',
            'slug' => 'slug', 'category' => 'категорія', 'search' => 'пошук', 'limit' => 'ліміт', 'status' => 'статус',
        ];
    }

    public static function category(int|string $ref): Category
    {
        $category = is_numeric($ref) ? Category::find((int) $ref) : Category::where('slug', $ref)->first();
        $category ??= Category::where('slug', (string) $ref)->first();

        return $category ?? throw new ToolError("Категорію «{$ref}» не знайдено. Подивіться catalog_list_categories.");
    }

    public static function product(int|string $ref): Product
    {
        $product = is_numeric($ref) ? Product::find((int) $ref) : null;
        $product ??= Product::where('slug', (string) $ref)->first();

        return $product ?? throw new ToolError("Товар «{$ref}» не знайдено. Подивіться catalog_list_products.");
    }

    /** @param  list<int|string>  $ids */
    public static function products(array $ids): Collection
    {
        self::guardBatch($ids);

        return Collection::make(array_map(fn ($id) => self::product($id), $ids));
    }

    /** @param  array<mixed>  $items */
    public static function guardBatch(array $items): void
    {
        if (count($items) > self::MAX_BATCH) {
            throw new ToolError('За один виклик можна змінити не більше '.self::MAX_BATCH.' обʼєктів, а передано '.count($items).'. Розбийте запит на кілька.');
        }

        if ($items === []) {
            throw new ToolError('Список порожній: передайте хоча б один обʼєкт.');
        }
    }

    public static function uniqueSlug(string $source, string $table, ?int $ignoreId = null): string
    {
        $base = Str::slug($source, '-', 'uk') ?: 'item';
        $slug = $base;
        $n = 2;

        while (DB::table($table)->where('slug', $slug)->when($ignoreId, fn ($q) => $q->where('id', '!=', $ignoreId))->exists()) {
            $slug = $base.'-'.$n++;
        }

        return $slug;
    }

    /** @return array<string, mixed> short form for lists */
    public static function brief(Product $p): array
    {
        $p->loadMissing('category', 'variants');

        return [
            'id' => $p->id,
            'slug' => $p->slug,
            'name' => $p->name,
            'subtitle' => $p->subtitle,
            'category' => $p->category?->slug,
            'status' => $p->status->value,
            'sizes' => $p->variants->where('is_active', true)->pluck('size_label')->all(),
        ];
    }

    /** @return array<string, mixed> everything about a product */
    public static function full(Product $p): array
    {
        $p->loadMissing('category', 'variants');

        return self::brief($p) + [
            'category_name' => $p->category?->name,
            'full_name' => $p->full_name,
            'short_tagline' => $p->short_tagline,
            'description' => $p->description,
            'composition' => $p->composition,
            'ingredients' => $p->ingredients,
            'cooking_steps' => $p->cooking_steps,
            'cooking_summary' => $p->cooking_summary,
            'packaging' => $p->packaging,
            'shelf_life' => $p->shelf_life,
            'storage_temp' => $p->storage_temp,
            'hue' => $p->hue,
            'needs_confirmation' => $p->needs_confirmation ?? [],
            'sort' => $p->sort,
            'variants' => $p->variants->map(fn (ProductVariant $v) => self::variant($v))->all(),
            'url' => $p->status === ProductStatus::Published ? route('product', $p->slug) : null,
            'updated_at' => $p->updated_at?->toIso8601String(),
        ];
    }

    /** @return array<string, mixed> */
    public static function variant(ProductVariant $v): array
    {
        return $v->only(['id', 'size_label', 'pack_note', 'weight_g', 'units', 'sku', 'pack_type', 'is_default', 'is_active', 'sort']);
    }

    /** @return array<string, mixed> the product and its variants as they are now (what a revision stores and what the audit diffs) */
    public static function snapshot(Product $p): array
    {
        $p->refresh()->load('variants');

        return [
            'product' => $p->only(array_merge(self::FIELDS, ['category_id', 'slug', 'status'])),
            'variants' => $p->variants->map(fn (ProductVariant $v) => $v->only(['id', 'sku', 'size_label', 'weight_g', 'units', 'pack_note', 'pack_type', 'is_default', 'is_active', 'sort']))->all(),
        ];
    }

    /** @param  array<string, mixed>  $before */
    public static function revision(Product $p, ?User $user, string $tool, array $before): ProductRevision
    {
        return ProductRevision::create(['product_id' => $p->id, 'user_id' => $user?->id, 'tool' => $tool, 'snapshot' => $before]);
    }

    /** Put a product back to a stored snapshot. Status is deliberately left as it is: reverting never publishes anything. */
    public static function restore(ProductRevision $rev): Product
    {
        $snap = $rev->snapshot;
        $product = Product::findOrFail($rev->product_id);

        DB::transaction(function () use ($product, $snap) {
            $product->update(collect($snap['product'])->only(self::FIELDS)->all());

            $keep = [];
            foreach ($snap['variants'] as $row) {
                $variant = ProductVariant::where('product_id', $product->id)->find($row['id'] ?? 0) ?? new ProductVariant(['product_id' => $product->id]);
                $variant->fill($row)->save();
                $keep[] = $variant->id;
            }
            ProductVariant::where('product_id', $product->id)->whereNotIn('id', $keep)->delete();
        });

        return $product->refresh();
    }
}
