<?php

namespace App\Mcp\Support;

use App\Models\Lead;

class LeadService
{
    public static function find(int $id): Lead
    {
        return Lead::with('product', 'telegramUser')->find($id) ?? throw new ToolError("Заявку {$id} не знайдено. Подивіться leads_list.");
    }

    /** @return array<string, mixed> */
    public static function brief(Lead $l): array
    {
        return [
            'id' => $l->id,
            'created_at' => $l->created_at?->timezone('Europe/Kyiv')->format('Y-m-d H:i'),
            'type' => $l->type?->value,
            'source' => $l->source?->value,
            'status' => $l->status->value,
            'company' => $l->company,
            'contact_name' => $l->contact_name,
            'phone' => $l->phone,
            'product' => $l->product ? ['id' => $l->product->id, 'slug' => $l->product->slug, 'name' => $l->product->name] : null,
            'manager_id' => $l->manager_id,
        ];
    }

    /** @return array<string, mixed> */
    public static function full(Lead $l): array
    {
        return self::brief($l) + [
            'comment' => $l->comment,
            'volume_kg' => $l->volume_kg,
            'notes' => $l->notes,
            'handled_by' => $l->handled_by,
            'handled_at' => $l->handled_at?->timezone('Europe/Kyiv')->format('Y-m-d H:i'),
            'telegram' => $l->telegramUser ? ['username' => $l->telegramUser->username, 'name' => $l->telegramUser->full_name] : null,
        ];
    }
}
