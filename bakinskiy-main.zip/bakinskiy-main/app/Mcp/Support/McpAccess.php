<?php

namespace App\Mcp\Support;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Laravel\Passport\Client;
use Laravel\Sanctum\PersonalAccessToken;

/**
 * Who is calling the MCP server and what they may do. Checked on every request and again inside every tool:
 * the role of the user is read from the database each time, so demoting or removing someone cuts access at once,
 * even if their token is still valid.
 */
class McpAccess
{
    public static function user(): ?User
    {
        $user = Auth::user();

        return $user instanceof User ? $user : null;
    }

    public static function allows(?User $user, string $ability): bool
    {
        if (! $user || ! $user->role || ! $user->hasAbility($ability)) {
            return false;
        }

        // A personal access token may narrow what the role allows (OAuth tokens carry the role's rights as they are).
        $token = $user->currentAccessToken();

        return ! $token instanceof PersonalAccessToken || $token->can('*') || $token->can($ability);
    }

    /** Human-readable client for the audit log: Claude, ChatGPT, "token: name" or the OAuth app's own name. */
    public static function client(?User $user): string
    {
        $token = $user?->currentAccessToken();

        if ($token instanceof PersonalAccessToken) {
            return 'токен: '.$token->name;
        }

        $clientId = is_object($token) ? ($token->oauth_client_id ?? null) : null;
        $name = $clientId ? (string) Client::find($clientId)?->name : '';

        return match (true) {
            $name === '' => 'сесія',
            str_contains(mb_strtolower($name), 'claude') => 'Claude',
            (bool) preg_match('/chatgpt|openai/i', $name) => 'ChatGPT',
            default => $name,
        };
    }
}
