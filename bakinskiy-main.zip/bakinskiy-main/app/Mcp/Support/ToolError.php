<?php

namespace App\Mcp\Support;

use RuntimeException;

/** A problem the model can understand and fix: it is returned as a tool error, in Ukrainian. */
class ToolError extends RuntimeException {}
