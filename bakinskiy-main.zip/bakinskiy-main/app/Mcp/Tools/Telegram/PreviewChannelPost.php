<?php

namespace App\Mcp\Tools\Telegram;

use App\Enums\Ability;
use App\Mcp\Support\CatalogService;
use App\Mcp\Support\ChannelPoster;
use App\Mcp\Tools\BaseTool;
use App\Models\User;
use App\Services\Telegram\TelegramSettings;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsReadOnly;

#[Name('telegram_preview_channel_post')]
#[Title('Перегляд поста для каналу')]
#[Description('Показує текст і кнопки поста для каналу БЕЗ публікації. kind: catalog_pinned (закріплений пост з каталогом) або product (пост про товар, потрібен product).')]
#[IsReadOnly]
class PreviewChannelPost extends BaseTool
{
    protected function ability(): string
    {
        return Ability::TelegramRead;
    }

    public function schema(JsonSchema $schema): array
    {
        return [
            'kind' => $schema->string()->enum(ChannelPoster::KINDS)->required(),
            'product' => $schema->string()->description('id або slug (для kind=product)'),
        ];
    }

    protected function run(Request $request, User $user): array
    {
        $d = $this->validated($request, ['kind' => 'required|in:'.implode(',', ChannelPoster::KINDS), 'product' => 'nullable']);
        $poster = app(ChannelPoster::class);
        $post = $poster->render($d['kind'], filled($d['product'] ?? null) ? CatalogService::product($d['product']) : null);

        return [
            'preview' => true,
            'text_html' => $post['text'],
            'buttons' => $post['buttons'],
            'channel_configured' => $poster->channelId() !== null,
            'will' => in_array($post['key'], array_keys(app(TelegramSettings::class)->group('channel')['messages'] ?? []), true) ? 'оновить уже опублікований пост' : 'створить новий пост',
            'note' => 'Це лише перегляд, у канал нічого не надіслано.',
        ];
    }
}
