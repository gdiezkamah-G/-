<?php

namespace App\Mcp\Tools\Telegram;

use App\Enums\Ability;
use App\Mcp\Tools\BaseTool;
use App\Models\User;
use App\Services\Telegram\PriceList;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;

#[Name('price_pdf_regenerate')]
#[Title('Перегенерувати PDF-прайс')]
#[Description('Перегенеровує PDF-прайс з поточного каталогу (опублікованих товарів). Займає до хвилини. Якщо в адмінці завантажено власний PDF, бот шле його, а не цей.')]
#[IsDestructive(false)]
class PricePdfRegenerate extends BaseTool
{
    protected bool $writes = true;

    protected function ability(): string
    {
        return Ability::TelegramWrite;
    }

    protected function run(Request $request, User $user): array
    {
        $price = app(PriceList::class);
        $path = $price->regenerate();
        $this->changed(null, ['generated' => true]);

        return ['message' => 'PDF-прайс перегенеровано.', 'size_kb' => is_file($path) ? (int) round(filesize($path) / 1024) : null];
    }
}
