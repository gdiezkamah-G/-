<?php

namespace App\Mcp\Tools\Telegram;

use App\Enums\Ability;
use App\Mcp\Support\ToolError;
use App\Mcp\Tools\BaseTool;
use App\Models\TelegramRecipient;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;
use Laravel\Mcp\Server\Tools\Annotations\IsIdempotent;

#[Name('telegram_recipient_toggle')]
#[Title('Увімкнути/вимкнути отримувача')]
#[Description('Вмикає або вимикає отримувача сповіщень про заявки (id з telegram_recipients_list). Вимкнений отримувач більше не отримує нових заявок.')]
#[IsIdempotent]
#[IsDestructive(false)]
class RecipientToggle extends BaseTool
{
    protected bool $writes = true;

    protected function ability(): string
    {
        return Ability::TelegramWrite;
    }

    public function schema(JsonSchema $schema): array
    {
        return ['id' => $schema->integer()->required(), 'active' => $schema->boolean()->required()];
    }

    protected function run(Request $request, User $user): array
    {
        $d = $this->validated($request, ['id' => 'required|integer', 'active' => 'required|boolean']);
        $r = TelegramRecipient::find($d['id']) ?? throw new ToolError("Отримувача {$d['id']} не знайдено.");

        $before = ['id' => $r->id, 'active' => $r->active];
        $r->update(['active' => (bool) $d['active']]);
        $this->changed($before, ['id' => $r->id, 'active' => $r->active]);

        return ['message' => ($r->title ?: "№{$r->id}").($r->active ? ' отримує сповіщення.' : ' більше не отримує сповіщень.')];
    }
}
