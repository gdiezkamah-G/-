<?php

namespace App\Mcp\Tools\Telegram;

use App\Enums\Ability;
use App\Mcp\Support\ChannelPoster;
use App\Mcp\Tools\BaseTool;
use App\Models\TelegramRecipient;
use App\Models\User;
use App\Services\Telegram\TelegramSettings;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsReadOnly;

#[Name('telegram_get_settings')]
#[Title('Налаштування Telegram')]
#[Description('Налаштування Telegram-бота: тексти, меню, що показувати в сповіщеннях, режим прайсу, канал. Без токенів і секретів (вони лише в змінних оточення).')]
#[IsReadOnly]
class GetSettings extends BaseTool
{
    protected function ability(): string
    {
        return Ability::TelegramRead;
    }

    protected function run(Request $request, User $user): array
    {
        $s = app(TelegramSettings::class);
        $price = $s->group('price');
        $channel = $s->group('channel');

        return [
            'bot_username' => config('bakinsky.telegram.bot_username'),
            'bot_configured' => filled(config('bakinsky.telegram.token')),
            'texts' => $s->group('texts'),
            'menu' => $s->group('menu'),
            'notification_fields' => $s->group('notification'),
            'price' => ['mode' => $price['mode'], 'generated_at' => $price['generated_at']],
            'channel' => ['configured' => app(ChannelPoster::class)->channelId() !== null, 'posts' => array_keys($channel['messages'] ?? [])],
            'recipients' => TelegramRecipient::count(),
        ];
    }
}
