<?php

namespace App\Mcp\Tools\Telegram;

use App\Enums\Ability;
use App\Mcp\Support\CatalogService;
use App\Mcp\Support\ChannelPoster;
use App\Mcp\Tools\BaseTool;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;

#[Name('telegram_publish_channel_post')]
#[Title('Опублікувати пост у каналі')]
#[Description('Публікує пост у Telegram-каналі або оновлює вже опублікований (не дублює). Без confirm=true повертає лише перегляд. Спочатку покажіть користувачу перегляд і викликайте з confirm=true лише після його явної згоди. kind: catalog_pinned | product.')]
#[IsDestructive]
class PublishChannelPost extends BaseTool
{
    protected bool $writes = true;

    protected function ability(): string
    {
        return Ability::TelegramWrite;
    }

    public function schema(JsonSchema $schema): array
    {
        return [
            'kind' => $schema->string()->enum(ChannelPoster::KINDS)->required(),
            'product' => $schema->string()->description('id або slug (для kind=product)'),
            'confirm' => $schema->boolean()->description('true — підтверджую публікацію в канал'),
        ];
    }

    protected function run(Request $request, User $user): array
    {
        $d = $this->validated($request, ['kind' => 'required|in:'.implode(',', ChannelPoster::KINDS), 'product' => 'nullable', 'confirm' => 'nullable|boolean']);
        $poster = app(ChannelPoster::class);
        $product = filled($d['product'] ?? null) ? CatalogService::product($d['product']) : null;
        $post = $poster->render($d['kind'], $product);

        if (empty($d['confirm'])) {
            return [
                'preview' => true,
                'message' => 'Буде опубліковано в каналі: '.($d['kind'] === 'product' ? "пост про «{$product->name}»" : 'закріплений пост з каталогом').'. Щоб підтвердити, викличте цей інструмент ще раз з confirm=true.',
                'text_html' => $post['text'],
                'buttons' => $post['buttons'],
            ];
        }

        $result = $poster->publish($d['kind'], $product);
        $this->changed(null, ['kind' => $d['kind'], 'product' => $product?->slug, 'result' => $result]);

        return ['message' => ['created' => 'Пост опубліковано в каналі.', 'updated' => 'Пост у каналі оновлено.', 'reposted' => 'Старий пост зник, тому опубліковано заново.', 'unchanged' => 'Пост у каналі вже має такий самий текст.'][$result], 'result' => $result];
    }
}
