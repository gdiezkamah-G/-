<?php

namespace App\Mcp\Tools\Telegram;

use App\Enums\Ability;
use App\Mcp\Tools\BaseTool;
use App\Models\Product;
use App\Models\User;
use App\Services\Telegram\PriceList;
use App\Services\Telegram\TelegramSettings;
use Illuminate\Support\Facades\Storage;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsReadOnly;

#[Name('price_pdf_info')]
#[Title('Стан PDF-прайсу')]
#[Description('Стан PDF-прайсу: режим (auto — з каталогу, upload — завантажений вручну), коли згенерований, чи актуальний щодо каталогу, розмір, скільки товарів у ньому.')]
#[IsReadOnly]
class PricePdfInfo extends BaseTool
{
    protected function ability(): string
    {
        return Ability::TelegramRead;
    }

    protected function run(Request $request, User $user): array
    {
        $price = app(TelegramSettings::class)->group('price');
        $disk = Storage::disk('local');
        $exists = $disk->exists(PriceList::AUTO_PATH);

        return [
            'mode' => $price['mode'],
            'uploaded_file' => $price['mode'] === 'upload' ? (bool) $price['file'] : false,
            'generated_at' => $price['generated_at'],
            'exists' => $exists,
            'size_kb' => $exists ? (int) round($disk->size(PriceList::AUTO_PATH) / 1024) : null,
            'up_to_date' => $exists && $price['hash'] === app(PriceList::class)->catalogHash(),
            'published_products' => Product::published()->count(),
        ];
    }
}
