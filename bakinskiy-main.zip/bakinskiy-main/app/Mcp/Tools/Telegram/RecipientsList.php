<?php

namespace App\Mcp\Tools\Telegram;

use App\Enums\Ability;
use App\Mcp\Tools\BaseTool;
use App\Models\TelegramRecipient;
use App\Models\User;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsReadOnly;

#[Name('telegram_recipients_list')]
#[Title('Отримувачі заявок')]
#[Description('Отримувачі сповіщень про заявки в Telegram (групи й чати менеджерів): id, назва, тип, активний, які типи заявок отримує (порожньо = усі).')]
#[IsReadOnly]
class RecipientsList extends BaseTool
{
    protected function ability(): string
    {
        return Ability::TelegramRead;
    }

    protected function run(Request $request, User $user): array
    {
        return ['recipients' => TelegramRecipient::orderBy('id')->get()->map(fn ($r) => [
            'id' => $r->id, 'title' => $r->title, 'type' => $r->type, 'active' => $r->active, 'lead_types' => $r->lead_types ?? [],
        ])->all()];
    }
}
