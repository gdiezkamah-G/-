<?php

namespace App\Mcp\Tools\Telegram;

use App\Enums\Ability;
use App\Mcp\Support\ToolError;
use App\Mcp\Tools\BaseTool;
use App\Models\User;
use App\Services\Telegram\TelegramSettings;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;
use Laravel\Mcp\Server\Tools\Annotations\IsIdempotent;

#[Name('telegram_update_texts')]
#[Title('Тексти бота')]
#[Description('Змінює тексти бота (лише передані): welcome — привітання /start, ask_contact, ask_company, thanks, price_caption — підпис до прайсу. Тексти бачать клієнти одразу, тому перед зміною покажіть користувачу новий текст.')]
#[IsIdempotent]
#[IsDestructive(false)]
class UpdateTexts extends BaseTool
{
    protected bool $writes = true;

    protected function ability(): string
    {
        return Ability::TelegramWrite;
    }

    public function schema(JsonSchema $schema): array
    {
        return [
            'welcome' => $schema->string()->max(1500), 'ask_contact' => $schema->string()->max(500),
            'ask_company' => $schema->string()->max(500), 'thanks' => $schema->string()->max(500),
            'price_caption' => $schema->string()->max(900),
        ];
    }

    protected function run(Request $request, User $user): array
    {
        $d = $this->validated($request, [
            'welcome' => 'sometimes|string|min:1|max:1500', 'ask_contact' => 'sometimes|string|min:1|max:500',
            'ask_company' => 'sometimes|string|min:1|max:500', 'thanks' => 'sometimes|string|min:1|max:500',
            'price_caption' => 'sometimes|string|min:1|max:900',
        ]);

        if ($d === []) {
            throw new ToolError('Не передано жодного тексту. Доступні: welcome, ask_contact, ask_company, thanks, price_caption.');
        }

        $s = app(TelegramSettings::class);
        $before = array_intersect_key($s->group('texts'), $d);
        $s->save('texts', $d); // merged over the stored group
        $this->changed($before, $d);

        return ['message' => 'Тексти бота оновлено: '.implode(', ', array_keys($d)).'.', 'texts' => $s->group('texts')];
    }
}
