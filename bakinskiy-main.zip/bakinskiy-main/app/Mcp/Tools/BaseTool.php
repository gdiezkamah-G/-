<?php

namespace App\Mcp\Tools;

use App\Mcp\Support\Audit;
use App\Mcp\Support\CatalogService;
use App\Mcp\Support\McpAccess;
use App\Mcp\Support\ToolError;
use App\Models\Product;
use App\Models\ProductRevision;
use App\Models\User;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use Laravel\Mcp\Request;
use Laravel\Mcp\Response;
use Laravel\Mcp\Server\Tool;
use Throwable;

/**
 * Every tool goes through here: the right is checked again on each call (not only when the tool list is built),
 * input errors come back as readable Ukrainian text so the model can correct itself, and every call lands in the audit log.
 */
abstract class BaseTool extends Tool
{
    /** The ability from App\Enums\Ability a user needs for this tool. */
    abstract protected function ability(): string;

    /** Does the tool change anything? Read-only tools are logged too, but marked as such. */
    protected bool $writes = false;

    /** @var array{before?: mixed, after?: mixed}|null */
    protected ?array $changes = null;

    /** @var list<ProductRevision> */
    private array $revisions = [];

    protected ?ProductRevision $lastRevision = null;

    /** @return array<string, mixed>|Response */
    abstract protected function run(Request $request, User $user): array|Response;

    /** The tool is not even listed for someone who lacks the right. */
    public function shouldRegister(): bool
    {
        return McpAccess::allows(McpAccess::user(), $this->ability());
    }

    final public function handle(Request $request): Response
    {
        $user = McpAccess::user();
        $input = $request->all();
        $this->changes = null;
        $this->revisions = [];

        if (! McpAccess::allows($user, $this->ability())) {
            Audit::write($user, $this->name(), $this->writes, $input, 'denied', 'немає права '.$this->ability());

            return Response::error('Недостатньо прав для цього інструмента ('.$this->ability().'). Зверніться до адміністратора.');
        }

        try {
            $result = $this->run($request, $user);
            $log = Audit::write($user, $this->name(), $this->writes, $input, 'ok', null, $this->changes);

            foreach ($this->revisions as $rev) {
                $rev->update(['audit_id' => $log->id]);
            }

            return $result instanceof Response ? $result : Response::json($result);
        } catch (ValidationException $e) {
            $message = 'Помилка в параметрах: '.collect($e->errors())->flatten()->implode(' ');
        } catch (ToolError $e) {
            $message = $e->getMessage();
        } catch (Throwable $e) {
            report($e);
            Log::error('MCP tool failed', ['tool' => $this->name(), 'error' => $e->getMessage()]);
            $message = 'Внутрішня помилка інструмента. Спробуйте ще раз або зверніться до адміністратора.';
        }

        Audit::write($user, $this->name(), $this->writes, $input, 'error', $message);

        return Response::error($message);
    }

    /** Validate with Ukrainian attribute names. */
    protected function validated(Request $request, array $rules, array $messages = []): array
    {
        return $request->validate($rules, $messages, CatalogService::attributes());
    }

    /** Remember the product as it is now, before the change that follows (undone by product_revert). */
    protected function remember(Product $product, User $user): array
    {
        $before = CatalogService::snapshot($product);
        $this->revisions[] = $this->lastRevision = CatalogService::revision($product, $user, $this->name(), $before);

        return $before;
    }

    /** @param  array<string, mixed>|null  $before */
    protected function changed(mixed $before, mixed $after): void
    {
        $this->changes = ['before' => $before, 'after' => $after];
    }

    /** Limit and cursor of the list tools. */
    protected function paging(Request $request, int $default = 20, int $max = 50): int
    {
        return max(1, min($max, (int) ($request->get('limit') ?? $default)));
    }
}
