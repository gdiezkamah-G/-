<?php

namespace App\Mcp\Tools\Site;

use App\Enums\Ability;
use App\Mcp\Support\ToolError;
use App\Mcp\Tools\BaseTool;
use App\Models\Setting;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;
use Laravel\Mcp\Server\Tools\Annotations\IsIdempotent;

#[Name('site_update_contacts')]
#[Title('Змінити контакти сайту')]
#[Description('Змінює контакти сайту (лише передані поля): phone, email, city, address, hours. Порожній рядок очищує поле. Зміна видна клієнтам на сайті, у застосунку й у прайсі одразу.')]
#[IsIdempotent]
#[IsDestructive(false)]
class UpdateContacts extends BaseTool
{
    protected bool $writes = true;

    protected function ability(): string
    {
        return Ability::SiteWrite;
    }

    public function schema(JsonSchema $schema): array
    {
        return [
            'phone' => $schema->string()->description('+380 50 123 45 67'), 'email' => $schema->string(),
            'city' => $schema->string(), 'address' => $schema->string()->description('Адреса виробництва'),
            'hours' => $schema->string()->description('Напр. «пн–пт, 9:00–18:00»'),
        ];
    }

    protected function run(Request $request, User $user): array
    {
        $d = $this->validated($request, [
            'phone' => ['sometimes', 'nullable', 'string', 'max:40', 'regex:/^[+\d\s()\-]{7,}$/'],
            'email' => 'sometimes|nullable|email|max:120', 'city' => 'sometimes|nullable|string|max:80',
            'address' => 'sometimes|nullable|string|max:200', 'hours' => 'sometimes|nullable|string|max:120',
        ], ['phone.regex' => 'Телефон: лише цифри, +, пробіли, дужки та дефіси.', 'email.email' => 'Некоректний e-mail.']);

        if ($d === []) {
            throw new ToolError('Не передано жодного поля. Доступні: phone, email, city, address, hours.');
        }

        $before = $after = [];
        foreach ($d as $field => $value) {
            $key = 'contact_'.$field;
            $before[$field] = Setting::get($key);
            Setting::put($key, filled($value) ? trim($value) : null);
            $after[$field] = filled($value) ? trim($value) : null;
        }
        $this->changed($before, $after);

        return ['message' => 'Контакти оновлено: '.implode(', ', array_keys($d)).'.', 'contacts' => $after];
    }
}
