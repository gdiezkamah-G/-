<?php

namespace App\Mcp\Tools\Site;

use App\Enums\Ability;
use App\Filament\Pages\ManageSettings;
use App\Mcp\Tools\BaseTool;
use App\Models\Setting;
use App\Models\User;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsReadOnly;

#[Name('site_get_settings')]
#[Title('Налаштування сайту')]
#[Description('Налаштування сайту: контакти (телефон, e-mail, місто, адреса, графік роботи) і режим показу цін.')]
#[IsReadOnly]
class GetSettings extends BaseTool
{
    protected function ability(): string
    {
        return Ability::SiteRead;
    }

    protected function run(Request $request, User $user): array
    {
        return [
            'contacts' => collect(ManageSettings::CONTACT_KEYS)->mapWithKeys(fn ($label, $key) => [substr($key, 8) => Setting::get($key)])->all(),
            'price_mode' => Setting::get('price_mode', 'ask'),
            'site_url' => config('app.url'),
        ];
    }
}
