<?php

namespace App\Mcp\Tools\Site;

use App\Enums\Ability;
use App\Mcp\Tools\BaseTool;
use App\Models\User;
use App\Services\Deploy\Check;
use App\Services\Deploy\Doctor;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsReadOnly;

#[Name('system_status')]
#[Title('Стан системи')]
#[Description('Стан системи, як app:doctor: база, міграції, черга, планувальник, Telegram webhook, адмін, прайс, бекапи, MCP. Кожен рядок OK / WARN / FAIL з поясненням.')]
#[IsReadOnly]
class SystemStatus extends BaseTool
{
    protected function ability(): string
    {
        return Ability::SystemRead;
    }

    protected function run(Request $request, User $user): array
    {
        $checks = array_map(fn (Check $c) => $c->toArray(), app(Doctor::class)->run());

        return [
            'ok' => ! array_filter($checks, fn ($c) => $c['status'] === Check::FAIL),
            'checks' => $checks,
        ];
    }
}
