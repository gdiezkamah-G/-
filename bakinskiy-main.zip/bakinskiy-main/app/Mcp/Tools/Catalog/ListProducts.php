<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\Ability;
use App\Enums\ProductStatus;
use App\Mcp\Support\CatalogService;
use App\Mcp\Tools\BaseTool;
use App\Models\Product;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsReadOnly;

#[Name('catalog_list_products')]
#[Title('Список товарів')]
#[Description('Список товарів (id, slug, назва, категорія, статус, фасування). Фільтри: пошук за назвою, категорія (slug або id), статус draft|published|archived. Постачається по сторінках: передайте cursor з попередньої відповіді.')]
#[IsReadOnly]
class ListProducts extends BaseTool
{
    protected function ability(): string
    {
        return Ability::CatalogRead;
    }

    public function schema(JsonSchema $schema): array
    {
        return [
            'search' => $schema->string()->description('Частина назви, підзаголовку або slug'),
            'category' => $schema->string()->description('slug або id категорії'),
            'status' => $schema->string()->enum(array_column(ProductStatus::cases(), 'value'))->description('draft — чернетка, published — на сайті, archived — в архіві'),
            'limit' => $schema->integer()->min(1)->max(50)->description('Скільки товарів (за замовчуванням 20)'),
            'cursor' => $schema->integer()->description('next_cursor з попередньої відповіді'),
        ];
    }

    protected function run(Request $request, User $user): array
    {
        $data = $this->validated($request, [
            'search' => 'nullable|string|max:100', 'category' => 'nullable|string|max:100',
            'status' => 'nullable|in:'.implode(',', array_column(ProductStatus::cases(), 'value')),
            'limit' => 'nullable|integer|min:1|max:50', 'cursor' => 'nullable|integer|min:0',
        ]);
        $limit = $this->paging($request);

        $query = Product::query()->with('category', 'variants')->orderBy('id');

        if (filled($data['search'] ?? null)) {
            $like = '%'.str_replace(['%', '_'], ['\%', '\_'], $data['search']).'%';
            $query->where(fn ($q) => $q->where('name', 'like', $like)->orWhere('subtitle', 'like', $like)->orWhere('slug', 'like', $like));
        }
        if (filled($data['category'] ?? null)) {
            $query->where('category_id', CatalogService::category($data['category'])->id);
        }
        if (filled($data['status'] ?? null)) {
            $query->where('status', $data['status']);
        }
        if (filled($data['cursor'] ?? null)) {
            $query->where('id', '>', (int) $data['cursor']);
        }

        $rows = $query->limit($limit + 1)->get();
        $more = $rows->count() > $limit;
        $rows = $rows->take($limit);

        return [
            'products' => $rows->map(fn (Product $p) => CatalogService::brief($p))->all(),
            'count' => $rows->count(),
            'next_cursor' => $more ? $rows->last()->id : null,
        ];
    }
}
