<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\Ability;
use App\Mcp\Support\CatalogService;
use App\Mcp\Support\ToolError;
use App\Mcp\Tools\BaseTool;
use App\Models\Category;
use App\Models\Product;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Facades\DB;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;
use Laravel\Mcp\Server\Tools\Annotations\IsIdempotent;

#[Name('catalog_reorder')]
#[Title('Змінити порядок')]
#[Description('Задає порядок показу: для кожного елемента type (category|product), id і sort (менше = вище). Не більше 20 елементів за виклик.')]
#[IsIdempotent]
#[IsDestructive(false)]
class Reorder extends BaseTool
{
    protected bool $writes = true;

    protected function ability(): string
    {
        return Ability::CatalogWrite;
    }

    public function schema(JsonSchema $schema): array
    {
        return [
            'items' => $schema->array()->min(1)->max(CatalogService::MAX_BATCH)->items($schema->object([
                'type' => $schema->string()->enum(['category', 'product'])->required(),
                'id' => $schema->integer()->required(),
                'sort' => $schema->integer()->min(0)->max(65535)->required(),
            ]))->required(),
        ];
    }

    protected function run(Request $request, User $user): array
    {
        $data = $this->validated($request, [
            'items' => 'required|array|min:1',
            'items.*.type' => 'required|in:category,product',
            'items.*.id' => 'required|integer',
            'items.*.sort' => 'required|integer|min:0|max:65535',
        ]);
        CatalogService::guardBatch($data['items']);

        $before = $after = [];

        DB::transaction(function () use ($data, &$before, &$after) {
            foreach ($data['items'] as $item) {
                $model = $item['type'] === 'category' ? Category::find($item['id']) : Product::find($item['id']);

                if (! $model) {
                    throw new ToolError("Не знайдено {$item['type']} з id {$item['id']}.");
                }

                $before[] = ['type' => $item['type'], 'id' => $model->id, 'sort' => $model->sort];
                $model->update(['sort' => $item['sort']]);
                $after[] = ['type' => $item['type'], 'id' => $model->id, 'sort' => $item['sort']];
            }
        });

        $this->changed($before, $after);

        return ['message' => 'Порядок оновлено: '.count($after).'.'];
    }
}
