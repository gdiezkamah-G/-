<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\Ability;
use App\Enums\ProductStatus;
use App\Mcp\Tools\BaseTool;
use App\Models\Category;
use App\Models\User;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsReadOnly;

#[Name('catalog_list_categories')]
#[Title('Категорії')]
#[Description('Усі категорії з кількістю товарів за статусами. Категорія без опублікованих товарів на сайті не показується.')]
#[IsReadOnly]
class ListCategories extends BaseTool
{
    protected function ability(): string
    {
        return Ability::CatalogRead;
    }

    protected function run(Request $request, User $user): array
    {
        $categories = Category::orderBy('sort')->withCount([
            'products', 'products as published_count' => fn ($q) => $q->where('status', ProductStatus::Published),
        ])->get();

        return ['categories' => $categories->map(fn (Category $c) => [
            'id' => $c->id, 'slug' => $c->slug, 'name' => $c->name, 'sort' => $c->sort,
            'products' => $c->products_count, 'published' => $c->published_count,
            'visible_on_site' => $c->published_count > 0,
        ])->all()];
    }
}
