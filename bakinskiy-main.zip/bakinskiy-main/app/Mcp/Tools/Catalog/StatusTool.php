<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\Ability;
use App\Enums\ProductStatus;
use App\Mcp\Support\CatalogService;
use App\Mcp\Tools\BaseTool;
use App\Models\Product;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;

/** Moves products between statuses. Up to 20 at once; each product reports on its own why it was skipped. */
abstract class StatusTool extends BaseTool
{
    protected bool $writes = true;

    /** @var list<ProductStatus> statuses a product may be in for this move */
    abstract protected function from(): array;

    abstract protected function to(): ProductStatus;

    /** Past tense for the message, e.g. «Опубліковано». */
    abstract protected function verb(): string;

    protected function ability(): string
    {
        return Ability::CatalogWrite;
    }

    /** Publishing needs an explicit confirm=true. */
    protected function needsConfirm(): bool
    {
        return false;
    }

    public function schema(JsonSchema $schema): array
    {
        return ['ids' => $schema->array()->min(1)->max(CatalogService::MAX_BATCH)->items($schema->string())->description('id або slug товарів, не більше 20')->required()]
            + ($this->needsConfirm() ? ['confirm' => $schema->boolean()->description('true — підтверджую публікацію. Без нього повертається лише попередній перегляд.')] : []);
    }

    /** @param  list<string>  $warnings */
    protected function warnings(Product $p): array
    {
        return [];
    }

    protected function run(Request $request, User $user): array
    {
        $data = $this->validated($request, ['ids' => 'required|array|min:1', 'ids.*' => 'required', 'confirm' => 'nullable|boolean']);
        $products = CatalogService::products($data['ids'])->unique('id')->values();

        $apply = [];
        $skipped = [];

        foreach ($products as $p) {
            in_array($p->status, $this->from(), true)
                ? $apply[] = $p
                : $skipped[] = ['id' => $p->id, 'slug' => $p->slug, 'reason' => "зараз «{$p->status->getLabel()}», потрібно: ".implode(' / ', array_map(fn ($s) => $s->getLabel(), $this->from()))];
        }

        $list = array_map(fn (Product $p) => ['id' => $p->id, 'slug' => $p->slug, 'name' => trim($p->name.' '.$p->subtitle), 'warnings' => $this->warnings($p)], $apply);

        if ($this->needsConfirm() && empty($data['confirm'])) {
            return [
                'preview' => true,
                'message' => $apply
                    ? 'Буде '.mb_strtolower($this->verb()).': '.implode('; ', array_column($list, 'name')).'. Щоб підтвердити, викличте цей інструмент ще раз з confirm=true.'
                    : 'Нічого змінювати: жоден товар не підходить.',
                'will_change' => $list,
                'skipped' => $skipped,
            ];
        }

        $before = $after = [];
        foreach ($apply as $p) {
            $before[] = ['id' => $p->id, 'status' => $p->status->value];
            $p->update(['status' => $this->to()]);
            $after[] = ['id' => $p->id, 'status' => $this->to()->value];
        }

        $apply && $this->changed($before, $after);

        return [
            'message' => $this->verb().': '.count($apply).($skipped ? ', пропущено: '.count($skipped) : '').'.',
            'changed' => $list,
            'skipped' => $skipped,
        ];
    }
}
