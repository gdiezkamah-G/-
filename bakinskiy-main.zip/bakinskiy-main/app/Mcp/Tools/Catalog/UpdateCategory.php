<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\Ability;
use App\Mcp\Support\CatalogService;
use App\Mcp\Support\ToolError;
use App\Mcp\Tools\BaseTool;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Validation\Rule;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;
use Laravel\Mcp\Server\Tools\Annotations\IsIdempotent;

#[Name('catalog_update_category')]
#[Title('Змінити категорію')]
#[Description('Змінює назву, slug або порядок категорії. Зміна slug міняє адреси сторінок категорії.')]
#[IsIdempotent]
#[IsDestructive(false)]
class UpdateCategory extends BaseTool
{
    protected bool $writes = true;

    protected function ability(): string
    {
        return Ability::CatalogWrite;
    }

    public function schema(JsonSchema $schema): array
    {
        return [
            'category' => $schema->string()->description('id або slug категорії')->required(),
            'name' => $schema->string(), 'slug' => $schema->string(), 'sort' => $schema->integer()->min(0)->max(65535),
        ];
    }

    protected function run(Request $request, User $user): array
    {
        $category = CatalogService::category($request->get('category') ?? '');

        $data = $this->validated($request, [
            'category' => 'required',
            'name' => ['sometimes', 'string', 'max:120', Rule::unique('categories', 'name')->ignore($category->id)],
            'slug' => ['sometimes', 'string', 'max:120', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', Rule::unique('categories', 'slug')->ignore($category->id)],
            'sort' => 'sometimes|integer|min:0|max:65535',
        ], ['name.unique' => 'Категорія з такою назвою вже є.', 'slug.unique' => 'Такий slug уже зайнятий.', 'slug.regex' => 'slug: лише латиниця, цифри і дефіси.']);

        $changes = array_intersect_key($data, array_flip(['name', 'slug', 'sort']));

        if ($changes === []) {
            throw new ToolError('Не передано жодного поля для зміни.');
        }

        $before = $category->only(['id', 'name', 'slug', 'sort']);
        $category->update($changes);
        $this->changed($before, $category->only(['id', 'name', 'slug', 'sort']));

        return ['message' => "Категорію «{$category->name}» оновлено.", 'category' => $category->only(['id', 'slug', 'name', 'sort'])];
    }
}
