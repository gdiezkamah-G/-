<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\Ability;
use App\Enums\ProductStatus;
use App\Mcp\Support\CatalogService;
use App\Mcp\Tools\BaseTool;
use App\Models\Product;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;

#[Name('catalog_create_product')]
#[Title('Створити товар (чернетка)')]
#[Description('Створює товар ЧЕРНЕТКОЮ (на сайті його не видно). Потрібні назва і категорія. Фасування додайте через catalog_set_variants, публікацію виконує окремо catalog_publish. Не вигадуйте склад і характеристики: залишайте порожнім те, чого немає в даних.')]
#[IsDestructive(false)]
class CreateProduct extends BaseTool
{
    protected bool $writes = true;

    protected function ability(): string
    {
        return Ability::CatalogWrite;
    }

    public function schema(JsonSchema $schema): array
    {
        return [
            'name' => $schema->string()->description('Назва, напр. «Люля-кебаб»')->required(),
            'category' => $schema->string()->description('slug або id категорії')->required(),
            'slug' => $schema->string()->description('Необов’язково; за замовчуванням з назви й підзаголовка'),
            'subtitle' => $schema->string()->description('Напр. «з м’яса курки, кулінарний»'),
            'full_name' => $schema->string(),
            'short_tagline' => $schema->string()->description('Одне речення'),
            'description' => $schema->string(),
            'composition' => $schema->string()->description('Склад одним рядком, лише з підтверджених даних'),
            'ingredients' => $schema->array()->items($schema->string()),
            'cooking_steps' => $schema->array()->items($schema->string()),
            'cooking_summary' => $schema->string(),
            'packaging' => $schema->string(),
            'shelf_life' => $schema->string()->description('Напр. «6 міс.»'),
            'storage_temp' => $schema->string()->description('Напр. «−18 °C»'),
            'needs_confirmation' => $schema->array()->items($schema->string())->description('Поля, які ще треба уточнити з виробництвом'),
            'sort' => $schema->integer()->min(0)->max(65535),
        ];
    }

    protected function run(Request $request, User $user): array
    {
        $data = $this->validated($request, CatalogService::productRules(true) + ['category' => 'required', 'slug' => ['nullable', 'string', 'max:160', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', 'unique:products,slug']], [
            'slug.unique' => 'Такий slug уже є. Вкажіть інший або не вказуйте взагалі.',
            'slug.regex' => 'slug: лише латиниця, цифри і дефіси.',
        ]);

        $category = CatalogService::category($data['category']);
        $slug = $data['slug'] ?? CatalogService::uniqueSlug(trim($data['name'].' '.($data['subtitle'] ?? '')), 'products');

        $product = Product::create(array_intersect_key($data, array_flip(CatalogService::FIELDS)) + [
            'category_id' => $category->id, 'slug' => $slug, 'status' => ProductStatus::Draft,
        ]);

        $this->changed(null, CatalogService::snapshot($product));

        return ['message' => "Створено чернетку «{$product->name}». На сайті її не видно, доки не буде опублікована.", 'product' => CatalogService::brief($product)];
    }
}
