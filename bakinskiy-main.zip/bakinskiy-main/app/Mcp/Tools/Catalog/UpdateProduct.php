<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\Ability;
use App\Mcp\Support\CatalogService;
use App\Mcp\Support\ToolError;
use App\Mcp\Tools\BaseTool;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Validation\Rule;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;
use Laravel\Mcp\Server\Tools\Annotations\IsIdempotent;

#[Name('catalog_update_product')]
#[Title('Змінити товар')]
#[Description('Змінює лише передані поля товару (статус не змінюється: для цього є publish/unpublish/archive/restore). Попередня версія зберігається, її можна повернути через product_revert. Для зміни категорії передайте category.')]
#[IsIdempotent]
#[IsDestructive(false)]
class UpdateProduct extends BaseTool
{
    protected bool $writes = true;

    protected function ability(): string
    {
        return Ability::CatalogWrite;
    }

    public function schema(JsonSchema $schema): array
    {
        return [
            'product' => $schema->string()->description('id або slug товару')->required(),
            'category' => $schema->string()->description('Нова категорія (slug або id)'),
            'slug' => $schema->string()->description('Новий slug (міняє адресу сторінки; обережно з опублікованими)'),
            'name' => $schema->string(), 'subtitle' => $schema->string(), 'full_name' => $schema->string(),
            'short_tagline' => $schema->string(), 'description' => $schema->string(), 'composition' => $schema->string(),
            'ingredients' => $schema->array()->items($schema->string()),
            'cooking_steps' => $schema->array()->items($schema->string()),
            'cooking_summary' => $schema->string(), 'packaging' => $schema->string(), 'shelf_life' => $schema->string(),
            'storage_temp' => $schema->string(), 'hue' => $schema->string()->description('Колір пака #rrggbb'),
            'needs_confirmation' => $schema->array()->items($schema->string()),
            'sort' => $schema->integer()->min(0)->max(65535),
        ];
    }

    protected function run(Request $request, User $user): array
    {
        $product = CatalogService::product($request->get('product') ?? '');

        $data = $this->validated($request, CatalogService::productRules(false) + [
            'product' => 'required', 'category' => 'sometimes|required',
            'slug' => ['sometimes', 'string', 'max:160', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', Rule::unique('products', 'slug')->ignore($product->id)],
        ], ['slug.unique' => 'Такий slug уже зайнятий іншим товаром.', 'slug.regex' => 'slug: лише латиниця, цифри і дефіси.']);

        $changes = array_intersect_key($data, array_flip([...CatalogService::FIELDS, 'slug']));

        if (isset($data['category'])) {
            $changes['category_id'] = CatalogService::category($data['category'])->id;
        }

        if ($changes === []) {
            throw new ToolError('Не передано жодного поля для зміни.');
        }

        $before = $this->remember($product, $user);
        $product->update($changes);
        $this->changed($before, CatalogService::snapshot($product));

        return ['message' => "Товар «{$product->name}» оновлено. Попередня версія збережена (revision_id {$this->lastRevision->id}).", 'product' => CatalogService::brief($product)];
    }
}
