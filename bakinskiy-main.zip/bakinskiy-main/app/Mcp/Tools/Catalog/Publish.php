<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\ProductStatus;
use App\Models\Product;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;

#[Name('catalog_publish')]
#[Title('Опублікувати товари')]
#[Description('Публікує товари чернетки НА САЙТІ (видно клієнтам). Без confirm=true лише показує, що буде опубліковано, і попередження (немає складу, фасування, є «потребує уточнення»). Покажіть перегляд користувачу і викликайте з confirm=true лише після його явної згоди. Не більше 20 товарів.')]
#[IsDestructive]
class Publish extends StatusTool
{
    protected function from(): array
    {
        return [ProductStatus::Draft];
    }

    protected function to(): ProductStatus
    {
        return ProductStatus::Published;
    }

    protected function verb(): string
    {
        return 'Опубліковано';
    }

    protected function needsConfirm(): bool
    {
        return true;
    }

    protected function warnings(Product $p): array
    {
        $p->loadMissing('activeVariants');

        return array_values(array_filter([
            blank($p->composition) && blank($p->ingredients) ? 'немає складу' : null,
            $p->activeVariants->isEmpty() ? 'немає активного фасування' : null,
            blank($p->description) && blank($p->short_tagline) ? 'немає опису' : null,
            ! empty($p->needs_confirmation) ? 'потребує уточнення: '.implode(', ', $p->needs_confirmation) : null,
        ]));
    }
}
