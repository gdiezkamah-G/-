<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\Ability;
use App\Mcp\Support\CatalogService;
use App\Mcp\Tools\BaseTool;
use App\Models\Category;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;

#[Name('catalog_create_category')]
#[Title('Створити категорію')]
#[Description('Створює категорію. Вона не видна на сайті, доки в ній немає опублікованих товарів (тобто вона «чернетка» за суттю).')]
#[IsDestructive(false)]
class CreateCategory extends BaseTool
{
    protected bool $writes = true;

    protected function ability(): string
    {
        return Ability::CatalogWrite;
    }

    public function schema(JsonSchema $schema): array
    {
        return [
            'name' => $schema->string()->description('Назва, напр. «Долма»')->required(),
            'slug' => $schema->string()->description('Необов’язково; з назви за замовчуванням'),
            'sort' => $schema->integer()->min(0)->max(65535),
        ];
    }

    protected function run(Request $request, User $user): array
    {
        $data = $this->validated($request, [
            'name' => 'required|string|max:120|unique:categories,name',
            'slug' => ['nullable', 'string', 'max:120', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', 'unique:categories,slug'],
            'sort' => 'nullable|integer|min:0|max:65535',
        ], ['name.unique' => 'Категорія з такою назвою вже є.', 'slug.unique' => 'Такий slug уже є.', 'slug.regex' => 'slug: лише латиниця, цифри і дефіси.']);

        $category = Category::create([
            'name' => $data['name'],
            'slug' => $data['slug'] ?? CatalogService::uniqueSlug($data['name'], 'categories'),
            'sort' => $data['sort'] ?? ((int) Category::max('sort') + 1),
        ]);

        $this->changed(null, $category->only(['id', 'name', 'slug', 'sort']));

        return ['message' => "Категорію «{$category->name}» створено. На сайті вона зʼявиться разом з першим опублікованим товаром.", 'category' => $category->only(['id', 'slug', 'name', 'sort'])];
    }
}
