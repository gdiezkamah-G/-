<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\ProductStatus;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;
use Laravel\Mcp\Server\Tools\Annotations\IsIdempotent;

#[Name('catalog_archive')]
#[Title('Архівувати товари')]
#[Description('Архівує товари (з чернеток або з сайту): їх не видно на сайті, і вони не потрапляють у прайс. Нічого не видаляється, повернути можна через catalog_restore. Не більше 20 товарів.')]
#[IsDestructive]
#[IsIdempotent]
class Archive extends StatusTool
{
    protected function from(): array
    {
        return [ProductStatus::Draft, ProductStatus::Published];
    }

    protected function to(): ProductStatus
    {
        return ProductStatus::Archived;
    }

    protected function verb(): string
    {
        return 'Заархівовано';
    }
}
