<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\Ability;
use App\Mcp\Support\CatalogService;
use App\Mcp\Support\ToolError;
use App\Mcp\Tools\BaseTool;
use App\Models\ProductVariant;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\Support\Facades\DB;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;
use Laravel\Mcp\Server\Tools\Annotations\IsIdempotent;

#[Name('catalog_set_variants')]
#[Title('Задати фасування')]
#[Description('Задає ПОВНИЙ набір фасувань товару (замінює поточний): size_label («1 кг»), pack_note («10 шт»), sort. Варіанти з id оновлюються, нові створюються, відсутні у списку видаляються (попередній набір зберігається, повернути можна через product_revert). Один варіант має бути default; якщо жодного не позначено, default стає перший.')]
#[IsIdempotent]
#[IsDestructive(false)]
class SetVariants extends BaseTool
{
    protected bool $writes = true;

    protected function ability(): string
    {
        return Ability::CatalogWrite;
    }

    public function schema(JsonSchema $schema): array
    {
        return [
            'product_id' => $schema->string()->description('id або slug товару')->required(),
            'variants' => $schema->array()->min(1)->max(CatalogService::MAX_BATCH)->items($schema->object([
                'id' => $schema->integer()->description('id наявного варіанта, щоб оновити його'),
                'size_label' => $schema->string()->description('Напр. «1 кг», «450 г»')->required(),
                'pack_note' => $schema->string()->description('Напр. «10 шт»'),
                'weight_g' => $schema->integer()->min(1),
                'units' => $schema->integer()->min(1),
                'sku' => $schema->string(),
                'pack_type' => $schema->string(),
                'is_default' => $schema->boolean(),
                'is_active' => $schema->boolean(),
                'sort' => $schema->integer()->min(0),
            ]))->required(),
        ];
    }

    protected function run(Request $request, User $user): array
    {
        $data = $this->validated($request, [
            'product_id' => 'required',
            'variants' => 'required|array|min:1',
            'variants.*.id' => 'nullable|integer',
            'variants.*.size_label' => 'required|string|max:60',
            'variants.*.pack_note' => 'nullable|string|max:120',
            'variants.*.weight_g' => 'nullable|integer|min:1|max:1000000',
            'variants.*.units' => 'nullable|integer|min:1|max:65535',
            'variants.*.sku' => 'nullable|string|max:60',
            'variants.*.pack_type' => 'nullable|string|max:60',
            'variants.*.is_default' => 'nullable|boolean',
            'variants.*.is_active' => 'nullable|boolean',
            'variants.*.sort' => 'nullable|integer|min:0|max:65535',
        ], [
            'variants.*.size_label.required' => 'У кожного фасування має бути size_label (напр. «1 кг»).',
        ]);

        CatalogService::guardBatch($data['variants']);
        $product = CatalogService::product($data['product_id']);
        $rows = $data['variants'];

        if (count(array_filter($rows, fn ($r) => ! empty($r['is_default']))) > 1) {
            throw new ToolError('Позначити default можна лише одне фасування.');
        }

        $skus = array_filter(array_column($rows, 'sku'));
        if (count($skus) !== count(array_unique($skus))) {
            throw new ToolError('sku мають бути унікальними.');
        }

        $before = $this->remember($product, $user);

        DB::transaction(function () use ($product, $rows) {
            $keep = [];
            $hasDefault = (bool) array_filter($rows, fn ($r) => ! empty($r['is_default']));

            foreach (array_values($rows) as $i => $row) {
                $variant = isset($row['id']) ? ProductVariant::where('product_id', $product->id)->find($row['id']) : null;

                if (isset($row['id']) && ! $variant) {
                    throw new ToolError("Фасування з id {$row['id']} не належить цьому товару.");
                }

                $variant ??= new ProductVariant(['product_id' => $product->id]);
                $variant->fill([
                    'size_label' => $row['size_label'], 'pack_note' => $row['pack_note'] ?? null, 'weight_g' => $row['weight_g'] ?? null,
                    'units' => $row['units'] ?? null, 'sku' => $row['sku'] ?? null, 'pack_type' => $row['pack_type'] ?? null,
                    'is_default' => ! empty($row['is_default']) || (! $hasDefault && $i === 0),
                    'is_active' => $row['is_active'] ?? true, 'sort' => $row['sort'] ?? $i,
                ])->save();
                $keep[] = $variant->id;
            }

            ProductVariant::where('product_id', $product->id)->whereNotIn('id', $keep)->delete();
        });

        $this->changed($before, CatalogService::snapshot($product));

        return [
            'message' => "Фасування товару «{$product->name}» оновлено ({$product->variants()->count()}).",
            'revision_id' => $this->lastRevision->id,
            'variants' => $product->variants()->get()->map(fn ($v) => CatalogService::variant($v))->all(),
        ];
    }
}
