<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\ProductStatus;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;
use Laravel\Mcp\Server\Tools\Annotations\IsIdempotent;

#[Name('catalog_unpublish')]
#[Title('Зняти з публікації')]
#[Description('Знімає товари з публікації: вони зникають із сайту, але лишаються чернетками (нічого не видаляється). Не більше 20 товарів.')]
#[IsDestructive]
#[IsIdempotent]
class Unpublish extends StatusTool
{
    protected function from(): array
    {
        return [ProductStatus::Published];
    }

    protected function to(): ProductStatus
    {
        return ProductStatus::Draft;
    }

    protected function verb(): string
    {
        return 'Знято з публікації';
    }
}
