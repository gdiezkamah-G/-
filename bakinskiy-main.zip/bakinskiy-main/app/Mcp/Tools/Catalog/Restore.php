<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\ProductStatus;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsIdempotent;

#[Name('catalog_restore')]
#[Title('Відновити з архіву')]
#[Description('Повертає товари з архіву як ЧЕРНЕТКИ (на сайті вони не зʼявляться, доки їх не опублікують окремо). Не більше 20 товарів.')]
#[IsIdempotent]
class Restore extends StatusTool
{
    protected function from(): array
    {
        return [ProductStatus::Archived];
    }

    protected function to(): ProductStatus
    {
        return ProductStatus::Draft;
    }

    protected function verb(): string
    {
        return 'Відновлено з архіву (чернетки)';
    }
}
