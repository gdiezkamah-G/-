<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\Ability;
use App\Mcp\Support\CatalogService;
use App\Mcp\Support\ToolError;
use App\Mcp\Tools\BaseTool;
use App\Models\ProductRevision;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;

#[Name('product_revert')]
#[Title('Повернути версію товару')]
#[Description('Повертає товар і його фасування до збереженої версії (revision_id є у відповідях catalog_update_product / catalog_set_variants та в журналі ШІ). Статус товару не змінюється: повернення ніколи нічого не публікує. Саме повернення теж можна скасувати.')]
#[IsDestructive(false)]
class ProductRevert extends BaseTool
{
    protected bool $writes = true;

    protected function ability(): string
    {
        return Ability::CatalogWrite;
    }

    public function schema(JsonSchema $schema): array
    {
        return ['revision_id' => $schema->integer()->description('id версії')->required()];
    }

    protected function run(Request $request, User $user): array
    {
        $data = $this->validated($request, ['revision_id' => 'required|integer']);
        $rev = ProductRevision::find($data['revision_id']) ?? throw new ToolError("Версію {$data['revision_id']} не знайдено.");
        $product = $rev->product ?? throw new ToolError('Товар цієї версії вже не існує.');

        if ($rev->reverted_at) {
            throw new ToolError('Цю версію вже було застосовано '.$rev->reverted_at->format('d.m.Y H:i').'. Зробіть нову зміну або оберіть іншу версію.');
        }

        $before = $this->remember($product, $user); // the revert itself can be reverted
        CatalogService::restore($rev);
        $rev->update(['reverted_at' => now()]);
        $this->changed($before, CatalogService::snapshot($product));

        return ['message' => "Товар «{$product->name}» повернуто до версії від {$rev->created_at->format('d.m.Y H:i')}. Статус не змінювався.", 'product' => CatalogService::brief($product->refresh()), 'new_revision_id' => $this->lastRevision->id];
    }
}
