<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\Ability;
use App\Enums\ProductStatus;
use App\Mcp\Tools\BaseTool;
use App\Models\Product;
use App\Models\User;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsReadOnly;

#[Name('catalog_audit')]
#[Title('Аудит каталогу')]
#[Description('Що в каталозі потребує уваги: товари без складу, опису чи фасування, з прапорцем «потребує уточнення», дублікати назв, опубліковані з проблемами. Архівні не перевіряються.')]
#[IsReadOnly]
class CatalogAudit extends BaseTool
{
    protected function ability(): string
    {
        return Ability::CatalogRead;
    }

    protected function run(Request $request, User $user): array
    {
        $products = Product::with('variants')->where('status', '!=', ProductStatus::Archived)->orderBy('id')->get();

        $issues = [
            'no_composition' => $products->filter(fn ($p) => blank($p->composition) && blank($p->ingredients)),
            'no_description' => $products->filter(fn ($p) => blank($p->description) && blank($p->short_tagline)),
            'no_variants' => $products->filter(fn ($p) => $p->variants->where('is_active', true)->isEmpty()),
            'needs_confirmation' => $products->filter(fn ($p) => ! empty($p->needs_confirmation)),
        ];

        $dupes = $products->groupBy(fn ($p) => mb_strtolower(trim($p->name.' '.$p->subtitle)))->filter(fn ($g) => $g->count() > 1);

        $row = fn (Product $p) => ['id' => $p->id, 'slug' => $p->slug, 'name' => trim($p->name.' '.$p->subtitle), 'status' => $p->status->value]
            + (empty($p->needs_confirmation) ? [] : ['needs_confirmation' => $p->needs_confirmation]);

        $report = array_map(fn ($c) => ['count' => $c->count(), 'products' => $c->take(30)->map($row)->values()->all()], $issues);
        $report['duplicate_names'] = ['count' => $dupes->count(), 'groups' => $dupes->take(20)->map(fn ($g) => $g->map($row)->values()->all())->values()->all()];

        $live = $products->where('status', ProductStatus::Published);
        $published = $live->filter(fn ($p) => blank($p->composition) && blank($p->ingredients) || $p->variants->where('is_active', true)->isEmpty() || ! empty($p->needs_confirmation));

        return [
            'summary' => [
                'checked' => $products->count(),
                'published_with_problems' => $published->count(),
                'note' => 'Фото в каталозі поки заглушки (окреме поле фото відсутнє), тому відсутність фото не перевіряється.',
            ],
            'published_with_problems' => $published->take(30)->map($row)->values()->all(),
        ] + $report;
    }
}
