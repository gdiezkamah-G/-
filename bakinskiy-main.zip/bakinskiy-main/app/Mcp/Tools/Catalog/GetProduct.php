<?php

namespace App\Mcp\Tools\Catalog;

use App\Enums\Ability;
use App\Mcp\Support\CatalogService;
use App\Mcp\Tools\BaseTool;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsReadOnly;

#[Name('catalog_get_product')]
#[Title('Картка товару')]
#[Description('Повна картка товару за id або slug: опис, склад, зберігання, усі фасування, прапорці «потребує уточнення».')]
#[IsReadOnly]
class GetProduct extends BaseTool
{
    protected function ability(): string
    {
        return Ability::CatalogRead;
    }

    public function schema(JsonSchema $schema): array
    {
        return ['product' => $schema->string()->description('id або slug товару')->required()];
    }

    protected function run(Request $request, User $user): array
    {
        $data = $this->validated($request, ['product' => 'required']);

        return CatalogService::full(CatalogService::product($data['product']));
    }
}
