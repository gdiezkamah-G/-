<?php

namespace App\Mcp\Tools\Leads;

use App\Enums\Ability;
use App\Enums\LeadSource;
use App\Enums\LeadStatus;
use App\Enums\LeadType;
use App\Mcp\Support\LeadService;
use App\Mcp\Tools\BaseTool;
use App\Models\Lead;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsReadOnly;

#[Name('leads_list')]
#[Title('Список заявок')]
#[Description('Заявки, нові спочатку. Фільтри: status (new, in_progress, won, lost, closed), type (order, price, sample, manager, request), source (site, miniapp, bot), дати YYYY-MM-DD, пошук за закладом/імʼям/телефоном. Сторінками: cursor з попередньої відповіді. Містить персональні дані клієнтів.')]
#[IsReadOnly]
class ListLeads extends BaseTool
{
    protected function ability(): string
    {
        return Ability::LeadsRead;
    }

    public function schema(JsonSchema $schema): array
    {
        return [
            'status' => $schema->string()->enum(array_column(LeadStatus::cases(), 'value')),
            'type' => $schema->string()->enum(array_column(LeadType::cases(), 'value')),
            'source' => $schema->string()->enum(array_column(LeadSource::cases(), 'value')),
            'date_from' => $schema->string()->description('YYYY-MM-DD'),
            'date_to' => $schema->string()->description('YYYY-MM-DD'),
            'search' => $schema->string(),
            'limit' => $schema->integer()->min(1)->max(50),
            'cursor' => $schema->integer()->description('next_cursor з попередньої відповіді'),
        ];
    }

    protected function run(Request $request, User $user): array
    {
        $d = $this->validated($request, [
            'status' => 'nullable|in:'.implode(',', array_column(LeadStatus::cases(), 'value')),
            'type' => 'nullable|in:'.implode(',', array_column(LeadType::cases(), 'value')),
            'source' => 'nullable|in:'.implode(',', array_column(LeadSource::cases(), 'value')),
            'date_from' => 'nullable|date_format:Y-m-d', 'date_to' => 'nullable|date_format:Y-m-d|after_or_equal:date_from',
            'search' => 'nullable|string|max:100', 'limit' => 'nullable|integer|min:1|max:50', 'cursor' => 'nullable|integer|min:0',
        ], ['date_from.date_format' => 'date_from: формат YYYY-MM-DD.', 'date_to.date_format' => 'date_to: формат YYYY-MM-DD.']);
        $limit = $this->paging($request);

        $q = Lead::with('product')->orderByDesc('id');
        foreach (['status', 'type', 'source'] as $f) {
            filled($d[$f] ?? null) && $q->where($f, $d[$f]);
        }
        filled($d['date_from'] ?? null) && $q->where('created_at', '>=', $d['date_from'].' 00:00:00');
        filled($d['date_to'] ?? null) && $q->where('created_at', '<=', $d['date_to'].' 23:59:59');
        filled($d['cursor'] ?? null) && $q->where('id', '<', (int) $d['cursor']);

        if (filled($d['search'] ?? null)) {
            $like = '%'.str_replace(['%', '_'], ['\%', '\_'], $d['search']).'%';
            $q->where(fn ($w) => $w->where('company', 'like', $like)->orWhere('contact_name', 'like', $like)->orWhere('phone', 'like', $like));
        }

        $rows = $q->limit($limit + 1)->get();
        $more = $rows->count() > $limit;
        $rows = $rows->take($limit);

        return ['leads' => $rows->map(fn (Lead $l) => LeadService::brief($l))->all(), 'count' => $rows->count(), 'next_cursor' => $more ? $rows->last()->id : null];
    }
}
