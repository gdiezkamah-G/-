<?php

namespace App\Mcp\Tools\Leads;

use App\Enums\Ability;
use App\Mcp\Support\LeadService;
use App\Mcp\Tools\BaseTool;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;

#[Name('leads_add_note')]
#[Title('Нотатка до заявки')]
#[Description('Додає нотатку до заявки (дописується в кінець із датою й автором; попередні нотатки не втрачаються).')]
#[IsDestructive(false)]
class AddLeadNote extends BaseTool
{
    protected bool $writes = true;

    protected function ability(): string
    {
        return Ability::LeadsWrite;
    }

    public function schema(JsonSchema $schema): array
    {
        return ['id' => $schema->integer()->required(), 'text' => $schema->string()->min(1)->max(1000)->required()];
    }

    protected function run(Request $request, User $user): array
    {
        $d = $this->validated($request, ['id' => 'required|integer', 'text' => 'required|string|max:1000']);
        $lead = LeadService::find($d['id']);
        $before = $lead->notes;

        $line = '['.now()->timezone('Europe/Kyiv')->format('d.m.Y H:i').', '.$user->name.'] '.trim($d['text']);
        $lead->update(['notes' => trim(($before ? $before."\n" : '').$line)]);
        $this->changed(['notes' => $before], ['notes' => $lead->notes]);

        return ['message' => "Нотатку додано до заявки №{$lead->id}.", 'notes' => $lead->notes];
    }
}
