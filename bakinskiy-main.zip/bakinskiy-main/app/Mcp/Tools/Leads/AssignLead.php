<?php

namespace App\Mcp\Tools\Leads;

use App\Enums\Ability;
use App\Mcp\Support\LeadService;
use App\Mcp\Support\ToolError;
use App\Mcp\Tools\BaseTool;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;
use Laravel\Mcp\Server\Tools\Annotations\IsIdempotent;

#[Name('leads_assign')]
#[Title('Призначити менеджера')]
#[Description('Призначає заявці відповідального менеджера (user_id співробітника адмінки). user_id=0 знімає призначення. Список співробітників повертає ця ж помилка, якщо id невірний.')]
#[IsIdempotent]
#[IsDestructive(false)]
class AssignLead extends BaseTool
{
    protected bool $writes = true;

    protected function ability(): string
    {
        return Ability::LeadsWrite;
    }

    public function schema(JsonSchema $schema): array
    {
        return ['id' => $schema->integer()->required(), 'user_id' => $schema->integer()->min(0)->description('id співробітника; 0 — зняти')->required()];
    }

    protected function run(Request $request, User $user): array
    {
        $d = $this->validated($request, ['id' => 'required|integer', 'user_id' => 'required|integer|min:0']);
        $lead = LeadService::find($d['id']);
        $assignee = null;

        if ($d['user_id'] > 0) {
            $assignee = User::whereNotNull('role')->find($d['user_id']);

            if (! $assignee) {
                $staff = User::whereNotNull('role')->orderBy('id')->get(['id', 'name'])->map(fn ($u) => "{$u->id} — {$u->name}")->implode('; ');
                throw new ToolError("Співробітника з id {$d['user_id']} немає. Доступні: {$staff}.");
            }
        }

        $before = $lead->manager_id;
        $lead->update(['manager_id' => $assignee?->id]);
        $this->changed(['manager_id' => $before], ['manager_id' => $assignee?->id]);

        return ['message' => $assignee ? "Заявку №{$lead->id} призначено: {$assignee->name}." : "З заявки №{$lead->id} знято призначення."];
    }
}
