<?php

namespace App\Mcp\Tools\Leads;

use App\Enums\Ability;
use App\Enums\LeadStatus;
use App\Mcp\Tools\BaseTool;
use App\Models\Lead;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsReadOnly;

#[Name('leads_summary')]
#[Title('Підсумок заявок')]
#[Description('Підсумок заявок за період: кількість за типами, джерелами, статусами, найпопулярніші товари, середній час до взяття в роботу, скільки «нових» чекають понад 24 години. period: today, week (7 днів), month (30 днів), all.')]
#[IsReadOnly]
class LeadsSummary extends BaseTool
{
    protected function ability(): string
    {
        return Ability::LeadsRead;
    }

    public function schema(JsonSchema $schema): array
    {
        return ['period' => $schema->string()->enum(['today', 'week', 'month', 'all'])->description('За замовчуванням week')];
    }

    protected function run(Request $request, User $user): array
    {
        $d = $this->validated($request, ['period' => 'nullable|in:today,week,month,all']);
        $period = $d['period'] ?? 'week';
        $from = match ($period) {
            'today' => now()->startOfDay(), 'week' => now()->subDays(7), 'month' => now()->subDays(30), default => null,
        };

        $leads = Lead::with('product')->when($from, fn ($q) => $q->where('created_at', '>=', $from))->get();
        $count = fn ($key) => $leads->groupBy(fn ($l) => $l->{$key}?->value ?? 'unknown')->map->count()->sortDesc()->all();

        $handled = $leads->filter(fn ($l) => $l->handled_at);
        $avg = $handled->isEmpty() ? null : round($handled->avg(fn ($l) => $l->created_at->diffInMinutes($l->handled_at, true)) / 60, 1);

        return [
            'period' => $period,
            'from' => $from?->timezone('Europe/Kyiv')->format('Y-m-d H:i'),
            'total' => $leads->count(),
            'by_type' => $count('type'),
            'by_source' => $count('source'),
            'by_status' => $count('status'),
            'top_products' => $leads->filter(fn ($l) => $l->product)->groupBy(fn ($l) => $l->product->slug)
                ->map(fn ($g) => ['name' => $g->first()->product->name, 'leads' => $g->count()])->sortByDesc('leads')->take(5)->all(),
            'avg_hours_to_first_action' => $avg,
            'new_older_than_24h' => Lead::where('status', LeadStatus::New)->where('created_at', '<', now()->subDay())->count(),
        ];
    }
}
