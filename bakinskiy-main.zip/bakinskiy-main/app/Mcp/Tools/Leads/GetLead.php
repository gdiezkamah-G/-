<?php

namespace App\Mcp\Tools\Leads;

use App\Enums\Ability;
use App\Mcp\Support\LeadService;
use App\Mcp\Tools\BaseTool;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsReadOnly;

#[Name('leads_get')]
#[Title('Заявка')]
#[Description('Одна заявка повністю: контакти, коментар, обсяг, нотатки менеджера, хто взяв у роботу.')]
#[IsReadOnly]
class GetLead extends BaseTool
{
    protected function ability(): string
    {
        return Ability::LeadsRead;
    }

    public function schema(JsonSchema $schema): array
    {
        return ['id' => $schema->integer()->description('id заявки')->required()];
    }

    protected function run(Request $request, User $user): array
    {
        $d = $this->validated($request, ['id' => 'required|integer']);

        return LeadService::full(LeadService::find($d['id']));
    }
}
