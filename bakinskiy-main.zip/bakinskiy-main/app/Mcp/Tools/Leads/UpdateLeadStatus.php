<?php

namespace App\Mcp\Tools\Leads;

use App\Enums\Ability;
use App\Enums\LeadStatus;
use App\Mcp\Support\LeadService;
use App\Mcp\Tools\BaseTool;
use App\Models\User;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Laravel\Mcp\Request;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Title;
use Laravel\Mcp\Server\Tools\Annotations\IsDestructive;
use Laravel\Mcp\Server\Tools\Annotations\IsIdempotent;

#[Name('leads_update_status')]
#[Title('Статус заявки')]
#[Description('Змінює статус заявки: new (нова), in_progress (в роботі), won (виграна), lost (втрачена), closed (закрита). Заявки не видаляються.')]
#[IsIdempotent]
#[IsDestructive(false)]
class UpdateLeadStatus extends BaseTool
{
    protected bool $writes = true;

    protected function ability(): string
    {
        return Ability::LeadsWrite;
    }

    public function schema(JsonSchema $schema): array
    {
        return [
            'id' => $schema->integer()->required(),
            'status' => $schema->string()->enum(array_column(LeadStatus::cases(), 'value'))->required(),
        ];
    }

    protected function run(Request $request, User $user): array
    {
        $d = $this->validated($request, ['id' => 'required|integer', 'status' => 'required|in:'.implode(',', array_column(LeadStatus::cases(), 'value'))]);
        $lead = LeadService::find($d['id']);
        $status = LeadStatus::from($d['status']);
        $before = $lead->status->value;

        $lead->status = $status;

        // the first move out of "new" records who took it, the same as the Telegram button does
        if ($before === LeadStatus::New->value && $status !== LeadStatus::New && ! $lead->handled_at) {
            $lead->handled_by = $user->name;
            $lead->handled_at = now();
        }

        $lead->save();
        $this->changed(['id' => $lead->id, 'status' => $before], ['id' => $lead->id, 'status' => $status->value]);

        return ['message' => "Заявка №{$lead->id}: {$status->getLabel()}.", 'lead' => LeadService::brief($lead)];
    }
}
