<?php

namespace App\Mcp\Servers;

use App\Mcp\Prompts;
use App\Mcp\Resources;
use App\Mcp\Tools\Catalog;
use App\Mcp\Tools\Leads;
use App\Mcp\Tools\Site;
use App\Mcp\Tools\Telegram;
use Laravel\Mcp\Server;

class BakinskyiServer extends Server
{
    protected string $name = 'Бакинський Бульвар';

    protected string $version = '1.0.0';

    protected string $instructions = <<<'TEXT'
Це сервер керування магазином «Бакинський Бульвар · Мануфактура»: власне виробництво ресторану, заморожені напівфабрикати (люля-кебаб, долма, плов, млинці) для кафе, готелів і кейтерингу. Продаємо лише бізнесу (B2B).

Правила:
- Усе українською: тексти, назви, відповіді користувачу.
- Ціни на сайті «за запитом». Не вигадуйте ціни, склад, терміни та характеристики: використовуйте лише дані картки або те, що сказав користувач; чого не знаєте, залишайте порожнім або запитайте.
- Усе нове (товар, категорія, пост) створюється ЧЕРНЕТКОЮ. Публікація на сайті (catalog_publish) і в Telegram-каналі (telegram_publish_channel_post) потребує явного confirm=true: спочатку покажіть користувачу перегляд і запитайте згоду.
- Видалення немає: є зняти з публікації, архівувати, відновити. Зміни товарів можна повернути через product_revert.
- За один виклик змінюється не більше 20 обʼєктів.
- Заявки містять персональні дані клієнтів: показуйте лише потрібне.
- Для довідки прочитайте ресурси bakinskyi://brand-guide, bakinskyi://catalog-schema, bakinskyi://lead-statuses.
TEXT;

    // all tools fit on the first page: some clients never ask for the next one
    public int $defaultPaginationLength = 50;

    protected array $tools = [
        Catalog\ListProducts::class, Catalog\GetProduct::class, Catalog\ListCategories::class,
        Catalog\CreateProduct::class, Catalog\UpdateProduct::class, Catalog\SetVariants::class,
        Catalog\CreateCategory::class, Catalog\UpdateCategory::class, Catalog\Reorder::class,
        Catalog\Publish::class, Catalog\Unpublish::class, Catalog\Archive::class, Catalog\Restore::class,
        Catalog\CatalogAudit::class, Catalog\ProductRevert::class,
        Leads\ListLeads::class, Leads\GetLead::class, Leads\UpdateLeadStatus::class, Leads\AddLeadNote::class,
        Leads\AssignLead::class, Leads\LeadsSummary::class,
        Telegram\GetSettings::class, Telegram\UpdateTexts::class, Telegram\RecipientsList::class, Telegram\RecipientToggle::class,
        Telegram\PreviewChannelPost::class, Telegram\PublishChannelPost::class, Telegram\PricePdfRegenerate::class, Telegram\PricePdfInfo::class,
        Site\GetSettings::class, Site\UpdateContacts::class, Site\SystemStatus::class,
    ];

    protected array $resources = [
        Resources\BrandGuide::class, Resources\CatalogSchema::class, Resources\LeadStatuses::class, Resources\ChannelPostTemplates::class,
    ];

    protected array $prompts = [
        Prompts\AddProductFromNotes::class, Prompts\WriteProductDescription::class, Prompts\PrepareChannelPost::class,
        Prompts\WeeklyLeadsReport::class, Prompts\CatalogCleanup::class, Prompts\FollowupLeads::class,
    ];
}
