<?php

namespace App\Mcp\Prompts;

use App\Enums\Ability;
use App\Mcp\Support\McpAccess;
use Laravel\Mcp\Request;
use Laravel\Mcp\Response;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Prompt;
use Laravel\Mcp\Server\Prompts\Argument;

#[Name('weekly_leads_report')]
#[Description('Тижневий звіт за заявками: підсумок, що в роботі, що застрягло, що порадити.')]
class WeeklyLeadsReport extends Prompt
{
    private const TEXT = <<<'TEXT'
Підготуй тижневий звіт за заявками для керівника.

1. Виклич leads_summary(period="week") і leads_summary(period="month") для порівняння.
2. Виклич leads_list(status="new") та leads_list(status="in_progress"), щоб побачити, що чекає й що в роботі.
3. Складіть звіт українською, стисло:
   - Підсумок: скільки заявок, за типами й джерелами, топ товарів.
   - Що в роботі і хто веде.
   - Що застрягло: «нові» понад 24 години, «в роботі» без руху, без менеджера.
   - 2–3 конкретні рекомендації (кому передзвонити, який товар просять найчастіше).
4. Не наводь зайвих персональних даних: достатньо закладу й типу заявки. Нічого не змінюй у заявках без прохання.
TEXT;

    public function shouldRegister(): bool
    {
        return McpAccess::allows(McpAccess::user(), Ability::LeadsRead);
    }

    /** @return array<int, Argument> */
    public function arguments(): array
    {
        return [
        ];
    }

    public function handle(Request $request): Response
    {
        return Response::text(self::TEXT);
    }
}
