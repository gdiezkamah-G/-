<?php

namespace App\Mcp\Prompts;

use App\Enums\Ability;
use App\Mcp\Support\McpAccess;
use Laravel\Mcp\Request;
use Laravel\Mcp\Response;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Prompt;
use Laravel\Mcp\Server\Prompts\Argument;

#[Name('catalog_cleanup')]
#[Description('Пройтись по аудиту каталогу й запропонувати виправлення пачкою.')]
class CatalogCleanup extends Prompt
{
    private const TEXT = <<<'TEXT'
Наведи лад у каталозі.

1. Виклич catalog_audit і прочитай bakinskyi://brand-guide.
2. Згрупуй проблеми: немає складу, немає опису, немає фасування, «потребує уточнення», дублікати назв, опубліковані з проблемами.
3. Для кожної групи запропонуй конкретні виправлення. Те, що можна взяти лише з даних картки, запропонуй сам; чого не знаєш (склад, термін), занеси як питання до користувача, а не вигадуй.
4. Покажи план пачкою (таблиця: товар, проблема, пропозиція) і чекай згоди.
5. Після згоди виконуй зміни не більше 20 обʼєктів за виклик (catalog_update_product, catalog_set_variants). Дублікати не видаляй: запропонуй catalog_archive.
6. Публікацію й зняття з публікації роби лише окремо, з явним підтвердженням (catalog_publish з confirm=true).
TEXT;

    public function shouldRegister(): bool
    {
        return McpAccess::allows(McpAccess::user(), Ability::CatalogRead);
    }

    /** @return array<int, Argument> */
    public function arguments(): array
    {
        return [
        ];
    }

    public function handle(Request $request): Response
    {
        return Response::text(self::TEXT);
    }
}
