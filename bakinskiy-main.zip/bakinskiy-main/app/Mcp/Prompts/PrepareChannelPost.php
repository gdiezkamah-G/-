<?php

namespace App\Mcp\Prompts;

use App\Enums\Ability;
use App\Mcp\Support\McpAccess;
use Laravel\Mcp\Request;
use Laravel\Mcp\Response;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Prompt;
use Laravel\Mcp\Server\Prompts\Argument;

#[Name('prepare_channel_post')]
#[Description('Підготувати пост для Telegram-каналу, показати перегляд і опублікувати лише після підтвердження.')]
class PrepareChannelPost extends Prompt
{
    private const TEXT = <<<'TEXT'
Підготуй пост для Telegram-каналу бренду.{product_line}{tone_line}

1. Прочитай bakinskyi://brand-guide та bakinskyi://channel-post-templates.
2. Виклич telegram_preview_channel_post(kind=<catalog_pinned або product>{product_arg}) і покажи користувачу текст і кнопки. Поясни, що це лише перегляд і що пост створить або оновить наявний.
3. Якщо користувач хоче змінити текст, поясни, що пост формується з картки товару: змінюється картка (catalog_update_product), а не окремий текст поста.
4. Публікуй (telegram_publish_channel_post) тільки після його явної згоди: спочатку без confirm (перегляд), потім з confirm=true. Ніколи не публікуй без підтвердження.
5. Скажи результат: створено чи оновлено пост.
TEXT;

    public function shouldRegister(): bool
    {
        return McpAccess::allows(McpAccess::user(), Ability::TelegramRead);
    }

    /** @return array<int, Argument> */
    public function arguments(): array
    {
        return [
            new Argument('product', 'id або slug товару (порожньо = закріплений пост з каталогом)', required: false),
            new Argument('tone', 'Тон: ділово (за замовчуванням), тепло, коротко', required: false),
        ];
    }

    public function handle(Request $request): Response
    {
        $product = trim((string) $request->get('product'));
        $tone = trim((string) $request->get('tone'));

        return Response::text(strtr(self::TEXT, [
            '{product_line}' => $product !== '' ? " Товар: {$product}." : ' Це закріплений пост з каталогом.',
            '{tone_line}' => $tone !== '' ? " Тон: {$tone}." : '',
            '{product_arg}' => $product !== '' ? ", product=\"{$product}\"" : '',
        ]));
    }
}
