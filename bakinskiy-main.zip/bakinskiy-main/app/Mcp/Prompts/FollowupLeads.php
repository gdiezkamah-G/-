<?php

namespace App\Mcp\Prompts;

use App\Enums\Ability;
use App\Mcp\Support\McpAccess;
use Laravel\Mcp\Request;
use Laravel\Mcp\Response;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Prompt;
use Laravel\Mcp\Server\Prompts\Argument;

#[Name('followup_leads')]
#[Description('Знайти «нові» заявки старше 24 годин і підготувати список для менеджера.')]
class FollowupLeads extends Prompt
{
    private const TEXT = <<<'TEXT'
Знайди заявки, які чекають відповіді занадто довго.

1. Виклич leads_list(status="new", limit=50) (за потреби далі за cursor) і відбери ті, що створені понад 24 години тому (поле created_at, київський час).
2. Для кожної візьми leads_get, якщо потрібен коментар. Відсортуй від найстаріших.
3. Складіть список для менеджера: № заявки, заклад, імʼя, телефон, тип, що просив (товар, коментар), скільки годин чекає. Далі одна рекомендована дія (передзвонити, надіслати прайс, уточнити обсяг).
4. Запропонуй призначити відповідального (leads_assign) і перевести в роботу (leads_update_status), але виконуй це лише за згодою користувача.
5. Нічого не закривай і не видаляй.
TEXT;

    public function shouldRegister(): bool
    {
        return McpAccess::allows(McpAccess::user(), Ability::LeadsRead);
    }

    /** @return array<int, Argument> */
    public function arguments(): array
    {
        return [
        ];
    }

    public function handle(Request $request): Response
    {
        return Response::text(self::TEXT);
    }
}
