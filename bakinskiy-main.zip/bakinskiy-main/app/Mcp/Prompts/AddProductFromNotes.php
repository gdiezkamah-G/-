<?php

namespace App\Mcp\Prompts;

use App\Enums\Ability;
use App\Mcp\Support\McpAccess;
use Laravel\Mcp\Request;
use Laravel\Mcp\Response;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Prompt;
use Laravel\Mcp\Server\Prompts\Argument;

#[Name('add_product_from_notes')]
#[Description('Додати товар із нотаток: розбирає ваш текст, питає про прогалини, створює чернетку й показує перегляд.')]
class AddProductFromNotes extends Prompt
{
    private const TEXT = <<<'TEXT'
Ти допомагаєш додати новий товар у каталог «Бакинський Бульвар». Ось нотатки користувача:

{notes}

Дій так, крок за кроком:
1. Спочатку прочитай ресурси bakinskyi://brand-guide та bakinskyi://catalog-schema, а також виклич catalog_list_categories і catalog_list_products(search=<назва>), щоб не створити дублікат і обрати категорію.
2. Розбери нотатки на поля картки: назва, підзаголовок, категорія, склад, зберігання, термін, фасування (size_label, pack_note). НІЧОГО не вигадуй: чого в нотатках немає, те залиш порожнім.
3. Перелічи користувачу прогалини (немає складу? фасування? категорії?) і постав короткі запитання. Не створюй товар, доки не зрозуміла категорія і назва.
4. Виклич catalog_create_product (воно створює ЧЕРНЕТКУ), потім catalog_set_variants для фасувань. Те, що лишилось невідомим, внеси в needs_confirmation.
5. Покажи користувачу готову картку (catalog_get_product) стисло: що збережено, чого бракує.
6. НЕ публікуй. Публікація лише за окремою явною згодою користувача через catalog_publish: спочатку без confirm (перегляд), потім з confirm=true.
TEXT;

    public function shouldRegister(): bool
    {
        return McpAccess::allows(McpAccess::user(), Ability::CatalogRead);
    }

    /** @return array<int, Argument> */
    public function arguments(): array
    {
        return [
            new Argument('notes', 'Нотатки про товар: назва, склад, фасування, зберігання, термін (як є, у вільній формі)', required: true),
        ];
    }

    public function handle(Request $request): Response
    {
        return Response::text(strtr(self::TEXT, [
            '{notes}' => trim((string) $request->get('notes')),
        ]));
    }
}
