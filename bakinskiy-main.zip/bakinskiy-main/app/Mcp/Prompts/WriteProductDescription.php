<?php

namespace App\Mcp\Prompts;

use App\Enums\Ability;
use App\Mcp\Support\McpAccess;
use Laravel\Mcp\Request;
use Laravel\Mcp\Response;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Prompt;
use Laravel\Mcp\Server\Prompts\Argument;

#[Name('write_product_description')]
#[Description('Написати опис товару у тоні бренду, лише з даних картки.')]
class WriteProductDescription extends Prompt
{
    private const TEXT = <<<'TEXT'
Напиши короткий опис для товару «{product}».

1. Виклич catalog_get_product(product="{product}") і прочитай bakinskyi://brand-guide.
2. Використовуй ЛИШЕ факти з картки (склад, зберігання, термін, фасування) і те, що сказав користувач. Не вигадуй відсотків, термінів, алергенів, походження, цін.
3. Напиши 1–3 речення у тоні бренду (спокійно, діловито, українською), для шеф-кухаря закладу. Запропонуй також одне речення для short_tagline.
4. Якщо даних замало, скажи, чого бракує, і не заповнюй прогалини вигадками.
5. Покажи текст користувачу. Збережи через catalog_update_product (description, short_tagline) лише після його згоди. Статус товару не змінюй.
TEXT;

    public function shouldRegister(): bool
    {
        return McpAccess::allows(McpAccess::user(), Ability::CatalogRead);
    }

    /** @return array<int, Argument> */
    public function arguments(): array
    {
        return [
            new Argument('product', 'id або slug товару', required: true),
        ];
    }

    public function handle(Request $request): Response
    {
        return Response::text(strtr(self::TEXT, [
            '{product}' => trim((string) $request->get('product')),
        ]));
    }
}
