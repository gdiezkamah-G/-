<?php

namespace App\Enums;

use Filament\Support\Contracts\HasLabel;

enum UserRole: string implements HasLabel
{
    case Admin = 'admin';
    case Editor = 'editor';
    case Manager = 'manager';

    public function getLabel(): string
    {
        return match ($this) {
            self::Admin => 'Адміністратор',
            self::Editor => 'Редактор',
            self::Manager => 'Менеджер',
        };
    }

    /**
     * What the role may do through the admin and MCP. admin = everything; editor = catalog + leads; manager = leads only.
     *
     * @return list<string>
     */
    public function abilities(): array
    {
        return match ($this) {
            self::Admin => Ability::all(),
            self::Editor => [Ability::CatalogRead, Ability::CatalogWrite, Ability::LeadsRead, Ability::LeadsWrite],
            self::Manager => [Ability::LeadsRead, Ability::LeadsWrite],
        };
    }

    public function can(string $ability): bool
    {
        return in_array($ability, $this->abilities(), true);
    }
}
