<?php

namespace App\Enums;

use Filament\Support\Contracts\HasLabel;

/** Where the lead came from. */
enum LeadSource: string implements HasLabel
{
    case Site = 'site';
    case MiniApp = 'miniapp';
    case Bot = 'bot';

    public function getLabel(): string
    {
        return match ($this) {
            self::Site => 'Сайт',
            self::MiniApp => 'Mini app',
            self::Bot => 'Бот',
        };
    }
}
