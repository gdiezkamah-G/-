<?php

namespace App\Enums;

use Filament\Support\Contracts\HasLabel;

/** What the client asked for. */
enum LeadType: string implements HasLabel
{
    case Order = 'order';
    case Price = 'price';
    case Sample = 'sample';
    case Manager = 'manager';
    case Request = 'request';

    public function getLabel(): string
    {
        return match ($this) {
            self::Order => 'Заявка',
            self::Price => 'Запит прайсу',
            self::Sample => 'Запит зразків',
            self::Request => 'Запит про товар',
            self::Manager => 'Зв’язок з менеджером',
        };
    }
}
