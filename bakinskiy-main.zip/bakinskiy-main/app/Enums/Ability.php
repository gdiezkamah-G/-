<?php

namespace App\Enums;

/** Abilities of MCP tools. A role grants a set of them; a personal access token may narrow that set further. */
final class Ability
{
    public const CatalogRead = 'catalog:read';

    public const CatalogWrite = 'catalog:write';

    public const LeadsRead = 'leads:read';

    public const LeadsWrite = 'leads:write';

    public const TelegramRead = 'telegram:read';

    public const TelegramWrite = 'telegram:write';

    public const SiteRead = 'site:read';

    public const SiteWrite = 'site:write';

    public const SystemRead = 'system:read';

    /** @return list<string> */
    public static function all(): array
    {
        return [
            self::CatalogRead, self::CatalogWrite, self::LeadsRead, self::LeadsWrite,
            self::TelegramRead, self::TelegramWrite, self::SiteRead, self::SiteWrite, self::SystemRead,
        ];
    }

    /** @return array<string, string> */
    public static function labels(): array
    {
        return [
            self::CatalogRead => 'Каталог: перегляд',
            self::CatalogWrite => 'Каталог: зміни (чернетки, публікація)',
            self::LeadsRead => 'Заявки: перегляд',
            self::LeadsWrite => 'Заявки: статуси, нотатки, призначення',
            self::TelegramRead => 'Telegram: перегляд налаштувань і постів',
            self::TelegramWrite => 'Telegram: тексти, пости в каналі, прайс',
            self::SiteRead => 'Сайт: перегляд контактів',
            self::SiteWrite => 'Сайт: зміна контактів',
            self::SystemRead => 'Стан системи',
        ];
    }
}
