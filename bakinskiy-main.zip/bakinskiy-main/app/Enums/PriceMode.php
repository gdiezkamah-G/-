<?php

namespace App\Enums;

use Filament\Support\Contracts\HasLabel;

enum PriceMode: string implements HasLabel
{
    case Ask = 'ask';
    case From = 'from';
    case Login = 'login';

    public function getLabel(): string
    {
        return match ($this) {
            self::Ask => 'За запитом',
            self::From => 'Від…',
            self::Login => 'Після входу',
        };
    }
}
