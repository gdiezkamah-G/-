<?php

namespace App\Services\Deploy;

use App\Enums\ProductStatus;
use App\Enums\UserRole;
use App\Models\Product;
use App\Models\Setting;
use App\Models\TelegramAdmin;
use App\Models\TelegramRecipient;
use App\Models\User;
use App\Services\Telegram\BotMenu;
use App\Services\Telegram\PriceList;
use App\Services\Telegram\TelegramSettings;
use App\Services\Telegram\WebhookInstaller;
use Illuminate\Database\Migrations\Migrator;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use SergiX44\Nutgram\Nutgram;
use Throwable;

/** Everything an operator wants to know after a deploy or a move, as OK / WARN / FAIL lines. */
class Doctor
{
    /** A heartbeat older than this means the process is gone. */
    public const STALE_AFTER = 300;

    /** @return list<Check> */
    public function run(): array
    {
        $checks = [$this->env(), $this->database()];

        // everything below needs the database
        if (! $checks[1]->failed()) {
            array_push($checks,
                $this->migrations(), $this->storage(), $this->cache(), $this->queue(), $this->scheduler(), $this->failedJobs(),
                $this->admin(), $this->catalog(), $this->telegram(), $this->recipients(), $this->priceList(), $this->mcp(), $this->backups(),
            );
        }

        return $checks;
    }

    private function env(): Check
    {
        $items = (new EnvCheck)->run();
        $fails = array_filter($items, fn (Check $c) => $c->failed());
        $warns = array_filter($items, fn (Check $c) => $c->status === Check::WARN);

        return match (true) {
            $fails !== [] => Check::fail('Змінні оточення', implode('; ', array_map(fn ($c) => "{$c->name}: {$c->detail}", $fails))),
            $warns !== [] => Check::warn('Змінні оточення', implode('; ', array_map(fn ($c) => "{$c->name}: {$c->detail}", $warns))),
            default => Check::ok('Змінні оточення', 'усі обов’язкові задано'),
        };
    }

    private function database(): Check
    {
        try {
            $pdo = DB::connection()->getPdo();

            return Check::ok('База даних', DB::connection()->getDriverName().' '.$pdo->getAttribute(\PDO::ATTR_SERVER_VERSION));
        } catch (Throwable $e) {
            return Check::fail('База даних', 'недоступна: '.$e->getMessage());
        }
    }

    private function migrations(): Check
    {
        if (! Schema::hasTable('migrations')) {
            return Check::fail('Міграції', 'таблиці міграцій немає: web-контейнер ще не запускав migrate');
        }
        $migrator = app(Migrator::class);
        $files = $migrator->getMigrationFiles($migrator->paths() + [database_path('migrations')]);
        $pending = count(array_diff(array_keys($files), $migrator->getRepository()->getRan()));

        return $pending ? Check::fail('Міграції', "очікують {$pending}: php artisan migrate --force") : Check::ok('Міграції', count($files).' застосовано');
    }

    private function storage(): Check
    {
        $link = public_path('storage');
        $problems = [];

        if (! is_link($link) && ! is_dir($link)) {
            $problems[] = 'немає public/storage (php artisan storage:link)';
        }
        foreach (['app', 'framework/cache', 'logs'] as $dir) {
            if (! is_writable(storage_path($dir))) {
                $problems[] = "storage/{$dir} не доступний для запису";
            }
        }
        if (! is_writable(base_path('bootstrap/cache'))) {
            $problems[] = 'bootstrap/cache не доступний для запису';
        }

        return $problems ? Check::fail('Storage', implode('; ', $problems)) : Check::ok('Storage', 'public/storage, права на запис');
    }

    private function cache(): Check
    {
        try {
            Cache::put('doctor.ping', 'pong', 30);
            $store = config('cache.default');

            return Cache::get('doctor.ping') === 'pong' ? Check::ok('Кеш / Redis', $store) : Check::fail('Кеш / Redis', "{$store}: запис не читається");
        } catch (Throwable $e) {
            return Check::fail('Кеш / Redis', 'недоступний: '.$e->getMessage());
        }
    }

    private function heartbeat(string $key, string $name, string $hint): Check
    {
        $at = Cache::get($key);
        $booted = (int) Setting::get('bootstrap_at');
        $young = $booted && time() - $booted < self::STALE_AFTER;

        return match (true) {
            $at && time() - (int) $at <= self::STALE_AFTER => Check::ok($name, 'живий, останній сигнал '.(time() - (int) $at).' с тому'),
            $at => Check::fail($name, 'мовчить уже '.round((time() - (int) $at) / 60).' хв. '.$hint),
            $young => Check::warn($name, 'ще не подавав сигналу (старт був щойно)'),
            default => Check::fail($name, 'жодного сигналу. '.$hint),
        };
    }

    private function queue(): Check
    {
        $check = $this->heartbeat('heartbeat.queue', 'Черга (воркер)', 'Сервіс queue не запущено або він не бачить Redis.');

        if ($check->status !== Check::FAIL) {
            try {
                $size = Queue::size();
                $size > 50 && $check = Check::warn('Черга (воркер)', "живий, але в черзі {$size} завдань");
            } catch (Throwable) {
            }
        }

        return $check;
    }

    private function scheduler(): Check
    {
        return $this->heartbeat('heartbeat.scheduler', 'Планувальник', 'Сервіс scheduler не запущено.');
    }

    private function failedJobs(): Check
    {
        $n = Schema::hasTable('failed_jobs') ? DB::table('failed_jobs')->count() : 0;

        return $n ? Check::warn('Невдалі завдання', "{$n} у failed_jobs (php artisan queue:retry all або queue:flush)") : Check::ok('Невдалі завдання', 'немає');
    }

    private function admin(): Check
    {
        $n = User::where('role', UserRole::Admin)->count();

        return $n ? Check::ok('Адмін сайту', "{$n}") : Check::fail('Адмін сайту', 'немає жодного: задайте ADMIN_EMAIL і ADMIN_PASSWORD (від 12 символів) і перезапустіть web');
    }

    private function catalog(): Check
    {
        $published = Product::where('status', ProductStatus::Published)->count();
        $drafts = Product::where('status', ProductStatus::Draft)->count();

        return match (true) {
            $published > 0 => Check::ok('Каталог', "опубліковано {$published}".($drafts ? ", чернеток {$drafts}" : '')),
            $drafts > 0 => Check::warn('Каталог', "{$drafts} товарів у чернетках, на сайті порожньо: опублікуйте їх в адмінці (масова дія «Опублікувати»)"),
            default => Check::warn('Каталог', 'порожній: додайте товари в адмінці або CATALOG_IMPORT=draft|publish'),
        };
    }

    private function telegram(): Check
    {
        if (! filled(config('bakinsky.telegram.token'))) {
            return Check::warn('Telegram', 'вимкнено: TELEGRAM_BOT_TOKEN не задано');
        }

        $installer = app(WebhookInstaller::class);
        $status = app(BotMenu::class)->webhookStatus(app(Nutgram::class));

        if (! ($status['url'] ?? null)) {
            return Check::fail('Telegram', 'webhook не встановлено'.($status['error'] ? ': '.$status['error'] : '').'. Кнопка «Перевстановити webhook».');
        }
        if (! $status['ok']) {
            return Check::fail('Telegram', 'webhook '.$status['url'].' з помилкою: '.($status['error'] ?: 'адреса не збігається з APP_URL'));
        }
        if (Setting::get('tg_webhook_signature') !== $installer->signature()) {
            return Check::warn('Telegram', 'webhook працює, але налаштування змінилися після встановлення: «Перевстановити webhook»');
        }

        return Check::ok('Telegram', 'webhook працює, у черзі '.$status['pending'].' оновлень');
    }

    private function recipients(): Check
    {
        if (! filled(config('bakinsky.telegram.token'))) {
            return Check::ok('Отримувачі заявок', 'Telegram вимкнено');
        }
        $active = TelegramRecipient::active()->count();
        $admins = TelegramAdmin::count();

        return match (true) {
            $active > 0 => Check::ok('Отримувачі заявок', "активних: {$active}, адмінів бота: {$admins}"),
            $admins === 0 => Check::warn('Отримувачі заявок', 'немає ні адмінів бота, ні груп: задайте TELEGRAM_ADMIN_IDS, напишіть боту /start, у групі /connect'),
            default => Check::warn('Отримувачі заявок', 'немає активних: адмін має написати боту /start або в групі /connect'),
        };
    }

    /** MCP for Claude / ChatGPT: the route, the OAuth keys, the tables and how many clients are connected. */
    private function mcp(): Check
    {
        $routed = collect(Route::getRoutes()->getRoutes())->contains(fn ($r) => $r->uri() === 'mcp' && in_array('POST', $r->methods(), true));
        $keys = (filled(config('passport.private_key')) && filled(config('passport.public_key')))
            || (is_file(storage_path('app/oauth/oauth-private.key')) && is_file(storage_path('app/oauth/oauth-public.key')));

        if (! $routed) {
            return Check::fail('MCP (підключення ШІ)', 'маршрут /mcp не зареєстровано (routes/ai.php)');
        }
        if (! Schema::hasTable('oauth_access_tokens') || ! Schema::hasTable('mcp_audit_log')) {
            return Check::fail('MCP (підключення ШІ)', 'немає таблиць Passport або журналу: виконайте міграції');
        }
        if (! $keys) {
            return Check::warn('MCP (підключення ШІ)', 'немає ключів OAuth (storage/app/oauth): вони створюються при старті, перезапустіть web');
        }

        $connections = DB::table('oauth_access_tokens')->where('revoked', false)->where(fn ($q) => $q->whereNull('expires_at')->orWhere('expires_at', '>', now()))->distinct()->count('client_id');
        $tokens = DB::table('personal_access_tokens')->where('tokenable_type', User::class)->count();

        return Check::ok('MCP (підключення ШІ)', url('/mcp').": OAuth-ключі є, активних підключень: {$connections}, персональних токенів: {$tokens}");
    }

    private function priceList(): Check
    {
        $price = app(TelegramSettings::class)->group('price');

        if ($price['mode'] === 'upload') {
            return $price['file'] && is_file(storage_path('app/private/'.$price['file']))
                ? Check::ok('PDF-прайс', 'завантажений вручну')
                : Check::warn('PDF-прайс', 'режим «свій PDF», але файлу немає: завантажте його на сторінці Telegram → Прайс');
        }

        if (is_file(storage_path('app/private/'.PriceList::AUTO_PATH))) {
            return Check::ok('PDF-прайс', 'створений '.($price['generated_at'] ? now()->parse($price['generated_at'])->timezone('Europe/Kyiv')->format('d.m.Y H:i') : ''));
        }

        $chrome = (string) env('LARAVEL_PDF_CHROME_PATH');

        return $chrome && ! is_file($chrome)
            ? Check::warn('PDF-прайс', "Chromium не знайдено ({$chrome}): автопрайс не створиться, завантажте PDF вручну")
            : Check::warn('PDF-прайс', 'ще не створений (створиться при першому запиті або кнопкою «Оновити прайс»)');
    }

    private function backups(): Check
    {
        if (! config('bakinsky.backup.enabled')) {
            return Check::warn('Бекапи', 'вимкнені (BACKUP_ENABLED=false)');
        }

        $age = app(BackupManager::class)->latestAge();
        $offsite = app(BackupManager::class)->s3() ? ', копія в S3' : ', лише на томі (без S3)';

        return match (true) {
            $age === null => Check::warn('Бекапи', 'ще не створювались (перший о '.config('bakinsky.backup.at').' за Києвом)'.$offsite),
            $age > 36 * 3600 => Check::warn('Бекапи', 'останній був '.round($age / 3600).' год тому, перевірте планувальник'),
            default => Check::ok('Бекапи', 'останній '.round($age / 3600, 1).' год тому'.$offsite),
        };
    }
}
