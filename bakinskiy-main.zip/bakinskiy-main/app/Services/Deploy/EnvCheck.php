<?php

namespace App\Services\Deploy;

/**
 * Reads the process environment (not cached config) and says in plain words what is missing, so a bad
 * deploy fails at the first second with a clear list instead of somewhere deep in the code.
 */
class EnvCheck
{
    /** @param  array<string, string|null>|null  $env  defaults to the real environment */
    public function __construct(private ?array $env = null) {}

    private function get(string $key): ?string
    {
        $value = $this->env !== null ? ($this->env[$key] ?? null) : (getenv($key) !== false ? getenv($key) : ($_ENV[$key] ?? null));

        return $value === null || trim((string) $value) === '' ? null : trim((string) $value);
    }

    /** @return list<Check> */
    public function run(): array
    {
        $checks = [];
        $production = ($this->get('APP_ENV') ?? 'production') === 'production';

        // ---- required ----
        $key = $this->get('APP_KEY');
        $keyOk = $key && str_starts_with($key, 'base64:') && strlen((string) base64_decode(substr($key, 7), true)) === 32;
        $checks[] = $keyOk
            ? Check::ok('APP_KEY')
            : Check::fail('APP_KEY', $key ? 'не схоже на ключ Laravel (base64:… 32 байти)' : 'не задано. Згенеруйте: echo "base64:$(openssl rand -base64 32)"');

        $url = $this->get('APP_URL');
        if (! $url || ! filter_var($url, FILTER_VALIDATE_URL)) {
            $checks[] = Check::fail('APP_URL', $url ? "«{$url}» не є коректною адресою" : 'не задано, напр. https://bakinskybulvar.com');
        } elseif ($production && ! str_starts_with($url, 'https://')) {
            $checks[] = Check::warn('APP_URL', "{$url}: без https не працюватимуть Telegram webhook і PWA");
        } elseif (str_ends_with($url, '/')) {
            $checks[] = Check::warn('APP_URL', 'прибрати / в кінці');
        } else {
            $checks[] = Check::ok('APP_URL', $url);
        }

        foreach (['DB_HOST', 'DB_DATABASE', 'DB_USERNAME', 'DB_PASSWORD'] as $var) {
            $checks[] = $this->get($var) ? Check::ok($var) : Check::fail($var, 'не задано (потрібне підключення до MySQL)');
        }

        $usesRedis = collect(['QUEUE_CONNECTION', 'CACHE_STORE', 'SESSION_DRIVER'])->contains(fn ($v) => $this->get($v) === 'redis');
        if ($usesRedis) {
            $checks[] = $this->get('REDIS_HOST') ? Check::ok('REDIS_HOST') : Check::fail('REDIS_HOST', 'черга/кеш/сесії налаштовані на Redis, а REDIS_HOST не задано');
        }

        // ---- consistent pairs ----
        $email = $this->get('ADMIN_EMAIL');
        $pass = $this->get('ADMIN_PASSWORD');
        if ($email || $pass) {
            if (! $email || ! $pass) {
                $checks[] = Check::warn('ADMIN_*', 'потрібні обидва: ADMIN_EMAIL і ADMIN_PASSWORD, адміна не буде створено');
            } elseif (strlen($pass) < 12) {
                $checks[] = Check::warn('ADMIN_PASSWORD', 'коротший за 12 символів: адміна не буде створено');
            } else {
                $checks[] = Check::ok('ADMIN_*', $email);
            }
        } else {
            $checks[] = Check::warn('ADMIN_*', 'не задано: адміна буде створено лише вручну (app:create-admin)');
        }

        $token = $this->get('TELEGRAM_BOT_TOKEN');
        if ($token) {
            $checks[] = $this->get('TELEGRAM_WEBHOOK_SECRET')
                ? Check::ok('TELEGRAM_*')
                : Check::warn('TELEGRAM_WEBHOOK_SECRET', 'токен є, а секрету немає: webhook не буде встановлено');
        } else {
            $checks[] = Check::warn('TELEGRAM_BOT_TOKEN', 'не задано: бот і mini app вимкнені (решта сайту працює)');
        }

        if (($this->get('MAIL_MAILER') ?? 'log') === 'smtp') {
            $checks[] = $this->get('MAIL_HOST') && ! preg_match('/[^\x20-\x7e]|ВАШ|your/i', (string) $this->get('MAIL_HOST'))
                ? Check::ok('MAIL_*', $this->get('MAIL_HOST'))
                : Check::warn('MAIL_HOST', 'MAIL_MAILER=smtp, а хост не задано або це шаблон: листи не підуть');
        } elseif ($production) {
            $checks[] = Check::warn('MAIL_MAILER', 'не smtp: листи про заявки лише пишуться в лог');
        }

        if ($this->get('BACKUP_S3_BUCKET') && ! ($this->get('BACKUP_S3_KEY') && $this->get('BACKUP_S3_SECRET'))) {
            $checks[] = Check::warn('BACKUP_S3_*', 'задано бакет, але немає BACKUP_S3_KEY / BACKUP_S3_SECRET');
        }

        return $checks;
    }
}
