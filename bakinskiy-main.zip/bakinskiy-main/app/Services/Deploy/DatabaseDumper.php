<?php

namespace App\Services\Deploy;

use Illuminate\Support\Facades\DB;
use PDO;
use RuntimeException;

/**
 * A plain-PHP SQL dump and restore (no mysqldump binary, no client/auth-plugin surprises). The data of this site is
 * small, so one gzip file holds everything. MySQL dumps are taken inside a consistent snapshot, without locking.
 * Statements are separated by a marker line so values containing newlines or semicolons restore safely.
 */
class DatabaseDumper
{
    public const MARK = "\n/*#*/\n";

    /** Tables whose rows are throw-away (cache, sessions, queue); the structure is still dumped. */
    private const SKIP_DATA = ['cache', 'cache_locks', 'sessions', 'jobs', 'job_batches'];

    /** Write a gzip dump to $path and return the number of rows dumped. */
    public function dump(string $path): int
    {
        $pdo = DB::connection()->getPdo();
        $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
        $gz = gzopen($path, 'wb9') ?: throw new RuntimeException("Cannot write {$path}");
        $rows = 0;

        if ($driver === 'mysql') {
            $pdo->exec('SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ');
            $pdo->exec('START TRANSACTION WITH CONSISTENT SNAPSHOT');
        }

        $write = fn (string $sql) => gzwrite($gz, $sql.self::MARK);
        $write('-- bakinsky dump '.now()->toIso8601String().' driver='.$driver);
        // SQLite ignores PRAGMA foreign_keys inside a transaction; deferring the checks works there
        $write($driver === 'mysql' ? 'SET FOREIGN_KEY_CHECKS=0' : 'PRAGMA defer_foreign_keys=ON');

        foreach ($this->tables($pdo, $driver) as $table => $create) {
            $q = $this->quoteIdent($table, $driver);
            $write("DROP TABLE IF EXISTS {$q}");
            $write($create);

            if (in_array($table, self::SKIP_DATA, true)) {
                continue;
            }

            $batch = [];
            foreach ($pdo->query("SELECT * FROM {$q}", PDO::FETCH_ASSOC) as $row) {
                $batch[] = '('.implode(',', array_map(fn ($v) => $this->literal($pdo, $v), $row)).')';
                $rows++;
                if (count($batch) >= 200) {
                    $write($this->insert($q, array_keys($row), $batch, $driver));
                    $batch = [];
                }
            }
            if ($batch) {
                $cols = array_keys($pdo->query("SELECT * FROM {$q} LIMIT 1", PDO::FETCH_ASSOC)->fetch(PDO::FETCH_ASSOC) ?: []);
                $write($this->insert($q, $cols, $batch, $driver));
            }
        }

        $driver === 'mysql' && $write('SET FOREIGN_KEY_CHECKS=1');
        $driver === 'mysql' && $pdo->exec('COMMIT');
        gzclose($gz);

        return $rows;
    }

    /** Replace the tables in the database with the ones from a dump made by dump(). */
    public function restore(string $path): int
    {
        $pdo = DB::connection()->getPdo();
        $gz = gzopen($path, 'rb') ?: throw new RuntimeException("Cannot read {$path}");
        $sql = '';
        while (! gzeof($gz)) {
            $sql .= gzread($gz, 1 << 20);
        }
        gzclose($gz);

        if (! str_starts_with($sql, '-- bakinsky dump')) {
            throw new RuntimeException('Це не дамп, створений app:db-backup.');
        }

        $count = 0;
        foreach (explode(self::MARK, $sql) as $statement) {
            $statement = trim($statement);
            if ($statement === '' || str_starts_with($statement, '--')) {
                continue;
            }
            try {
                $pdo->exec($statement);
            } catch (\Throwable $e) {
                throw new RuntimeException('Помилка в операції №'.($count + 1).' ('.mb_substr($statement, 0, 100).'…): '.$e->getMessage(), 0, $e);
            }
            $count++;
        }

        return $count;
    }

    /** @return array<string, string> table => CREATE statement */
    private function tables(PDO $pdo, string $driver): array
    {
        $out = [];

        if ($driver === 'mysql') {
            foreach ($pdo->query("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'")->fetchAll(PDO::FETCH_NUM) as [$name]) {
                $out[$name] = $pdo->query('SHOW CREATE TABLE `'.str_replace('`', '``', $name).'`')->fetch(PDO::FETCH_NUM)[1];
            }
        } else {
            foreach ($pdo->query("SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")->fetchAll(PDO::FETCH_NUM) as [$name, $sql]) {
                $out[$name] = $sql;
            }
        }

        return $out;
    }

    private function quoteIdent(string $name, string $driver): string
    {
        return $driver === 'mysql' ? '`'.str_replace('`', '``', $name).'`' : '"'.str_replace('"', '""', $name).'"';
    }

    private function insert(string $table, array $columns, array $rows, string $driver): string
    {
        $cols = implode(',', array_map(fn ($c) => $this->quoteIdent($c, $driver), $columns));

        return "INSERT INTO {$table} ({$cols}) VALUES ".implode(',', $rows);
    }

    private function literal(PDO $pdo, mixed $v): string
    {
        return match (true) {
            $v === null => 'NULL',
            is_int($v), is_float($v) => (string) $v,
            default => $pdo->quote((string) $v),
        };
    }
}
