<?php

namespace App\Services\Deploy;

/** One line of a health/config report: OK, WARN or FAIL with a human message. */
final class Check
{
    public const OK = 'OK';

    public const WARN = 'WARN';

    public const FAIL = 'FAIL';

    public function __construct(public string $status, public string $name, public string $detail = '') {}

    public static function ok(string $name, string $detail = ''): self
    {
        return new self(self::OK, $name, $detail);
    }

    public static function warn(string $name, string $detail): self
    {
        return new self(self::WARN, $name, $detail);
    }

    public static function fail(string $name, string $detail): self
    {
        return new self(self::FAIL, $name, $detail);
    }

    public function failed(): bool
    {
        return $this->status === self::FAIL;
    }

    public function toArray(): array
    {
        return ['status' => $this->status, 'name' => $this->name, 'detail' => $this->detail];
    }
}
