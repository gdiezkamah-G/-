<?php

namespace App\Services\Deploy;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Storage;
use RuntimeException;

/** Creates, rotates, lists and restores database backups on the storage volume and (optionally) in S3. */
class BackupManager
{
    public const PREFIX = 'db-';

    public function __construct(private DatabaseDumper $dumper) {}

    public function local(): Filesystem
    {
        return Storage::build(['driver' => 'local', 'root' => storage_path('app/backups')]);
    }

    public function s3(): ?Filesystem
    {
        $c = config('bakinsky.backup.s3');

        if (! filled($c['bucket']) || ! filled($c['key']) || ! filled($c['secret'])) {
            return null;
        }

        return Storage::build(array_filter([
            'driver' => 's3', 'bucket' => $c['bucket'], 'key' => $c['key'], 'secret' => $c['secret'], 'region' => $c['region'],
            'endpoint' => $c['endpoint'], 'use_path_style_endpoint' => $c['path_style'], 'throw' => true,
        ], fn ($v) => $v !== null));
    }

    /** @return array{file: string, size: int, rows: int, s3: bool, s3_error: ?string, removed: int} */
    public function run(int $keepDays): array
    {
        $name = self::PREFIX.now()->format('Ymd-His').'.sql.gz';
        $disk = $this->local();
        @mkdir(storage_path('app/backups'), 0775, true);
        $path = storage_path("app/backups/{$name}");

        $rows = $this->dumper->dump($path);

        $s3 = false;
        $s3Error = null;
        if ($remote = $this->s3()) {
            try {
                $remote->put($this->key($name), fopen($path, 'r'));
                $s3 = true;
            } catch (\Throwable $e) {
                $s3Error = $e->getMessage();
            }
        }

        return [
            'file' => $name, 'size' => filesize($path), 'rows' => $rows, 's3' => $s3, 's3_error' => $s3Error,
            'removed' => $this->rotate($keepDays),
        ];
    }

    /** Delete backups older than $keepDays, locally and in S3. The newest backup is never deleted. */
    public function rotate(int $keepDays): int
    {
        $removed = 0;
        $limit = now()->subDays(max(1, $keepDays))->timestamp;

        $targets = [[$this->local(), ''], [$this->s3(), (string) config('bakinsky.backup.s3.prefix')]];

        foreach ($targets as [$disk, $prefix]) {
            if (! $disk) {
                continue;
            }
            $files = collect($disk->files($prefix))
                ->filter(fn ($f) => str_contains(basename($f), self::PREFIX) && str_ends_with($f, '.sql.gz'))
                ->sortByDesc(fn ($f) => basename($f))->values();

            foreach ($files->skip(1) as $file) {
                try {
                    if ($disk->lastModified($file) < $limit) {
                        $disk->delete($file);
                        $removed++;
                    }
                } catch (\Throwable) {
                    // a file that cannot be rotated must not fail the backup
                }
            }
        }

        return $removed;
    }

    /** @return list<array{file: string, size: int, at: int}> newest first (local volume) */
    public function list(): array
    {
        return collect($this->local()->files())
            ->filter(fn ($f) => str_ends_with($f, '.sql.gz'))
            ->map(fn ($f) => ['file' => $f, 'size' => $this->local()->size($f), 'at' => $this->local()->lastModified($f)])
            ->sortByDesc('file')->values()->all();
    }

    public function latestAge(): ?int
    {
        $latest = $this->list()[0] ?? null;

        return $latest ? time() - $latest['at'] : null;
    }

    /** Download the newest dump from S3 onto the volume and return its path (for a move to a new server). */
    public function fetchLatestFromS3(): string
    {
        $remote = $this->s3() ?? throw new RuntimeException('S3 не налаштовано (BACKUP_S3_BUCKET, BACKUP_S3_KEY, BACKUP_S3_SECRET).');
        $latest = collect($remote->files(config('bakinsky.backup.s3.prefix')))
            ->filter(fn ($f) => str_contains(basename($f), self::PREFIX) && str_ends_with($f, '.sql.gz'))
            ->sort()->last() ?? throw new RuntimeException('У бакеті немає жодного бекапа.');

        @mkdir(storage_path('app/backups'), 0775, true);
        $path = storage_path('app/backups/'.basename($latest));
        file_put_contents($path, $remote->readStream($latest));

        return $path;
    }

    /** Resolve "latest", "s3" (newest in the bucket), a file name on the volume, or an absolute path. */
    public function resolve(string $ref): string
    {
        if ($ref === 's3') {
            return $this->fetchLatestFromS3();
        }

        if ($ref === 'latest') {
            $latest = $this->list()[0] ?? throw new RuntimeException('На томі немає жодного бекапу.');

            return storage_path('app/backups/'.$latest['file']);
        }
        foreach ([$ref, storage_path("app/backups/{$ref}")] as $candidate) {
            if (is_file($candidate)) {
                return $candidate;
            }
        }

        throw new RuntimeException("Файл не знайдено: {$ref}");
    }

    private function key(string $name): string
    {
        return config('bakinsky.backup.s3.prefix').'/'.$name;
    }
}
