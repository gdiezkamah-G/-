<?php

namespace App\Services\Telegram;

use App\Models\Setting;

/**
 * Everything about the bot except the three secrets in .env lives in the database and is edited
 * on the "Налаштування Telegram" admin page. Each group is a JSON blob merged over these defaults.
 */
class TelegramSettings
{
    public const DEFAULTS = [
        'texts' => [
            'welcome' => "Вітаємо в «Бакинський Бульвар · Мануфактура»!\nЗаморожені напівфабрикати за рецептами ресторану для кафе, готелів і кейтерингу.\n\nВідкрийте каталог або замовте прайс.",
            'ask_contact' => 'Поділіться контактом, і ми надішлемо відповідь. Натисніть кнопку нижче або напишіть номер вручну.',
            'ask_company' => 'Як називається ваш заклад? (необов’язково)',
            'thanks' => 'Дякуємо! Менеджер зв’яжеться з вами протягом робочого дня.',
            'price_caption' => 'Прайс-лист «Бакинський Бульвар · Мануфактура»',
        ],
        'notification' => [
            'type' => true, 'name' => true, 'phone' => true, 'company' => true,
            'comment' => true, 'product' => true, 'source' => true, 'status' => true,
            'write_button' => true,
        ],
        'menu' => [
            'button_text' => 'Каталог',
            'commands' => [
                'catalog' => ['enabled' => true, 'description' => 'Відкрити каталог'],
                'price' => ['enabled' => true, 'description' => 'Отримати прайс'],
                'samples' => ['enabled' => true, 'description' => 'Замовити зразки'],
                'manager' => ['enabled' => true, 'description' => 'Зв’язатися з менеджером'],
            ],
        ],
        // the channel the catalog / product posts go to; messages remembers what was posted where, so a post is edited, not duplicated
        'channel' => ['chat_id' => null, 'messages' => []],
        // mode: auto = generated from the catalog, upload = the PDF uploaded in the admin
        'price' => ['mode' => 'auto', 'file' => null, 'file_id' => null, 'file_hash' => null, 'hash' => null, 'generated_at' => null],
    ];

    /** Fixed phrases that are not worth an admin field. */
    public const SYSTEM_TEXTS = [
        'invalid_phone' => 'Схоже, це не номер телефону. Напишіть у форматі +380…',
        'manual_phone' => 'Напишіть номер телефону у форматі +380…',
        'disabled' => 'Ця функція тимчасово недоступна.',
        'private_only' => 'Напишіть мені в особисті повідомлення, щоб продовжити.',
        'price_unavailable' => 'Прайс тимчасово недоступний, але менеджер надішле його вам протягом робочого дня.',
        'not_admin' => 'Ця команда доступна лише адміністраторам бота.',
        'group_only' => 'Команда /connect працює лише в групі.',
        'connected' => 'Групу підключено: сюди надходитимуть нові заявки.',
        'skip' => 'Пропустити',
        'share_contact' => 'Поділитися контактом',
        'type_phone' => 'Написати номер вручну',
        'open_catalog' => 'Відкрити каталог',
        'open_app' => 'Відкрити застосунок',
    ];

    public function group(string $name): array
    {
        $stored = json_decode((string) Setting::get("tg_{$name}"), true);

        return array_replace_recursive(self::DEFAULTS[$name], is_array($stored) ? $stored : []);
    }

    public function save(string $name, array $values): void
    {
        Setting::put("tg_{$name}", json_encode(array_replace_recursive($this->group($name), $values), JSON_UNESCAPED_UNICODE));
    }

    /** Overwrite a group completely (used by the admin page so removed keys do not linger). */
    public function replace(string $name, array $values): void
    {
        Setting::put("tg_{$name}", json_encode($values, JSON_UNESCAPED_UNICODE));
    }

    public function text(string $key): string
    {
        return $this->group('texts')[$key] ?? self::SYSTEM_TEXTS[$key] ?? '';
    }

    public static function system(string $key): string
    {
        return self::SYSTEM_TEXTS[$key];
    }

    public function commandEnabled(string $command): bool
    {
        return (bool) ($this->group('menu')['commands'][$command]['enabled'] ?? true);
    }

    public function miniAppUrl(?string $param = null): string
    {
        $url = rtrim((string) config('app.url'), '/').'/tg';

        return $param ? $url.'?p='.rawurlencode($param) : $url;
    }
}
