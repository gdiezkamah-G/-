<?php

namespace App\Services\Telegram;

use App\Models\Setting;
use SergiX44\Nutgram\Nutgram;
use Throwable;

/**
 * Keeps Telegram's webhook, command list and menu button in line with the configuration, with no human step.
 * A signature of (APP_URL, secret, token, menu settings) is stored after a successful install; a start with a
 * different signature (moved to another domain, new token or secret, edited menu) installs again.
 */
class WebhookInstaller
{
    public function __construct(private BotMenu $menu, private TelegramSettings $settings) {}

    public function signature(): string
    {
        return md5(json_encode([
            rtrim((string) config('app.url'), '/'),
            (string) config('bakinsky.telegram.webhook_secret'),
            md5((string) config('bakinsky.telegram.token')),
            $this->settings->group('menu'),
        ]));
    }

    /** @return array{state: 'skipped'|'unchanged'|'installed'|'failed', message: string} */
    public function ensure(?Nutgram $bot = null, bool $force = false): array
    {
        if (! filled(config('bakinsky.telegram.token'))) {
            return ['state' => 'skipped', 'message' => 'TELEGRAM_BOT_TOKEN не задано: бот вимкнений, пропускаю.'];
        }
        if (! filled(config('bakinsky.telegram.webhook_secret'))) {
            return ['state' => 'skipped', 'message' => 'TELEGRAM_WEBHOOK_SECRET не задано: webhook без секрету не ставлю.'];
        }
        if (! str_starts_with((string) config('app.url'), 'https://')) {
            return ['state' => 'skipped', 'message' => 'APP_URL не https: Telegram приймає лише захищені webhook, пропускаю.'];
        }

        $signature = $this->signature();

        if (! $force && Setting::get('tg_webhook_signature') === $signature) {
            return ['state' => 'unchanged', 'message' => 'Webhook уже встановлено для '.$this->menu->webhookUrl().'.'];
        }

        try {
            $bot ??= app(Nutgram::class); // built only now: without a token it cannot exist
            $this->menu->installWebhook($bot);
            $this->menu->installMenu($bot);
        } catch (Throwable $e) {
            return ['state' => 'failed', 'message' => 'Telegram відхилив запит: '.$e->getMessage()];
        }

        Setting::put('tg_webhook_signature', $signature);
        Setting::put('tg_webhook_installed_at', now()->toIso8601String());

        return ['state' => 'installed', 'message' => 'Webhook, команди й кнопка меню встановлені: '.$this->menu->webhookUrl()];
    }
}
