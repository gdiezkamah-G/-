<?php

namespace App\Services\Telegram;

use App\Models\Category;
use App\Models\Product;
use App\Models\Setting;
use Illuminate\Support\Facades\Storage;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Exceptions\TelegramException;
use SergiX44\Nutgram\Telegram\Types\Internal\InputFile;
use Spatie\LaravelPdf\Enums\Format;
use Spatie\LaravelPdf\Facades\Pdf;

/**
 * The price list PDF: either the file uploaded in the admin or one generated from the catalog
 * (documents/price-list.html layout). The generated file is cached and rebuilt only when the catalog
 * changes; Telegram's file_id is cached too, so the file is uploaded to Telegram once.
 */
class PriceList
{
    public const AUTO_PATH = 'telegram/price-list.pdf';

    public const NAME = 'price-list.pdf';

    public function __construct(private TelegramSettings $settings) {}

    /** Absolute path of the PDF to send, regenerating it first when it is out of date. */
    public function path(): string
    {
        $price = $this->settings->group('price');

        if ($price['mode'] === 'upload' && $price['file'] && Storage::disk('local')->exists($price['file'])) {
            return Storage::disk('local')->path($price['file']);
        }

        $stale = ! Storage::disk('local')->exists(self::AUTO_PATH) || $price['hash'] !== $this->catalogHash();

        return $stale ? $this->regenerate() : Storage::disk('local')->path(self::AUTO_PATH);
    }

    /** Build the PDF from the catalog and forget the cached Telegram file_id. */
    public function regenerate(): string
    {
        $abs = Storage::disk('local')->path(self::AUTO_PATH);
        @mkdir(dirname($abs), 0775, true);

        Pdf::view('documents.price-list', $this->data())->format(Format::A4)->margins(0, 0, 0, 0)->save($abs);

        $this->settings->save('price', ['hash' => $this->catalogHash(), 'generated_at' => now()->toIso8601String(), 'file_id' => null, 'file_hash' => null]);

        return $abs;
    }

    /** Changes whenever a published product, its variants or the contacts change. */
    public function catalogHash(): string
    {
        $products = Product::published()->with('activeVariants')->get(['id', 'updated_at']);

        return md5(json_encode([
            $products->map(fn ($p) => [$p->id, (string) $p->updated_at, $p->activeVariants->pluck('updated_at')->map(fn ($d) => (string) $d)])->all(),
            Category::orderBy('id')->pluck('updated_at', 'id')->all(),
            Setting::get('contact_phone'), Setting::get('contact_email'),
        ]));
    }

    /** @return array{date: string, groups: array, contacts: string} */
    public function data(): array
    {
        $groups = Category::orderBy('sort')->get()->map(function (Category $c) {
            $rows = $c->products()->published()->with('activeVariants')->get()->map(fn (Product $p) => [
                'name' => trim($p->name.' '.$p->subtitle),
                'pack' => $p->activeVariants->map(fn ($v) => $v->size_label.($v->pack_note ? ' ('.$v->pack_note.')' : ''))->implode(' · ') ?: '—',
                'storage' => str_replace(' °C', '°C', collect([$p->storage_temp, $p->shelf_life])->filter()->implode(' · ')) ?: '—',
                'price' => '—',
            ])->all();

            return ['name' => $c->name, 'rows' => $rows];
        })->filter(fn ($g) => $g['rows'])->values()->all();

        return [
            'date' => now()->timezone('Europe/Kyiv')->format('d.m.Y'),
            'groups' => $groups,
            'contacts' => collect([Setting::get('contact_phone'), Setting::get('contact_email')])->filter()->implode(' · '),
        ];
    }

    /** Send the PDF to a chat, uploading it to Telegram only the first time. */
    public function sendTo(Nutgram $bot, int $chatId, ?string $caption = null): void
    {
        $path = $this->path();
        $hash = md5_file($path);
        $price = $this->settings->group('price');
        $caption ??= $this->settings->text('price_caption');

        if ($price['file_id'] && $price['file_hash'] === $hash) {
            try {
                $bot->sendDocument(document: $price['file_id'], chat_id: $chatId, caption: $caption);

                return;
            } catch (TelegramException) {
                // the cached id is no longer valid: fall through and upload again
            }
        }

        $message = $bot->sendDocument(
            document: InputFile::make(fopen($path, 'r'), self::NAME),
            chat_id: $chatId,
            caption: $caption,
        );

        if ($fileId = $message?->document?->file_id) {
            $this->settings->save('price', ['file_id' => $fileId, 'file_hash' => $hash]);
        }
    }
}
