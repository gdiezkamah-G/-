<?php

namespace App\Services\Telegram;

use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Types\Command\BotCommand;
use SergiX44\Nutgram\Telegram\Types\Command\BotCommandScopeAllChatAdministrators;
use SergiX44\Nutgram\Telegram\Types\Command\MenuButtonWebApp;
use SergiX44\Nutgram\Telegram\Types\WebApp\WebAppInfo;

/** Pushes the webhook, the command list and the "Каталог" menu button to Telegram (settings come from the admin). */
class BotMenu
{
    public function __construct(private TelegramSettings $settings) {}

    public function webhookUrl(): string
    {
        return rtrim((string) config('app.url'), '/').'/telegram/webhook';
    }

    /** @return list<BotCommand> */
    public function commands(): array
    {
        $commands = [new BotCommand('start', 'Почати')];

        foreach ($this->settings->group('menu')['commands'] as $name => $config) {
            if ($config['enabled'] ?? false) {
                $commands[] = new BotCommand($name, (string) ($config['description'] ?: $name));
            }
        }

        return $commands;
    }

    public function installWebhook(Nutgram $bot): void
    {
        $bot->setWebhook(
            url: $this->webhookUrl(),
            allowed_updates: ['message', 'callback_query', 'my_chat_member'],
            drop_pending_updates: false,
            secret_token: (string) config('bakinsky.telegram.webhook_secret'),
        );
    }

    public function installMenu(Nutgram $bot): void
    {
        $bot->setMyCommands($this->commands());
        // /connect is for group admins only, so it is listed only in that scope
        $bot->setMyCommands([new BotCommand('connect', 'Підключити групу для заявок')], new BotCommandScopeAllChatAdministrators);
        $bot->setChatMenuButton(menu_button: new MenuButtonWebApp(
            text: $this->settings->group('menu')['button_text'] ?: 'Каталог',
            web_app: new WebAppInfo($this->settings->miniAppUrl()),
        ));
    }

    /** @return array{ok: bool, url: ?string, pending: int, error: ?string, error_at: ?string} */
    public function webhookStatus(Nutgram $bot): array
    {
        try {
            $info = $bot->getWebhookInfo();

            return [
                'ok' => $info?->url === $this->webhookUrl() && ! $info->last_error_message,
                'url' => $info?->url ?: null,
                'pending' => (int) $info?->pending_update_count,
                'error' => $info?->last_error_message,
                'error_at' => $info?->last_error_date ? date('d.m.Y H:i', $info->last_error_date) : null,
            ];
        } catch (\Throwable $e) {
            return ['ok' => false, 'url' => null, 'pending' => 0, 'error' => $e->getMessage(), 'error_at' => null];
        }
    }
}
