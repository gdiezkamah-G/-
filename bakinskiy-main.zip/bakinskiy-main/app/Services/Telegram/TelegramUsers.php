<?php

namespace App\Services\Telegram;

use App\Models\TelegramUser;

class TelegramUsers
{
    /** Create or refresh a user from a Telegram `user` object (array or Nutgram User). */
    public function upsert(array|object $user): TelegramUser
    {
        $get = fn (string $key) => is_array($user) ? ($user[$key] ?? null) : ($user->{$key} ?? null);

        return TelegramUser::updateOrCreate(['telegram_id' => $get('id')], array_filter([
            'first_name' => $get('first_name'),
            'last_name' => $get('last_name'),
            'username' => $get('username'),
            'language_code' => $get('language_code'),
        ], fn ($v) => $v !== null) + ['last_seen_at' => now()]);
    }

    /** Telegram may send the number without "+". */
    public static function normalizePhone(string $raw): string
    {
        $raw = trim($raw);
        $digits = preg_replace('/\D/', '', $raw);

        return str_starts_with($raw, '+') || strlen($digits) < 10 ? $raw : '+'.$digits;
    }

    public static function looksLikePhone(string $text): bool
    {
        return (bool) preg_match('/^[+\d\s()\-]{7,}$/', trim($text));
    }
}
