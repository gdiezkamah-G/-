<?php

namespace App\Services\Telegram;

use App\Enums\LeadStatus;
use App\Models\Lead;
use App\Models\TelegramRecipient;
use Illuminate\Support\Collection;
use SergiX44\Nutgram\Telegram\Types\Keyboard\InlineKeyboardButton;
use SergiX44\Nutgram\Telegram\Types\Keyboard\InlineKeyboardMarkup;

/** How a lead looks in Telegram and who gets it. */
class LeadNotifier
{
    public function __construct(private TelegramSettings $settings) {}

    /** @return Collection<int, TelegramRecipient> */
    public function recipientsFor(Lead $lead): Collection
    {
        return TelegramRecipient::active()->get()->filter(fn (TelegramRecipient $r) => $r->wants($lead->type))->values();
    }

    public function text(Lead $lead): string
    {
        $show = $this->settings->group('notification');
        $e = fn (?string $v) => htmlspecialchars((string) $v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $lead->loadMissing(['product', 'telegramUser']);

        $lines = ['<b>Нова заявка'.($show['type'] ? ': '.$e($lead->type->getLabel()) : '').'</b>'];

        $rows = [
            'name' => ['Ім’я', $lead->contact_name],
            'phone' => ['Телефон', $lead->phone],
            'company' => ['Заклад', $lead->company ?: '—'],
            'comment' => ['Коментар', $lead->comment],
            'product' => ['Позиція', $lead->product ? trim($lead->product->name.' '.$lead->product->subtitle) : null],
            'source' => ['Джерело', $lead->source->getLabel()],
            'status' => ['Статус', $lead->status->getLabel()],
        ];

        foreach ($rows as $key => [$label, $value]) {
            if (($show[$key] ?? false) && filled($value)) {
                $lines[] = $e($label).': '.$e($value);
            }
        }

        if ($lead->volume_kg && ($show['comment'] ?? false)) {
            $lines[] = 'Обсяг: '.$e((string) $lead->volume_kg).' кг';
        }

        if ($lead->handled_by) {
            $verb = $lead->status === LeadStatus::Closed ? 'Закрив(ла)' : 'Взяв(ла) в роботу';
            $lines[] = "\n<i>{$verb}: ".$e($lead->handled_by).' · '.$lead->handled_at?->timezone('Europe/Kyiv')->format('d.m H:i').'</i>';
        }

        return implode("\n", $lines);
    }

    public function keyboard(Lead $lead): InlineKeyboardMarkup
    {
        $kb = InlineKeyboardMarkup::make();
        $actions = [];

        if ($lead->status === LeadStatus::New) {
            $actions[] = InlineKeyboardButton::make('Взяти в роботу', callback_data: "lead:take:{$lead->id}");
        }
        if ($lead->status !== LeadStatus::Closed) {
            $actions[] = InlineKeyboardButton::make('Закрити', callback_data: "lead:close:{$lead->id}");
        }
        if ($actions) {
            $kb->addRow(...$actions);
        }

        if ($this->settings->group('notification')['write_button'] && ($url = $this->writeUrl($lead))) {
            $kb->addRow(InlineKeyboardButton::make('Написати клієнту', url: $url));
        }

        return $kb;
    }

    /** Username link when we have one, then the user id, then a link by phone number. */
    public function writeUrl(Lead $lead): ?string
    {
        $lead->loadMissing('telegramUser');
        $tg = $lead->telegramUser;

        if ($tg?->username) {
            return 'https://t.me/'.$tg->username;
        }
        if ($tg) {
            return 'tg://user?id='.$tg->telegram_id;
        }

        $digits = preg_replace('/\D/', '', (string) $lead->phone);

        return strlen($digits) >= 9 ? 'https://t.me/+'.$digits : null;
    }
}
