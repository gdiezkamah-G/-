<?php

namespace App\Livewire;

use App\Actions\CreateLead;
use App\Enums\LeadSource;
use App\Enums\LeadType;
use App\Models\Product;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Livewire\Component;

/** The "Замовити" bottom sheet of the phone app: request / price list / samples. */
class OrderSheet extends Component
{
    public const MODES = ['order' => 0, 'price' => 1, 'sample' => 2];

    /** 0 = Заявка, 1 = Прайс, 2 = Зразки */
    public int $mode = 0;

    public string $company = '';

    public string $contactName = '';

    public string $phone = '';

    public ?string $productId = '';

    public ?string $volumeKg = null;

    /** Honeypot: real visitors never fill it. */
    public string $website = '';

    public bool $sent = false;

    protected function rules(): array
    {
        return [
            'company' => 'required|string|max:160',
            'contactName' => 'required|string|max:120',
            'phone' => ['required', 'string', 'max:32', 'regex:/^[+\d\s()\-]{7,}$/'],
            'productId' => 'nullable|integer|exists:products,id',
            'volumeKg' => 'nullable|integer|min:1|max:100000',
        ];
    }

    protected function messages(): array
    {
        return [
            'company.required' => 'Вкажіть назву закладу.',
            'contactName.required' => 'Вкажіть контактну особу.',
            'phone.required' => 'Вкажіть телефон.',
            'phone.regex' => 'Телефон має містити лише цифри, +, пробіли, дужки та дефіси (мінімум 7 символів).',
            'volumeKg.integer' => 'Обсяг вкажіть цілим числом кілограмів.',
            'volumeKg.min' => 'Обсяг має бути не менше 1 кг.',
            'volumeKg.max' => 'Обсяг не може перевищувати 100 000 кг.',
        ];
    }

    /** Called by the page before the sheet opens. $mode: order | price | sample. */
    public function prepare(?string $productId, string $mode = 'order'): void
    {
        $this->resetValidation();

        if ($this->sent) {
            $this->reset('company', 'contactName', 'phone', 'volumeKg', 'website', 'sent');
        }

        $this->productId = (string) (Product::published()->whereKey($productId)->value('id') ?? '');
        $this->mode = self::MODES[$mode] ?? 0;
    }

    public function setMode(int $mode): void
    {
        $this->mode = in_array($mode, self::MODES, true) ? $mode : 0;
    }

    public function submit(CreateLead $action): void
    {
        try {
            $this->validate();
        } catch (ValidationException $e) {
            $this->dispatch('app-toast', message: 'Перевірте виділені поля');

            throw $e;
        }

        if ($this->website !== '') {
            $this->sent = true;

            return;
        }

        $lead = $action->handle([
            'company' => $this->company,
            'contact_name' => $this->contactName,
            'phone' => $this->phone,
            'product_id' => $this->productId ?: null,
            'volume_kg' => $this->volumeKg ?: null,
        ], match ($this->mode) {
            1 => LeadType::Price,
            2 => LeadType::Sample,
            default => LeadType::Order,
        }, LeadSource::Site);

        if (! $lead) {
            $this->addError('company', 'Забагато спроб. Спробуйте за хвилину.');
            $this->dispatch('app-toast', message: 'Забагато спроб. Спробуйте за хвилину');

            return;
        }

        $this->sent = true;
    }

    public function render(): View
    {
        return view('livewire.order-sheet', [
            'products' => Product::published()->get(['id', 'name', 'subtitle']),
            'product' => $this->productId ? Product::published()->with('activeVariants')->find($this->productId) : null,
        ]);
    }
}
