<?php

namespace App\Livewire;

use App\Actions\CreateLead;
use App\Enums\LeadSource;
use App\Enums\LeadType;
use App\Jobs\SendPriceToChat;
use App\Models\Product;
use App\Models\TelegramUser;
use App\Services\Telegram\TelegramUsers;
use App\Support\TelegramInitData;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use InvalidArgumentException;
use Livewire\Component;

/**
 * The bottom sheet of the Telegram Mini App: price list, samples, manager, question about a product.
 * Who the user is comes only from initData that the server verifies on every call; without valid initData
 * the sheet simply asks for a name and a phone ("manual mode") and the lead has no Telegram user.
 */
class TgSheet extends Component
{
    public const MODES = ['price' => LeadType::Price, 'samples' => LeadType::Sample, 'manager' => LeadType::Manager, 'request' => LeadType::Request];

    /** price | samples | manager | request ('' = closed) */
    public string $mode = '';

    /** choose (price: share a number or type it) | waiting (for the number from Telegram) | form | done */
    public string $step = 'form';

    public string $productSlug = '';

    public string $initData = '';

    public string $company = '';

    public string $comment = '';

    public string $name = '';

    public string $phone = '';

    /** The user refused to share the number (or it never arrived): show the manual form with a note. */
    public bool $declined = false;

    public int $polls = 0;

    /** Honeypot. */
    public string $website = '';

    public string $resultTitle = '';

    public string $resultText = '';

    public function open(string $mode, ?string $slug = null, string $initData = ''): void
    {
        $this->resetState();

        if (! isset(self::MODES[$mode])) {
            return;
        }

        $this->initData = $initData;
        $product = $mode === 'request' && $slug ? Product::published()->where('slug', $slug)->first() : null;

        if ($mode === 'request' && ! $product) {
            $mode = 'manager'; // the product is gone or never existed: still let the client write to us
        }

        $this->mode = $mode;
        $this->productSlug = $product?->slug ?? '';
        $user = $this->telegramUser();
        $this->company = (string) $user?->company;
        $this->step = $mode === 'price' && $user ? 'choose' : 'form';
    }

    public function close(): void
    {
        $this->resetState();
    }

    /** "Ввести вручну". */
    public function manual(): void
    {
        $this->step = 'form';
    }

    /** "Поділитися номером": use the number we already know, otherwise ask Telegram for it. */
    public function share(): void
    {
        $user = $this->telegramUser();

        if (! $user) {
            $this->step = 'form';

            return;
        }

        if ($user->phone) {
            $this->finish($user, LeadType::Price);

            return;
        }

        $this->step = 'waiting';
        $this->polls = 0;
        $this->dispatch('tg-request-contact');
    }

    /** Telegram's answer to requestContact: false = the user said no. The number itself reaches us through the bot. */
    public function contactResult(bool $shared): void
    {
        if ($this->step !== 'waiting') {
            return;
        }

        if (! $shared) {
            $this->declined = true;
            $this->step = 'form';
        }
    }

    /** Polled while waiting: the contact message arrives at the bot webhook a moment after the user agrees. */
    public function checkPhone(): void
    {
        if ($this->step !== 'waiting') {
            return;
        }

        $user = $this->telegramUser();

        if ($user?->phone) {
            $this->finish($user, LeadType::Price);

            return;
        }

        if (++$this->polls >= 20) {
            $this->declined = true;
            $this->step = 'form';
        }
    }

    public function submit(): void
    {
        if ($this->step === 'done' || $this->mode === '') {
            return; // a second tap on a finished request does nothing
        }

        $user = $this->telegramUser();

        try {
            $this->validate($this->rules($user), $this->messages());
        } catch (ValidationException $e) {
            $this->dispatch('tg-result', ok: false);

            throw $e;
        }

        if ($this->website !== '') {
            $this->step = 'done';

            return;
        }

        $this->finish($user, self::MODES[$this->mode]);
    }

    private function finish(?TelegramUser $user, LeadType $type): void
    {
        if ($this->step === 'done') {
            return;
        }

        $phone = $user ? ($user->phone ?: trim($this->phone)) : trim($this->phone);
        $product = $this->productSlug ? Product::published()->where('slug', $this->productSlug)->first() : null;

        $lead = app(CreateLead::class)->handle([
            'company' => filled($this->company) ? trim($this->company) : null,
            'contact_name' => $user ? $user->full_name : trim($this->name),
            'phone' => $phone,
            'comment' => filled($this->comment) ? trim($this->comment) : null,
            'product_id' => $product?->id,
        ], $type, LeadSource::MiniApp, $user);

        if (! $lead) {
            $this->step = 'form';
            $this->addError('company', 'Забагато спроб. Спробуйте за хвилину.');
            $this->dispatch('tg-result', ok: false);

            return;
        }

        if ($user) {
            $user->update(array_filter(['company' => $this->company ?: null, 'phone' => $user->phone ? null : ($phone ?: null)]));
        }

        if ($type === LeadType::Price && $user) {
            SendPriceToChat::dispatch($user->telegram_id);
        }

        [$this->resultTitle, $this->resultText] = $type === LeadType::Price && $user
            ? ['Прайс надіслано', 'PDF у чаті з ботом. Менеджер також отримав вашу заявку.']
            : ($type === LeadType::Price
                ? ['Дякуємо!', 'Менеджер надішле прайс найближчим часом.']
                : ['Дякуємо!', 'Менеджер зв’яжеться з вами найближчим часом.']);

        $this->step = 'done';
        $this->dispatch('tg-result', ok: true);
    }

    /** @return array<string, mixed> */
    private function rules(?TelegramUser $user): array
    {
        $needsPhone = ! $user || ($this->mode === 'price' && ! $user->phone);

        return [
            'company' => 'nullable|string|max:160',
            'comment' => 'nullable|string|max:1000',
            'name' => $user ? 'nullable' : 'required|string|max:120',
            'phone' => $needsPhone ? ['required', 'string', 'max:32', 'regex:/^[+\d\s()\-]{7,}$/'] : 'nullable',
        ];
    }

    /** @return array<string, string> */
    protected function messages(): array
    {
        return [
            'name.required' => 'Вкажіть імʼя.',
            'phone.required' => 'Вкажіть телефон.',
            'phone.regex' => 'Телефон має містити лише цифри, +, пробіли, дужки та дефіси (мінімум 7 символів).',
            'company.max' => 'Назва закладу задовга.',
            'comment.max' => 'Коментар задовгий (до 1000 символів).',
            'name.max' => 'Імʼя задовге.',
        ];
    }

    /** The verified Telegram user, or null (outside Telegram, forged or expired initData). */
    private function telegramUser(): ?TelegramUser
    {
        if ($this->initData === '') {
            return null;
        }

        try {
            $init = TelegramInitData::validate($this->initData, config('bakinsky.telegram.token'));
        } catch (InvalidArgumentException) {
            return null;
        }

        return app(TelegramUsers::class)->upsert($init['user']);
    }

    private function resetState(): void
    {
        $this->resetValidation();
        $this->reset('mode', 'step', 'productSlug', 'company', 'comment', 'name', 'phone', 'declined', 'polls', 'website', 'resultTitle', 'resultText');
    }

    public function render(): View
    {
        $user = $this->mode !== '' ? $this->telegramUser() : null;
        $product = $this->productSlug ? Product::published()->with('activeVariants')->where('slug', $this->productSlug)->first() : null;

        return view('livewire.tg-sheet', [
            'user' => $user,
            'product' => $product,
            'productLine' => $product ? trim($product->name.' · '.$product->pack_label, ' ·') : '',
        ]);
    }
}
