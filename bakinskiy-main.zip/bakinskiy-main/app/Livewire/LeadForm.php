<?php

namespace App\Livewire;

use App\Actions\CreateLead;
use App\Enums\LeadType;
use App\Models\Product;
use Illuminate\View\View;
use Livewire\Attributes\Validate;
use Livewire\Component;

class LeadForm extends Component
{
    #[Validate('required|string|max:160')]
    public string $company = '';

    #[Validate('required|string|max:120')]
    public string $contactName = '';

    #[Validate(['required', 'string', 'max:32', 'regex:/^[+\d\s()\-]{7,}$/'])]
    public string $phone = '';

    #[Validate('nullable|integer|exists:products,id')]
    public ?string $productId = '';

    #[Validate('nullable|integer|min:1|max:100000')]
    public ?string $volumeKg = null;

    public bool $sample = false;

    /** Honeypot: real visitors never fill it. */
    public string $website = '';

    public bool $sent = false;

    public function prepare(?string $productId, bool $sample): void
    {
        $this->resetValidation();

        if ($this->sent) {
            $this->reset('company', 'contactName', 'phone', 'volumeKg', 'sent');
        }

        $this->productId = (string) (Product::published()->whereKey($productId)->value('id') ?? '');
        $this->sample = $sample;
    }

    public function submit(CreateLead $action): void
    {
        $this->validate();

        if ($this->website !== '') {
            $this->sent = true;

            return;
        }

        $lead = $action->handle([
            'company' => $this->company,
            'contact_name' => $this->contactName,
            'phone' => $this->phone,
            'product_id' => $this->productId ?: null,
            'volume_kg' => $this->volumeKg ?: null,
        ], $this->sample ? LeadType::Sample : LeadType::Order);

        if (! $lead) {
            $this->addError('company', 'Забагато спроб. Спробуйте за хвилину.');

            return;
        }

        $this->sent = true;
    }

    public function render(): View
    {
        return view('livewire.lead-form', [
            'products' => Product::published()->get(['id', 'name', 'subtitle']),
        ]);
    }
}
