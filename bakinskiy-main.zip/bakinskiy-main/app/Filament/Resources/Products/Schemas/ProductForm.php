<?php

namespace App\Filament\Resources\Products\Schemas;

use App\Enums\ProductStatus;
use App\Models\Product;
use Filament\Forms\Components\ColorPicker;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Str;

class ProductForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema->columns(1)->components([
            Section::make('Потрібно уточнити')
                ->description('Ці дані треба підтвердити з клієнтом. Після підтвердження видаліть рядок: коли список порожній, помітка зникає.')
                ->icon(Heroicon::OutlinedExclamationTriangle)
                ->iconColor('warning')
                ->visible(fn (?Product $record) => filled($record?->needs_confirmation))
                ->schema([
                    Repeater::make('needs_confirmation')->label('')->simple(TextInput::make('note')->label('Що уточнити'))
                        ->addable(false)->reorderable(false)->deleteAction(fn ($action) => $action->label('Підтверджено, прибрати')),
                ]),
            Section::make('Основне')->columns(2)->schema([
                TextInput::make('name')->label('Назва')->required()->maxLength(120)
                    ->live(onBlur: true)
                    ->afterStateUpdated(fn ($state, $set, $get) => filled($get('slug')) ? null : $set('slug', Str::slug($state))),
                TextInput::make('subtitle')->label('Підзаголовок (курсив)')->maxLength(160),
                TextInput::make('full_name')->label('Повна назва (технічна картка, документи)')->maxLength(255)->columnSpanFull(),
                TextInput::make('slug')->label('Slug (адреса сторінки)')->required()->alphaDash()->unique(ignoreRecord: true),
                Select::make('category_id')->label('Категорія')->relationship('category', 'name')->required()->preload(),
                TextInput::make('short_tagline')->label('Слоган')->columnSpanFull(),
                Textarea::make('description')->label('Опис (для пошукових систем)')->rows(3)->columnSpanFull(),
                ColorPicker::make('hue')->label('Колір упаковки')->required()->default('#5a2a1c'),
                Select::make('status')->label('Статус')->options(ProductStatus::class)->default('draft')->required(),
                TextInput::make('sort')->label('Порядок')->numeric()->default(0)->required(),
            ]),
            Section::make('Фасовка')->schema([
                Repeater::make('variants')->label('Варіанти')->relationship()->orderColumn('sort')->reorderable()
                    ->columns(3)->defaultItems(0)
                    ->schema([
                        TextInput::make('size_label')->label('Підпис (500 г)')->required(),
                        TextInput::make('weight_g')->label('Вага, г')->numeric(),
                        TextInput::make('pack_note')->label('Примітка (10 шт)'),
                        TextInput::make('units')->label('Штук в упаковці')->numeric(),
                        TextInput::make('sku')->label('SKU')->distinct(),
                        TextInput::make('price')->label('Ціна, грн')->numeric()->prefix('₴')->minValue(0)
                            ->dehydrateStateUsing(fn ($state) => filled($state) ? (int) round(((float) $state) * 100) : null)
                            ->formatStateUsing(fn ($state) => $state === null ? null : $state / 100),
                        Select::make('availability')->label('Наявність')->options(['in stock' => 'В наявності', 'out of stock' => 'Немає', 'preorder' => 'Передзамовлення'])->default('in stock')->nullable(),
                        Toggle::make('is_default')->label('На упаковці')->inline(false),
                        Toggle::make('is_active')->label('Активна')->default(true)->inline(false),
                    ]),
            ]),
            Section::make('Склад і приготування')->schema([
                Textarea::make('composition')->label('Склад (повний текст для технічної картки)')->rows(4),
                Repeater::make('ingredients')->label('Інгредієнти (4–6)')->columns(2)->maxItems(6)->defaultItems(0)
                    ->schema([
                        TextInput::make('name')->label('Назва')->required(),
                        ColorPicker::make('color')->label('Колір кружка')->required()->default('#d9d3c0'),
                    ]),
                Repeater::make('cooking_steps')->label('Кроки приготування (до 3)')->columns(3)->maxItems(3)->defaultItems(0)
                    ->schema([
                        TextInput::make('title')->label('Крок')->required(),
                        TextInput::make('text')->label('Опис')->required(),
                        TextInput::make('minutes')->label('Таймер, хв (0 = без таймера)')->numeric()->default(0),
                    ]),
            ]),
            Section::make('Технічна картка')->columns(2)->schema([
                TextInput::make('cooking_summary')->label('Приготування (коротко)'),
                TextInput::make('packaging')->label('Паковання'),
                TextInput::make('shelf_life')->label('Термін придатності'),
                TextInput::make('storage_temp')->label('Зберігання')->default('−18 °C')->required(),
            ]),
        ]);
    }
}
