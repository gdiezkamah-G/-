<?php

namespace App\Filament\Resources\Products\Tables;

use App\Enums\ProductStatus;
use App\Models\Category;
use App\Models\Product;
use Filament\Actions\BulkAction;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\Select;
use Filament\Notifications\Notification;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\Filter;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Collection;

class ProductsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')->label('Назва')->description(fn (Product $record) => $record->subtitle)->searchable(['name', 'subtitle', 'full_name']),
                TextColumn::make('category.name')->label('Категорія')->sortable(),
                TextColumn::make('variants.size_label')->label('Фасовка')->badge(),
                TextColumn::make('status')->label('Статус')->badge(),
                TextColumn::make('needs_confirmation')->label('Уточнити')->badge()->color('warning')
                    ->state(fn ($record) => count($record->needs_confirmation ?? []) ?: null)
                    ->formatStateUsing(fn ($state) => "Потрібно уточнити: {$state}")
                    ->tooltip(fn ($record) => implode("\n", $record->needs_confirmation ?? []) ?: null),
                TextColumn::make('sort')->label('Порядок')->sortable(),
            ])
            ->filters([
                SelectFilter::make('status')->label('Статус')->options(ProductStatus::class),
                Filter::make('needs_confirmation')->label('Потрібно уточнити')
                    ->query(fn ($query) => $query->whereNotNull('needs_confirmation')->where('needs_confirmation', '!=', '[]')),
            ])
            ->defaultSort('sort')
            ->recordActions([EditAction::make()])
            ->toolbarActions([
                BulkActionGroup::make([
                    BulkAction::make('publish')->label('Опублікувати')->icon(Heroicon::OutlinedEye)->color('success')
                        ->requiresConfirmation()
                        ->modalDescription(fn (Collection $records) => self::publishWarning($records))
                        ->action(fn (Collection $records) => self::setStatus($records, ProductStatus::Published))
                        ->deselectRecordsAfterCompletion(),
                    BulkAction::make('draft')->label('Зняти з публікації')->icon(Heroicon::OutlinedEyeSlash)->color('gray')
                        ->requiresConfirmation()
                        ->action(fn (Collection $records) => self::setStatus($records, ProductStatus::Draft))
                        ->deselectRecordsAfterCompletion(),
                    BulkAction::make('category')->label('Змінити категорію')->icon(Heroicon::OutlinedTag)
                        ->schema([Select::make('category_id')->label('Категорія')->options(fn () => Category::orderBy('sort')->pluck('name', 'id'))->required()])
                        ->action(function (Collection $records, array $data) {
                            Product::whereKey($records->modelKeys())->update(['category_id' => $data['category_id']]);
                            Notification::make()->success()->title("Категорію змінено: {$records->count()}")->send();
                        })
                        ->deselectRecordsAfterCompletion(),
                    BulkAction::make('confirm')->label('Прибрати помітки «Потрібно уточнити»')->icon(Heroicon::OutlinedCheckCircle)->color('warning')
                        ->requiresConfirmation()
                        ->modalDescription('Підтверджую, що всі помітки до вибраних товарів опрацьовані з клієнтом.')
                        ->action(function (Collection $records) {
                            Product::whereKey($records->modelKeys())->update(['needs_confirmation' => null]);
                            Notification::make()->success()->title("Помітки прибрано: {$records->count()}")->send();
                        })
                        ->deselectRecordsAfterCompletion(),
                    DeleteBulkAction::make(),
                ]),
            ]);
    }

    private static function setStatus(Collection $records, ProductStatus $status): void
    {
        Product::whereKey($records->modelKeys())->update(['status' => $status->value]);

        Notification::make()->success()
            ->title(($status === ProductStatus::Published ? 'Опубліковано' : 'Знято з публікації').": {$records->count()}")->send();
    }

    /** Publishing is allowed, but the manager is told what is still unresolved. */
    private static function publishWarning(Collection $records): string
    {
        $open = $records->filter(fn (Product $p) => filled($p->needs_confirmation))->count();

        return $open
            ? "Увага: у {$open} з вибраних товарів дані ще не підтверджені (є помітки «Потрібно уточнити»), але товари стануть видимі на сайті."
            : 'Вибрані товари стануть видимі на сайті.';
    }
}
