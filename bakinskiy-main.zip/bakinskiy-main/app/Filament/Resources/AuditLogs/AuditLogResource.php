<?php

namespace App\Filament\Resources\AuditLogs;

use App\Enums\Ability;
use App\Filament\Resources\AuditLogs\Pages\ListAuditLogs;
use App\Mcp\Support\Audit;
use App\Mcp\Support\CatalogService;
use App\Models\McpAuditLog;
use App\Models\User;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Forms\Components\DatePicker;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\Filter;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Contracts\View\View;
use Illuminate\Database\Eloquent\Builder;

/** What the AI did in the shop: every MCP call, with the change before and after. Read-only; a product edit can be rolled back. */
class AuditLogResource extends Resource
{
    protected static ?string $model = McpAuditLog::class;

    protected static ?string $modelLabel = 'дія ШІ';

    protected static ?string $pluralModelLabel = 'Журнал ШІ';

    protected static ?string $navigationLabel = 'Журнал ШІ';

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedClipboardDocumentList;

    protected static ?int $navigationSort = 90;

    protected static ?string $slug = 'ai-log';

    public static function canAccess(): bool
    {
        return auth()->user()?->role !== null;
    }

    public static function canCreate(): bool
    {
        return false;
    }

    public static function canEdit($record): bool
    {
        return false;
    }

    public static function canDelete($record): bool
    {
        return false;
    }

    /** Admins see everything; others only their own calls. */
    public static function getEloquentQuery(): Builder
    {
        $user = auth()->user();

        return parent::getEloquentQuery()->with('user', 'revision')
            ->when($user?->hasAbility(Ability::SystemRead) !== true, fn (Builder $q) => $q->where('user_id', $user?->id));
    }

    public static function table(Table $table): Table
    {
        return $table
            ->defaultSort('id', 'desc')
            ->columns([
                TextColumn::make('created_at')->label('Час')->dateTime('d.m.Y H:i:s')->timezone('Europe/Kyiv')->sortable(),
                TextColumn::make('user.name')->label('Користувач')->placeholder('—'),
                TextColumn::make('client')->label('Клієнт')->placeholder('—'),
                TextColumn::make('tool')->label('Інструмент')->searchable()->fontFamily('mono'),
                TextColumn::make('writes')->label('Тип')->badge()->formatStateUsing(fn ($state) => $state ? 'зміна' : 'читання')->color(fn ($state) => $state ? 'warning' : 'gray'),
                TextColumn::make('result')->label('Результат')->badge()
                    ->formatStateUsing(fn ($state) => ['ok' => 'успіх', 'error' => 'помилка', 'denied' => 'відмова'][$state] ?? $state)
                    ->color(fn ($state) => ['ok' => 'success', 'error' => 'danger', 'denied' => 'danger'][$state] ?? 'gray'),
                TextColumn::make('message')->label('Повідомлення')->limit(70)->tooltip(fn ($record) => $record->message)->placeholder('—'),
            ])
            ->filters([
                SelectFilter::make('user_id')->label('Користувач')->options(fn () => User::whereNotNull('role')->orderBy('name')->pluck('name', 'id')),
                SelectFilter::make('tool')->label('Інструмент')->options(fn () => McpAuditLog::distinct()->orderBy('tool')->pluck('tool', 'tool'))->searchable(),
                SelectFilter::make('result')->label('Результат')->options(['ok' => 'успіх', 'error' => 'помилка', 'denied' => 'відмова']),
                SelectFilter::make('writes')->label('Тип')->options([1 => 'зміна', 0 => 'читання']),
                Filter::make('period')->label('Дата')->schema([
                    DatePicker::make('from')->label('Від'),
                    DatePicker::make('to')->label('До'),
                ])->query(fn (Builder $q, array $data) => $q
                    ->when($data['from'] ?? null, fn ($q, $d) => $q->whereDate('created_at', '>=', $d))
                    ->when($data['to'] ?? null, fn ($q, $d) => $q->whereDate('created_at', '<=', $d))),
            ])
            ->recordActions([
                Action::make('details')->label('Деталі')->icon(Heroicon::OutlinedEye)->color('gray')->slideOver()->modalSubmitAction(false)->modalCancelActionLabel('Закрити')
                    ->modalContent(fn (McpAuditLog $record): View => view('filament.ai.log-details', ['log' => $record])),
                Action::make('revert')->label('Відкотити')->icon(Heroicon::OutlinedArrowUturnLeft)->color('warning')->requiresConfirmation()
                    ->modalDescription('Товар і його фасування повернуться до стану до цієї дії. Статус публікації не зміниться.')
                    ->visible(fn (McpAuditLog $record) => $record->revision && ! $record->revision->reverted_at && auth()->user()?->hasAbility(Ability::CatalogWrite))
                    ->action(function (McpAuditLog $record) {
                        $rev = $record->revision;
                        $product = $rev->product;
                        $before = CatalogService::snapshot($product);
                        CatalogService::restore($rev);
                        $rev->update(['reverted_at' => now()]);
                        Audit::write(auth()->user(), 'product_revert', true, ['revision_id' => $rev->id, 'via' => 'admin'], 'ok', null, ['before' => $before, 'after' => CatalogService::snapshot($product)]);
                        Notification::make()->success()->title('Повернуто до попередньої версії')->send();
                    }),
            ]);
    }

    public static function getPages(): array
    {
        return ['index' => ListAuditLogs::route('/')];
    }
}
