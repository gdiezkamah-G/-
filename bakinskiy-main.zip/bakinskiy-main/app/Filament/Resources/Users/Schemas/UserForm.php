<?php

namespace App\Filament\Resources\Users\Schemas;

use App\Enums\UserRole;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;

class UserForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('name')->label('Ім’я')->required()->maxLength(120),
            TextInput::make('email')->label('E-mail')->email()->required()->unique(ignoreRecord: true),
            Select::make('role')->label('Роль')->options(collect(UserRole::cases())->mapWithKeys(fn (UserRole $role) => [$role->value => $role->getLabel()]))->required(),
            TextInput::make('password')->label('Пароль')->password()->revealable()->minLength(12)->required(fn (string $operation) => $operation === 'create')->dehydrated(fn (?string $state) => filled($state)),
        ]);
    }
}
