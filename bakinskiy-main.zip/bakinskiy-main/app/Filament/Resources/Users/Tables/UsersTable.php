<?php

namespace App\Filament\Resources\Users\Tables;

use App\Enums\UserRole;
use App\Models\User;
use Filament\Actions\DeleteAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;

class UsersTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')->label('Ім’я')->searchable()->sortable(),
                TextColumn::make('email')->label('E-mail')->searchable(),
                TextColumn::make('role')->label('Роль')->badge()->formatStateUsing(fn (?UserRole $state) => $state?->getLabel() ?? '—'),
                TextColumn::make('created_at')->label('Створено')->dateTime()->sortable(),
            ])
            ->filters([
                SelectFilter::make('role')->label('Роль')->options(collect(UserRole::cases())->mapWithKeys(fn (UserRole $role) => [$role->value => $role->getLabel()])),
            ])
            ->recordActions([
                EditAction::make(),
                DeleteAction::make()->disabled(fn (User $record) => $record->is(auth()->user()))->tooltip(fn (User $record) => $record->is(auth()->user()) ? 'Не можна видалити власний обліковий запис' : null),
            ]);
    }
}
