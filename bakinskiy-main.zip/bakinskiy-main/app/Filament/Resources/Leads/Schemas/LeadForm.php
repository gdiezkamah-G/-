<?php

namespace App\Filament\Resources\Leads\Schemas;

use App\Enums\LeadSource;
use App\Enums\LeadStatus;
use App\Enums\LeadType;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;

class LeadForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema->columns(2)->components([
            TextInput::make('company')->label('Заклад'),
            TextInput::make('contact_name')->label('Контактна особа')->required(),
            TextInput::make('phone')->label('Телефон')->tel(),
            Select::make('product_id')->label('Позиція')->relationship('product', 'name')->placeholder('Кілька позицій'),
            TextInput::make('volume_kg')->label('Обсяг, кг')->numeric(),
            Select::make('type')->label('Тип')->options(LeadType::class)->required()->default('order'),
            Select::make('source')->label('Джерело')->options(LeadSource::class)->required()->default('site'),
            Select::make('status')->label('Статус')->options(LeadStatus::class)->required()->default('new'),
            Select::make('manager_id')->label('Менеджер')->relationship('manager', 'name'),
            Textarea::make('comment')->label('Коментар клієнта')->columnSpanFull(),
            Textarea::make('notes')->label('Нотатки')->columnSpanFull(),
        ]);
    }
}
