<?php

namespace App\Filament\Resources\Leads\Tables;

use App\Enums\LeadSource;
use App\Enums\LeadStatus;
use App\Enums\LeadType;
use App\Models\Lead;
use App\Models\User;
use Filament\Actions\BulkAction;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Forms\Components\Select;
use Filament\Notifications\Notification;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Collection;

class LeadsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('created_at')->label('Дата')->dateTime('d.m.Y H:i')->sortable(),
                TextColumn::make('company')->label('Заклад')->searchable(),
                TextColumn::make('contact_name')->label('Контакт')->searchable(),
                TextColumn::make('phone')->label('Телефон')->searchable(),
                TextColumn::make('product.name')->label('Позиція')->placeholder('Кілька позицій'),
                TextColumn::make('volume_kg')->label('кг')->numeric(),
                TextColumn::make('type')->label('Тип')->badge(),
                TextColumn::make('source')->label('Джерело')->badge()->color('gray'),
                TextColumn::make('status')->label('Статус')->badge(),
            ])
            ->defaultSort('created_at', 'desc')
            ->filters([
                SelectFilter::make('status')->label('Статус')->options(LeadStatus::class),
                SelectFilter::make('type')->label('Тип')->options(LeadType::class),
                SelectFilter::make('source')->label('Джерело')->options(LeadSource::class),
            ])
            ->recordActions([EditAction::make()])
            ->toolbarActions([
                BulkActionGroup::make([
                    BulkAction::make('status')->label('Змінити статус')->icon(Heroicon::OutlinedArrowPath)
                        ->schema([Select::make('status')->label('Статус')->options(LeadStatus::class)->required()])
                        ->action(function (Collection $records, array $data) {
                            Lead::whereKey($records->modelKeys())->update(['status' => $data['status']]);
                            Notification::make()->success()->title("Статус змінено: {$records->count()}")->send();
                        })
                        ->deselectRecordsAfterCompletion(),
                    BulkAction::make('manager')->label('Призначити менеджера')->icon(Heroicon::OutlinedUserPlus)
                        ->schema([Select::make('manager_id')->label('Менеджер')->options(fn () => User::whereNotNull('role')->orderBy('name')->pluck('name', 'id'))->required()])
                        ->action(function (Collection $records, array $data) {
                            Lead::whereKey($records->modelKeys())->update(['manager_id' => $data['manager_id']]);
                            Notification::make()->success()->title("Менеджера призначено: {$records->count()}")->send();
                        })
                        ->deselectRecordsAfterCompletion(),
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}
