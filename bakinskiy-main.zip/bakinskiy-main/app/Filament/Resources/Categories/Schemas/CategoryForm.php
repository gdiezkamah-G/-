<?php

namespace App\Filament\Resources\Categories\Schemas;

use Filament\Forms\Components\TextInput;
use Filament\Schemas\Schema;

class CategoryForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('name')->label('Назва')->required()->maxLength(120),
            TextInput::make('slug')->label('Slug (для фільтра)')->required()->alphaDash()->unique(ignoreRecord: true),
            TextInput::make('sort')->label('Порядок')->required()->numeric()->default(0),
        ]);
    }
}
