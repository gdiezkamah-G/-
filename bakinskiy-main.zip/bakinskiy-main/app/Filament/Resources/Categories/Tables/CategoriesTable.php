<?php

namespace App\Filament\Resources\Categories\Tables;

use App\Models\Category;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Notifications\Notification;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Collection;

class CategoriesTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')->label('Назва')
                    ->searchable(),
                TextColumn::make('slug')->label('Slug')
                    ->searchable(),
                TextColumn::make('sort')->label('Порядок')
                    ->numeric()
                    ->sortable(),
                TextColumn::make('created_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('updated_at')
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                //
            ])
            ->recordActions([
                EditAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    // A category that still has products cannot be deleted (FK restrict): skip it and say so.
                    DeleteBulkAction::make()
                        ->action(function (Collection $records) {
                            [$empty, $used] = $records->load('products')->partition(fn (Category $c) => $c->products->isEmpty());
                            $empty->each->delete();

                            $note = Notification::make()->title("Видалено: {$empty->count()}");
                            $used->isEmpty()
                                ? $note->success()
                                : $note->warning()->body('Не видалено, бо в них є товари: '.$used->pluck('name')->implode(', '));
                            $note->send();
                        })
                        ->deselectRecordsAfterCompletion(),
                ]),
            ]);
    }
}
