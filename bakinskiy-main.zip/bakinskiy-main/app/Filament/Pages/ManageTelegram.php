<?php

namespace App\Filament\Pages;

use App\Enums\LeadType;
use App\Enums\UserRole;
use App\Models\TelegramAdmin;
use App\Models\TelegramRecipient;
use App\Services\Telegram\BotMenu;
use App\Services\Telegram\PriceList;
use App\Services\Telegram\TelegramSettings;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Forms\Components\CheckboxList;
use Filament\Forms\Components\FileUpload;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\Radio;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Components\Actions;
use Filament\Schemas\Components\EmbeddedSchema;
use Filament\Schemas\Components\Form;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Schemas\Components\Text;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Arr;
use Illuminate\Support\HtmlString;
use SergiX44\Nutgram\Nutgram;
use Throwable;

class ManageTelegram extends Page
{
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedPaperAirplane;

    protected static ?string $navigationLabel = 'Telegram';

    protected static ?string $title = 'Налаштування Telegram';

    protected static ?string $slug = 'telegram';

    protected static ?int $navigationSort = 90;

    /** @var array<string, mixed> */
    public ?array $data = [];

    /** Webhook state shown on the "Бот" tab (filled on mount, refreshed by the buttons). */
    public array $webhook = [];

    public static function canAccess(): bool
    {
        return auth()->user()?->role === UserRole::Admin;
    }

    public function mount(): void
    {
        $s = app(TelegramSettings::class);
        $price = $s->group('price');

        $this->form->fill([
            'texts' => $s->group('texts'),
            'notification' => $s->group('notification'),
            'menu' => $s->group('menu'),
            'channel_id' => $s->group('channel')['chat_id'],
            'price_mode' => $price['mode'],
            'price_file' => $price['file'],
            'recipients' => TelegramRecipient::orderBy('id')->get()->map(fn ($r) => $r->only(['id', 'chat_id', 'title', 'type', 'active', 'lead_types']))->all(),
            'admins' => TelegramAdmin::orderBy('id')->get()->map(fn ($a) => $a->only(['id', 'telegram_id', 'name']))->all(),
        ]);

        $this->refreshWebhook();
    }

    public function refreshWebhook(): void
    {
        $this->webhook = filled(config('bakinsky.telegram.token'))
            ? app(BotMenu::class)->webhookStatus(app(Nutgram::class))
            : ['ok' => false, 'url' => null, 'pending' => 0, 'error' => 'TELEGRAM_BOT_TOKEN не задано', 'error_at' => null];
    }

    public function form(Schema $schema): Schema
    {
        return $schema->statePath('data')->components([
            Tabs::make()->persistTabInQueryString()->tabs([
                Tab::make('Бот')->icon(Heroicon::OutlinedSignal)->schema([
                    Text::make(fn () => $this->statusHtml()),
                ]),
                Tab::make('Отримувачі заявок')->icon(Heroicon::OutlinedUserGroup)->schema([
                    Text::make('Групу підключають командою /connect (від адміна бота). Приватний чат адміна додається, коли він натисне /start. Порожній вибір типів = усі заявки.'),
                    Repeater::make('recipients')->hiddenLabel()->addActionLabel('Додати отримувача за chat id')->reorderable(false)->collapsible()
                        ->itemLabel(fn (array $state) => (($state['title'] ?? '') ?: ($state['chat_id'] ?? 'новий')).' · '.(($state['type'] ?? 'group') === 'group' ? 'група' : 'особистий').(($state['active'] ?? false) ? '' : ' · вимкнено'))
                        ->extraItemActions([
                            Action::make('test')->label('Надіслати тест')->icon(Heroicon::OutlinedPaperAirplane)
                                ->action(fn (array $arguments) => $this->sendTest((string) $arguments['item'])),
                        ])
                        ->columns(2)->schema([
                            Hidden::make('id'),
                            TextInput::make('chat_id')->label('Chat id')->numeric()->required()->helperText('Для групи число з мінусом, напр. -1001234567890'),
                            TextInput::make('title')->label('Назва'),
                            Select::make('type')->label('Тип')->options(['group' => 'Група', 'private' => 'Особистий чат'])->default('group')->required(),
                            Toggle::make('active')->label('Активний')->default(true)->inline(false),
                            CheckboxList::make('lead_types')->label('Які заявки надсилати')->options(LeadType::class)->columns(2)->columnSpanFull()
                                ->helperText('Нічого не вибрано — надсилати всі типи.'),
                        ]),
                ]),
                Tab::make('Адміни бота')->icon(Heroicon::OutlinedShieldCheck)->schema([
                    Text::make('Адміни можуть підключати групи командою /connect. Перший адмін: php artisan app:telegram-add-admin {telegram_id}. Свій id підкаже @userinfobot.'),
                    Repeater::make('admins')->hiddenLabel()->addActionLabel('Додати адміна')->reorderable(false)->columns(2)
                        ->schema([
                            Hidden::make('id'),
                            TextInput::make('telegram_id')->label('Telegram id')->numeric()->required()->distinct(),
                            TextInput::make('name')->label('Ім’я'),
                        ]),
                ]),
                Tab::make('Сповіщення')->icon(Heroicon::OutlinedBell)->schema([
                    Section::make('Що показувати в повідомленні про заявку')->columns(2)->schema([
                        Toggle::make('notification.type')->label('Тип заявки'),
                        Toggle::make('notification.name')->label('Ім’я'),
                        Toggle::make('notification.phone')->label('Телефон'),
                        Toggle::make('notification.company')->label('Заклад'),
                        Toggle::make('notification.comment')->label('Коментар та обсяг'),
                        Toggle::make('notification.product')->label('Позиція'),
                        Toggle::make('notification.source')->label('Джерело (сайт / mini app / бот)'),
                        Toggle::make('notification.status')->label('Статус'),
                        Toggle::make('notification.write_button')->label('Кнопка «Написати клієнту»'),
                    ]),
                ]),
                Tab::make('Тексти бота')->icon(Heroicon::OutlinedChatBubbleLeftRight)->schema([
                    Textarea::make('texts.welcome')->label('Привітання (/start)')->rows(4)->required(),
                    Textarea::make('texts.ask_contact')->label('Прохання контакту')->rows(2)->required(),
                    Textarea::make('texts.ask_company')->label('Запитання про заклад')->rows(2)->required(),
                    Textarea::make('texts.thanks')->label('Подяка після заявки')->rows(2)->required(),
                    TextInput::make('texts.price_caption')->label('Підпис до прайсу')->required()->maxLength(900),
                ]),
                Tab::make('Меню і команди')->icon(Heroicon::OutlinedListBullet)->schema([
                    TextInput::make('menu.button_text')->label('Назва кнопки меню бота (відкриває mini app)')->required()->maxLength(30),
                    ...collect(['catalog' => '/catalog', 'price' => '/price', 'samples' => '/samples', 'manager' => '/manager'])->map(
                        fn (string $cmd, string $key) => Section::make($cmd)->columns(2)->schema([
                            Toggle::make("menu.commands.{$key}.enabled")->label('Увімкнено')->inline(false),
                            TextInput::make("menu.commands.{$key}.description")->label('Підпис у списку команд')->maxLength(256)->required(),
                        ])
                    )->values()->all(),
                    Text::make('Після збереження натисніть «Перевстановити webhook» на вкладці «Бот», щоб Telegram отримав новий список команд.'),
                ]),
                Tab::make('Канал')->icon(Heroicon::OutlinedMegaphone)->schema([
                    Text::make('Канал, куди ШІ-помічник (за вашим підтвердженням) публікує закріплений пост з каталогом і пости про товари. Додайте бота адміністратором каналу з правом публікувати й закріплювати.'),
                    TextInput::make('channel_id')->label('Канал')->placeholder('@bakinsky_channel або -1001234567890')->maxLength(80)
                        ->helperText('Порожньо — береться з TELEGRAM_CHANNEL_ID. Пости не дублюються: повторна публікація оновлює вже наявний.'),
                ]),
                Tab::make('Прайс')->icon(Heroicon::OutlinedDocumentText)->schema([
                    Radio::make('price_mode')->label('Звідки брати PDF')->options([
                        'auto' => 'Згенерувати автоматично з каталогу',
                        'upload' => 'Використати мій PDF',
                    ])->live()->required(),
                    FileUpload::make('price_file')->label('PDF прайсу')->disk('local')->directory('telegram')->acceptedFileTypes(['application/pdf'])
                        ->maxSize(10240)->visible(fn ($get) => $get('price_mode') === 'upload')->helperText('Файл надсилається клієнтам як price-list.pdf.'),
                    Text::make(fn () => $this->priceStatus()),
                ]),
            ]),
        ]);
    }

    public function content(Schema $schema): Schema
    {
        return $schema->components([
            Form::make([EmbeddedSchema::make('form')])
                ->id('form')
                ->livewireSubmitHandler('save')
                ->footer([Actions::make([Action::make('save')->label('Зберегти')->submit('save')])]),
        ]);
    }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('webhook')->label('Перевстановити webhook')->icon(Heroicon::OutlinedArrowPath)->color('gray')->requiresConfirmation()
                ->modalDescription('Webhook, список команд і кнопка меню будуть записані в Telegram заново за збереженими налаштуваннями.')
                ->action(function () {
                    try {
                        $menu = app(BotMenu::class);
                        $menu->installWebhook(app(Nutgram::class));
                        $menu->installMenu(app(Nutgram::class));
                        Notification::make()->success()->title('Webhook і меню бота оновлено')->send();
                    } catch (Throwable $e) {
                        Notification::make()->danger()->title('Telegram відхилив запит')->body($e->getMessage())->send();
                    }
                    $this->refreshWebhook();
                }),
            Action::make('price')->label('Оновити прайс')->icon(Heroicon::OutlinedDocumentArrowDown)->color('gray')
                ->action(function () {
                    try {
                        app(PriceList::class)->regenerate();
                        Notification::make()->success()->title('Прайс перегенеровано')->send();
                    } catch (Throwable $e) {
                        Notification::make()->danger()->title('Не вдалося створити PDF')->body($e->getMessage())->send();
                    }
                }),
        ];
    }

    public function sendTest(string $item): void
    {
        $row = $this->data['recipients'][$item] ?? null;

        if (! $row || ! filled($row['chat_id'] ?? null)) {
            return;
        }

        try {
            app(Nutgram::class)->sendMessage(text: 'Тестове повідомлення: сюди надходитимуть нові заявки «Бакинський Бульвар».', chat_id: (int) $row['chat_id']);
            Notification::make()->success()->title('Тест надіслано')->send();
        } catch (Throwable $e) {
            Notification::make()->danger()->title('Не вдалося надіслати')->body($e->getMessage())->send();
        }
    }

    public function save(): void
    {
        $s = $this->form->getState();

        $recipients = collect($s['recipients'] ?? [])->values();
        $admins = collect($s['admins'] ?? [])->values();

        if ($recipients->pluck('chat_id')->duplicates()->isNotEmpty()) {
            Notification::make()->danger()->title('Один chat id вказано двічі')->send();

            return;
        }

        $settings = app(TelegramSettings::class);
        $settings->replace('texts', $s['texts']);
        $settings->replace('notification', array_map('boolval', $s['notification']));
        $settings->replace('menu', $s['menu']);

        $channel = $settings->group('channel');
        $channelId = filled($s['channel_id'] ?? null) ? trim($s['channel_id']) : null;
        $settings->replace('channel', ['chat_id' => $channelId, 'messages' => $channelId === $channel['chat_id'] ? $channel['messages'] : []]);

        $file = is_array($s['price_file'] ?? null) ? Arr::first($s['price_file']) : ($s['price_file'] ?? null);
        $price = $settings->group('price');
        $changed = $price['file'] !== $file || $price['mode'] !== $s['price_mode'];
        $settings->save('price', ['mode' => $s['price_mode'], 'file' => $file] + ($changed ? ['file_id' => null, 'file_hash' => null] : []));

        $this->sync(TelegramRecipient::class, $recipients, fn ($r) => [
            'chat_id' => (int) $r['chat_id'], 'title' => $r['title'] ?? null, 'type' => $r['type'] ?? 'group',
            'active' => (bool) ($r['active'] ?? true), 'lead_types' => array_values($r['lead_types'] ?? []),
        ]);
        $this->sync(TelegramAdmin::class, $admins, fn ($a) => ['telegram_id' => (int) $a['telegram_id'], 'name' => $a['name'] ?? null]);

        Notification::make()->success()->title('Збережено')->send();
        $this->mount();
    }

    /** Create / update the rows that are in the form and delete the ones that were removed. */
    private function sync(string $model, $rows, callable $attributes): void
    {
        $keep = [];

        foreach ($rows as $row) {
            $record = ! empty($row['id']) ? $model::find($row['id']) : null;
            $record ? $record->update($attributes($row)) : $record = $model::create($attributes($row));
            $keep[] = $record->id;
        }

        $model::whereNotIn('id', $keep)->delete();
    }

    private function statusHtml(): HtmlString
    {
        $username = config('bakinsky.telegram.bot_username');
        $w = $this->webhook;
        $e = fn ($v) => e((string) $v);
        $rows = [
            'Бот' => $username ? '<a href="https://t.me/'.$e(ltrim($username, '@')).'" target="_blank" rel="noopener" class="underline">@'.$e(ltrim($username, '@')).'</a>' : 'TELEGRAM_BOT_USERNAME не задано',
            'Токен' => filled(config('bakinsky.telegram.token')) ? 'задано' : '<b>не задано</b> (TELEGRAM_BOT_TOKEN)',
            'Секрет webhook' => filled(config('bakinsky.telegram.webhook_secret')) ? 'задано' : '<b>не задано</b> (TELEGRAM_WEBHOOK_SECRET)',
            'Webhook' => ($w['ok'] ?? false) ? 'працює: '.$e($w['url']) : '<b>не активний</b>'.($w['error'] ? ' — '.$e($w['error']).($w['error_at'] ? ' ('.$e($w['error_at']).')' : '') : ''),
            'Черга оновлень' => $e($w['pending'] ?? 0),
            'Mini app' => $e(app(TelegramSettings::class)->miniAppUrl()),
        ];

        return new HtmlString('<dl class="grid gap-y-2" style="grid-template-columns:max-content 1fr;column-gap:1.5rem">'.collect($rows)->map(fn ($v, $k) => "<dt class=\"font-medium\">$k</dt><dd>$v</dd>")->implode('').'</dl>');
    }

    private function priceStatus(): string
    {
        $p = app(TelegramSettings::class)->group('price');

        return $p['generated_at']
            ? 'Автопрайс створено: '.now()->parse($p['generated_at'])->timezone('Europe/Kyiv')->format('d.m.Y H:i').'. Перегенерується сам, коли змінюється каталог.'
            : 'Автопрайс ще не створювали: він з’явиться при першому запиті або після «Оновити прайс».';
    }
}
