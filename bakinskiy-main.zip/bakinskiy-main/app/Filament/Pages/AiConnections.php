<?php

namespace App\Filament\Pages;

use App\Enums\Ability;
use App\Mcp\Support\McpAccess;
use App\Models\McpAuditLog;
use App\Models\User;
use BackedEnum;
use Carbon\Carbon;
use Filament\Actions\Action;
use Filament\Forms\Components\CheckboxList;
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Facades\DB;
use Laravel\Sanctum\PersonalAccessToken;

/** How to connect Claude / ChatGPT, who is connected right now, and personal tokens for scripts. Staff see their own; admins see everyone's. */
class AiConnections extends Page
{
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedSparkles;

    protected static ?string $navigationLabel = 'Підключення ШІ';

    protected static ?string $title = 'Підключення ШІ';

    protected static ?string $slug = 'ai-connections';

    protected static ?int $navigationSort = 89;

    protected string $view = 'filament.pages.ai-connections';

    /** The token that was just created: shown once, never stored in plain text. */
    public ?string $newToken = null;

    public static function canAccess(): bool
    {
        $user = auth()->user();

        return $user instanceof User && $user->role !== null;
    }

    private function seesAll(): bool
    {
        return auth()->user()?->hasAbility(Ability::SystemRead) === true;
    }

    public function serverUrl(): string
    {
        return url('/mcp');
    }

    /** @return list<array{id: string, client: string, user: string, since: string, last: ?string, expires: ?string}> */
    public function connections(): array
    {
        $rows = DB::table('oauth_access_tokens as t')
            ->join('oauth_clients as c', 'c.id', '=', 't.client_id')
            ->where('t.revoked', false)->where(fn ($q) => $q->whereNull('t.expires_at')->orWhere('t.expires_at', '>', now()))
            ->when(! $this->seesAll(), fn ($q) => $q->where('t.user_id', auth()->id()))
            ->orderByDesc('t.created_at')->limit(100)
            ->get(['t.id', 't.user_id', 't.created_at', 't.expires_at', 'c.name as client']);

        $users = User::whereIn('id', $rows->pluck('user_id')->filter())->pluck('name', 'id');

        return $rows->map(function ($r) use ($users) {
            $last = McpAuditLog::where('user_id', $r->user_id)->latest('id')->value('created_at');

            return [
                'id' => $r->id,
                'client' => $r->client,
                'user' => $users[$r->user_id] ?? '—',
                'since' => Carbon::parse($r->created_at)->timezone('Europe/Kyiv')->format('d.m.Y H:i'),
                'last' => $last ? Carbon::parse($last)->timezone('Europe/Kyiv')->format('d.m.Y H:i') : null,
                'expires' => $r->expires_at ? Carbon::parse($r->expires_at)->timezone('Europe/Kyiv')->format('d.m.Y') : null,
            ];
        })->all();
    }

    /** @return list<array{id: int, name: string, user: string, abilities: string, last: ?string}> */
    public function tokens(): array
    {
        return PersonalAccessToken::where('tokenable_type', User::class)
            ->when(! $this->seesAll(), fn ($q) => $q->where('tokenable_id', auth()->id()))
            ->with('tokenable')->latest('id')->limit(100)->get()
            ->map(fn (PersonalAccessToken $t) => [
                'id' => $t->id,
                'name' => $t->name,
                'user' => $t->tokenable?->name ?? '—',
                'abilities' => in_array('*', $t->abilities ?? [], true) ? 'усі права ролі' : implode(', ', $t->abilities ?? []),
                'last' => $t->last_used_at?->timezone('Europe/Kyiv')->format('d.m.Y H:i'),
            ])->all();
    }

    public function revokeConnection(string $id): void
    {
        $query = DB::table('oauth_access_tokens')->where('id', $id)->when(! $this->seesAll(), fn ($q) => $q->where('user_id', auth()->id()));

        if ($query->update(['revoked' => true])) {
            DB::table('oauth_refresh_tokens')->where('access_token_id', $id)->update(['revoked' => true]);
            Notification::make()->success()->title('Доступ відкликано')->body('Клієнт більше не зможе звертатися до магазину.')->send();
        }
    }

    public function revokeToken(int $id): void
    {
        $token = PersonalAccessToken::where('tokenable_type', User::class)->when(! $this->seesAll(), fn ($q) => $q->where('tokenable_id', auth()->id()))->find($id);
        $token?->delete();
        $token && Notification::make()->success()->title('Токен відкликано')->send();
    }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('createToken')->label('Створити токен для Claude / скрипта')->icon(Heroicon::OutlinedKey)
                ->modalHeading('Персональний токен')
                ->modalDescription('Для Claude Code та скриптів. Токен показується один раз: скопіюйте його одразу. Він діє від вашого імені й не може мати більше прав, ніж ваша роль.')
                ->schema([
                    TextInput::make('name')->label('Назва (для чого)')->required()->maxLength(60)->default('Claude')->placeholder('Claude Code на ноутбуці'),
                    CheckboxList::make('abilities')->label('Права')->options(fn () => collect(Ability::labels())->only(auth()->user()->role->abilities())->all())
                        ->default(fn () => auth()->user()->role->abilities())->required()->columns(1),
                ])
                ->action(function (array $data) {
                    $allowed = auth()->user()->role->abilities();
                    $abilities = array_values(array_intersect($data['abilities'], $allowed));
                    $this->newToken = auth()->user()->createToken($data['name'], $abilities)->plainTextToken;
                }),
        ];
    }

    public function dismissToken(): void
    {
        $this->newToken = null;
    }

    /** The rights this user has through MCP, for the page. */
    /** @return list<string> */
    public function myAbilities(): array
    {
        $user = auth()->user();

        return array_values(array_map(fn ($a) => Ability::labels()[$a], array_filter(Ability::all(), fn ($a) => McpAccess::allows($user, $a))));
    }
}
