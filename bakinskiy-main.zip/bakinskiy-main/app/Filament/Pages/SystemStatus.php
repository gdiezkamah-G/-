<?php

namespace App\Filament\Pages;

use App\Enums\UserRole;
use App\Services\Deploy\BackupManager;
use App\Services\Deploy\Check;
use App\Services\Deploy\Doctor;
use App\Services\Telegram\WebhookInstaller;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\Facades\Artisan;
use Throwable;

/** The same checks as `php artisan app:doctor`, with buttons for the usual fixes. */
class SystemStatus extends Page
{
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedHeart;

    protected static ?string $navigationLabel = 'Стан системи';

    protected static ?string $title = 'Стан системи';

    protected static ?string $slug = 'system';

    protected static ?int $navigationSort = 95;

    protected string $view = 'filament.pages.system-status';

    /** @var list<array{status: string, name: string, detail: string}> */
    public array $checks = [];

    public static function canAccess(): bool
    {
        return auth()->user()?->role === UserRole::Admin;
    }

    public function mount(): void
    {
        $this->refreshChecks();
    }

    public function refreshChecks(): void
    {
        $this->checks = array_map(fn (Check $c) => $c->toArray(), app(Doctor::class)->run());
    }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('refresh')->label('Перевірити знову')->icon(Heroicon::OutlinedArrowPath)->color('gray')
                ->action(fn () => $this->refreshChecks()),
            Action::make('webhook')->label('Перевстановити webhook')->icon(Heroicon::OutlinedSignal)->color('gray')->requiresConfirmation()
                ->action(function () {
                    $r = app(WebhookInstaller::class)->ensure(force: true);
                    $notice = Notification::make()->title($r['message']);
                    in_array($r['state'], ['installed', 'unchanged'], true) ? $notice->success() : $notice->warning();
                    $notice->send();
                    $this->refreshChecks();
                }),
            Action::make('cache')->label('Оновити кеш')->icon(Heroicon::OutlinedBolt)->color('gray')
                ->action(function () {
                    $this->run(fn () => [Artisan::call('optimize:clear'), Artisan::call('optimize'), Artisan::call('filament:optimize')], 'Кеш оновлено');
                }),
            Action::make('worker')->label('Перезапустити воркер')->icon(Heroicon::OutlinedPower)->color('gray')->requiresConfirmation()
                ->modalDescription('Воркер завершить поточне завдання й підніметься знову з новим кодом (його перезапускає Docker).')
                ->action(fn () => $this->run(fn () => Artisan::call('queue:restart'), 'Воркер перезапуститься протягом хвилини')),
            Action::make('backup')->label('Створити бекап зараз')->icon(Heroicon::OutlinedArchiveBoxArrowDown)->color('gray')
                ->action(function () {
                    $this->run(function () {
                        $r = app(BackupManager::class)->run((int) config('bakinsky.backup.keep_days'));
                        $this->refreshChecks();

                        return $r;
                    }, 'Бекап створено');
                }),
        ];
    }

    private function run(callable $fn, string $success): void
    {
        try {
            $fn();
            Notification::make()->success()->title($success)->send();
        } catch (Throwable $e) {
            Notification::make()->danger()->title('Не вдалося')->body($e->getMessage())->send();
        }
        $this->refreshChecks();
    }
}
