<?php

namespace App\Filament\Pages;

use App\Enums\Ability;
use App\Enums\PriceMode;
use App\Models\Setting;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Forms\Components\Radio;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Components\Actions;
use Filament\Schemas\Components\EmbeddedSchema;
use Filament\Schemas\Components\Form;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;

class ManageSettings extends Page
{
    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedCog6Tooth;

    protected static ?string $navigationLabel = 'Налаштування';

    protected static ?string $title = 'Налаштування сайту';

    /** Contact details shown in the phone app. Empty ones are not shown. */
    public const CONTACT_KEYS = [
        'contact_phone' => 'Телефон',
        'contact_email' => 'E-mail',
        'contact_city' => 'Місто',
        'contact_address' => 'Адреса виробництва',
        'contact_hours' => 'Графік роботи',
    ];

    public const META_FEED_KEYS = [
        'meta_feed_enabled' => 'Увімкнути фід',
        'meta_feed_brand' => 'Бренд',
        'meta_feed_store_url' => 'URL магазину',
        'meta_feed_image_url' => 'Зображення за замовчуванням',
    ];

    public const SEO_KEYS = [
        'seo_default_title' => 'Назва сайту',
        'seo_default_description' => 'Опис сайту',
        'seo_og_image_url' => 'Зображення для соцмереж',
        'seo_org_phone' => 'Телефон організації',
        'seo_org_email' => 'E-mail організації',
        'seo_org_address' => 'Адреса організації',
        'seo_org_city' => 'Місто організації',
        'seo_org_hours' => 'Графік роботи організації',
        'seo_instagram_url' => 'Instagram',
        'seo_facebook_url' => 'Facebook',
        'seo_google_analytics_id' => 'Google Analytics ID',
        'seo_meta_pixel_id' => 'Meta Pixel ID',
        'seo_gtm_id' => 'Google Tag Manager ID',
    ];

    public static function canAccess(): bool
    {
        return auth()->user()?->hasAbility(Ability::SiteWrite) === true;
    }

    /** @var array<string, mixed> */
    public ?array $data = [];

    public function mount(): void
    {
        $from = Setting::get('price_from');

        $this->form->fill([
            ...collect(self::CONTACT_KEYS)->mapWithKeys(fn ($label, $key) => [$key => Setting::get($key)])->all(),
            'price_mode' => Setting::get('price_mode', PriceMode::Ask->value),
            'price_from' => filled($from) ? (int) $from / 100 : null,
            'meta_feed_enabled' => Setting::get('meta_feed_enabled', '0') === '1',
            'meta_feed_brand' => Setting::get('meta_feed_brand', 'Бакинський Бульвар'),
            'meta_feed_store_url' => Setting::get('meta_feed_store_url', config('app.url')),
            'meta_feed_image_url' => Setting::get('meta_feed_image_url', url('/assets/og-default.png')),
            ...collect(self::SEO_KEYS)->mapWithKeys(fn ($label, $key) => [$key => Setting::get($key)])->all(),
        ]);
    }

    public function form(Schema $schema): Schema
    {
        return $schema->statePath('data')->components([
            Radio::make('price_mode')->label('Режим показу цін')->options(PriceMode::class)->required()->live(),
            TextInput::make('price_from')->label('Ціна «від», ₴ / кг')->numeric()->minValue(0)
                ->visible(fn ($get) => ($get('price_mode') instanceof PriceMode ? $get('price_mode') : PriceMode::tryFrom((string) $get('price_mode'))) === PriceMode::From),
            Section::make('Контакти (застосунок, сторінка «Контакти»)')->description('Порожні поля на сайті не показуються.')->columns(2)->schema([
                TextInput::make('contact_phone')->label('Телефон')->tel()->placeholder('+380 50 123 45 67')->maxLength(40),
                TextInput::make('contact_email')->label('E-mail')->email()->maxLength(120),
                TextInput::make('contact_city')->label('Місто')->maxLength(80),
                TextInput::make('contact_address')->label('Адреса виробництва')->maxLength(200),
                TextInput::make('contact_hours')->label('Графік роботи')->placeholder('пн–пт, 9:00–18:00')->maxLength(120),
            ]),
            Section::make('Товарний фід Meta (Instagram / Facebook)')
                ->description('Після збереження передайте Commerce Manager URL фіду: '.url('/feeds/meta/products.csv'))
                ->columns(2)->schema([
                    Toggle::make('meta_feed_enabled')->label('Публікувати фід')->inline(false),
                    TextInput::make('meta_feed_brand')->label('Бренд')->required()->maxLength(120),
                    TextInput::make('meta_feed_store_url')->label('URL магазину')->url()->required()->maxLength(255),
                    TextInput::make('meta_feed_image_url')->label('Зображення за замовчуванням')->url()->required()->maxLength(255),
                ]),
            Section::make('SEO, соцмережі та аналітика')
                ->description('Порожні поля не виводяться на сайт. ID аналітики можна отримати у відповідних сервісах.')
                ->columns(2)->schema([
                    TextInput::make('seo_default_title')->label('Назва сайту')->maxLength(160),
                    TextInput::make('seo_og_image_url')->label('Зображення для соцмереж')->url()->maxLength(255),
                    TextInput::make('seo_default_description')->label('Опис сайту')->maxLength(255)->columnSpanFull(),
                    TextInput::make('seo_org_phone')->label('Телефон організації')->tel(),
                    TextInput::make('seo_org_email')->label('E-mail організації')->email(),
                    TextInput::make('seo_org_address')->label('Адреса'),
                    TextInput::make('seo_org_city')->label('Місто'),
                    TextInput::make('seo_org_hours')->label('Графік роботи'),
                    TextInput::make('seo_instagram_url')->label('Instagram')->url(),
                    TextInput::make('seo_facebook_url')->label('Facebook')->url(),
                    TextInput::make('seo_google_analytics_id')->label('Google Analytics ID')->placeholder('G-XXXXXXXXXX'),
                    TextInput::make('seo_meta_pixel_id')->label('Meta Pixel ID'),
                    TextInput::make('seo_gtm_id')->label('Google Tag Manager ID')->placeholder('GTM-XXXXXXX'),
                ]),
        ]);
    }

    public function content(Schema $schema): Schema
    {
        return $schema->components([
            Form::make([EmbeddedSchema::make('form')])
                ->id('form')
                ->livewireSubmitHandler('save')
                ->footer([Actions::make([Action::make('save')->label('Зберегти')->submit('save')])]),
        ]);
    }

    public function save(): void
    {
        $state = $this->form->getState();

        $mode = $state['price_mode'];
        Setting::put('price_mode', $mode instanceof PriceMode ? $mode->value : $mode);
        foreach (array_keys(self::CONTACT_KEYS) as $key) {
            Setting::put($key, filled($state[$key] ?? null) ? trim($state[$key]) : null);
        }

        Setting::put('price_from', filled($state['price_from'] ?? null) ? (string) round($state['price_from'] * 100) : null);

        Setting::put('meta_feed_enabled', ! empty($state['meta_feed_enabled']) ? '1' : '0');
        Setting::put('meta_feed_brand', trim($state['meta_feed_brand'] ?? 'Бакинський Бульвар'));
        Setting::put('meta_feed_store_url', rtrim(trim($state['meta_feed_store_url'] ?? config('app.url')), '/'));
        Setting::put('meta_feed_image_url', trim($state['meta_feed_image_url'] ?? url('/assets/og-default.png')));
        foreach (array_keys(self::SEO_KEYS) as $key) {
            Setting::put($key, filled($state[$key] ?? null) ? trim((string) $state[$key]) : null);
        }

        Notification::make()->success()->title('Збережено')->send();
    }
}
