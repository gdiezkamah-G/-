<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Response;

class SeoController extends Controller
{
    public function sitemap(): Response
    {
        $urls = collect([
            ['loc' => route('home'), 'lastmod' => null, 'priority' => '1.0'],
            ['loc' => route('catalog'), 'lastmod' => Product::published()->max('updated_at'), 'priority' => '0.9'],
        ])->concat(
            Product::published()->get(['slug', 'updated_at'])->map(fn ($p) => [
                'loc' => route('product', $p->slug),
                'lastmod' => $p->updated_at,
                'priority' => '0.8',
            ]),
        );

        return response()
            ->view('seo.sitemap', ['urls' => $urls])
            ->header('Content-Type', 'application/xml; charset=UTF-8');
    }

    public function robots(): Response
    {
        $lines = app()->environment('production')
            ? ['User-agent: *', 'Disallow: /admin', 'Disallow: /livewire', 'Disallow: /tg', 'Allow: /']
            : ['User-agent: *', 'Disallow: /'];   // never index staging or local copies

        $lines[] = '';
        $lines[] = 'Sitemap: '.route('sitemap');

        return response(implode("\n", $lines)."\n", 200, ['Content-Type' => 'text/plain; charset=UTF-8']);
    }
}
