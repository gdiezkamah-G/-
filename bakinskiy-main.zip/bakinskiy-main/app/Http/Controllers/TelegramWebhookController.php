<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use SergiX44\Nutgram\Nutgram;

class TelegramWebhookController extends Controller
{
    /** Telegram sends the secret we registered in the X-Telegram-Bot-Api-Secret-Token header. */
    public function __invoke(Request $request, Nutgram $bot): Response
    {
        $secret = config('bakinsky.telegram.webhook_secret');

        abort_unless(filled($secret) && hash_equals((string) $secret, (string) $request->header('X-Telegram-Bot-Api-Secret-Token')), 403);

        $bot->run();

        return response()->noContent();
    }
}
