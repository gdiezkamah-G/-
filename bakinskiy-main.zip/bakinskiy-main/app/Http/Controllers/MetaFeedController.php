<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Setting;
use Illuminate\Http\Response;

class MetaFeedController extends Controller
{
    public function __invoke(): Response
    {
        if (Setting::get('meta_feed_enabled', '0') !== '1') {
            abort(404);
        }

        $storeUrl = rtrim(Setting::get('meta_feed_store_url', config('app.url')), '/');
        $brand = Setting::get('meta_feed_brand', 'Бакинський Бульвар');
        $imageUrl = Setting::get('meta_feed_image_url', url('/assets/og-default.png'));
        $products = Product::published()->with(['category', 'activeVariants'])->get();
        $rows = [];

        foreach ($products as $product) {
            foreach ($product->activeVariants as $variant) {
                if (! $variant->sku || $variant->price === null) {
                    continue;
                }

                $rows[] = [
                    'id' => $variant->sku,
                    'item_group_id' => (string) $product->id,
                    'title' => trim($product->name.' — '.$variant->size_label),
                    'description' => $product->description ?: $product->name,
                    'availability' => $variant->availability ?: 'in stock',
                    'condition' => 'new',
                    'price' => number_format($variant->price / 100, 2, '.', '').' '.$variant->currency,
                    'link' => $storeUrl.'/produkciya/'.$product->slug,
                    'image_link' => $imageUrl,
                    'brand' => $brand,
                    'google_product_category' => 'Food, Beverages & Tobacco > Food Items',
                ];
            }
        }

        $columns = ['id', 'item_group_id', 'title', 'description', 'availability', 'condition', 'price', 'link', 'image_link', 'brand', 'google_product_category'];
        $csv = fopen('php://temp', 'w+');
        fputcsv($csv, $columns);
        foreach ($rows as $row) {
            fputcsv($csv, array_map(fn (string $column) => $row[$column], $columns));
        }
        rewind($csv);
        $contents = stream_get_contents($csv);
        fclose($csv);

        return response($contents, 200, [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => 'inline; filename="meta-products.csv"',
            'Cache-Control' => 'public, max-age=300',
        ]);
    }
}
