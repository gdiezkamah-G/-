<?php

namespace App\Http\Controllers;

use App\Enums\PriceMode;
use App\Models\Category;
use App\Models\Setting;
use Illuminate\Http\Response;
use Illuminate\Support\Str;

/** Telegram Mini App: one long page with the whole published catalog, rendered on the server. */
class TgController extends Controller
{
    public function __invoke(): Response
    {
        $categories = Category::orderBy('sort')
            ->with(['products' => fn ($q) => $q->published()->with('activeVariants')])
            ->get()
            ->filter(fn (Category $c) => $c->products->isNotEmpty())
            ->values();

        $site = (string) config('app.url');
        $mode = PriceMode::tryFrom((string) Setting::get('price_mode', 'ask')) ?? PriceMode::Ask;
        $from = Setting::get('price_from');
        $price = match ($mode) {
            PriceMode::From => 'від '.(filled($from) ? number_format((int) $from / 100, 0, ',', ' ') : 'ХХХ').' ₴ / кг',
            PriceMode::Login => 'для партнерів',
            default => 'за запитом',
        };

        return response()->view('tg.index', [
            'categories' => $categories,
            'price' => $price,
            'contacts' => [
                'phone' => Setting::get('contact_phone'),
                'phone_href' => Setting::get('contact_phone') ? 'tel:'.preg_replace('/[^\d+]/', '', (string) Setting::get('contact_phone')) : null,
                'city' => Setting::get('contact_city') ?: Setting::get('contact_address'),
                'site' => $site,
                'site_label' => Str::after($site, '://'),
            ],
        ])->header('Cache-Control', 'no-store');
    }
}
