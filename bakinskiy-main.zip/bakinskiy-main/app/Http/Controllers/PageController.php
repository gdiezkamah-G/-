<?php

namespace App\Http\Controllers;

use App\Enums\PriceMode;
use App\Models\Category;
use App\Models\Product;
use App\Models\Setting;
use App\Support\UiMode;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class PageController extends Controller
{
    public function home(Request $request): Response
    {
        $products = Product::published()->with(['category', 'activeVariants'])->get();

        if (UiMode::isApp($request)) {
            return $this->render('app.home', ['products' => $products, 'categories' => $this->categoriesWith($products)]);
        }

        return $this->render('pages.home', ['products' => $products]);
    }

    public function catalog(Request $request): Response
    {
        $products = Product::published()->with(['category', 'activeVariants'])->get();
        $categories = Category::whereHas('products', fn ($q) => $q->published())->orderBy('sort')->get();

        return $this->render(UiMode::isApp($request) ? 'app.catalog' : 'pages.catalog', [
            'categories' => $categories,
            'products' => $products,
        ]);
    }

    public function product(Request $request, string $slug): Response
    {
        $product = Product::published()->with(['category', 'activeVariants'])->where('slug', $slug)->firstOrFail();

        return $this->render(UiMode::isApp($request) ? 'app.product' : 'pages.product', [
            'product' => $product,
            'jsonLd' => $this->productJsonLd($product),
            'related' => Product::published()->with(['category', 'activeVariants'])->whereKeyNot($product->id)->get(),
        ]);
    }

    /** Contacts, "Для HoReCa" and "Виробництво" exist as phone screens; their desktop pages come later (phase 1C). */
    public function appOnly(Request $request, string $screen): Response|RedirectResponse
    {
        if (! UiMode::isApp($request)) {
            return redirect()->route('home');
        }

        return $this->render("app.{$screen}", ['contacts' => $this->contacts()]);
    }

    public function offline(): Response
    {
        return response()->view('offline')->header('Cache-Control', 'no-cache');
    }

    /** Contact details come from the admin settings; empty ones are simply not shown. */
    private function contacts(): array
    {
        $phone = Setting::get('contact_phone');
        $bot = config('bakinsky.telegram.bot_username');

        return [
            'phone' => $phone,
            'phone_href' => $phone ? 'tel:'.preg_replace('/[^\d+]/', '', $phone) : null,
            'email' => Setting::get('contact_email'),
            'address' => Setting::get('contact_address'),
            'hours' => Setting::get('contact_hours'),
            'telegram' => $bot ? 'https://t.me/'.ltrim($bot, '@') : null,
        ];
    }

    /** @return Collection<int, Category> categories that have published products, with a pack tint */
    private function categoriesWith(Collection $products): Collection
    {
        return Category::orderBy('sort')->get()
            ->map(function (Category $c) use ($products) {
                $own = $products->where('category_id', $c->id);
                $c->setAttribute('products_count', $own->count());
                $c->setAttribute('hue', $own->first()?->hue ?? '#5a2a1c');

                return $c;
            })
            ->filter(fn (Category $c) => $c->products_count > 0)
            ->values();
    }

    private function render(string $view, array $data): Response
    {
        return response()->view($view, $data + ['contacts' => $this->contacts()])
            ->header('Vary', 'Cookie, User-Agent');
    }

    /** Schema.org Product. An offer is added only when the site shows a "from" price; never in ask/login modes. */
    private function productJsonLd(Product $product): array
    {
        $data = [
            '@context' => 'https://schema.org',
            '@type' => 'Product',
            'name' => trim($product->name.' '.$product->subtitle),
            'description' => $product->description ?: $product->short_tagline ?: $product->full_name,
            'url' => route('product', $product->slug),
            'image' => url('/assets/og-default.png'),
            'category' => $product->category->name,
            'brand' => ['@type' => 'Brand', 'name' => 'Бакинський Бульвар'],
            'sku' => $product->activeVariants->firstWhere('sku', '!=', null)?->sku,
        ];

        $offers = $product->activeVariants
            ->filter(fn ($variant) => $variant->price !== null)
            ->map(fn ($variant) => [
                '@type' => 'Offer',
                'sku' => $variant->sku,
                'name' => $variant->size_label,
                'priceCurrency' => $variant->currency ?: 'UAH',
                'price' => number_format($variant->price / 100, 2, '.', ''),
                'availability' => 'https://schema.org/'.match ($variant->availability ?: 'in stock') {
                    'out of stock' => 'OutOfStock',
                    'preorder' => 'PreOrder',
                    default => 'InStock',
                },
                'url' => route('product', $product->slug),
            ])->values()->all();

        if (! $offers && Setting::get('price_mode') === PriceMode::From->value && filled($from = Setting::get('price_from'))) {
            $offers[] = [
                '@type' => 'Offer',
                'priceCurrency' => 'UAH',
                'price' => number_format((int) $from / 100, 2, '.', ''),
                'availability' => 'https://schema.org/InStock',
                'url' => route('product', $product->slug),
            ];
        }

        if ($offers) {
            $data['offers'] = count($offers) === 1 ? $offers[0] : $offers;
        }

        return [
            '@context' => 'https://schema.org',
            '@graph' => [
                array_filter($data, fn ($v) => filled($v)),
                [
                    '@type' => 'BreadcrumbList',
                    'itemListElement' => [
                        ['@type' => 'ListItem', 'position' => 1, 'name' => 'Головна', 'item' => route('home')],
                        ['@type' => 'ListItem', 'position' => 2, 'name' => 'Продукція', 'item' => route('catalog')],
                        ['@type' => 'ListItem', 'position' => 3, 'name' => $product->name, 'item' => route('product', $product->slug)],
                    ],
                ],
            ],
        ];
    }
}
