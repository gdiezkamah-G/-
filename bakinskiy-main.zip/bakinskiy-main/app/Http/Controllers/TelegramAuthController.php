<?php

namespace App\Http\Controllers;

use App\Models\TelegramUser;
use App\Services\Telegram\TelegramUsers;
use App\Support\TelegramInitData;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use InvalidArgumentException;

/** Mini app sign-in: verifies initData, upserts the user, hands out a short-lived Sanctum token. No registration. */
class TelegramAuthController extends Controller
{
    public function auth(Request $request, TelegramUsers $users): JsonResponse
    {
        $data = $request->validate(['init_data' => 'required|string|max:4096']);

        try {
            $init = TelegramInitData::validate($data['init_data'], config('bakinsky.telegram.token'));
        } catch (InvalidArgumentException $e) {
            return response()->json(['message' => 'Невірні дані Telegram.'], 401);
        }

        $user = $users->upsert($init['user']);
        $user->tokens()->where('name', 'miniapp')->delete();
        $token = $user->createToken('miniapp', ['miniapp'], now()->addDay());

        return response()->json(['token' => $token->plainTextToken, 'start_param' => $init['start_param']] + $this->payload($user));
    }

    /** Fresh profile (the phone may have been shared in the bot after sign-in). */
    public function me(Request $request): JsonResponse
    {
        return response()->json($this->payload($request->user()));
    }

    private function payload(TelegramUser $user): array
    {
        return ['user' => [
            'name' => $user->full_name,
            'first_name' => $user->first_name,
            'phone' => $user->phone,
            'company' => $user->company,
        ]];
    }
}
