<?php

namespace App\Http\Middleware;

use App\Enums\Ability;
use App\Mcp\Support\McpAccess as Access;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/** After the token is validated: only staff with a role may use MCP, whatever the token says. */
class McpAccess
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = Access::user();

        if (! $user || ! $user->role) {
            return response()->json(['message' => 'Доступ до MCP мають лише користувачі адмінки.'], 403);
        }

        // a role that can do nothing here (no abilities at all) gets nothing either
        if (! array_filter(Ability::all(), fn ($a) => Access::allows($user, $a))) {
            return response()->json(['message' => 'Токен не дає жодного права.'], 403);
        }

        return $next($request);
    }
}
