<?php

namespace App\Telegram\Handlers;

use App\Models\TelegramLeadMessage;
use App\Models\TelegramRecipient;
use SergiX44\Nutgram\Nutgram;

/** A group that became a supergroup gets a new chat id: keep the recipient (and its message log) pointing at it. */
class ChatMigrationHandler
{
    public function __invoke(Nutgram $bot): void
    {
        $old = $bot->chatId();
        $new = $bot->message()?->migrate_to_chat_id;

        if (! $old || ! $new) {
            return;
        }

        TelegramRecipient::where('chat_id', $old)->update(['chat_id' => $new]);
        TelegramLeadMessage::where('chat_id', $old)->update(['chat_id' => $new]);
    }
}
