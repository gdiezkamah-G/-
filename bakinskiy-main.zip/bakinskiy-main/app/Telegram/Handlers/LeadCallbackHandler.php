<?php

namespace App\Telegram\Handlers;

use App\Enums\LeadStatus;
use App\Jobs\RefreshLeadMessages;
use App\Models\Lead;
use App\Models\TelegramLeadMessage;
use SergiX44\Nutgram\Nutgram;

/** Inline buttons under a lead: "Взяти в роботу" / "Закрити". */
class LeadCallbackHandler
{
    public function __invoke(Nutgram $bot, string $action, string $id): void
    {
        $lead = Lead::find((int) $id);
        $chatId = $bot->callbackQuery()?->message?->chat?->id;

        // the button must sit under a copy of this very lead, in a chat the bot posted it to
        if (! $lead || ! $chatId || ! TelegramLeadMessage::where('lead_id', $lead->id)->where('chat_id', $chatId)->exists()) {
            $bot->answerCallbackQuery(text: 'Заявку не знайдено.', show_alert: true);

            return;
        }

        $status = match ($action) {
            'take' => LeadStatus::InProgress,
            'close' => LeadStatus::Closed,
            default => null,
        };

        if (! $status || $lead->status === $status || ($lead->status === LeadStatus::Closed && $status === LeadStatus::InProgress)) {
            $bot->answerCallbackQuery(text: 'Уже оброблено.');

            return;
        }

        $from = $bot->user();
        $lead->update([
            'status' => $status,
            'handled_by' => trim($from->first_name.' '.$from->last_name) ?: ($from->username ? '@'.$from->username : (string) $from->id),
            'handled_at' => now(),
        ]);

        $bot->answerCallbackQuery(text: $status === LeadStatus::Closed ? 'Заявку закрито.' : 'Взято в роботу.');
        RefreshLeadMessages::dispatchSync($lead->id);
    }
}
