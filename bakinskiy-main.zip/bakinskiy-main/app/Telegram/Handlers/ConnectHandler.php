<?php

namespace App\Telegram\Handlers;

use App\Models\TelegramAdmin;
use App\Models\TelegramRecipient;
use App\Services\Telegram\TelegramSettings;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Properties\ChatType;

/** /connect in a group: only a TelegramAdmin may turn the group into a lead recipient. */
class ConnectHandler
{
    public function __invoke(Nutgram $bot): void
    {
        $chat = $bot->chat();

        if (! in_array($chat?->type, [ChatType::GROUP, ChatType::SUPERGROUP], true)) {
            $bot->sendMessage(TelegramSettings::system('group_only'));

            return;
        }

        if (! TelegramAdmin::isAdmin($bot->userId())) {
            $bot->sendMessage(TelegramSettings::system('not_admin'));

            return;
        }

        $recipient = TelegramRecipient::firstOrNew(['chat_id' => $chat->id]);
        $recipient->fill(['title' => $chat->title, 'type' => 'group'] + ($recipient->exists ? [] : ['active' => true]))->save();

        $bot->sendMessage(TelegramSettings::system('connected'));
    }
}
