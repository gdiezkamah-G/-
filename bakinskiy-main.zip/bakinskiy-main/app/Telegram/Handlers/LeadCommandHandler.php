<?php

namespace App\Telegram\Handlers;

use App\Services\Telegram\TelegramSettings;
use App\Telegram\Conversations\ManagerConversation;
use App\Telegram\Conversations\PriceConversation;
use App\Telegram\Conversations\SamplesConversation;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Properties\ChatType;

/** /price, /samples and /manager: start the matching conversation in a private chat. */
class LeadCommandHandler
{
    private const CONVERSATIONS = [
        'price' => PriceConversation::class,
        'samples' => SamplesConversation::class,
        'manager' => ManagerConversation::class,
    ];

    public function __construct(private TelegramSettings $settings) {}

    public static function for(string $command): callable
    {
        return fn (Nutgram $bot) => app(self::class)($bot, $command);
    }

    public function __invoke(Nutgram $bot, string $command): void
    {
        if ($bot->chat()?->type !== ChatType::PRIVATE) {
            $bot->sendMessage(TelegramSettings::system('private_only'));

            return;
        }

        if (! $this->settings->commandEnabled($command)) {
            $bot->sendMessage(TelegramSettings::system('disabled'));

            return;
        }

        self::CONVERSATIONS[$command]::begin($bot);
    }
}
