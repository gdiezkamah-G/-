<?php

namespace App\Telegram\Handlers;

use App\Services\Telegram\TelegramSettings;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Types\Keyboard\InlineKeyboardButton;
use SergiX44\Nutgram\Telegram\Types\Keyboard\InlineKeyboardMarkup;
use SergiX44\Nutgram\Telegram\Types\WebApp\WebAppInfo;

class CatalogHandler
{
    public function __construct(private TelegramSettings $settings) {}

    public function __invoke(Nutgram $bot): void
    {
        if (! $this->settings->commandEnabled('catalog')) {
            $bot->sendMessage(TelegramSettings::system('disabled'));

            return;
        }

        $bot->sendMessage(
            text: 'Наш каталог у застосунку:',
            reply_markup: InlineKeyboardMarkup::make()->addRow(
                InlineKeyboardButton::make(TelegramSettings::system('open_catalog'), web_app: new WebAppInfo($this->settings->miniAppUrl('catalog'))),
            ),
        );
    }
}
