<?php

namespace App\Telegram\Handlers;

use App\Models\TelegramRecipient;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Properties\ChatMemberStatus;

/** The bot was kicked from a group: stop sending leads there instead of failing on every lead. */
class BotRemovedHandler
{
    public function __invoke(Nutgram $bot): void
    {
        $status = $bot->chatMember()?->new_chat_member?->status;

        if (in_array($status, [ChatMemberStatus::LEFT, ChatMemberStatus::KICKED], true)) {
            TelegramRecipient::where('chat_id', $bot->chatId())->update(['active' => false]);
        }
    }
}
