<?php

namespace App\Telegram\Handlers;

use App\Models\TelegramAdmin;
use App\Models\TelegramRecipient;
use App\Services\Telegram\TelegramSettings;
use App\Services\Telegram\TelegramUsers;
use App\Telegram\Conversations\ManagerConversation;
use App\Telegram\Conversations\PriceConversation;
use App\Telegram\Conversations\SamplesConversation;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Properties\ChatType;
use SergiX44\Nutgram\Telegram\Types\Keyboard\InlineKeyboardButton;
use SergiX44\Nutgram\Telegram\Types\Keyboard\InlineKeyboardMarkup;
use SergiX44\Nutgram\Telegram\Types\WebApp\WebAppInfo;

/** /start, optionally with a deep-link parameter that the Mini App opens on: catalog | price | samples | manager | product_<slug> | contacts */
class StartHandler
{
    public function __construct(private TelegramSettings $settings, private TelegramUsers $users) {}

    public function __invoke(Nutgram $bot, ?string $param = null): void
    {
        if ($bot->chat()?->type !== ChatType::PRIVATE) {
            $bot->sendMessage(TelegramSettings::system('private_only'));

            return;
        }

        $this->users->upsert($bot->user());
        $this->registerAdminChat($bot);

        $param = trim((string) $param);

        match (true) {
            $param === 'price' => $this->enter($bot, 'price', PriceConversation::class),
            $param === 'samples' => $this->enter($bot, 'samples', SamplesConversation::class),
            $param === 'manager' => $this->enter($bot, 'manager', ManagerConversation::class),
            default => $this->welcome($bot, $param),
        };
    }

    private function enter(Nutgram $bot, string $command, string $conversation): void
    {
        if (! $this->settings->commandEnabled($command)) {
            $bot->sendMessage(TelegramSettings::system('disabled'));

            return;
        }

        $conversation::begin($bot);
    }

    private function welcome(Nutgram $bot, string $param): void
    {
        $startParam = match (true) {
            in_array($param, ['catalog', 'contacts'], true), str_starts_with($param, 'product_') => $param,
            default => null,
        };

        $keyboard = InlineKeyboardMarkup::make()->addRow(
            InlineKeyboardButton::make(
                TelegramSettings::system($startParam ? 'open_app' : 'open_catalog'),
                web_app: new WebAppInfo($this->settings->miniAppUrl($startParam)),
            ),
        );

        if (! $startParam) {
            $keyboard->addRow(
                ...collect(['price' => 'Прайс', 'samples' => 'Зразки', 'manager' => 'Менеджер'])
                    ->map(fn (string $label, string $p) => InlineKeyboardButton::make($label, web_app: new WebAppInfo($this->settings->miniAppUrl($p))))
                    ->values()->all(),
            );
        }

        $bot->sendMessage(text: $this->settings->text('welcome'), reply_markup: $keyboard);
    }

    /** An admin's private chat becomes a recipient the first time they press /start (they can switch it off in the admin). */
    private function registerAdminChat(Nutgram $bot): void
    {
        $id = $bot->userId();

        if (TelegramAdmin::isAdmin($id) && ! TelegramRecipient::where('chat_id', $id)->exists()) {
            TelegramRecipient::create(['chat_id' => $id, 'title' => trim($bot->user()->first_name.' '.$bot->user()->last_name), 'type' => 'private', 'active' => true]);
        }
    }
}
