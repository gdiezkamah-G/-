<?php

namespace App\Telegram\Handlers;

use App\Services\Telegram\TelegramUsers;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Types\Keyboard\ReplyKeyboardRemove;

/** A contact shared outside a conversation (e.g. via the Mini App "use my number" button): remember the phone. */
class ContactHandler
{
    public function __construct(private TelegramUsers $users) {}

    public function __invoke(Nutgram $bot): void
    {
        $contact = $bot->message()?->contact;

        // only the sender's own number counts
        if (! $contact || ($contact->user_id && $contact->user_id !== $bot->userId())) {
            return;
        }

        $this->users->upsert($bot->user())->update(['phone' => TelegramUsers::normalizePhone($contact->phone_number)]);
        $bot->sendMessage(text: 'Дякуємо, номер збережено.', reply_markup: ReplyKeyboardRemove::make(true));
    }
}
