<?php

namespace App\Telegram\Conversations;

use App\Enums\LeadType;

class ManagerConversation extends LeadConversation
{
    protected function type(): LeadType
    {
        return LeadType::Manager;
    }
}
