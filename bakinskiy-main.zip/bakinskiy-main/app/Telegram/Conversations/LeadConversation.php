<?php

namespace App\Telegram\Conversations;

use App\Actions\CreateLead;
use App\Enums\LeadSource;
use App\Enums\LeadType;
use App\Services\Telegram\PriceList;
use App\Services\Telegram\TelegramSettings;
use App\Services\Telegram\TelegramUsers;
use Illuminate\Support\Facades\Log;
use SergiX44\Nutgram\Conversations\Conversation;
use SergiX44\Nutgram\Nutgram;
use SergiX44\Nutgram\Telegram\Types\Keyboard\KeyboardButton;
use SergiX44\Nutgram\Telegram\Types\Keyboard\ReplyKeyboardMarkup;
use SergiX44\Nutgram\Telegram\Types\Keyboard\ReplyKeyboardRemove;
use Throwable;

/**
 * Collects a contact (and the venue name), saves a Lead and, for the price list, sends the PDF.
 * A known user (we already have the phone) skips the questions; a new Lead is created every time.
 */
abstract class LeadConversation extends Conversation
{
    public ?string $phone = null;

    public ?string $company = null;

    abstract protected function type(): LeadType;

    /** Whether to ask for the venue name when we do not know it yet. */
    protected function asksCompany(): bool
    {
        return false;
    }

    private function settings(): TelegramSettings
    {
        return app(TelegramSettings::class);
    }

    public function start(Nutgram $bot): void
    {
        $user = app(TelegramUsers::class)->upsert($bot->user());
        $this->phone = $user->phone;
        $this->company = $user->company;

        if ($this->phone) {
            $this->afterContact($bot);

            return;
        }

        $bot->sendMessage(
            text: $this->settings()->text('ask_contact'),
            reply_markup: ReplyKeyboardMarkup::make(resize_keyboard: true, one_time_keyboard: true)
                ->addRow(KeyboardButton::make(TelegramSettings::system('share_contact'), request_contact: true))
                ->addRow(KeyboardButton::make(TelegramSettings::system('type_phone'))),
        );
        $this->next('contact');
    }

    public function contact(Nutgram $bot): void
    {
        $message = $bot->message();
        $text = trim((string) $message?->text);

        if ($message?->contact) {
            $this->phone = TelegramUsers::normalizePhone($message->contact->phone_number);
        } elseif ($text === TelegramSettings::system('type_phone')) {
            $bot->sendMessage(text: TelegramSettings::system('manual_phone'), reply_markup: ReplyKeyboardRemove::make(true));
            $this->next('contact');

            return;
        } elseif (TelegramUsers::looksLikePhone($text)) {
            $this->phone = TelegramUsers::normalizePhone($text);
        } else {
            $bot->sendMessage(text: TelegramSettings::system('invalid_phone'));
            $this->next('contact');

            return;
        }

        app(TelegramUsers::class)->upsert($bot->user())->update(['phone' => $this->phone]);
        $this->afterContact($bot);
    }

    private function afterContact(Nutgram $bot): void
    {
        if ($this->asksCompany() && ! $this->company) {
            $bot->sendMessage(
                text: $this->settings()->text('ask_company'),
                reply_markup: ReplyKeyboardMarkup::make(resize_keyboard: true, one_time_keyboard: true)
                    ->addRow(KeyboardButton::make(TelegramSettings::system('skip'))),
            );
            $this->next('company');

            return;
        }

        $this->finish($bot);
    }

    public function company(Nutgram $bot): void
    {
        $text = trim((string) $bot->message()?->text);

        if ($text !== '' && $text !== TelegramSettings::system('skip')) {
            $this->company = mb_substr($text, 0, 160);
            app(TelegramUsers::class)->upsert($bot->user())->update(['company' => $this->company]);
        }

        $this->finish($bot);
    }

    private function finish(Nutgram $bot): void
    {
        $user = app(TelegramUsers::class)->upsert($bot->user());

        $lead = app(CreateLead::class)->handle([
            'company' => $this->company,
            'contact_name' => $user->full_name,
            'phone' => $this->phone ?? $user->phone,
        ], $this->type(), LeadSource::Bot, $user);

        if (! $lead) {
            $bot->sendMessage(text: 'Забагато запитів поспіль. Спробуйте за хвилину.', reply_markup: ReplyKeyboardRemove::make(true));
            $this->end();

            return;
        }

        $this->deliver($bot);
        $bot->sendMessage(text: $this->settings()->text('thanks'), reply_markup: ReplyKeyboardRemove::make(true));
        $this->end();
    }

    /** What the client gets besides the thank-you (the price list for /price). */
    protected function deliver(Nutgram $bot): void {}

    protected function sendPrice(Nutgram $bot): void
    {
        try {
            app(PriceList::class)->sendTo($bot, $bot->chatId());
        } catch (Throwable $e) {
            Log::error('Price list could not be sent', ['error' => $e->getMessage()]);
            $bot->sendMessage(text: TelegramSettings::system('price_unavailable'));
        }
    }
}
