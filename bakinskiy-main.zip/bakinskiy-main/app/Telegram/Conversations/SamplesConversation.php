<?php

namespace App\Telegram\Conversations;

use App\Enums\LeadType;

class SamplesConversation extends LeadConversation
{
    protected function type(): LeadType
    {
        return LeadType::Sample;
    }

    /** Samples are sent to a venue, so we ask for its name. */
    protected function asksCompany(): bool
    {
        return true;
    }
}
