<?php

namespace App\Telegram\Conversations;

use App\Enums\LeadType;
use SergiX44\Nutgram\Nutgram;

class PriceConversation extends LeadConversation
{
    protected function type(): LeadType
    {
        return LeadType::Price;
    }

    protected function deliver(Nutgram $bot): void
    {
        $this->sendPrice($bot);
    }
}
