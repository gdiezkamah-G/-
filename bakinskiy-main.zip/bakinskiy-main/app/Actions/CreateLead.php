<?php

namespace App\Actions;

use App\Enums\LeadSource;
use App\Enums\LeadType;
use App\Jobs\SendLeadNotification;
use App\Models\Lead;
use App\Models\TelegramUser;
use App\Notifications\NewLeadNotification;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\RateLimiter;

/** One place that turns a validated request into a Lead and tells the managers. */
class CreateLead
{
    public const MAX_PER_MINUTE = 5;

    /**
     * @param  array{company?: ?string, contact_name: string, phone: string, product_id?: ?int, volume_kg?: ?int, comment?: ?string}  $data
     * @return Lead|null null when the sender made too many requests in the last minute
     */
    public function handle(array $data, LeadType $type, LeadSource $source = LeadSource::Site, ?TelegramUser $user = null): ?Lead
    {
        $key = 'lead-form:'.($user ? 'tg:'.$user->telegram_id : request()->ip());

        if (RateLimiter::tooManyAttempts($key, self::MAX_PER_MINUTE)) {
            return null;
        }

        RateLimiter::hit($key, 60);

        $lead = Lead::create([
            'company' => $data['company'] ?? null,
            'contact_name' => $data['contact_name'],
            'phone' => $data['phone'],
            'product_id' => $data['product_id'] ?? null,
            'volume_kg' => $data['volume_kg'] ?? null,
            'comment' => $data['comment'] ?? null,
            'type' => $type,
            'source' => $source,
            'telegram_user_id' => $user?->id,
        ]);

        // Neither of these may break the answer to the client: both run on the queue.
        SendLeadNotification::dispatch($lead)->afterCommit();
        Notification::route('mail', config('bakinsky.manager_email'))->notify(new NewLeadNotification($lead));

        return $lead;
    }
}
