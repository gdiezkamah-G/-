<?php

namespace App\Console\Commands;

use App\Enums\UserRole;
use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Validator;

use function Laravel\Prompts\password;
use function Laravel\Prompts\text;

class CreateAdmin extends Command
{
    protected $signature = 'app:create-admin
        {email? : Login e-mail}
        {--name= : Display name}
        {--role=admin : admin or manager}
        {--password= : Password (prefer the interactive prompt, it stays out of shell history)}';

    protected $description = 'Create or update a staff user for the /admin panel';

    public function handle(): int
    {
        $role = UserRole::tryFrom((string) $this->option('role'));

        if (! $role) {
            $this->error('Role must be "admin" or "manager".');

            return self::FAILURE;
        }

        $email = $this->argument('email') ?? text('E-mail', required: true);
        $name = $this->option('name') ?? text('Ім’я', default: 'Адміністратор', required: true);
        $password = $this->option('password') ?? password('Пароль (мін. 12 символів)', required: true);

        $validator = Validator::make(
            compact('email', 'name', 'password'),
            ['email' => 'required|email', 'name' => 'required|string|max:120', 'password' => 'required|string|min:12'],
        );

        if ($validator->fails()) {
            $this->error($validator->errors()->first());

            return self::FAILURE;
        }

        $user = User::firstOrNew(['email' => $email]);
        $existed = $user->exists;
        $user->forceFill(['name' => $name, 'password' => $password, 'role' => $role])->save();

        $this->info(($existed ? 'Updated ' : 'Created ')."{$role->value}: {$email}");

        return self::SUCCESS;
    }
}
