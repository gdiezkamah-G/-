<?php

namespace App\Console\Commands;

use App\Services\Deploy\Check;
use App\Services\Deploy\Doctor as DoctorService;
use Illuminate\Console\Command;

class Doctor extends Command
{
    protected $signature = 'app:doctor {--json : Machine-readable output} {--no-fail : Always exit 0 (used at container start)}';

    protected $description = 'Check the database, migrations, storage, queue, scheduler, Telegram, admin, price list and backups';

    public function handle(DoctorService $doctor): int
    {
        $checks = $doctor->run();

        if ($this->option('json')) {
            $this->line(json_encode(array_map(fn (Check $c) => $c->toArray(), $checks), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        } else {
            $this->table(['', 'Перевірка', 'Деталі'], array_map(fn (Check $c) => [$c->status, $c->name, $c->detail], $checks));
        }

        $failed = count(array_filter($checks, fn (Check $c) => $c->failed()));

        return $failed && ! $this->option('no-fail') ? self::FAILURE : self::SUCCESS;
    }
}
