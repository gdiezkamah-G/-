<?php

namespace App\Console\Commands;

use App\Jobs\WarmPriceList;
use App\Models\Category;
use App\Models\Product;
use App\Models\Setting;
use App\Models\TelegramAdmin;
use App\Services\Telegram\TelegramSettings;
use App\Services\Telegram\WebhookInstaller;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Laravel\Passport\Passport;
use Throwable;

/**
 * Everything a fresh or moved deployment needs, in one idempotent run (executed by the web container at start,
 * under a database lock, so two containers never do it at once). Only a failed migration stops the start.
 */
class Bootstrap extends Command
{
    protected $signature = 'app:bootstrap';

    protected $description = 'Idempotent first-run: migrate, admin, Telegram admins, catalog (only if empty), webhook, price list, queue restart';

    private const LOCK = 'bakinsky_bootstrap';

    public function handle(): int
    {
        $locked = $this->lock();

        try {
            if (! $this->step('Міграції', fn () => $this->migrate(), fatal: true)) {
                return self::FAILURE;
            }
            $this->step('Адмін із ADMIN_*', fn () => $this->admin());
            $this->step('Адміни Telegram із TELEGRAM_ADMIN_IDS', fn () => $this->telegramAdmins());
            $this->step('Каталог (лише якщо порожній)', fn () => $this->catalog());
            $this->step('Ключі OAuth для підключень ШІ (MCP)', fn () => $this->oauthKeys());
            $this->step('Telegram webhook, меню, команди', fn () => $this->webhook());
            $this->step('PDF-прайс', fn () => $this->price());
            $this->step('Перезапуск воркера', fn () => $this->restartWorker());

            Setting::put('bootstrap_at', (string) time());
        } finally {
            $locked && $this->unlock();
        }

        return self::SUCCESS;
    }

    /** @param  callable(): array{0: string, 1: string}  $fn  [state, message] */
    private function step(string $name, callable $fn, bool $fatal = false): bool
    {
        try {
            [$state, $message] = $fn();
        } catch (Throwable $e) {
            [$state, $message] = [$fatal ? 'FAIL' : 'WARN', $e->getMessage()];
        }

        $line = sprintf('[%s] %s: %s', $state, $name, $message);
        match ($state) {
            'FAIL' => $this->error($line),
            'WARN' => $this->warn($line),
            default => $this->line($line),
        };

        return $state !== 'FAIL';
    }

    private function migrate(): array
    {
        // a brand-new database has no migrations table yet
        $count = fn () => Schema::hasTable('migrations') ? DB::table('migrations')->count() : 0;
        $before = $count();
        $code = Artisan::call('migrate', ['--force' => true]);
        $after = $count();

        if ($code !== 0) {
            return ['FAIL', trim(Artisan::output())];
        }

        return ['OK', $after === $before ? "нових міграцій немає ({$after})" : 'застосовано '.($after - $before).' (усього '.$after.')'];
    }

    private function admin(): array
    {
        $code = Artisan::call('app:sync-admin');
        $out = trim(Artisan::output());

        if (! filled(config('bakinsky.admin.email')) || ! filled(config('bakinsky.admin.password'))) {
            return ['SKIP', 'ADMIN_EMAIL / ADMIN_PASSWORD не задано'];
        }

        return [$code === 0 ? 'OK' : 'WARN', $out ?: 'без змін'];
    }

    private function telegramAdmins(): array
    {
        $ids = config('bakinsky.telegram.admin_ids');

        if (! $ids) {
            return ['SKIP', 'TELEGRAM_ADMIN_IDS не задано'];
        }

        $added = 0;
        foreach ($ids as $id) {
            if (ctype_digit((string) $id) && (int) $id > 0 && ! TelegramAdmin::where('telegram_id', (int) $id)->exists()) {
                TelegramAdmin::create(['telegram_id' => (int) $id, 'name' => 'з TELEGRAM_ADMIN_IDS']);
                $added++;
            }
        }

        return ['OK', $added ? "додано {$added}" : 'усі вже є'];
    }

    private function catalog(): array
    {
        $mode = (string) config('bakinsky.catalog_import');

        if ($mode === 'off') {
            return ['SKIP', 'CATALOG_IMPORT=off'];
        }
        if (Product::count() > 0 || Category::count() > 0) {
            return ['SKIP', 'у базі вже є дані: нічого не чіпаю ('.Product::count().' товарів)'];
        }
        if (! is_file(database_path('data/products.json'))) {
            return ['WARN', 'немає database/data/products.json'];
        }

        $code = Artisan::call('app:import-products', $mode === 'publish' ? ['--publish' => true] : []);

        return [$code === 0 ? 'OK' : 'WARN', 'імпортовано '.Product::count().' товарів ('.($mode === 'publish' ? 'опубліковано' : 'чернетки').')'];
    }

    /** Passport signs the tokens of Claude / ChatGPT with a key pair. Generated once on the persistent volume, never overwritten. */
    private function oauthKeys(): array
    {
        if (filled(config('passport.private_key')) && filled(config('passport.public_key'))) {
            return ['SKIP', 'ключі задано змінними PASSPORT_PRIVATE_KEY / PASSPORT_PUBLIC_KEY'];
        }

        $dir = storage_path('app/oauth');

        if (is_file("{$dir}/oauth-private.key") && is_file("{$dir}/oauth-public.key")) {
            return ['SKIP', 'ключі вже є'];
        }

        @mkdir($dir, 0700, true);
        Passport::loadKeysFrom($dir);
        $code = Artisan::call('passport:keys', ['--force' => true]);
        @chmod("{$dir}/oauth-private.key", 0600);

        return $code === 0 && is_file("{$dir}/oauth-private.key") ? ['OK', 'ключі створено в storage/app/oauth'] : ['WARN', 'не вдалося створити ключі: '.trim(Artisan::output())];
    }

    private function webhook(): array
    {
        $result = app(WebhookInstaller::class)->ensure();

        return [match ($result['state']) {
            'installed', 'unchanged' => 'OK',
            'skipped' => 'SKIP',
            default => 'WARN',
        }, $result['message']];
    }

    private function price(): array
    {
        $price = app(TelegramSettings::class)->group('price');

        if ($price['mode'] !== 'auto' || ! filled(config('bakinsky.telegram.token')) || ! Product::where('status', 'published')->exists()) {
            return ['SKIP', 'не потрібно (є свій PDF, бот вимкнений або каталог без опублікованих товарів)'];
        }
        if (is_file(storage_path('app/private/telegram/price-list.pdf'))) {
            return ['SKIP', 'вже створений'];
        }

        WarmPriceList::dispatch();

        return ['OK', 'буде створено у фоні воркером'];
    }

    private function restartWorker(): array
    {
        Artisan::call('queue:restart');

        return ['OK', 'воркер підхопить новий код'];
    }

    private function lock(): bool
    {
        if (DB::connection()->getDriverName() !== 'mysql') {
            return false;
        }

        $got = DB::selectOne('SELECT GET_LOCK(?, 300) AS l', [self::LOCK])->l ?? 0;
        $got ? $this->line('[OK] Блокування бази отримано') : $this->warn('[WARN] Блокування не отримано за 300 с, продовжую без нього');

        return (bool) $got;
    }

    private function unlock(): void
    {
        DB::select('SELECT RELEASE_LOCK(?)', [self::LOCK]);
    }
}
