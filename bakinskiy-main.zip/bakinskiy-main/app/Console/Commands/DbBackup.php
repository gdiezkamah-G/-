<?php

namespace App\Console\Commands;

use App\Services\Deploy\BackupManager;
use Illuminate\Console\Command;
use Throwable;

class DbBackup extends Command
{
    protected $signature = 'app:db-backup {--keep= : Days to keep (default BACKUP_KEEP_DAYS, 14)} {--list : Only list the backups on the volume}';

    protected $description = 'Dump the database to a gzip file on the storage volume (and S3 when configured), rotate old ones';

    public function handle(BackupManager $backups): int
    {
        if ($this->option('list')) {
            $list = $backups->list();
            $list ? $this->table(['Файл', 'Розмір', 'Створено'], collect($list)->map(fn ($b) => [$b['file'], round($b['size'] / 1024).' КБ', date('d.m.Y H:i', $b['at'])])->all()) : $this->line('Бекапів немає.');

            return self::SUCCESS;
        }

        try {
            $r = $backups->run((int) ($this->option('keep') ?: config('bakinsky.backup.keep_days')));
        } catch (Throwable $e) {
            $this->error('Бекап не вдався: '.$e->getMessage());

            return self::FAILURE;
        }

        $this->info("Бекап: storage/app/backups/{$r['file']} ({$r['rows']} рядків, ".round($r['size'] / 1024).' КБ)');
        $r['removed'] && $this->line("Видалено старих: {$r['removed']}");

        if ($backups->s3()) {
            if ($r['s3']) {
                $this->info('Копію завантажено в S3.');
            } else {
                $this->error('Не вдалося завантажити в S3: '.$r['s3_error'].' (локальний бекап збережено).');

                return self::FAILURE;
            }
        }

        return self::SUCCESS;
    }
}
