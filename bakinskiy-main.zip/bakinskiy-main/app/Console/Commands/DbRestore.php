<?php

namespace App\Console\Commands;

use App\Services\Deploy\BackupManager;
use App\Services\Deploy\DatabaseDumper;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;
use Throwable;

class DbRestore extends Command
{
    protected $signature = 'app:db-restore {file=latest : "latest" (volume), "s3" (newest in the bucket), a file name on the volume, or a path} {--force : Do not ask for confirmation}';

    protected $description = 'Restore the database from a backup made by app:db-backup (replaces the current tables)';

    public function handle(BackupManager $backups, DatabaseDumper $dumper): int
    {
        try {
            $path = $backups->resolve($this->argument('file'));
        } catch (Throwable $e) {
            $this->error($e->getMessage());

            return self::FAILURE;
        }

        $this->warn("Буде замінено ВСІ дані в базі даними з {$path}.");

        if (! $this->option('force') && ! $this->confirm('Продовжити?')) {
            $this->line('Скасовано.');

            return self::FAILURE;
        }

        try {
            $n = $dumper->restore($path);
        } catch (Throwable $e) {
            $this->error('Відновлення не вдалося: '.$e->getMessage());

            return self::FAILURE;
        }

        // an older dump may lack the newest tables
        Artisan::call('migrate', ['--force' => true]);
        Artisan::call('queue:restart');
        $this->info("Відновлено ({$n} операцій). Міграції дозастосовано, воркер перезапущено.");

        return self::SUCCESS;
    }
}
