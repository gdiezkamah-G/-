<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Database\Migrations\Migrator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Throwable;

/** Workers must not start before the web container finished the migrations of this release. */
class WaitReady extends Command
{
    protected $signature = 'app:wait-ready {--timeout= : Seconds to wait (default DB_WAIT_SECONDS or 180)}';

    protected $description = 'Wait until the database answers and every migration has been applied';

    public function handle(Migrator $migrator): int
    {
        $timeout = $this->option('timeout') !== null ? (int) $this->option('timeout') : (int) env('DB_WAIT_SECONDS', 180);
        $deadline = time() + $timeout;
        $reason = 'база даних недоступна';

        do {
            try {
                DB::connection()->getPdo();

                if (! Schema::hasTable('migrations')) {
                    $reason = 'міграції ще не запускалися (чекаємо web-контейнер)';
                } else {
                    $pending = $this->pending($migrator);
                    if ($pending === 0) {
                        $this->info('Database ready, migrations applied.');

                        return self::SUCCESS;
                    }
                    $reason = "очікують {$pending} міграцій (чекаємо web-контейнер)";
                }
            } catch (Throwable $e) {
                $reason = 'база даних недоступна: '.$e->getMessage();
            }

            $this->line("Waiting: {$reason}");

            if (time() >= $deadline) {
                break;
            }

            sleep(3);
            // drop a half-open connection before retrying (never for an in-memory SQLite database: purging would erase it)
            DB::connection()->getDriverName() === 'sqlite' || DB::purge();
        } while (time() < $deadline);

        $this->error("Не дочекалися за {$timeout} с: {$reason}.");

        return self::FAILURE;
    }

    private function pending(Migrator $migrator): int
    {
        $repository = $migrator->getRepository();
        $ran = $repository->getRan();
        $files = $migrator->getMigrationFiles($migrator->paths() + [database_path('migrations')]);

        return count(array_diff(array_keys($files), $ran));
    }
}
