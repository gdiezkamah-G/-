<?php

namespace App\Console\Commands;

use App\Enums\UserRole;
use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Validator;

class SyncAdmin extends Command
{
    protected $signature = 'app:sync-admin
        {--reset-password : Overwrite the password of an existing admin with ADMIN_PASSWORD}';

    protected $description = 'Create the admin from ADMIN_EMAIL / ADMIN_NAME / ADMIN_PASSWORD (idempotent, runs on every deploy)';

    public function handle(): int
    {
        $cfg = config('bakinsky.admin');
        $email = trim((string) ($cfg['email'] ?? ''));
        $password = (string) ($cfg['password'] ?? '');

        // Not configured: nothing to do, and not an error.
        if ($email === '' || $password === '') {
            return self::SUCCESS;
        }

        $validator = Validator::make(
            ['email' => $email, 'password' => $password],
            ['email' => 'email', 'password' => 'min:12'],
        );

        // Messages never include the password value.
        if ($validator->fails()) {
            $this->error('ADMIN_* ignored: '.($validator->errors()->has('password')
                ? 'ADMIN_PASSWORD must be at least 12 characters.'
                : 'ADMIN_EMAIL is not a valid e-mail address.'));

            return self::FAILURE;
        }

        $reset = $this->option('reset-password') || filter_var($cfg['reset_password'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $user = User::where('email', $email)->first();

        if (! $user) {
            User::forceCreate([
                'email' => $email,
                'name' => trim((string) ($cfg['name'] ?? '')) ?: 'Admin',
                'password' => $password,
                'role' => UserRole::Admin,
            ]);
            $this->info("Admin created: {$email}");

            return self::SUCCESS;
        }

        if ($reset) {
            $user->forceFill(['password' => $password])->save();
            $this->info("Admin password reset: {$email}. Remove ADMIN_PASSWORD_RESET from the environment now.");

            return self::SUCCESS;
        }

        $this->line("Admin {$email} already exists, left unchanged.");

        return self::SUCCESS;
    }
}
