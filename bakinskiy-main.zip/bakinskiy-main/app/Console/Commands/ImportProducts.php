<?php

namespace App\Console\Commands;

use App\Enums\ProductStatus;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductVariant;
use Database\Seeders\CatalogSeeder;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use JsonException;

class ImportProducts extends Command
{
    protected $signature = 'app:import-products
        {--file=database/data/products.json : JSON file with categories and products}
        {--publish : Publish imported products (default: new products are drafts)}
        {--overwrite : Also overwrite fields that already have a value (e.g. edited in the admin)}
        {--remove-demo : Delete the demo products and categories created by the local seeder}';

    protected $description = 'Import categories, products and pack variants (idempotent: only empty fields are filled)';

    /** Pack tint per category, taken from the prototype hues. */
    private const HUES = [
        'lyulya-kebab' => '#7a3320',
        'dolma' => '#4f6234',
        'shaurma' => '#7a4a2a',
        'plov' => '#8a6420',
        'mlynci' => '#8a7448',
    ];

    private const DEFAULT_HUE = '#5a2a1c';

    /** Ingredient colour by keyword (first match wins); unknown names fall back to cycling PALETTE. */
    private const COLORS = [
        'курк' => '#d9d3c0', 'індич' => '#d9c9a8', 'телят' => '#a63d2a', 'яловичин' => '#a63d2a', 'баран' => '#8a3a2a',
        'м’яс' => '#a63d2a', 'жир' => '#e6dfc8', 'цибул' => '#e6dfc8', 'часник' => '#e6dfc8', 'сіль' => '#f0ece0',
        'перець чорн' => '#7a6a58', 'перець' => '#a63d2a', 'куркум' => '#e0a21a', 'шафран' => '#e0a21a',
        'виноград' => '#6b8a3a', 'кінза' => '#5d7a3a', 'зелен' => '#5d7a3a', 'коріандр' => '#5d7a3a',
        'рис' => '#e6dfc8', 'круп' => '#e6dfc8', 'борошн' => '#e6dfc8', 'масло' => '#e0c86a', 'яйц' => '#e0c86a',
        'молок' => '#d9d3c0', 'вод' => '#9fb4c0', 'морк' => '#d9822b', 'барбарис' => '#a63d2a', 'курага' => '#d6a24a',
        'родзинк' => '#7a3a4a', 'чорнослив' => '#6a3a4a', 'джем' => '#b0562f', 'горіх' => '#b08a5a', 'суміш' => '#c9b98a',
    ];

    private const PALETTE = ['#d9d3c0', '#c98a4b', '#8a9a4a', '#a63d2a', '#d6a24a', '#6b8a3a', '#e6dfc8', '#b0562f', '#7a3a4a', '#e0c86a'];

    private array $stats = [];

    public function handle(): int
    {
        $path = $this->resolvePath((string) $this->option('file'));

        if (! is_file($path)) {
            $this->error("File not found: {$path}");

            return self::FAILURE;
        }

        try {
            $data = json_decode(file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException $e) {
            $this->error('Invalid JSON: '.$e->getMessage());

            return self::FAILURE;
        }

        if (! is_array($data['categories'] ?? null) || ! is_array($data['products'] ?? null)) {
            $this->error('The file must contain "categories" and "products" arrays.');

            return self::FAILURE;
        }

        $this->stats = array_fill_keys(['categories', 'products', 'variants'], ['created' => 0, 'updated' => 0, 'skipped' => 0]);
        $errors = [];

        DB::transaction(function () use ($data, &$errors) {
            $categories = [];
            foreach ($data['categories'] as $row) {
                $categories[$row['slug']] = $this->importCategory($row);
            }

            $slugs = [];
            foreach ($data['products'] as $row) {
                $category = $categories[$row['category'] ?? ''] ?? Category::where('slug', $row['category'] ?? '')->first();

                if (! $category) {
                    $errors[] = "{$row['slug']}: unknown category \"".($row['category'] ?? '').'"';

                    continue;
                }

                $slugs[] = $row['slug'];
                $this->importProduct($row, $category);
            }

            if ($this->option('remove-demo')) {
                $this->removeDemo($slugs);
            }
        });

        $this->report($errors);

        return $errors ? self::FAILURE : self::SUCCESS;
    }

    private function importCategory(array $row): Category
    {
        $values = ['name' => $this->text($row['name'] ?? null), 'sort' => $row['sort'] ?? null];
        $category = Category::where('slug', $row['slug'])->first();

        if (! $category) {
            $this->stats['categories']['created']++;

            return Category::create(['slug' => $row['slug'], 'sort' => 0, ...array_filter($values, fn ($v) => $v !== null)]);
        }

        $this->touch('categories', $this->fill($category, $values));

        return $category;
    }

    private function importProduct(array $row, Category $category): void
    {
        $values = [
            'name' => $this->text($row['name'] ?? null),
            'subtitle' => $this->text($row['subtitle'] ?? null),
            'full_name' => $this->text($row['full_name'] ?? null),
            'composition' => $this->text($row['composition'] ?? null),
            'ingredients' => $this->ingredients($row['highlights'] ?? []),
            'storage_temp' => $this->text($row['storage_temp'] ?? null),
            'shelf_life' => $this->shelfLife($row['shelf_life_months'] ?? null),
            'hue' => self::HUES[$category->slug] ?? self::DEFAULT_HUE,
            // cooking_steps stays null: the block is hidden until a manager fills the steps in the admin.
            'cooking_steps' => $row['cooking_steps'] ?? null,
        ];
        $values = array_filter($values, fn ($v) => $v !== null && $v !== []);

        $product = Product::where('slug', $row['slug'])->first();

        if (! $product) {
            $product = Product::create([
                ...$values,
                'slug' => $row['slug'],
                'category_id' => $category->id,
                'sort' => $row['sort'] ?? 0,
                'status' => $this->option('publish') ? ProductStatus::Published : ProductStatus::Draft,
                // Only set on creation: a manager removes confirmed items, a re-run must not bring them back.
                'needs_confirmation' => array_map(fn ($t) => $this->text($t), $row['needs_confirmation'] ?? []) ?: null,
            ]);
            $this->stats['products']['created']++;
        } else {
            $this->fill($product, $values, save: false);

            if ($this->option('overwrite')) {
                $product->category_id = $category->id;
                $product->sort = $row['sort'] ?? $product->sort;
                $product->needs_confirmation = array_map(fn ($t) => $this->text($t), $row['needs_confirmation'] ?? []) ?: null;
            }

            if ($this->option('publish')) {
                $product->status = ProductStatus::Published;
            }

            $dirty = $product->isDirty();
            $dirty && $product->save();
            $this->touch('products', $dirty);
        }

        foreach (array_values($row['variants'] ?? []) as $i => $variant) {
            $this->importVariant($product, $variant, $i);
        }
    }

    private function importVariant(Product $product, array $row, int $index): void
    {
        $label = $this->text($row['size_label'] ?? null);

        // A position without a weight has no pack variant yet.
        if ($label === null || $label === '') {
            return;
        }

        $values = ['weight_g' => $row['weight_g'] ?? null, 'units' => $row['units'] ?? null, 'pack_note' => $this->text($row['pack_note'] ?? null)];
        $variant = ProductVariant::where('product_id', $product->id)->where('size_label', $label)->first();

        if (! $variant) {
            ProductVariant::create([
                ...array_filter($values, fn ($v) => $v !== null),
                'product_id' => $product->id,
                'size_label' => $label,
                'is_default' => (bool) ($row['is_default'] ?? false),
                'is_active' => true,
                'sort' => $index,
            ]);
            $this->stats['variants']['created']++;

            return;
        }

        $this->touch('variants', $this->fill($variant, $values));
    }

    /** @param  list<string>  $slugsInFile */
    private function removeDemo(array $slugsInFile): void
    {
        $products = Product::whereIn('slug', array_diff(CatalogSeeder::DEMO_PRODUCTS, $slugsInFile))->get();
        $products->each->delete();

        $categories = Category::whereIn('slug', CatalogSeeder::DEMO_CATEGORIES)->doesntHave('products')->get();
        $categories->each->delete();

        $this->info("Demo data removed: {$products->count()} products, {$categories->count()} categories.");
    }

    /**
     * Fill empty attributes (or all with --overwrite). Null values never overwrite anything.
     *
     * @param  array<string, mixed>  $values
     */
    private function fill(Model $model, array $values, bool $save = true): bool
    {
        foreach ($values as $attr => $value) {
            if ($value === null || $value === []) {
                continue;
            }

            if ($this->option('overwrite') || $this->isBlank($model->{$attr})) {
                $model->{$attr} = $value;
            }
        }

        if (! $model->isDirty()) {
            return false;
        }

        $save && $model->save();

        return true;
    }

    private function isBlank(mixed $v): bool
    {
        return $v === null || $v === '' || $v === [];
    }

    private function touch(string $entity, bool $changed): void
    {
        $this->stats[$entity][$changed ? 'updated' : 'skipped']++;
    }

    /** @return list<array{name: string, color: string}> */
    private function ingredients(array $names): array
    {
        $out = [];

        foreach (array_values($names) as $i => $name) {
            $name = $this->text($name);
            $out[] = ['name' => $name, 'color' => $this->colorFor($name, $i)];
        }

        return $out;
    }

    private function colorFor(string $name, int $index): string
    {
        $lower = mb_strtolower($name);

        foreach (self::COLORS as $keyword => $color) {
            if (str_contains($lower, $keyword)) {
                return $color;
            }
        }

        return self::PALETTE[$index % count(self::PALETTE)];
    }

    private function shelfLife(?int $months): ?string
    {
        if (! $months) {
            return null;
        }

        $word = match (true) {
            $months % 100 >= 11 && $months % 100 <= 14 => 'місяців',
            $months % 10 === 1 => 'місяць',
            in_array($months % 10, [2, 3, 4], true) => 'місяці',
            default => 'місяців',
        };

        return "{$months} {$word}";
    }

    /** Typographic apostrophe between letters, real minus before a number (−18 °C), like the rest of the site. */
    private function text(?string $s): ?string
    {
        if ($s === null) {
            return null;
        }

        $s = preg_replace("/(?<=\p{L})'(?=\p{L})/u", '’', $s);

        return trim(preg_replace('/^-(?=\d)/', '−', $s));
    }

    private function resolvePath(string $file): string
    {
        return Str::startsWith($file, ['/', '~']) ? $file : base_path($file);
    }

    private function report(array $errors): void
    {
        $this->newLine();
        $this->table(
            ['', 'created', 'updated', 'skipped'],
            collect($this->stats)->map(fn ($s, $k) => [$k, $s['created'], $s['updated'], $s['skipped']])->values()->all(),
        );

        foreach ($errors as $e) {
            $this->error($e);
        }

        $pending = Product::whereNotNull('needs_confirmation')->orderBy('sort')->get()->filter(fn ($p) => filled($p->needs_confirmation));

        if ($pending->isNotEmpty()) {
            $this->newLine();
            $this->warn('Потрібно уточнити ('.$pending->count().'):');
            foreach ($pending as $p) {
                $this->line("  {$p->slug}");
                foreach ($p->needs_confirmation as $note) {
                    $this->line("    - {$note}");
                }
            }
        }

        $this->newLine();
        $this->line($this->option('publish') ? 'Imported products are published.' : 'New products are drafts: publish them in the admin or re-run with --publish.');
    }
}
