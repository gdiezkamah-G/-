<?php

namespace App\Console\Commands;

use App\Models\TelegramAdmin;
use Illuminate\Console\Command;

class TelegramAddAdmin extends Command
{
    protected $signature = 'app:telegram-add-admin {telegram_id : Numeric Telegram user id} {--name= : Display name}';

    protected $description = 'Allow a Telegram user to run /connect and manage the bot (the first admin is added here)';

    public function handle(): int
    {
        $id = $this->argument('telegram_id');

        if (! ctype_digit((string) $id) || (int) $id <= 0) {
            $this->error('telegram_id must be a positive number (ask @userinfobot for yours).');

            return self::FAILURE;
        }

        $admin = TelegramAdmin::updateOrCreate(['telegram_id' => (int) $id], array_filter(['name' => $this->option('name')]));
        $this->info(($admin->wasRecentlyCreated ? 'Added' : 'Updated')." Telegram admin {$admin->telegram_id}".($admin->name ? " ({$admin->name})" : '').'.');

        return self::SUCCESS;
    }
}
