<?php

namespace App\Console\Commands;

use App\Services\Deploy\Check;
use App\Services\Deploy\EnvCheck;
use Illuminate\Console\Command;

class CheckEnv extends Command
{
    protected $signature = 'app:check-env {--quiet-ok : Print only warnings and failures}';

    protected $description = 'Check the environment variables (runs first on every container start; exit 1 when a required one is missing)';

    public function handle(): int
    {
        $checks = (new EnvCheck)->run();
        $failed = false;

        foreach ($checks as $c) {
            if ($c->status === Check::OK && $this->option('quiet-ok')) {
                continue;
            }
            $line = sprintf('[%s] %s%s', $c->status, $c->name, $c->detail ? ': '.$c->detail : '');
            match ($c->status) {
                Check::FAIL => $this->error($line),
                Check::WARN => $this->warn($line),
                default => $this->line($line),
            };
            $failed = $failed || $c->failed();
        }

        if ($failed) {
            $this->newLine();
            $this->error('Деплой зупинено: задайте обов’язкові змінні (див. .env.example і docs/08-deploy-and-migration.md).');

            return self::FAILURE;
        }

        return self::SUCCESS;
    }
}
