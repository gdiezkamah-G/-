<?php

namespace App\Console\Commands;

use App\Services\Telegram\BotMenu;
use App\Services\Telegram\WebhookInstaller;
use Illuminate\Console\Command;
use SergiX44\Nutgram\Nutgram;
use Throwable;

class TelegramSetWebhook extends Command
{
    protected $signature = 'app:telegram-set-webhook {--menu-only : Only the command list and the menu button}';

    protected $description = 'Register the Telegram webhook, the command list and the «Каталог» menu button';

    public function handle(BotMenu $menu, WebhookInstaller $installer): int
    {
        foreach (['bakinsky.telegram.token' => 'TELEGRAM_BOT_TOKEN', 'bakinsky.telegram.webhook_secret' => 'TELEGRAM_WEBHOOK_SECRET'] as $key => $env) {
            if (! filled(config($key))) {
                $this->error("{$env} is not set.");

                return self::FAILURE;
            }
        }

        if (! str_starts_with((string) config('app.url'), 'https://')) {
            $this->error('APP_URL must be https:// — Telegram only calls secure webhooks.');

            return self::FAILURE;
        }

        try {
            if ($this->option('menu-only')) {
                $menu->installMenu(app(Nutgram::class));
                $this->info('Commands and «Каталог» menu button installed → '.rtrim((string) config('app.url'), '/').'/tg');
            } else {
                $result = $installer->ensure(force: true);
                if ($result['state'] === 'failed') {
                    throw new \RuntimeException($result['message']);
                }
                $this->info('Webhook: '.$menu->webhookUrl());
                $this->info('Commands and «Каталог» menu button installed → '.rtrim((string) config('app.url'), '/').'/tg');
            }
        } catch (Throwable $e) {
            $this->error('Telegram refused: '.$e->getMessage());

            return self::FAILURE;
        }

        return self::SUCCESS;
    }
}
