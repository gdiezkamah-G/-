<?php

namespace App\Notifications;

use App\Models\Lead;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

/** E-mail copy for MANAGER_EMAIL. Telegram recipients are handled by SendLeadNotification. */
class NewLeadNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public Lead $lead) {}

    public function via(object $notifiable): array
    {
        return config('bakinsky.manager_email') ? ['mail'] : [];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $l = $this->lead->loadMissing('product');

        return (new MailMessage)
            ->subject($l->type->getLabel().': '.($l->company ?: $l->contact_name))
            ->line(implode("\n", array_filter([
                'Заклад: '.($l->company ?: '—'),
                "Контакт: {$l->contact_name}, {$l->phone}",
                'Позиція: '.($l->product?->name ?? 'Кілька позицій'),
                $l->volume_kg ? "Обсяг: {$l->volume_kg} кг" : null,
                $l->comment ? "Коментар: {$l->comment}" : null,
                'Джерело: '.$l->source->getLabel(),
            ])));
    }
}
