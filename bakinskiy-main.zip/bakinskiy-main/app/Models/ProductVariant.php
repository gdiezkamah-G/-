<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProductVariant extends Model
{
    protected $fillable = ['product_id', 'sku', 'price', 'currency', 'availability', 'size_label', 'weight_g', 'units', 'pack_note', 'pack_type', 'is_default', 'is_active', 'sort'];

    protected function casts(): array
    {
        return ['price' => 'integer', 'is_active' => 'boolean', 'is_default' => 'boolean'];
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}
