<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class McpAuditLog extends Model
{
    public const UPDATED_AT = null;

    protected $table = 'mcp_audit_log';

    protected $guarded = [];

    protected function casts(): array
    {
        return ['input' => 'array', 'changes' => 'array', 'writes' => 'boolean'];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function revision(): HasOne
    {
        return $this->hasOne(ProductRevision::class, 'audit_id');
    }
}
