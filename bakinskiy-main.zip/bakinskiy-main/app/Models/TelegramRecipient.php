<?php

namespace App\Models;

use App\Enums\LeadType;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class TelegramRecipient extends Model
{
    protected $fillable = ['chat_id', 'title', 'type', 'active', 'lead_types'];

    protected function casts(): array
    {
        return ['active' => 'boolean', 'lead_types' => 'array'];
    }

    public function scopeActive(Builder $query): void
    {
        $query->where('active', true);
    }

    /** Empty lead_types means "every type". */
    public function wants(LeadType $type): bool
    {
        $types = $this->lead_types ?? [];

        return $types === [] || in_array($type->value, $types, true);
    }
}
