<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** Where a lead notification was posted, so a status change can edit every copy. */
class TelegramLeadMessage extends Model
{
    protected $fillable = ['lead_id', 'chat_id', 'message_id'];

    public function lead(): BelongsTo
    {
        return $this->belongsTo(Lead::class);
    }
}
