<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TelegramAdmin extends Model
{
    protected $fillable = ['telegram_id', 'name'];

    public static function isAdmin(?int $telegramId): bool
    {
        return $telegramId !== null && static::where('telegram_id', $telegramId)->exists();
    }
}
