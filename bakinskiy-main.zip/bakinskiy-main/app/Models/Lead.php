<?php

namespace App\Models;

use App\Enums\LeadSource;
use App\Enums\LeadStatus;
use App\Enums\LeadType;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Lead extends Model
{
    protected $fillable = [
        'company', 'contact_name', 'phone', 'product_id', 'volume_kg', 'comment',
        'type', 'source', 'status', 'manager_id', 'telegram_user_id', 'handled_by', 'handled_at', 'notes',
    ];

    protected function casts(): array
    {
        return [
            'type' => LeadType::class,
            'source' => LeadSource::class,
            'handled_at' => 'datetime',
            'status' => LeadStatus::class,
        ];
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function telegramMessages(): HasMany
    {
        return $this->hasMany(TelegramLeadMessage::class);
    }

    public function telegramUser(): BelongsTo
    {
        return $this->belongsTo(TelegramUser::class);
    }

    public function manager(): BelongsTo
    {
        return $this->belongsTo(User::class, 'manager_id');
    }
}
