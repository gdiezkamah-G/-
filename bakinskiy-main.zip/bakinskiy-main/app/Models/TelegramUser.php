<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Laravel\Sanctum\HasApiTokens;

class TelegramUser extends Model
{
    use HasApiTokens;

    protected $fillable = ['telegram_id', 'first_name', 'last_name', 'username', 'language_code', 'phone', 'company', 'last_seen_at'];

    protected function casts(): array
    {
        return ['last_seen_at' => 'datetime'];
    }

    public function leads(): HasMany
    {
        return $this->hasMany(Lead::class);
    }

    public function getFullNameAttribute(): string
    {
        return trim($this->first_name.' '.$this->last_name) ?: ($this->username ? '@'.$this->username : (string) $this->telegram_id);
    }

    /** A user we already have a phone for does not have to share it again. */
    public function getIsKnownAttribute(): bool
    {
        return filled($this->phone);
    }
}
