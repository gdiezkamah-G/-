<?php

namespace App\Models;

use App\Enums\ProductStatus;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Product extends Model
{
    protected $fillable = [
        'category_id', 'name', 'subtitle', 'full_name', 'composition', 'needs_confirmation', 'slug', 'short_tagline', 'description', 'hue',
        'ingredients', 'cooking_steps', 'cooking_summary', 'packaging', 'shelf_life',
        'storage_temp', 'status', 'sort',
    ];

    protected function casts(): array
    {
        return [
            'ingredients' => 'array',
            'cooking_steps' => 'array',
            'needs_confirmation' => 'array',
            'status' => ProductStatus::class,
        ];
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function variants(): HasMany
    {
        return $this->hasMany(ProductVariant::class)->orderBy('sort');
    }

    public function activeVariants(): HasMany
    {
        return $this->variants()->where('is_active', true);
    }

    public function scopePublished(Builder $query): void
    {
        $query->where('status', ProductStatus::Published)->orderBy('sort');
    }

    public function getRouteKeyName(): string
    {
        return 'slug';
    }

    /** Size label shown on the pack and in cards: the variant flagged as default, else the first active one. */
    public function getPackLabelAttribute(): string
    {
        $variants = $this->activeVariants;

        return ($variants->firstWhere('is_default', true) ?? $variants->first())?->size_label ?? '';
    }

    public function getHasStepsAttribute(): bool
    {
        return filled($this->cooking_steps);
    }

    /** Text for the Склад row: the full composition when known, else the highlighted ingredient names. */
    public function getCompositionTextAttribute(): string
    {
        return filled($this->composition)
            ? $this->composition
            : collect($this->ingredients ?? [])->pluck('name')->implode(', ');
    }

    /** Meat base for the catalog filter, derived from the name and composition (a dish can have several). */
    public function getBasesAttribute(): array
    {
        $text = mb_strtolower($this->name.' '.$this->subtitle.' '.$this->full_name.' '.$this->composition_text);
        $map = ['курка' => ['курк'], 'телятина' => ['телят', 'яловичин'], 'баранина' => ['баран'], 'індичка' => ['індич']];
        $found = [];

        foreach ($map as $label => $needles) {
            foreach ($needles as $needle) {
                if (str_contains($text, $needle)) {
                    $found[] = $label;
                    break;
                }
            }
        }

        $meat = str_contains($text, 'м’яс') || str_contains($text, "м'яс") || str_contains($text, 'фарш');

        return $found ?: ($meat ? [] : ['без м’яса']);
    }

    /** Lower-cased text the app catalog search looks in. */
    public function getSearchTextAttribute(): string
    {
        return mb_strtolower(trim($this->name.' '.$this->subtitle.' '.$this->full_name));
    }

    /** Minutes of the first step that has a timer (shown in the stats row). */
    public function getCookMinutesAttribute(): int
    {
        foreach ($this->cooking_steps ?? [] as $step) {
            if (! empty($step['minutes'])) {
                return (int) $step['minutes'];
            }
        }

        return 0;
    }
}
