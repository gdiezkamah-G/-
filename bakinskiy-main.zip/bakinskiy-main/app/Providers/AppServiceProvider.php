<?php

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Foundation\Events\DiagnosingHealth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;
use Laravel\Mcp\Server\Registrar;
use Laravel\Passport\Passport;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Absolute URLs (canonical, sitemap, Open Graph, JSON-LD) always use the main domain from APP_URL,
        // never whatever Host header the request came with.
        if (filled(config('app.url'))) {
            URL::forceRootUrl(config('app.url'));
        }

        if (str_starts_with((string) config('app.url'), 'https://')) {
            URL::forceScheme('https');
        }

        $this->mcp();

        // /up answers 200 only when the app boots and the database responds.
        Event::listen(DiagnosingHealth::class, function () {
            DB::select('select 1');

            // queue, cache and sessions live in Redis: a container that cannot reach it is not ready
            if (config('cache.default') === 'redis') {
                Cache::store('redis')->get('health');
            }
        });
    }

    /** OAuth for the MCP connectors (Claude, ChatGPT) and the rate limit of /mcp. */
    private function mcp(): void
    {
        // Keys live on the persistent volume (storage/app is the only one that survives a redeploy and is shared by web and queue).
        Passport::loadKeysFrom(storage_path('app/oauth'));
        Passport::tokensCan(Registrar::ensureMcpScope());
        Passport::tokensExpireIn(now()->addDays(7));
        Passport::refreshTokensExpireIn(now()->addDays(60));
        Passport::authorizationView('mcp.authorize');

        RateLimiter::for('mcp', fn (Request $request) => Limit::perMinute(90)->by($request->user()?->getAuthIdentifier() ?: $request->ip()));
    }
}
