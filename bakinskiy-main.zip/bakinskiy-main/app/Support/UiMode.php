<?php

namespace App\Support;

use Illuminate\Http\Request;

/**
 * Which layout a visitor gets: the phone "app" shell or the desktop site.
 *
 * Order of precedence: explicit choice (cookie ui_pin) > last client decision (cookie ui) > User-Agent guess.
 * The client script in <head> re-checks the real viewport width before the first paint and reloads once if the
 * server guessed wrong, so the guess only matters for the very first request.
 */
class UiMode
{
    public const APP = 'app';

    public const FULL = 'full';

    public static function resolve(Request $request): string
    {
        foreach (['ui_pin', 'ui'] as $cookie) {
            $value = $request->cookie($cookie);

            if (in_array($value, [self::APP, self::FULL], true)) {
                return $value;
            }
        }

        return preg_match('/Android.+Mobile|iPhone|iPod|Windows Phone|Mobile.+Firefox|webOS|BlackBerry/i', (string) $request->userAgent())
            ? self::APP
            : self::FULL;
    }

    public static function isApp(Request $request): bool
    {
        return self::resolve($request) === self::APP;
    }
}
