<?php

namespace App\Support;

use Illuminate\Support\Facades\Cache;

/**
 * The document CSS (tokens + bundle) with fonts and ornaments inlined as data URIs, so a PDF renders
 * with no network and no file:// access. Source files are the handoff pack in resources/documents.
 */
class DocumentCss
{
    public static function inlined(): string
    {
        $dir = resource_path('documents');
        $stamp = max(filemtime("$dir/tokens.css"), filemtime("$dir/bundle.css"));

        return Cache::store('array')->rememberForever("document-css.$stamp", function () use ($dir) {
            $css = file_get_contents("$dir/tokens.css")."\n".file_get_contents("$dir/bundle.css");

            return preg_replace_callback('/url\((fonts|assets)\/([^)]+)\)/', function ($m) use ($dir) {
                $file = "$dir/{$m[1]}/{$m[2]}";
                if (! is_file($file)) {
                    return $m[0];
                }
                $mime = str_ends_with($file, '.woff2') ? 'font/woff2' : 'image/svg+xml';

                return 'url(data:'.$mime.';base64,'.base64_encode(file_get_contents($file)).')';
            }, $css);
        });
    }

    public static function image(string $name): string
    {
        $file = resource_path("documents/assets/$name");

        return 'data:image/svg+xml;base64,'.base64_encode(file_get_contents($file));
    }
}
