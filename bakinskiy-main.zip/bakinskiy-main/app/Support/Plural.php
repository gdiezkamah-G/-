<?php

namespace App\Support;

class Plural
{
    /** Ukrainian plural form: [1 позиція, 2 позиції, 5 позицій]. */
    public static function uk(int $n, array $forms): string
    {
        $mod100 = $n % 100;
        $mod10 = $n % 10;

        return match (true) {
            $mod100 >= 11 && $mod100 <= 14 => $forms[2],
            $mod10 === 1 => $forms[0],
            $mod10 >= 2 && $mod10 <= 4 => $forms[1],
            default => $forms[2],
        };
    }
}
