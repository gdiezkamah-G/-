<?php

namespace App\Support;

use InvalidArgumentException;

/**
 * Validates Telegram Mini App `initData` (https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app).
 */
class TelegramInitData
{
    public const MAX_AGE = 86400; // 24 h

    /**
     * @return array{user: array, auth_date: int, start_param: ?string}
     *
     * @throws InvalidArgumentException when the signature is wrong, missing or the data is too old
     */
    public static function validate(string $initData, ?string $botToken, int $maxAge = self::MAX_AGE, ?int $now = null): array
    {
        if (! filled($botToken)) {
            throw new InvalidArgumentException('Bot token is not configured.');
        }

        parse_str($initData, $fields);
        $hash = $fields['hash'] ?? null;
        unset($fields['hash']);

        if (! is_string($hash) || $fields === []) {
            throw new InvalidArgumentException('initData is malformed.');
        }

        ksort($fields);
        $check = collect($fields)->map(fn ($v, $k) => "$k=$v")->implode("\n");
        $secret = hash_hmac('sha256', $botToken, 'WebAppData', true);

        if (! hash_equals(hash_hmac('sha256', $check, $secret), strtolower($hash))) {
            throw new InvalidArgumentException('initData signature is invalid.');
        }

        $authDate = (int) ($fields['auth_date'] ?? 0);
        $now ??= time();

        if ($authDate <= 0 || $now - $authDate > $maxAge || $authDate - $now > 300) {
            throw new InvalidArgumentException('initData is expired.');
        }

        $user = json_decode($fields['user'] ?? '', true);

        if (! is_array($user) || empty($user['id'])) {
            throw new InvalidArgumentException('initData has no user.');
        }

        return ['user' => $user, 'auth_date' => $authDate, 'start_param' => $fields['start_param'] ?? null];
    }

    /** Test/helper: build a correctly signed initData string. */
    public static function sign(array $fields, string $botToken): string
    {
        ksort($fields);
        $check = collect($fields)->map(fn ($v, $k) => "$k=$v")->implode("\n");
        $fields['hash'] = hash_hmac('sha256', $check, hash_hmac('sha256', $botToken, 'WebAppData', true));

        return http_build_query($fields);
    }
}
