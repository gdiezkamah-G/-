# Завдання 1C: додаткові сторінки сайту

Прочитай CLAUDE.md і docs/04-pages.md (розділ «Додаткові сторінки»). Відкрий reference/prototype.html у Playwright
(маршрути #horeca, #vyrobnytstvo, #kontakty) і скриншоти reference/screens/page-*.

Реалізуй три сторінки один в один: /horeca, /vyrobnytstvo, /kontakty. Повторно використовуй вже готові компоненти
(page-header, cta-band, process-timeline, macro-statement, форма заявки), нові Blade-компоненти: benefit-grid, audience-chips,
flow-steps, faq, story, principles, contact-info, map-placeholder.

- Оновити меню в шапці та футер (як у прототипі).
- Контактні дані, FAQ, історія, принципи: з Setting/БД (редагуються у Filament), умовні значення з прототипу як сідери.
- Вбудована форма на /kontakty використовує ту саму Livewire-логіку й модель Lead, що й модалка.
- SEO: title/description/Open Graph для кожної сторінки, додати в sitemap.
- Pest-тести: сторінки 200, форма на /kontakty валідується і створює Lead.
- Скриншоти 1366 і 400 px порівняти з еталоном, розбіжності виправити.
Дизайн не змінювати. Коміти дрібні. У кінці звіт.
