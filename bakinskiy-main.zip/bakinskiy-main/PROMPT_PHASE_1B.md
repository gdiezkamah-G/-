# Завдання 1B: деплой на Dokploy і хвости фази 1

Прочитай CLAUDE.md і свій звіт по фазі 1. Репозиторій уже в GitHub (main). Дизайн не змінюємо.

1. Деплой:
   - Production Dockerfile (multi-stage: збірка Vite і composer --no-dev, потім php-fpm + nginx
     в одному образі або зв'язка docker-compose для Dokploy; обери простіше і поясни вибір).
   - Healthcheck endpoint /up і healthcheck у контейнері.
   - Міграції та кешування (config, route, view) при старті.
   - Queue-воркер і scheduler окремими процесами або сервісами.
   - Змінні оточення описати в .env.example і README (APP_URL, DB, Redis, MAIL_*,
     MANAGER_EMAIL, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID).
   - Сховище завантажень (storage:link) і права на теки.
2. Безпека адмінки: доступ у /admin тільки для ролей admin і manager (просте поле role, без
   пакета). Прибрати пароль за замовчуванням із сідера для production. Artisan-команда
   для створення адміна.
3. Фасовка на паку: на сторінці товару вага на паку слідує за обраним чіпом, у каталозі
   вага фасовки за замовчуванням (поле is_default у варіанта).
4. SEO і канали: sitemap.xml, robots.txt, мета та Open Graph на трьох сторінках,
   JSON-LD Product (без ціни, поки режим «за запитом»).
5. Тести: доступ у /admin і health endpoint. Pest і Pint проходять.

Коміти дрібні, по пунктах. У кінці звіт: що зроблено, що потрібно від мене
(домен, змінні оточення), як задеплоїти на Dokploy покроково.
